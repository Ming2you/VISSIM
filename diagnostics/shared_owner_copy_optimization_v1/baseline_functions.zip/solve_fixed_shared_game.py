def solve_fixed_shared_game(follower, state, reference, forecast, incumbent, *,
                            callbacks, context, context_fingerprint, horizon_steps,
                            lambda_p, lambda_uf, target_np_veh, target_nuf_veh_h,
                            price_context, max_sweeps, max_evaluations, time_budget_sec,
                            improvement_tolerance, shared_tolerance, scope_label,
                            np_tolerance_veh, nuf_tolerance_veh_h):
    """Select a realized joint action at one explicit fixed leader/price context.

    Uses the installed neighbor/writer callbacks and the same captured physical
    trajectory for all 19 local payoffs, accepted quantities and implemented
    model constraints. Repeated whole actions are reused only within this solve.
    No refresh of prices/duals, late lever refinement or legacy dispatch occurs.
    The returned finite certificate is conditional on the implemented model;
    it does not certify native VISSIM capacity fidelity or a price fixed point.

    The caller must bind source, mapping, writer, candidate and operational
    context in context_fingerprint. Callback construction/initial realization
    happens before this timed solve. Time limits are cooperative and incomplete
    owner checks keep null gaps. No uncounted endpoint runs occur after a stop.
    """
    import copy
    import hashlib
    import pickle
    from time import perf_counter
    from evaluation.controllers import joint_owner_game as game
    from evaluation.controllers.area_leader_objective import fixed_joint_price_terms, shared_quantity_constraints

    required = {'ownership', 'neighbors', 'physical_fingerprint', 'physical_rows', 'command_evidence'}
    if not isinstance(callbacks, dict) or not required.issubset(callbacks):
        raise ValueError('Installed joint neighbor/writer callbacks required')
    owners = callbacks['ownership'].owners
    if (len(owners) != 19 or set(owners) != set(follower.cfg.network.signals)
            | set(follower.cfg.network.freeway_links)):
        raise ValueError('Fixed shared game requires every configured 19 owner')
    if type(horizon_steps) is not int or horizon_steps < 1:
        raise ValueError('Explicit positive held horizon required')
    private, initial, anchor, demand, policy = copy.deepcopy(
        (follower, state, reference, forecast, price_context))
    def packed(value):
        return pickle.dumps(value, protocol=5)
    def token(value):
        return hashlib.sha256(packed(value)).hexdigest()
    fixed = packed((private, initial, anchor, demand, policy,
                    lambda_p, lambda_uf, target_np_veh, target_nuf_veh_h, horizon_steps,
                    np_tolerance_veh, nuf_tolerance_veh_h))
    external_token = context_fingerprint(context)
    if type(external_token) not in (str, bytes) or not external_token:
        raise ValueError('Explicit full context fingerprint required')
    def fingerprint(supplied):
        if packed((private, initial, anchor, demand, policy,
                   lambda_p, lambda_uf, target_np_veh, target_nuf_veh_h, horizon_steps,
                   np_tolerance_veh, nuf_tolerance_veh_h)) != fixed:
            raise ValueError('Private fixed game inputs changed')
        observed = context_fingerprint(supplied)
        if observed != external_token:
            raise ValueError('External fixed game context changed')
        return token((external_token, fixed))

    cache = {}
    batch_context_token = None
    stats = {'requests': 0, 'endpoint_calls': 0, 'cache_hits': 0,
             'endpoint_sec': 0., 'local_score_sec': 0., 'price_sec': 0., 'query_sec': 0.}
    def command_query(callback, action, supplied):
        trial = copy.deepcopy(action)
        before = packed(trial)
        with shared_query_runtime_scope():
            value = callback(trial, supplied)
        if packed(trial) != before:
            raise ValueError('Command serialization changed its supplied full action')
        fingerprint(supplied)
        return value
    def evaluate(owner, action, supplied):
        nonlocal batch_context_token
        fingerprint(supplied)
        stats['requests'] += 1
        key = packed(action)
        if key not in cache:
            tick = perf_counter()
            batch = evaluate_shared_owner_batch(private, initial, anchor, demand,
                                                (action,), horizon_steps=horizon_steps)
            stats['query_sec'] += perf_counter() - tick
            stats['endpoint_calls'] += batch['endpoint_calls']
            stats['endpoint_sec'] += batch['endpoint_sec']
            stats['local_score_sec'] += batch['score_sec']
            item = batch['results'][0]
            if item['action_token'] != hashlib.sha256(key).hexdigest():
                raise ValueError('Shared response is bound to another full action')
            if batch_context_token is None:
                batch_context_token = item['frozen_context_token']
            elif batch_context_token != item['frozen_context_token']:
                raise ValueError('Candidate queries used different fixed model inputs')
            if set(item['local_base_costs']) != set(owners):
                raise ValueError('Incomplete common-response local payoff catalog')
            tick = perf_counter()
            with shared_query_runtime_scope():
                additions = fixed_joint_price_terms(private, action, item['quantities'],
                    lambda_p=lambda_p, lambda_uf=lambda_uf, target_np_veh=target_np_veh,
                    target_nuf_veh_h=target_nuf_veh_h, price_context=policy)
            if set(additions['owners']) != set(owners):
                raise ValueError('Incomplete fixed-price owner catalog')
            costs = {who: float(item['local_base_costs'][who] + additions['owners'][who]['total'])
                     for who in owners}
            if not all(math.isfinite(value) for value in costs.values()):
                raise ValueError('Nonfinite fixed-game owner payoff')
            quantity_constraints = shared_quantity_constraints(private, action, item['quantities'],
                np_mode=policy['np_mode'], target_np_veh=target_np_veh,
                np_tolerance_veh=np_tolerance_veh, nuf_mode=policy['nuf_mode'],
                target_nuf_veh_h=target_nuf_veh_h, nuf_tolerance_veh_h=nuf_tolerance_veh_h,
                start_sec=initial.time_sec, horizon_steps=horizon_steps)
            fingerprint(supplied)
            item.update(owner_costs=costs, additive_terms=additions, quantity_constraints=quantity_constraints,
                        physical_owner_tokens=command_query(callbacks['physical_fingerprint'], action, supplied))
            cache[key] = packed(item)
            stats['price_sec'] += perf_counter() - tick
        else:
            stats['cache_hits'] += 1
        item = pickle.loads(cache[key])
        coverage = item.get('model_constraint_coverage')
        witnessed = (item.get('conditional_model_feasibility_witness') is True
                     and isinstance(coverage, dict) and coverage.get('complete') is True)
        violation = item['resource_summary']['max_exceedance_veh']
        feasible = witnessed and violation <= shared_tolerance and item['quantity_constraints']['feasible'] is True
        reason = None
        if not witnessed:
            reason = 'Implemented model constraint coverage is incomplete'
        elif violation > shared_tolerance:
            reason = 'Accepted allocation exceeds an implemented model limit'
        elif not item['quantity_constraints']['feasible']:
            reason = 'Frozen leader quantity constraint violated: ' + repr(item['quantity_constraints'])
        return game.Evaluation(feasible=feasible,
            cost=item['owner_costs'][owner], shared_violation=violation,
            witness_complete=witnessed, reason=reason)

    started = perf_counter()
    result = game.solve(callbacks['ownership'], incumbent, context,
        neighbors=callbacks['neighbors'], evaluate=evaluate,
        context_fingerprint=fingerprint, physical_fingerprint=callbacks['physical_fingerprint'],
        max_sweeps=max_sweeps, max_evaluations=max_evaluations, time_budget_sec=time_budget_sec,
        improvement_tolerance=improvement_tolerance, shared_tolerance=shared_tolerance,
        scope_label=scope_label, nuf_semantics='realized_sum')
    stats['solve_wall_sec'] = perf_counter() - started
    stats['retained_result_bytes'] = sum(len(key) + len(value) for key, value in cache.items())
    final = result['control']
    final_score = pickle.loads(cache[packed(final)]) if packed(final) in cache else None
    # These are serialization-only checks. Never rescore an unvisited final
    # incumbent or change a command after the cooperative game deadline.
    fingerprint(context)
    physical = command_query(callbacks['physical_fingerprint'], final, context)
    evidence = command_query(callbacks['command_evidence'], final, context)
    if final_score is not None and physical != final_score['physical_owner_tokens']:
        raise ValueError('Final written command differs from the scored full action')
    fingerprint(context)
    return {'game': result, 'final_score': final_score, 'command_evidence': evidence,
            'queries': stats, 'fixed_inputs_token': hashlib.sha256(fixed).hexdigest(),
            'final_action_token': token(final),
            'price_refresh_performed': False, 'leader_or_dual_update_performed': False,
            'native_plant_feasibility_certified': False,
            'shared_violation_scalar_scope': 'Traffic allocation exceedance in vehicles; leader NP/NUF residuals and tolerances are reported separately in final_score.quantity_constraints',
            'scope': 'Finite fixed-price 19-owner selection conditional on implemented model constraints; no native or price-fixed-point certificate'}
