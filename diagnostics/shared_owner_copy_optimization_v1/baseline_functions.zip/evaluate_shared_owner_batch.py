def evaluate_shared_owner_batch(follower, state, reference, forecast, candidates, *, horizon_steps):
    """Evaluate exact full-action repeats once in a single private query batch.

    This is the common physical response used for local costs and matched
    external-cost probes. No optimizer, price refresh, COM, or cross-batch cache
    runs here. The full action is the cache key: physical aliases are NOT merged
    before their model/price equivalence has been proved. Only compact scored
    results are retained; large trajectories are released after each query.

    Follower/config, initial state, reference and demand are private copies.
    Adapter diagnostic accumulators are restored on success and failure. This
    does not certify arbitrary concurrent module-hook replacement or all shared
    capacities; runtime installation must finish before invoking this function.
    """
    import copy
    import hashlib
    import pickle
    from collections import Counter
    from time import perf_counter
    from evaluation.controllers import vissim_stackelberg_adapter as adapter
    from evaluation.controllers.area_leader_objective import shared_urban_quantities
    from src.controllers import rollout_endpoint

    if type(horizon_steps) is not int or horizon_steps < 1:
        raise ValueError('Explicit positive held horizon required')
    if not enabled(follower.cfg):
        raise ValueError('Shared owner batch requires the Omega endpoint')
    private, initial, anchor, demand, actions = copy.deepcopy(
        (follower, state, reference, forecast, tuple(candidates)))
    if not actions:
        raise ValueError('A shared owner batch must contain candidates')
    # Pickle is a process-local exact-value key, not a portable content hash.
    def packed(value):
        return pickle.dumps(value, protocol=5)
    frozen = packed((private, initial, anchor, demand))
    token = hashlib.sha256(frozen).hexdigest()
    diagnostics = {key: (value, copy.deepcopy(value)) for key, value in vars(adapter).items()
                   if key.endswith('_LAST') and isinstance(value, dict)}
    def restore_diagnostics():
        for name in tuple(vars(adapter)):
            value = getattr(adapter, name)
            if name.endswith('_LAST') and isinstance(value, dict) and name not in diagnostics:
                delattr(adapter, name)
        for name, (original, before) in diagnostics.items():
            original.clear()
            original.update(copy.deepcopy(before))
            setattr(adapter, name, original)
    cache, results = {}, []
    endpoint_sec = score_sec = 0.0
    try:
        for action in actions:
            key = packed(action)
            if key in cache:
                # Unpickle prevents aliases between separate returned requests.
                results.append(pickle.loads(cache[key]))
                continue
            restore_diagnostics()
            tick = perf_counter()
            with shared_query_runtime_scope():
                point = rollout_endpoint.evaluate_price_point(initial, action, demand, (),
                    rollout_endpoint.ObjectiveSpec(private.cfg, depth_override=horizon_steps,
                        box_walk=False, score_mode='raw'), capture_response=True)
            endpoint_sec += perf_counter() - tick
            if point.aborted or len(point.states) != horizon_steps:
                raise ValueError('Incomplete shared endpoint is not cacheable')
            tick = perf_counter()
            with shared_query_runtime_scope():
                local = score_shared_owner_point(private, point, initial, action, anchor,
                                                 horizon_steps=horizon_steps)
            response = point.control_area_response
            quantities = shared_urban_quantities(private, response,
                start_sec=initial.time_sec, horizon_steps=horizon_steps)
            if packed(action) != key or packed((private, initial, anchor, demand)) != frozen:
                raise ValueError('Shared query mutated its frozen operands')
            resources = response['resource_allocations']
            value = {'objective_veh_h': float(point.objective),
                'local_base_costs': {owner: row['cost'] for owner, row in local.items()},
                'local_costs': local, 'quantities': quantities,
                'control_area': copy.deepcopy(point.control_area),
                'response_token': hashlib.sha256(packed(response)).hexdigest(),
                'action_token': hashlib.sha256(key).hexdigest(),
                'frozen_context_token': token,
                'price_or_quantity_terms_included': False,
                'shared_capacity_certificate': False,
                'model_constraint_coverage': copy.deepcopy(response.get('model_constraint_coverage')),
                'conditional_model_feasibility_witness': response.get('conditional_model_feasibility_witness', False),
                'native_prehead_reference_overdraw_veh': (
                    getattr(point.states[-1], 'native_input_prehead_state', {}).get('existing_wn_budget_overdraw_veh', 0.)
                    - getattr(initial, 'native_input_prehead_state', {}).get('existing_wn_budget_overdraw_veh', 0.)),
                'native_prehead_limit_scope': 'Existing W/N versus left-reference budget mismatch; upstream capacity and same-step crossing correspondence are unverified',
                'resource_summary': {'count': len(resources),
                    'kinds': dict(Counter(row['kind'] for row in resources)),
                    'max_exceedance_veh': max((row['exceedance_veh'] for row in resources), default=0.)}}
            cache[key] = packed(value)
            results.append(pickle.loads(cache[key]))
            score_sec += perf_counter() - tick
            del point, response
    finally:
        restore_diagnostics()
    return {'results': results, 'requested': len(actions), 'endpoint_calls': len(cache),
            'cache_hits': len(actions) - len(cache),
            'retained_result_bytes': sum(len(key) + len(value) for key, value in cache.items()),
            'endpoint_sec': endpoint_sec, 'score_sec': score_sec,
            'scope': 'Exact full-action reuse within one private shared-response batch; no solver or full feasibility certificate'}
