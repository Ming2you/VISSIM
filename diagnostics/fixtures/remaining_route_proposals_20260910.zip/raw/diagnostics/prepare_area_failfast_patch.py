"""Do not turn strict-area accounting failures into a successful fixed-control run."""
import ast
import difflib
from pathlib import Path
from types import FunctionType

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / 'evaluation/controllers/vissim_stackelberg_adapter.py'


def proposed_source(source):
    old = '''    except Exception as exc:  # Keep Vissim running; log and fall back safely.
        if args.controller in (*diagnostic_profile.CONTROLLERS, diagnostic_signal_profile.CONTROLLER):
            raise  # An invalid causal arm must not silently become fixed control.
'''
    new = '''    except Exception as exc:  # Legacy modes retain their fixed-control fallback.
        if (args.controller in (*diagnostic_profile.CONTROLLERS, diagnostic_signal_profile.CONTROLLER)
                or bool(getattr(cfg.network, "control_area_enabled", False))):
            raise  # Invalid strict-area or causal-arm evaluations must fail the decision.
'''
    if source.count(old) != 1:
        raise ValueError('Expected exactly one reviewed main decision fallback')
    return source.replace(old, new, 1)


def install_isolated(adapter):
    source = proposed_source(PATH.read_text(encoding='utf-8'))
    node = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == 'main')
    namespace = dict(vars(adapter))
    exec(compile(ast.Module(body=[node], type_ignores=[]), '<unapplied strict-area main fallback>', 'exec'), namespace)
    function = namespace['main']
    adapter.main = FunctionType(function.__code__, vars(adapter), 'main', function.__defaults__, function.__closure__)


if __name__ == '__main__':
    source = PATH.read_text(encoding='utf-8')
    target = PATH.relative_to(ROOT).as_posix()
    (ROOT / 'diagnostics/area_failfast.patch').write_text(''.join(difflib.unified_diff(
        source.splitlines(True), proposed_source(source).splitlines(True), fromfile='a/' + target, tofile='b/' + target)), encoding='utf-8')
