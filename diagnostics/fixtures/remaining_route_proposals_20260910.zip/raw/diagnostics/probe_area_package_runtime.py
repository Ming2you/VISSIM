"""Main/worker replay of the proposed package without writing production files."""
from pathlib import Path
import hashlib
import json
import pickle
import subprocess
import sys
import tempfile
import types
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'diagnostics'), str(ROOT / 'vendor/NumSim-mine')]
from build_area_routes_and_sc2001_patch import sources


def install_isolated_proposal():
    import evaluation.controllers as package
    changed = sources()
    for name in ['area_dynamic_routes', 'sc2001_corridor', 'projection_support', 'urban_flow_accounting', 'area_runtime', 'runtime_setup']:
        path = f'evaluation/controllers/{name}.py'
        module = types.ModuleType('evaluation.controllers.' + name)
        module.__file__ = str(ROOT / path)
        sys.modules[module.__name__] = module
        setattr(package, name, module)
        exec(compile(changed[path][1], '<isolated proposed ' + name + '>', 'exec'), module.__dict__)


def fresh_worker(input_path, output_path):
    from evaluation.controllers import vissim_stackelberg_adapter as adapter
    install_isolated_proposal()
    from evaluation.controllers import runtime_setup, area_runtime
    with Path(input_path).open('rb') as stream:
        payload = pickle.load(stream)
    cfg, state = payload['cfg'], payload['state']
    adapter.install_config_switches(payload['tuning'])
    frozen = pickle.dumps(state, protocol=5)
    runtime_setup.install_worker_runtime(adapter, cfg, payload['raw'], payload['detectors'])
    if frozen != pickle.dumps(state, protocol=5):
        raise AssertionError('Fresh worker changed received state during setup')
    from src.controllers.rollout_endpoint import ObjectiveSpec, evaluate_price_point
    result = evaluate_price_point(state, payload['control'], payload['forecast'], [], ObjectiveSpec(cfg, depth_override=1, score_mode='raw'))
    result.states[-1]._control_area_ledger.assert_stocks(area_runtime.model_inventory(result.states[-1], cfg))
    Path(output_path).write_text(json.dumps({'area': result.control_area, 'objective': result.objective}), encoding='utf-8')


def main():
    from test_observation_projection import ActualInstalledProjection as Harness
    Harness.setUpClass()
    adapter = Harness.adapter
    install_isolated_proposal()
    from evaluation.controllers import runtime_setup, area_runtime
    from src.models.state import TrafficState, ControlAction
    from src.models.demand import DemandStep
    run = ROOT / 'evaluation/runs/codex_nc_s13_6056c94_20260909_retry/decisions_codex_nc_s13_6056c94_20260909_retry'
    raw = adapter.load_optional_json(str(run / 'state_000900.json'))
    tuning = adapter.load_optional_json(str(ROOT / 'evaluation/configs/n21_n7_20260908.json'))
    overlay_path = ROOT/'diagnostics/control_area_physics_overlay.json'
    tuning = adapter.deep_update(tuning, json.loads(overlay_path.read_text(encoding='utf-8')))
    tuning['control_area_objective'] = {'enabled': True, 'beta_seconds': 0,
        'membership_path': 'diagnostics/control_area_membership.json',
        'route_contract_path': 'diagnostics/control_area_route_contract_physical_routes.json'}
    adapter.install_config_switches(tuning)
    calibration = adapter.deep_update(dict(Harness.calibration), tuning.get('calibration_override', {}))
    mapping = adapter.load_optional_json(str(ROOT / tuning['mapping_json']))
    detectors = adapter.load_optional_json(str(ROOT / tuning['detector_mapping_json']))
    detectors, _ = adapter.filter_midblock_links_from_detector_mapping(detectors, tuning)
    cfg = adapter.build_config(ROOT / 'vendor/NumSim-mine', raw['control_interval_sec'], raw['sim_period_sec'],
        'fast-smoke', calibration, tuning, local_observation=True, flagship=True)
    adapter.install_adapter_calibration_fingerprints(cfg, tuning)
    previous = str(run / 'action_000001.json')
    state, detectors, metadata = runtime_setup.configure_runtime(adapter, cfg, tuning, mapping, raw,
        previous, detectors, calibration, TrafficState)
    from src.controllers.rollout_endpoint import ObjectiveSpec, evaluate_price_point
    action = adapter.control_from_json(Path(previous), cfg, ControlAction)
    forecast = adapter.demand_from_state(raw, cfg, DemandStep, 1)
    main_result = evaluate_price_point(state, action, forecast, [], ObjectiveSpec(cfg, depth_override=1, score_mode='raw'))
    before = pickle.dumps(state, protocol=5)
    for _ in range(2):
        runtime_setup.install_worker_runtime(adapter, cfg, raw, detectors)
    if before != pickle.dumps(state, protocol=5):
        raise AssertionError('Worker runtime mutated its received state')
    worker_result = evaluate_price_point(state, action, forecast, [], ObjectiveSpec(cfg, depth_override=1, score_mode='raw'))
    for result in [main_result, worker_result]:
        result.states[-1]._control_area_ledger.assert_stocks(area_runtime.model_inventory(result.states[-1], cfg))
    if main_result.control_area != worker_result.control_area or main_result.objective != worker_result.objective:
        raise AssertionError('Worker runtime changed the accepted-flow area prediction')
    with tempfile.TemporaryDirectory(prefix='sc2001_worker_', dir=ROOT/'diagnostics') as folder:
        temporary = Path(folder).resolve()
        if not temporary.is_relative_to((ROOT/'diagnostics').resolve()):
            raise ValueError('Worker temporary directory is outside the diagnostic workspace')
        input_path, output_path = temporary/'input.pkl', temporary/'output.json'
        input_path.write_bytes(pickle.dumps({'cfg': cfg, 'state': state, 'raw': raw, 'detectors': detectors,
            'control': action, 'forecast': forecast, 'tuning': tuning}, protocol=5))
        child = subprocess.run([sys.executable, '-X', 'utf8', str(Path(__file__)), '--worker', str(input_path), str(output_path)],
            cwd=ROOT, text=True, encoding='utf-8', capture_output=True, timeout=55)
        if child.returncode:
            raise AssertionError('Fresh worker failed: ' + child.stderr)
        fresh = json.loads(output_path.read_text(encoding='utf-8'))
        if fresh['area'] != main_result.control_area or fresh['objective'] != main_result.objective:
            raise AssertionError('Fresh worker result differs from the main prediction')
    initial_inside = sum(value['inside'] for value in state._control_area_ledger.stocks.values())
    physical_inside = set(json.loads((ROOT/'diagnostics/control_area_membership.json').read_text())['inside_links'])
    raw_inside = sum(value for key, value in raw['vehicle_records']['full_network_link_counts'].items() if key in physical_inside)
    output = {'main_worker_150sec_equal': True, 'reinstall_state_unchanged': True,
        'fresh_worker_150sec_equal': True,
        'initial_physical_inside_veh': raw_inside, 'initial_model_inside_veh': initial_inside,
        'initial_residual_veh': raw_inside-initial_inside,
        'initial_corridor_veh': metadata['sc2001_initial_veh'],
        'initial_shared_69_veh': metadata['shared_initial_veh'],
        'corridor_cfg_sha256': cfg.network.sc2001_corridor['source']['sha256'],
        'physics_overlay_sha256': hashlib.sha256(overlay_path.read_bytes()).hexdigest(),
        'main_area': main_result.control_area, 'worker_area': worker_result.control_area,
        'new_corridor_adds_native_demand': False,
        'limitations': 'Isolated main and fresh subprocess runtime-hook replay; VISSIM treatment validation remains separate.'}
    for key in ('main_area', 'worker_area'):
        output[key] = {k: v for k, v in output[key].items() if k != 'flow_counts'}
    (ROOT/'diagnostics/area_package_runtime_replay.json').write_text(json.dumps(output, indent=2), encoding='utf-8')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == '--worker':
        fresh_worker(sys.argv[2], sys.argv[3])
    else:
        main()
