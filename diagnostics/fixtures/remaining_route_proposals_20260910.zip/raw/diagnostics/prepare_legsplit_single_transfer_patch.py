"""Canonical W_out transfer owns source withdrawal once, without undo estimates."""
import ast
import difflib
from pathlib import Path
from types import FunctionType

ROOT = Path(__file__).resolve().parents[1]


def once(source, old, new):
    if source.count(old) != 1:
        raise ValueError('Single-transfer source context drifted: ' + old[:100])
    return source.replace(old, new, 1)


def proposed_source(source):
    from prepare_legsplit_receiving_patch import proposed_source as receiving_source
    source = receiving_source(source)
    source = once(source,
        '    # 양(reach)만 목적지별로 나누고 램프는 공간·연결로 용량(ramp_capacity)으로만 막는다. 호출 뒤\n'
        '    # vendor 가 뺀 총량과 의도 총량의 차이를 저류로 되돌리고 램프 몫을 저수지에 넣는다.\n',
        '    # 양(reach)만 목적지별로 나눈다. 일반 sink 인출은 이 래퍼에서만 유예하며, 도시 본문 실행 뒤\n'
        '    # 실제 수신 여유를 다시 확인한 accepted 양만 원 저장고에서 한 번 빼고 목적지로 옮긴다.\n')
    source = once(source,
        '    adjust: dict[str, float] = {}   # link -> (의도 인출 − vendor 인출); 양수면 vendor 가 더 뺀 것 → 되돌림\n',
        '    adjust: dict[str, float] = {}   # source link -> accepted departures freeing its storage\n')
    source = once(source, '    ramp_release_veh_h: Mapping[str, float] | None = None,\n) -> Tuple[float, Dict[str, float]]:\n',
        '    ramp_release_veh_h: Mapping[str, float] | None = None,\n    defer_legsplit_sinks: bool = False,\n) -> Tuple[float, Dict[str, float]]:\n')
    source = once(source, '    for link in sink_links:\n        cap = net.urban_link_storage_veh.get(link, net.boundary_queue_max_veh)\n',
        '    for link in sink_links:\n        if defer_legsplit_sinks and link in ramp_split:\n            continue  # The wrapper performs one explicit accepted W_out transfer.\n        cap = net.urban_link_storage_veh.get(link, net.boundary_queue_max_veh)\n')
    source = once(source, '                        ramp_release_veh_h=rel)\n',
        '                        ramp_release_veh_h=rel, defer_legsplit_sinks=True)\n')
    source = once(source, '        vendor_free = min(arrived * free_share, exit_cap_veh) if finite_exit else arrived * free_share\n', '')
    source = once(source, '        vendor_total = vendor_free\n', '')
    source = once(source, '            meter = max(0.0, float((rel or {}).get(str(ramp), 0.0))) * float(sim.T_u_h)\n            vendor_total += min(arrived * sh, min(space, meter))\n', '')
    source = once(source, '        adjust[str(link)] = intended_total - vendor_total\n', '        adjust[str(link)] = intended_total\n')
    source = once(source,
        '        # storage = 가용공간. vendor 가 departed 만큼 늘렸으니 (의도 − vendor) 만큼 더 늘리거나 줄인다.\n'
        '        state.urban_link_storage[link] = min(cap_l, max(0.0, float(state.urban_link_storage.get(link, cap_l)) + delta))\n',
        '        # The generic sink was deferred, so actual accepted departures\n'
        '        # now free their source space exactly once; never infer an undo.\n'
        '        available = float(state.urban_link_storage.get(link, cap_l))\n'
        '        if delta < -1.0e-9 or available + delta > cap_l + 1.0e-7:\n'
        '            raise ValueError("accepted W_out transfer exceeds source stock: " + str(link))\n'
        '        state.urban_link_storage[link] = available + delta\n')
    return source


def install_isolated():
    from evaluation.controllers import urban_flow_accounting as urban
    from build_area_routes_and_sc2001_patch import sources
    source = proposed_source(sources()['evaluation/controllers/urban_flow_accounting.py'][1])
    names = {'_receive_corridor', 'urban_substep_accounted', 'legsplit_substep_accounted'}
    nodes = [n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name in names]
    namespace = dict(vars(urban))
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<unapplied single accepted W_out transfer>', 'exec'), namespace)
    for name in names:
        function = namespace[name]
        setattr(urban, name, FunctionType(function.__code__, vars(urban), name, function.__defaults__, function.__closure__))


if __name__ == '__main__':
    from build_area_routes_and_sc2001_patch import sources
    target = 'evaluation/controllers/urban_flow_accounting.py'
    before = sources()[target][1]
    after = proposed_source(before)
    (ROOT / 'diagnostics/legsplit_single_transfer.patch').write_text(''.join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True), fromfile='a/' + target, tofile='b/' + target)), encoding='utf-8')
    print('Supersedes legsplit_receiving.patch; apply after the area route package.')
