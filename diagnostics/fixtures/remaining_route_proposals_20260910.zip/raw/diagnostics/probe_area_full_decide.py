"""Call the real adapter main with isolated proposed modules and worker bootstrap.

No adapter copy, modified vendor source, VISSIM call, or live output path.
"""
import argparse
import json
import os
import pickle
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'diagnostics'), str(ROOT / 'vendor/NumSim-mine')]


def install_proposals():
    from evaluation.controllers import vissim_stackelberg_adapter as adapter
    from diagnostics.probe_area_package_runtime import install_isolated_proposal
    from diagnostics.prepare_freeway_initial_count_patch import proposed_functions
    install_isolated_proposal()
    for name, function in proposed_functions(adapter).items():
        setattr(adapter, name, function)
    from diagnostics.prepare_legsplit_single_transfer_patch import install_isolated as install_receiving
    install_receiving()
    from diagnostics.prepare_area_failfast_patch import install_isolated as install_failfast
    install_failfast(adapter)
    install_clip_probe()
    install_failed_endpoint_capture()
    return adapter


def install_failed_endpoint_capture():
    from evaluation.controllers.control_area_objective import ModelAreaLedger
    original = ModelAreaLedger.assert_stocks
    if getattr(original, '_diagnostic_failure_capture', False):
        return
    def checked(self, *args, **kwargs):
        try:
            return original(self, *args, **kwargs)
        except Exception as error:
            frame = sys._getframe(1)
            while frame is not None:
                values = frame.f_locals
                if frame.f_code.co_name == 'evaluate_price_point' and 'objective_spec' in values:
                    keys = ('state', 'previous', 'forecast', 'action_schedule', 'objective_spec')
                    folder = ROOT / 'diagnostics/area_main_preflight'
                    folder.mkdir(exist_ok=True)
                    stem = folder / f'failed_endpoint_{os.getpid()}'
                    stem.with_suffix('.pkl').write_bytes(pickle.dumps({key:values[key] for key in keys}, protocol=5))
                    stem.with_suffix('.json').write_text(json.dumps({'error': str(error),
                        'state_time': values['state'].time_sec,
                        'beta': values['objective_spec'].cfg.network.control_area_beta_seconds}), encoding='utf-8')
                    break
                frame = frame.f_back
            raise
    checked._diagnostic_failure_capture = True
    ModelAreaLedger.assert_stocks = checked


def install_clip_probe():
    """Observe the pending post-body injection before its existing cap clips it."""
    from evaluation.controllers import urban_flow_accounting as urban
    original = urban.urban_substep_accounted
    captured = False

    def watched(state, control, demand, cfg, *args, **kwargs):
        nonlocal captured
        parent = sys._getframe(1)
        planned = parent.f_locals.get('inject', {}) if parent.f_code is urban.legsplit_substep_accounted.__code__ else {}
        before = state.copy() if not captured and any(
            cfg.network.ramp_queue_cap(r) - state.ramp_queue.get(r, 0) < amount + 8
            for r, amount in planned.items()) else None
        result = original(state, control, demand, cfg, *args, **kwargs)
        clipped = {r: {'before_body': before.ramp_queue[r], 'after_body': state.ramp_queue[r],
                      'planned_injection': amount, 'capacity': cfg.network.ramp_queue_cap(r),
                      'would_clip': state.ramp_queue[r] + amount - cfg.network.ramp_queue_cap(r)}
                   for r, amount in planned.items() if before is not None
                   and state.ramp_queue[r] + amount > cfg.network.ramp_queue_cap(r) + 1e-8}
        if clipped and not captured:
            captured = True
            folder = ROOT / 'diagnostics/area_main_preflight'
            folder.mkdir(exist_ok=True)
            payload = {'state': before, 'control': control, 'demand': demand, 'cfg': cfg,
                       'args': args, 'kwargs': kwargs}
            stem = folder / f'first_ramp_clip_{os.getpid()}'
            stem.with_suffix('.pkl').write_bytes(pickle.dumps(payload, protocol=5))
            stem.with_suffix('.json').write_text(json.dumps({'clipped': clipped,
                'urban_step_index': kwargs.get('urban_step_index'),
                'accepted_transfers_planned': parent.f_locals.get('accepted_transfers'),
                'note': 'Captured immediately after urban body, before legacy injection min(cap).'}, indent=2), encoding='utf-8')
        return result
    urban.urban_substep_accounted = watched


def install_worker_proposals(cfg, state_json, detector_mapping):
    """Native controller.__setstate__ calls this in each actual spawn worker."""
    adapter = install_proposals()
    from evaluation.controllers import runtime_setup
    metadata = runtime_setup.install_worker_runtime(adapter, cfg, state_json, detector_mapping)
    if not bool(getattr(cfg.network, 'physical_vehicle_counts', False)):
        raise ValueError('Diagnostic worker received a config without exact physical counts')
    return metadata


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--time', type=int, default=1200)
    parser.add_argument('--beta', type=int, choices=(0, 60, 150, 300), default=0)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--prepare-only', action='store_true', help='Stop at the real decide call after main setup; explicitly not a full MPC test.')
    args = parser.parse_args()
    config = args.config or ROOT / f'diagnostics/area_candidate_configs/n7_area_beta{args.beta}.json'
    if not config.is_absolute():
        config = ROOT / config
    run = 'codex_n7_pure_s13_20260910'
    decisions = ROOT / 'evaluation/runs' / run / f'decisions_{run}'
    state_path = decisions / f'state_{args.time:06d}.json'
    previous = max((path for path in decisions.glob('action_*.json') if int(path.stem.split('_')[-1]) < args.time),
                   key=lambda path: int(path.stem.split('_')[-1]))
    out = (ROOT / f'diagnostics/area_main_preflight/t{args.time}_beta{args.beta}').resolve()
    if not out.is_relative_to((ROOT / 'diagnostics').resolve()):
        raise ValueError('Preflight output escaped diagnostic workspace')
    out.mkdir(parents=True, exist_ok=True)
    adapter = install_proposals()
    original_bootstrap = adapter.install_price_worker_bootstrap

    def isolated_bootstrap(controller, raw, detectors):
        result = original_bootstrap(controller, raw, detectors)
        if getattr(controller, 'price_worker_bootstrap', None):
            controller.price_worker_bootstrap['module'] = 'diagnostics.probe_area_full_decide'
            controller.price_worker_bootstrap['func'] = 'install_worker_proposals'
        return result

    original_build = adapter.build_priced_wu_link_controller
    prepared = {}

    class PreparationComplete(BaseException):
        pass

    def capture_build(cfg, tuning):
        controller = original_build(cfg, tuning)
        if args.prepare_only:
            def stop(state, forecast, previous, cfg_arg):
                from evaluation.controllers.area_runtime import model_inventory
                state._control_area_ledger.assert_stocks(model_inventory(state, cfg_arg))
                prepared.update({'reached_actual_main_decide': True, 'decide_executed': False,
                    'horizon_steps': len(forecast), 'parallel_workers': controller.price_parallel_workers,
                    'beta_seconds': cfg_arg.network.control_area_beta_seconds,
                    'initial_omega_veh': sum(row['inside'] for row in state._control_area_ledger.stocks.values()),
                    'bootstrap': {key: value for key, value in controller.price_worker_bootstrap.items() if key != 'detector_mapping'},
                    'sc2001_enabled': hasattr(cfg_arg.network, 'sc2001_corridor'),
                    'physical_vehicle_counts': cfg_arg.network.physical_vehicle_counts})
                raise PreparationComplete()
            controller.decide_with_info = stop
        return controller

    tuning = json.loads(config.read_text(encoding='utf-8'))
    argv = [str(Path(adapter.__file__)), '--state-json', str(state_path),
        '--previous-action-json', str(previous), '--out-action-json', str(out / 'action.json'),
        '--out-action-csv', str(out / 'action.csv'), '--repo-root', str(ROOT / 'vendor/NumSim-mine'),
        '--mapping-json', str(ROOT / tuning['mapping_json']),
        '--detector-mapping-json', str(ROOT / tuning['detector_mapping_json']),
        '--calibration-json', str(ROOT / 'evaluation/calibration/real_world_prediction_calibration_core17legs4b_20260820.json'),
        '--tuning-json', str(config), '--controller', 'wu-link', '--mode', 'fast-smoke']
    try:
        with patch.object(sys, 'argv', argv), \
             patch.object(adapter, 'install_price_worker_bootstrap', isolated_bootstrap), \
             patch.object(adapter, 'build_priced_wu_link_controller', capture_build):
            adapter.main()
    except PreparationComplete:
        (out / 'preparation.json').write_text(json.dumps(prepared, indent=2), encoding='utf-8')
        print(json.dumps(prepared, indent=2))
        return
    if not (out / 'action.json').is_file():
        raise AssertionError('Real main completed without its diagnostic action output')
    metadata = json.loads((out / 'action.json').read_text(encoding='utf-8'))['metadata']
    if metadata.get('controller_status') == 'fallback_fixed':
        raise RuntimeError('Actual main fell back: ' + metadata.get('controller_error_type', '') + ': ' + metadata.get('controller_error', ''))
    print('MAIN_DECIDE_OUTPUT=' + str(out / 'action.json'))


if __name__ == '__main__':
    main()
