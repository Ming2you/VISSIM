"""Full physical-observation coverage of the final proposed area pipeline."""
from pathlib import Path
import json
import sys
import argparse
from contextlib import nullcontext

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'diagnostics')]
from probe_sc2001_corridor_replay import fixture, Harness
from evaluation.controllers.control_area_objective import physical_membership_from_ledger
from evaluation.controllers.area_freeway_accounting import continuity_vehicle_counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--support-path')
    parser.add_argument('--exact-freeway-counts', action='store_true')
    parser.add_argument('--label', default='')
    args = parser.parse_args()
    physical = physical_membership_from_ledger(json.loads((ROOT / 'diagnostics/control_area_membership.json').read_text(encoding='utf-8')))
    tuning = json.loads((ROOT / 'evaluation/configs/n21_n7_20260908.json').read_text(encoding='utf-8'))
    mapping = json.loads((ROOT / tuning['mapping_json']).read_text(encoding='utf-8'))
    fw_links = {str(link) for row in mapping['freeway_model_links'].values() for link in row['chain_links']}
    run = ROOT / 'evaluation/runs/codex_n7_pure_s13_20260910/decisions_codex_n7_pure_s13_20260910'
    results = []
    for path in sorted(run.glob('state_*.json')):
        if not 900 <= int(path.stem.split('_')[-1]) <= 5400:
            continue
        try:
            options = {'support_path': args.support_path} if args.support_path else {}
            from prepare_freeway_initial_count_patch import installed_proposal
            context = installed_proposal(force_flag=True) if args.exact_freeway_counts else nullcontext()
            with context:
                cfg, state, _, raw = fixture(path, **options)
                continuity_counts = continuity_vehicle_counts(state, cfg)
                cell_errors = {key: [modeled-row['count'] for modeled, row in zip(values, raw['freeway_segments'][key])]
                               for key, values in continuity_counts.items()}
                if args.exact_freeway_counts:
                    getter_counts = Harness.adapter._freeway_vehicle_count_by_link(state, cfg)
                    state_counts = state.freeway_vehicle_count_by_link(cfg.network)
                    if getter_counts != continuity_counts or state_counts != continuity_counts:
                        raise AssertionError('FW getter/model coordinate mismatch')
            from src.models.demand import DemandStep
            demand = Harness.adapter.demand_from_state(raw, cfg, DemandStep, 1)[0]
            counts = raw['vehicle_records']['full_network_link_counts']
            assignments = state.local_observation_summary['projection_diagnostics']['physical_stock_assignment_by_link']
            differences = [{'physical_link': link, 'raw_veh': count, 'assigned_veh': sum(assignments.get(link, {}).values())}
                           for link, count in counts.items() if physical[link] and link not in fw_links
                           and abs(count-sum(assignments.get(link, {}).values())) > 1e-7]
            result = {'snapshot_sec': state.time_sec, 'raw_omega_veh': sum(count for link, count in counts.items() if physical[link]),
                      'model_omega_veh': sum(row['inside'] for row in state._control_area_ledger.stocks.values()),
                      'raw_fw_veh': sum(counts.get(link, 0) for link in fw_links),
                      'model_fw_veh': sum(sum(row) for row in continuity_vehicle_counts(state, cfg).values()),
                      'urban_physical_assignment_differences': differences}
            result['independent_ramp_demand_veh_h'] = demand.ramp_arrival
            result['legacy_shared69_gate_demand_veh_h'] = {key: demand.urban_boundary.get(key, 0)
                for key in ('in_SC1004_W', 'in_SC1005_W')}
            result['fw_projection_minus_continuity_veh'] = result['raw_fw_veh'] - result['model_fw_veh']
            result['fw_per_cell_errors_veh'] = cell_errors
            result['exact_freeway_count_proposal'] = args.exact_freeway_counts
            if args.exact_freeway_counts:
                if differences or max(abs(x) for values in cell_errors.values() for x in values) > 1e-9:
                    raise AssertionError('Physical per-cell projection mismatch')
                if abs(result['model_omega_veh'] - result['raw_omega_veh']) > 1e-7:
                    raise AssertionError('Physical union inventory mismatch')
            print(f"t={int(state.time_sec)} urban_gaps={len(differences)} FWdelta={result['fw_projection_minus_continuity_veh']:.6f}", flush=True)
        except Exception as exc:
            result = {'snapshot': path.name, 'error': repr(exc)}
            print(f'FAIL {path.name}: {exc}', flush=True)
        results.append(result)
        suffix = '_' + args.label if args.label else ''
        (ROOT / ('diagnostics/area_all_initial_physical_coverage' + suffix + '.json')).write_text(json.dumps(results, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
