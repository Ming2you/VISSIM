"""Replay the first actual full-MPC receiving race, with conserved rejected stock."""
import copy
import ast
import json
from pathlib import Path
import pickle
import sys
import unittest
from unittest.mock import patch
from types import FunctionType

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'diagnostics'), str(ROOT / 'vendor/NumSim-mine')]


class LegsplitReceivingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from diagnostics.probe_area_full_decide import install_worker_proposals
        path = ROOT / 'diagnostics/area_main_preflight/first_ramp_clip_50548.pkl'
        if not path.is_file():
            raise unittest.SkipTest('Actual first clipping fixture missing')
        cls.payload = pickle.loads(path.read_bytes())
        cfg = cls.payload['cfg']
        install_worker_proposals(cfg, {'network_path': str(ROOT / 'network/real_world_gaepo_modi/modi_eval_userfix Ver2.inpx')}, {})
        from evaluation.controllers import urban_flow_accounting as urban
        cls.urban = urban
        from build_area_routes_and_sc2001_patch import sources
        source = sources()['evaluation/controllers/urban_flow_accounting.py'][1]
        node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'legsplit_substep_accounted')
        namespace = dict(vars(urban))
        exec(compile(ast.Module(body=[node], type_ignores=[]), '<fixed pre-receipt reference>', 'exec'), namespace)
        reference = namespace[node.name]
        cls.old = staticmethod(FunctionType(reference.__code__, vars(urban), node.name, reference.__defaults__, reference.__closure__))
        from prepare_legsplit_receiving_patch import install_isolated
        install_isolated()
        cls.fixed = staticmethod(urban.legsplit_substep_accounted)

    def run_step(self, function, *, mutate=None):
        p = copy.deepcopy(self.payload)
        if mutate:
            mutate(p)
        initial = p['state'].copy()
        function(p['state'], p['control'], p['demand'], p['cfg'], *p['args'], **p['kwargs'])
        return initial, p['state'], p['cfg']

    def test_actual_failed_candidate_reproduces_exact_clip(self):
        _, final, _ = self.run_step(self.old)
        tracked = sum(final._control_area_ledger.stocks['ramp:R_D_W'].values())
        self.assertAlmostEqual(tracked - final.ramp_queue['R_D_W'], 0.22302305524194777)
        self.assertEqual(final.ramp_queue['R_D_W'], 153.2)

    def test_rejected_vehicle_stays_in_original_source_and_only_accepted_is_emitted(self):
        _, old, cfg = self.run_step(self.old)
        _, fixed, _ = self.run_step(self.fixed)
        key = 'SC1001_W_out'
        self.assertAlmostEqual(old.urban_link_storage[key] - fixed.urban_link_storage[key], .22302305524194777)
        self.assertAlmostEqual(sum(fixed._control_area_ledger.stocks['ramp:R_D_W'].values()), fixed.ramp_queue['R_D_W'])
        from evaluation.controllers.area_runtime import model_inventory
        inventory = model_inventory(fixed, cfg)
        # During a Tu step an already released vehicle legitimately waits for
        # the next Tf merge. All other physical stocks must already agree.
        for key, row in fixed._control_area_ledger.stocks.items():
            if not key.startswith('merge_pending:'):
                self.assertAlmostEqual(sum(row.values()), inventory.get(key, 0), places=6, msg=key)

    def test_same_step_does_not_mutate_input_candidate_and_repeats_exactly(self):
        before = pickle.dumps(self.payload, protocol=5)
        _, a, _ = self.run_step(self.fixed)
        _, b, _ = self.run_step(self.fixed)
        self.assertEqual({k:v for k,v in vars(a).items() if k != '_control_area_ledger'},
                         {k:v for k,v in vars(b).items() if k != '_control_area_ledger'})
        self.assertEqual(vars(a._control_area_ledger), vars(b._control_area_ledger))
        self.assertEqual(pickle.dumps(self.payload, protocol=5), before)

    def test_no_competition_preserves_every_state_field_and_flow(self):
        def more_space(p):
            p['cfg'].network.ramp_queue_max_veh_by_ramp['R_D_W'] += 100
        _, old, _ = self.run_step(self.old, mutate=more_space)
        _, fixed, _ = self.run_step(self.fixed, mutate=more_space)
        # The new receipt counter is adapter metadata, not a model state change.
        self.assertEqual({k:v for k,v in vars(old).items() if k != '_control_area_ledger'},
                         {k:v for k,v in vars(fixed).items() if k != '_control_area_ledger'})
        self.assertEqual(vars(old._control_area_ledger), vars(fixed._control_area_ledger))


if __name__ == '__main__':
    unittest.main(verbosity=2)
