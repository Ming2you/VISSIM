"""Prepare guarded corridor calls in the canonical urban body; no live edits."""
from pathlib import Path
import difflib

ROOT = Path(__file__).resolve().parents[1]


def once(source, old, new):
    if source.count(old) != 1:
        raise ValueError('Expected exactly one reviewed urban hook: ' + old[:100])
    return source.replace(old, new, 1)


def proposed_source(source):
    helper = '''def _receive_corridor(state, cfg, movement, vehicles, urban_step_index):
    if not getattr(cfg.network, 'sc2001_corridor', None):
        return False
    from evaluation.controllers.sc2001_corridor import receive_accepted
    return receive_accepted(state, cfg, movement, vehicles, urban_step_index)


'''
    source = once(source, 'def _drain_offramp_storage_accounted(', helper + 'def _drain_offramp_storage_accounted(')
    old = '    sink_links = _uqm.sink_storage_links(cfg)\n'
    new = old + '''    corridor = getattr(net, 'sc2001_corridor', None)
    if corridor:
        from evaluation.controllers.sc2001_corridor import advance
        corridor_diagnostics = advance(state, control, demand, cfg, step_idx)
        diagnostics.update({key: value for key, value in corridor_diagnostics.items()
                            if isinstance(value, (int, float))})
        sink_links = set(sink_links) - {corridor['storage']}
'''
    source = once(source, old, new)
    source = once(source, '    for link in net.urban_link_storage_veh:\n',
                  "    for link in net.urban_link_storage_veh:\n        if corridor and link == corridor['storage']:\n            continue\n")
    source = once(source, '    for source, targets in routing.items():\n',
                  "    for source, targets in routing.items():\n        if corridor and source == corridor['storage']:\n            continue\n")
    # Both accepted urban service and the narrow off-ramp drain use one receipt
    # API. The actual stock subtraction and existing area transfer stay outside.
    for indent in (' ' * 16, ' ' * 12):
        start = source.index('\n' + indent + 'delay_steps = _uqm._link_delay_steps(state, cfg, receiving_link)\n') + 1
        end_text = '\n' + indent + '_uqm._schedule(state.urban_storage_release_buffer, receiving_link, arrival_step, actual)\n'
        end = source.index(end_text, start) + len(end_text)
        original = source[start:end]
        replacement = (indent + 'if not _receive_corridor(state, cfg, movement, actual, step_idx):\n'
                       + ''.join('    ' + line for line in original.splitlines(keepends=True)))
        source = source[:start] + replacement + source[end:]
        start += len(replacement)
    source = once(source, "    if not getattr(cfg.network, 'control_area_enabled', False):\n        return {'area_urban_accounting_enabled': 0.0}\n",
                  "    if not getattr(cfg.network, 'control_area_enabled', False) and not getattr(cfg.network, 'sc2001_corridor', None):\n        return {'area_urban_accounting_enabled': 0.0}\n")
    source = once(source, "        if not getattr(cfg.network, 'control_area_enabled', False):\n            return original_urban(state, control, demand, cfg, *args, **kwargs)\n        if get_ledger(state) is None:\n",
                  "        area_enabled = bool(getattr(cfg.network, 'control_area_enabled', False))\n        if not area_enabled and not getattr(cfg.network, 'sc2001_corridor', None):\n            return original_urban(state, control, demand, cfg, *args, **kwargs)\n        if area_enabled and get_ledger(state) is None:\n")
    source = once(source, "        keys = [k for k in get_ledger(state).stocks if k.startswith(('storage:', 'movement:', 'ramp:', 'transit:'))]\n        integrate_residence(state, cfg, keys, cfg.simulation.T_u_h)\n",
                  "        if area_enabled:\n            keys = [k for k in get_ledger(state).stocks if k.startswith(('storage:', 'movement:', 'ramp:', 'transit:'))]\n            integrate_residence(state, cfg, keys, cfg.simulation.T_u_h)\n")
    return source


def main():
    target = 'evaluation/controllers/urban_flow_accounting.py'
    before = (ROOT / target).read_text(encoding='utf-8')
    after = proposed_source(before)
    compile(after, '<reviewed corridor urban proposal>', 'exec')
    (ROOT / 'diagnostics/sc2001_urban_flow_accounting.patch').write_text(''.join(
        difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                             fromfile='a/' + target, tofile='b/' + target)), encoding='utf-8')
    print('Prepared corridor urban patch; runtime unchanged.')


if __name__ == '__main__':
    main()
