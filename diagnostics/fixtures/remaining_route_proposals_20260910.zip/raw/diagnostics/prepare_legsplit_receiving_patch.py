"""Unapplied fix for competing accepted ramp receipts in canonical urban physics."""
import ast
import difflib
from pathlib import Path
from types import FunctionType

ROOT = Path(__file__).resolve().parents[1]


def proposed_source(source):
    old = '''    for ramp, veh in inject.items():
        cap_r = float(net_a.ramp_queue_cap(ramp))
        state.ramp_queue[ramp] = min(cap_r, max(0.0, float(state.ramp_queue.get(ramp, 0.0))) + veh)
        _adapter._LEGSPLIT_LAST["leg_ramp_split_injected_%s" % ramp] = _adapter._LEGSPLIT_LAST.get("leg_ramp_split_injected_%s" % ramp, 0.0) + veh
'''
    new = '''    # The body can accept other urban/corridor vehicles into the same
    # ramp after these requests were prepared. Reconcile requests against the
    # actual remaining room before withdrawing any of their source stock.
    receipt_scale: dict[str, float] = {}
    for ramp, requested in inject.items():
        room = max(0.0, float(net_a.ramp_queue_cap(ramp)) - float(state.ramp_queue.get(ramp, 0.0)))
        accepted = min(requested, room)
        receipt_scale[ramp] = accepted / requested if requested > 0.0 else 0.0
        inject[ramp] = accepted
        _adapter._LEGSPLIT_LAST["leg_ramp_split_receiving_rejected_veh"] = (
            _adapter._LEGSPLIT_LAST.get("leg_ramp_split_receiving_rejected_veh", 0.0) + requested - accepted)
    reconciled_transfers = []
    for source_link, ramp, requested in accepted_transfers:
        accepted = requested if ramp is None else requested * receipt_scale[ramp]
        # Available storage increases only by accepted departures. A rejected
        # vehicle stays in its original W_out, retaining its arrival reservation.
        adjust[source_link] -= requested - accepted
        reconciled_transfers.append((source_link, ramp, accepted))
    accepted_transfers = reconciled_transfers
    for ramp, veh in inject.items():
        state.ramp_queue[ramp] = max(0.0, float(state.ramp_queue.get(ramp, 0.0))) + veh
        _adapter._LEGSPLIT_LAST["leg_ramp_split_injected_%s" % ramp] = _adapter._LEGSPLIT_LAST.get("leg_ramp_split_injected_%s" % ramp, 0.0) + veh
'''
    if source.count(old) != 1:
        raise ValueError('Expected exactly one canonical post-body ramp injection')
    return source.replace(old, new, 1)


def install_isolated():
    from evaluation.controllers import urban_flow_accounting as urban
    from build_area_routes_and_sc2001_patch import sources
    source = proposed_source(sources()['evaluation/controllers/urban_flow_accounting.py'][1])
    node = next(node for node in ast.parse(source).body
                if isinstance(node, ast.FunctionDef) and node.name == 'legsplit_substep_accounted')
    namespace = dict(vars(urban))
    exec(compile(ast.Module(body=[node], type_ignores=[]), '<unapplied accepted ramp receiving>', 'exec'), namespace)
    function = namespace[node.name]
    urban.legsplit_substep_accounted = FunctionType(function.__code__, vars(urban), node.name,
                                                    function.__defaults__, function.__closure__)


def main():
    from build_area_routes_and_sc2001_patch import sources
    target = 'evaluation/controllers/urban_flow_accounting.py'
    before = sources()[target][1]
    after = proposed_source(before)
    patch = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                       fromfile='a/' + target, tofile='b/' + target))
    (ROOT / 'diagnostics/legsplit_receiving.patch').write_text(patch, encoding='utf-8')
    print('Apply after area_routes_and_sc2001.patch; production unchanged.')


if __name__ == '__main__':
    main()
