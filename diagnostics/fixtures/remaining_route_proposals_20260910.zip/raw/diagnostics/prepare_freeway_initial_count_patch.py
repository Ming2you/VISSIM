"""Generate/replay an unapplied per-cell inventory projection patch.

Only this diagnostic harness compiles proposed function bodies. Production uses
normal source functions; no runtime AST execution or aggregate count correction.
"""
from contextlib import ExitStack, contextmanager
import ast
import difflib
from pathlib import Path
import sys
from types import FunctionType
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
ADAPTER_PATH = ROOT / 'evaluation/controllers/vissim_stackelberg_adapter.py'
NAMES = ('_freeway_vehicle_count_by_link',
         'install_vissim_calibration_runtime_patches', 'traffic_state_from_vissim')


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError('Frozen adapter context drifted: ' + old[:90])
    return source.replace(old, new, 1)


def proposed_source(source):
    source = replace_once(source,
        '        lengths = _freeway_segment_lengths_km(cfg, key, len(densities))\n',
        '        # Physical N follows the scalar cell length in the continuity equation.\n'
        '        lengths = ([float(net.freeway_segment_length_km)] * len(densities)\n'
        '                   if physical_counts else _freeway_segment_lengths_km(cfg, key, len(densities)))\n')
    source = replace_once(source,
        '                    if len(lengths) < len(densities):\n'
        '                        lengths = lengths + [base] * (len(densities) - len(lengths))\n',
        '                    if physical_counts:\n'
        '                        lengths = [float(net.freeway_segment_length_km)] * len(densities)\n'
        '                    elif len(lengths) < len(densities):\n'
        '                        lengths = lengths + [base] * (len(densities) - len(lengths))\n')
    source = replace_once(source,
        '    segs = state_json.get("freeway_segments", {})\n',
        '    # Project observed N into the exact density coordinates used by the\n'
        '    # continuity equation. Keep physical lengths for travel/speed geometry.\n'
        '    continuity_length_km = None\n'
        '    if bool(getattr(cfg.network, "physical_vehicle_counts", False)):\n'
        '        continuity_length_km = float(cfg.network.freeway_segment_length_km)\n'
        '        if not math.isfinite(continuity_length_km) or continuity_length_km <= 0.0:\n'
        '            raise ValueError("physical_vehicle_counts requires a positive finite continuity cell length")\n'
        '    segs = state_json.get("freeway_segments", {})\n')
    source = replace_once(source,
        '            density = count / (length_km * lanes)\n',
        '            density_length_km = length_km if continuity_length_km is None else continuity_length_km\n'
        '            density = count / (density_length_km * lanes)\n')
    return source


def proposed_functions(adapter):
    source = proposed_source(ADAPTER_PATH.read_text(encoding='utf-8'))
    nodes = [node for node in ast.parse(source).body
             if isinstance(node, ast.FunctionDef) and node.name in NAMES]
    assert len(nodes) == len(NAMES)
    namespace = dict(vars(adapter))
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<unapplied freeway count proposal>', 'exec'), namespace)
    # Use actual module globals so existing summary mocks/runtime hooks continue
    # to resolve exactly as normal imported production functions do.
    functions = {}
    for name in NAMES:
        original = namespace[name]
        function = FunctionType(original.__code__, vars(adapter), name,
                                original.__defaults__, original.__closure__)
        function.__kwdefaults__ = original.__kwdefaults__
        function.__annotations__ = original.__annotations__
        functions[name] = function
    return functions


@contextmanager
def installed_proposal(*, force_flag=False):
    """Patch only this isolated diagnostic process, never any source file."""
    sys.path[:0] = [str(ROOT), str(ROOT / 'vendor/NumSim-mine')]
    from evaluation.controllers import vissim_stackelberg_adapter as adapter
    from src.models.state import TrafficState
    functions = proposed_functions(adapter)
    if force_flag:
        project = functions['traffic_state_from_vissim']
        def project_enabled(state_json, cfg, *args, **kwargs):
            cfg.network.physical_vehicle_counts = True
            return project(state_json, cfg, *args, **kwargs)
        functions['traffic_state_from_vissim'] = project_enabled
    with ExitStack() as stack:
        for name, function in functions.items():
            stack.enter_context(patch.object(adapter, name, function))
        # The calibration installer updates these class methods; restore them
        # too, so one test cannot contaminate a later baseline fixture.
        for name in ('freeway_vehicle_count_by_link', 'total_freeway_vehicles'):
            stack.enter_context(patch.object(TrafficState, name, getattr(TrafficState, name)))
        yield adapter


def main():
    source = ADAPTER_PATH.read_text(encoding='utf-8')
    proposal = proposed_source(source)
    rel = ADAPTER_PATH.relative_to(ROOT).as_posix()
    difference = ''.join(difflib.unified_diff(source.splitlines(True), proposal.splitlines(True),
                                            fromfile='a/' + rel, tofile='b/' + rel))
    destination = ROOT / 'diagnostics/freeway_initial_count.patch'
    destination.write_text(difference, encoding='utf-8')
    print(destination)


if __name__ == '__main__':
    main()
