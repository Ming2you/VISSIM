"""One unapplied package for reviewed dynamic routes and the finite corridor.

Supersedes dynamic_area_runtime.patch and sc2001_urban_flow_accounting.patch.
Existing adapter observation/provenance/transit fixes are separate prerequisites.
"""
from pathlib import Path
import difflib
import hashlib
import json
from prepare_sc2001_urban_patch import once, proposed_source

ROOT = Path(__file__).resolve().parents[1]


def sources():
    changed = {}
    for source, target in [('diagnostics/proposed_area_dynamic_routes.py', 'evaluation/controllers/area_dynamic_routes.py'),
                           ('diagnostics/sc2001_corridor_proposal.py', 'evaluation/controllers/sc2001_corridor.py')]:
        changed[target] = ('', (ROOT / source).read_text(encoding='utf-8'))
    target = 'evaluation/controllers/urban_flow_accounting.py'
    before = (ROOT / target).read_text(encoding='utf-8')
    changed[target] = (before, proposed_source(before))
    target = 'evaluation/controllers/runtime_setup.py'
    before = (ROOT / target).read_text(encoding='utf-8')
    after = once(before, '        metadata.update(topology_metadata)\n', '''        metadata.update(topology_metadata)
    if 'dynamic_physical_route_topology' in (tuning or {}).get('urban', {}).get('movements', {}):
        from evaluation.controllers import area_dynamic_routes
        detector_mapping, dynamic_metadata = area_dynamic_routes.configure(
            cfg, detector_mapping, tuning, state_json=state_json)
        metadata.update(dynamic_metadata)
''')
    after = once(after, '    state = a.traffic_state_from_vissim(\n', '''    if (tuning or {}).get('urban', {}).get('sc2001_corridor'):
        from evaluation.controllers import sc2001_corridor
        metadata.update(sc2001_corridor.configure(cfg, tuning, state_json))
        detector_mapping, state_json, corridor_projection = sc2001_corridor.prepare_projection(
            cfg, detector_mapping, state_json)
        metadata.update(corridor_projection)
    state = a.traffic_state_from_vissim(
''')
    after = once(after, "    if (tuning or {}).get('control_area_objective', {}).get('enabled', False):\n", '''    if getattr(cfg.network, 'sc2001_corridor', None):
        from evaluation.controllers import sc2001_corridor, urban_flow_accounting
        metadata.update(sc2001_corridor.initialize(state, cfg, state_json, detector_mapping))
        metadata.update(urban_flow_accounting.install(a, cfg))
    if (tuning or {}).get('control_area_objective', {}).get('enabled', False):
''')
    after = once(after, "    if getattr(cfg.network, 'control_area_enabled', False):\n", '''    if getattr(cfg.network, 'sc2001_corridor', None):
        from evaluation.controllers import urban_flow_accounting
        metadata.update(urban_flow_accounting.install(a, cfg))
    if getattr(cfg.network, 'control_area_enabled', False):
''')
    changed[target] = (before, after)
    target = 'evaluation/controllers/area_runtime.py'
    before = (ROOT / target).read_text(encoding='utf-8')
    after = once(before, '    routes, arrival_metadata = extend_gate_routes(cfg, routes, membership, root=root, detector_mapping=detector_mapping)\n', '''    routes, arrival_metadata = extend_gate_routes(cfg, routes, membership, root=root, detector_mapping=detector_mapping)
    dynamic_path = getattr(cfg.network, 'dynamic_physical_route_topology_path', None)
    if dynamic_path:
        from evaluation.controllers.area_dynamic_routes import extend_routes
        routes, dynamic_metadata = extend_routes(cfg, routes, detector_mapping, membership, dynamic_path)
        arrival_metadata.update(dynamic_metadata)
''')
    after = once(after, '    cfg.network.control_area_routes = routes\n', '''    cfg.network.control_area_routes = routes
    if getattr(cfg.network, 'sc2001_corridor', None):
        from evaluation.controllers.sc2001_corridor import extend_area_routes
        arrival_metadata.update(extend_area_routes(cfg))
''')
    changed[target] = (before, after)
    target = 'evaluation/controllers/projection_support.py'
    before = (ROOT / target).read_text(encoding='utf-8')
    after = once(before, '    records = complete_records(raw)\n', '''    records = complete_records(raw)
    coverage = document.get('full_area_coverage_audit', {})
    if coverage.get('require_positive_unresolved_failure'):
        unresolved = set(coverage['unresolved_physical_links'])
        active = Counter(str(row['link_no']) for row in records if str(row['link_no']) in unresolved)
        if active:
            raise ValueError('Positive Omega records have unresolved physical stock support: '
                             + str(dict(sorted(active.items(), key=lambda item: int(item[0])))))
''')
    changed[target] = (before, after)
    return changed


def main():
    parts, manifest = [], {}
    for target, (before, after) in sources().items():
        compile(after, target, 'exec')
        raw_before = (ROOT / target).read_bytes() if before else b''
        # This checkout has both LF and CRLF production files. Preserve each
        # file's actual context EOL so git apply needs no whitespace override.
        if raw_before and raw_before.count(b'\r\n') == raw_before.count(b'\n'):
            before, after = before.replace('\n', '\r\n'), after.replace('\n', '\r\n')
        parts.extend(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                     fromfile='a/'+target if before else '/dev/null', tofile='b/'+target))
        manifest[target] = {'before_sha256': hashlib.sha256(before.encode()).hexdigest() if before else None,
                            'after_sha256': hashlib.sha256(after.encode()).hexdigest()}
    (ROOT / 'diagnostics/area_routes_and_sc2001.patch').write_bytes(''.join(parts).encode('utf-8'))
    (ROOT / 'diagnostics/area_routes_and_sc2001_patch_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print('Prepared one combined unapplied package; production files unchanged.')


if __name__ == '__main__':
    main()
