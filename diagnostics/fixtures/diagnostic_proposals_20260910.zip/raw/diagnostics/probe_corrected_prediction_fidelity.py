"""Compare fixed-action 150 s predictions using the final unapplied physics fixture."""
import csv
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'diagnostics'), str(ROOT / 'vendor/NumSim-mine')]
from prepare_freeway_initial_count_patch import installed_proposal


def main():
    run = 'codex_n7_pure_s13_20260910'
    directory = ROOT / 'evaluation/runs' / run
    decisions = directory / f'decisions_{run}'
    segment_path = directory / f'bottleneck_segments_{run}.csv'
    with segment_path.open(encoding='utf-8-sig', newline='') as stream:
        observed = {(int(row['sim_sec']), row['model_link'], int(row['segment_index'])): row
                    for row in csv.DictReader(stream)}
    with (ROOT / 'diagnostics/n7_prediction_fidelity.csv').open(encoding='utf-8', newline='') as stream:
        baseline = {(int(row['start_sec']), row['model_link'], int(row['cell'])): row
                    for row in csv.DictReader(stream) if int(row['horizon_sec']) == 150}
    records = []
    hashes = {}
    with installed_proposal(force_flag=True) as adapter:
        from probe_sc2001_corridor_replay import fixture, proposal_module
        from evaluation.controllers import urban_flow_accounting, area_runtime
        from src.models.demand import DemandStep
        from src.models.state import ControlAction
        for time in (1200, 3300):
            path = decisions / f'state_{time:06d}.json'
            cfg, state, _, raw, detectors = fixture(path, return_detectors=True,
                support_path='diagnostics/physical_projection_support_635_proposal.json')
            action_path = decisions / f'action_{time:06d}.json'
            control = adapter.control_from_json(action_path, cfg, ControlAction)
            tuning = json.loads((ROOT / 'evaluation/configs/n21_n7_20260908.json').read_text(encoding='utf-8'))
            calibration = adapter.load_optional_json(str(ROOT / 'evaluation/calibration/real_world_prediction_calibration_core17legs4b_20260820.json'))
            calibration = adapter.deep_update(dict(calibration), tuning.get('calibration_override', {}))
            demand = adapter.demand_from_state(raw, cfg, DemandStep, 1, calibration, detectors)
            proposal, old_hash, new_hash = proposal_module()
            from src.controllers.rollout_endpoint import evaluate_price_point, ObjectiveSpec
            with patch.object(urban_flow_accounting, 'urban_substep_accounted', proposal.urban_substep_accounted):
                result = evaluate_price_point(state, control, demand, [],
                    ObjectiveSpec(cfg, depth_override=1, box_walk=False, score_mode='raw'))
            final = result.states[-1]
            final._control_area_ledger.assert_stocks(area_runtime.model_inventory(final, cfg))
            assert not result.aborted and len(result.states) == 1 and final.time_sec == time + 150
            for link in cfg.network.freeway_links:
                for cell in range(cfg.network.freeway_segments_per_link):
                    actual = observed[(time + 150, link, cell)]
                    old = baseline[(time, link, cell)]
                    records.append({'start_sec': time, 'horizon_sec': 150, 'model_link': link, 'cell': cell,
                        'actual_speed_kph': float(actual['mean_speed_kph']),
                        'baseline_prediction_speed_kph': float(old['predicted_speed_kph']),
                        'corrected_prediction_speed_kph': final.freeway_speed[link][cell],
                        'actual_density_veh_km_lane': float(actual['density_veh_km_lane']),
                        'baseline_prediction_density': float(old['predicted_density']),
                        'corrected_prediction_density': final.freeway_density[link][cell]})
            for source in (path, action_path):
                hashes[str(source.relative_to(ROOT))] = hashlib.sha256(source.read_bytes()).hexdigest()
            print(json.dumps([row for row in records if row['start_sec'] == time and row['model_link'] == 'FW_E' and row['cell'] == 8]), flush=True)
    payload = {'method': 'Each observed initial state + actual same-time action + one current-rate forecast interval; no candidate search or fitted parameters.',
        'fixes': '635 support, physical branch projection, initial transit pairing, validated/empirical dynamic routes, finite SC2001 and shared69, exact per-cell FW count projection.',
        'limitations': ['Known signal-model timing and offset mismatch remain; no FD/speed calibration change.',
            'Empirical NC13 turn priors are exploratory; seed14 holdout pending.',
            'Density uses the scalar continuity cell coordinates; physical lengths remain for speed/travel geometry.',
            'These are model predictions, not VISSIM counterfactual control outcomes.'],
        'source_sha256': hashes, 'records': records}
    output = ROOT / 'diagnostics/corrected_prediction_fidelity_two_states.json'
    output.write_text(json.dumps(payload, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
