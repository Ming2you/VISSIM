"""Bounded isolated 450 s price-endpoint replays of every saved pure-n7 state."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import pickle
import subprocess
import sys
import time
from unittest.mock import patch
from contextlib import nullcontext

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'diagnostics'), str(ROOT / 'vendor/NumSim-mine')]
BETAS = (0, 60, 150, 300)


def fingerprint(value):
    return hashlib.sha256(pickle.dumps(value, protocol=5)).hexdigest()


def one(path, support_path=None):
    from probe_sc2001_corridor_replay import fixture, proposal_module, Harness
    from evaluation.controllers import urban_flow_accounting, area_runtime
    from src.models.demand import DemandStep
    options = {'support_path': support_path} if support_path else {}
    cfg, state, control, raw = fixture(path, **options)
    from src.controllers.rollout_endpoint import ObjectiveSpec, LeverMove, evaluate_price_point
    proposal, source_hash, proposed_hash = proposal_module()
    from evaluation.controllers.control_area_objective import physical_membership_from_ledger
    physical = physical_membership_from_ledger(json.loads((ROOT / 'diagnostics/control_area_membership.json').read_text(encoding='utf-8')))
    tuning = json.loads((ROOT / 'evaluation/configs/n21_n7_20260908.json').read_text(encoding='utf-8'))
    mapping = json.loads((ROOT / tuning['mapping_json']).read_text(encoding='utf-8'))
    fw_links = {str(link) for row in mapping['freeway_model_links'].values() for link in row['chain_links']}
    raw_counts = raw['vehicle_records']['full_network_link_counts']
    assigned = state.local_observation_summary['projection_diagnostics']['physical_stock_assignment_by_link']
    gaps = {link: count-sum(assigned.get(link, {}).values()) for link, count in raw_counts.items()
            if physical[link] and link not in fw_links and abs(count-sum(assigned.get(link, {}).values())) > 1e-7}
    if gaps:
        raise AssertionError('Initial physical urban observations are unrepresented: ' + str(gaps))
    raw_initial = sum(count for link, count in raw_counts.items() if physical[link])
    modeled_initial = sum(row['inside'] for row in state._control_area_ledger.stocks.values())
    forecast = Harness.adapter.demand_from_state(raw, cfg, DemandStep, 3)
    meter = float(control.ramp_metering['R_F_W'])
    cap = float(cfg.network.ramp_capacity_veh_h['R_F_W'])
    meter_target = min(cap, meter + .1*cap) if meter < .95*cap else max(.2*cap, meter - .1*cap)
    vsl_values = sorted(float(x) for x in cfg.freeway_follower.vsl_set)
    target_vsl = min(vsl_values, key=lambda value: abs(value - 80))
    vsl_keys = [key for key in control.vsl if key.startswith('FW_E__seg') and int(key.split('__seg')[1]) < 6]
    if not vsl_keys:
        vsl_keys = ['FW_E']
    if all(control.vsl[key] == target_vsl for key in vsl_keys):
        target_vsl = max(vsl_values)
    green_now = control.green_times['SC1004_p1']
    green_target = min(cfg.network.signal_green_max('SC1004'), green_now + 10)
    if green_target == green_now:
        green_target = max(cfg.network.green_min, green_now - 10)
    candidates = {'previous': [], 'green_SC1004_primary': [LeverMove('green', 'SC1004', green_target)],
                  'meter_R_F_W': [LeverMove('meter', 'R_F_W', meter_target)],
                  'vsl_FW_E_upstream': [LeverMove('vsl', key, target_vsl) for key in vsl_keys],
                  'offset_SC1004': [LeverMove('offset', 'SC1004', float(control.offsets.get('SC1004', 0)) + 10)]}
    before_state, before_control = fingerprint(state), fingerprint(control)
    scored = {}
    for name, schedule in candidates.items():
        rows = {}
        physics = None
        for beta in BETAS:
            cfg.network.control_area_beta_seconds = beta
            spec = ObjectiveSpec(cfg, depth_override=3, score_mode='price', far_enabled=True,
                                 abort_above=0, box_walk=False)
            with patch.object(urban_flow_accounting, 'urban_substep_accounted', proposal.urban_substep_accounted):
                result = evaluate_price_point(state, control, forecast, schedule, spec)
            last = result.states[-1]
            ledger = last._control_area_ledger
            ledger.assert_stocks(area_runtime.model_inventory(last, cfg))
            if result.aborted or len(result.states) != 3 or result.far != 0:
                raise AssertionError(f'Endpoint horizon/pruning mismatch: aborted={result.aborted}, states={len(result.states)}, far={result.far}, times={[s.time_sec for s in result.states]}')
            metrics = result.control_area
            expected = metrics['ttt_veh_h'] - beta/3600 * metrics['ttd_veh'] + metrics['additional_cost_veh_h']
            if not math.isclose(result.objective, expected, abs_tol=1e-8):
                raise AssertionError('Actual price endpoint does not use TTT minus beta times exits')
            observed = (metrics['ttt_veh_h'], metrics['ttd_veh'], fingerprint(ledger.stocks))
            if physics is None:
                physics = observed
            elif observed != physics:
                raise AssertionError('Changing objective coefficient mutated physical rollout or candidate stock')
            if fingerprint(state) != before_state or fingerprint(control) != before_control:
                raise AssertionError('Candidate evaluation changed its shared observation/action')
            if ledger is state._control_area_ledger:
                raise AssertionError('Candidate reused the observation ledger instance')
            rows[str(beta)] = result.objective
        scored[name] = {'ttt_veh_h': physics[0], 'ttd_veh': physics[1], 'objectives_veh_h': rows,
                        'schedule': [vars(move) for move in schedule], 'event_count': metrics['event_count']}
    # Rerun the opening candidate after every other candidate, then mutate only
    # that result ledger to prove independent copy ownership, not just equality.
    cfg.network.control_area_beta_seconds = 0
    with patch.object(urban_flow_accounting, 'urban_substep_accounted', proposal.urban_substep_accounted):
        repeated = evaluate_price_point(state, control, forecast, [], ObjectiveSpec(cfg, depth_override=3, score_mode='price', box_walk=False))
    if repeated.objective != scored['previous']['objectives_veh_h']['0']:
        raise AssertionError('Candidate order changed the opening candidate score')
    stock = next(iter(repeated.states[-1]._control_area_ledger.stocks.values()))
    stock['inside'] += 1
    if fingerprint(state) != before_state:
        raise AssertionError('Mutating a returned candidate changed the observation ledger')
    rankings = {str(beta): sorted(scored, key=lambda key: scored[key]['objectives_veh_h'][str(beta)]) for beta in BETAS}
    return {'snapshot_sec': state.time_sec, 'horizon_sec': 450, 'source_snapshot': str(path.relative_to(ROOT)),
            'physical_route_coverage_validated': True, 'all_stock_closures_pass': True,
            'candidate_copy_independence': True, 'coefficient_does_not_change_physics': True,
            'actual_price_endpoint_coefficients_verified': True, 'far_and_invalid_pruning_disabled': True,
            'fixed_controls': 'box_walk=False isolates each requested lever for this coverage probe',
            'canonical_urban_source_sha256': source_hash, 'urban_proposal_sha256': proposed_hash,
            'initial_urban_physical_coverage': True, 'raw_initial_omega_veh': raw_initial,
            'model_initial_omega_veh': modeled_initial, 'initial_FW_geometry_delta_veh': raw_initial-modeled_initial,
            'projection_support_path': support_path,
            'scores': scored, 'rankings': rankings,
            'calibration_scope': 'NC seed13 offline route priors; pure n7 seed13 is exploratory, seed14 holdout pending.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--snapshot', type=Path)
    parser.add_argument('--timeout-sec', type=float, default=45)
    parser.add_argument('--support-path')
    parser.add_argument('--exact-freeway-counts', action='store_true')
    parser.add_argument('--conservative-receiving', action='store_true')
    parser.add_argument('--label', default='')
    args = parser.parse_args()
    if args.snapshot:
        from prepare_freeway_initial_count_patch import installed_proposal
        context = installed_proposal(force_flag=True) if args.exact_freeway_counts else nullcontext()
        with context:
            if args.conservative_receiving:
                from prepare_legsplit_receiving_patch import install_isolated
                install_isolated()
            result = one(args.snapshot, args.support_path)
        result['unapplied_exact_freeway_counts'] = args.exact_freeway_counts
        result['unapplied_conservative_receiving'] = args.conservative_receiving
        if args.exact_freeway_counts and abs(result['initial_FW_geometry_delta_veh']) > 1e-7:
            raise AssertionError('Exact per-cell FW projection did not preserve initial Ω N')
        print('AREA_SNAPSHOT=' + json.dumps(result, sort_keys=True))
        return
    run = ROOT / 'evaluation/runs/codex_n7_pure_s13_20260910/decisions_codex_n7_pure_s13_20260910'
    paths = sorted(path for path in run.glob('state_*.json') if 900 <= int(path.stem.split('_')[-1]) <= 5400)
    output = {'snapshots': [], 'failures': [], 'expected_times': list(range(900, 5401, 150)),
              'purpose': 'Offline strict route/stock/copy/price endpoint coverage, not a VISSIM performance result.'}
    suffix = '_' + args.label if args.label else ''
    destination = ROOT / ('diagnostics/area_all_pure_n7_snapshots' + suffix + '.json')
    for path in paths:
        started = time.monotonic()
        try:
            command = [sys.executable, '-X', 'utf8', str(Path(__file__)), '--snapshot', str(path)]
            if args.support_path:
                command += ['--support-path', args.support_path]
            if args.exact_freeway_counts:
                command += ['--exact-freeway-counts']
            if args.conservative_receiving:
                command += ['--conservative-receiving']
            process = subprocess.run(command,
                cwd=ROOT, capture_output=True, text=True, encoding='utf-8', timeout=args.timeout_sec)
            line = next((line for line in process.stdout.splitlines() if line.startswith('AREA_SNAPSHOT=')), None)
            if process.returncode or line is None:
                raise RuntimeError(process.stderr[-5000:] + process.stdout[-1000:])
            result = json.loads(line.split('=', 1)[1])
            output['snapshots'].append(result)
            print(f"PASS t={int(result['snapshot_sec'])} candidates=5 betas=4 elapsed={time.monotonic()-started:.2f}s", flush=True)
        except Exception as exc:
            output['failures'].append({'snapshot': path.name, 'error': str(exc)})
            print(f'FAIL {path.name}: {str(exc)[-500:]}', flush=True)
        output['all_expected_snapshots_present'] = [int(path.stem.split('_')[-1]) for path in paths] == output['expected_times']
        destination.write_text(json.dumps(output, indent=2), encoding='utf-8')
    output['complete'] = output['all_expected_snapshots_present'] and not output['failures'] and len(output['snapshots']) == len(paths)
    destination.write_text(json.dumps(output, indent=2), encoding='utf-8')
    print(json.dumps({'complete': output['complete'], 'passed': len(output['snapshots']), 'failed': len(output['failures'])}))


if __name__ == '__main__':
    main()
