"""Run the existing 31-state endpoint grid with the final single-transfer body."""
import hashlib
from pathlib import Path
import sys
import types
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'diagnostics'), str(ROOT / 'vendor/NumSim-mine')]
import probe_all_area_snapshots as grid


def final_one(path, support_path=None):
    import probe_sc2001_corridor_replay as replay
    from evaluation.controllers import urban_flow_accounting as urban
    from evaluation.controllers import vissim_stackelberg_adapter as adapter
    from build_area_routes_and_sc2001_patch import sources
    from prepare_legsplit_single_transfer_patch import proposed_source
    replay.Harness.setUpClass()
    if not path.is_absolute():
        path = ROOT / path
    replay.proposal_module()  # Installs only the existing corridor module alias.
    before = sources()['evaluation/controllers/urban_flow_accounting.py'][1]
    after = proposed_source(before)
    module = types.ModuleType('diagnostics.grid_single_transfer')
    exec(compile(after, '<isolated single accepted W_out transfer grid>', 'exec'), module.__dict__)
    module._adapter = adapter
    result = (module, hashlib.sha256(before.encode()).hexdigest(), hashlib.sha256(after.encode()).hexdigest())
    with patch.object(replay, 'proposal_module', lambda: result), \
         patch.object(urban, 'legsplit_substep_accounted', module.legsplit_substep_accounted):
        output = original_one(path, support_path)
    output['unapplied_single_accepted_transfer'] = True
    return output


original_one = grid.one
grid.one = final_one
# Existing bounded runner spawns this wrapper, preserving one identical grid
# implementation instead of maintaining a copied driver.
grid.__file__ = __file__


if __name__ == '__main__':
    grid.main()
