"""Compare local predictor fixes on identical observed states and candidates.

This is a local follower intervention probe, not a complete MPC decision or a
VISSIM performance result. Neighbour controls/coupling are held at the supplied
previous action in every arm. Live adapter source and run outputs are untouched.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "vendor/NumSim-mine"), str(ROOT / "diagnostics")]
from probe_model_area_integration import build_projected
from evaluation.controllers import vissim_stackelberg_adapter as adapter
from evaluation.controllers import freeway_local_state as fix
from src.controllers import local_freeway_plant as plant
from src.controllers import wu_faithful_follower as wff
from src.models.state import ControlAction
from src.models.demand import DemandStep


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--state", type=Path, required=True)
    p.add_argument("--previous", type=Path, required=True)
    p.add_argument("--config", type=Path, default=ROOT / "evaluation/configs/n21_n7_20260908.json")
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    cfg, state, detectors, tuning, raw, mapping, _ = build_projected(args.config, args.state, args.previous)
    cal = adapter.load_optional_json(str(ROOT / "evaluation/calibration/real_world_prediction_calibration_core17legs4b_20260820.json"))
    cal = adapter.deep_update(dict(cal), tuning.get("calibration_override", {}))
    previous = adapter.control_from_json(args.previous, cfg, ControlAction)
    forecast = adapter.demand_from_state(raw, cfg, DemandStep, cfg.mpc.horizon_steps, cal, detectors)
    results = []
    for variant, flags in (("n7", (False, False)), ("lane_context", (True, False)),
                           ("conservative_drain", (False, True)), ("both", (True, True))):
        fix.configure(cfg, {"freeway": dict(zip(("local_lane_context", "conservative_offramp_drain"), flags))})
        fix.install(cfg, adapter._FW_SEG_CTX_STATE)
        follower = adapter.build_priced_wu_link_controller(cfg, tuning).nash_solver
        coupling = follower._wu._coupling(state, previous, forecast[0])
        for link in cfg.network.freeway_links:
            for cap in (120.0, 100.0, 80.0):
                profile = [cap if i < 10 else 120.0 for i in range(cfg.network.freeway_segments_per_link)]
                old_step = wff.freeway_substep_local
                trace = []

                def observe(*step_args, **kwargs):
                    result = old_step(*step_args, **kwargs)
                    trace.append(dict(occupancy=dict(step_args[4]), offramp_inflow_vph=result[4],
                                      core_vehicles=sum(result[5])))
                    return result

                wff.freeway_substep_local = observe
                try:
                    chosen, cost, evaluations = follower._solve_freeway_agent_local(
                        link, state.copy(), coupling, forecast[0], previous.copy(), vsl_override=profile)
                finally:
                    wff.freeway_substep_local = old_step
                results.append(dict(variant=variant, link=link, upstream_vsl=cap, local_cost_veh_h=cost,
                    evaluations=evaluations, first=trace[0], last=trace[-1], substeps=len(trace)))
    payload = {"state": str(args.state), "previous": str(args.previous),
        "scope": "Local follower candidates at identical observed state; neighbour coupling frozen; not full MPC/VISSIM",
        "sim_sec": raw["sim_sec"], "rows": results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    for row in results:
        print(row["variant"], row["link"], row["upstream_vsl"], round(row["local_cost_veh_h"], 6), row["last"]["occupancy"])


if __name__ == "__main__":
    main()
