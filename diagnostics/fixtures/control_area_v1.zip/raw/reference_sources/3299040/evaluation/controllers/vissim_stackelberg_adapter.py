from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Mapping, MutableMapping, Sequence


WORKSPACE_ROOT = Path(__file__).resolve().parents[2]
if str(WORKSPACE_ROOT) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_ROOT))
PLANT_PACKAGE_ROOT = WORKSPACE_ROOT / "plant" / "src"
if str(PLANT_PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PLANT_PACKAGE_ROOT))
from vissim_strict import (
    ProjectionReferenceValidationError,
    load_validated_approved_topology,
    load_bounded_json_snapshot,
    project_vehicle_records,
    publish_projection_outputs,
    validate_physical_projection_reference,
    validate_projection_output_paths,
    validate_run_manifest,
)
from vissim_strict.physical_projection import (
    file_sha256 as strict_file_sha256,
    freeze_json,
    json_type_strict_equal,
    normalize_vehicle_records,
    thaw_json,
)
from vissim_strict.physical_projection_reference import MAX_STATE_BYTES
# N4-5: SG 단위 액추에이션 계획. 순수 함수만 들어 있어 import 부작용이 없다.
from evaluation.controllers import action_csv_schema
from evaluation.controllers import diagnostic_profile
from evaluation.controllers import diagnostic_signal_profile
from evaluation.controllers import offset_promotion
from evaluation.controllers import observation_projection
from evaluation.controllers import plant_cycle
from evaluation.controllers import signal_group_plan
from vissim_strict.run_evidence import (
    MAX_APPROVAL_BYTES,
    MAX_RUN_MANIFEST_BYTES,
    MAX_TOPOLOGY_BYTES,
    resolve_canonical_workspace_destination,
    resolve_canonical_workspace_file,
)
# 2026-07-31: 기본 모델 저장소를 NUMSIM_REPO_ROOT env → NumSim-mine(flagship-ms-adapt-clean,
# HEAD 7f10393) 순서로 결정한다. 과거 경로 이력(재현용):
#   - "C:/Users/TRLAB/Desktop/찐찐막/Numerical-Sim": 비-git 스냅샷(default.yaml nu_cong=65/
#     capacity_drop=false). nu_cong 격리 재현의 A/B 기준으로만 --repo-root로 명시 지정.
#   - "C:/Users/TRLAB/Desktop/찐찐막/Numerical-Sim-git": GitHub HEAD 0e07c1c 추적 클론
#     (2026-06-29 audit follow-up). 이 머신에는 없음.
_BUNDLED_NUMSIM_ROOT = WORKSPACE_ROOT / "vendor" / "NumSim-mine"
DEFAULT_REPO_ROOT = Path(
    os.environ.get("NUMSIM_REPO_ROOT")
    or (_BUNDLED_NUMSIM_ROOT if _BUNDLED_NUMSIM_ROOT.is_dir() else WORKSPACE_ROOT.parent / "NumSim-mine")
)
DEFAULT_MAPPING = WORKSPACE_ROOT / "evaluation/vsl_install/vsl_segment_mapping_8seg.json"
DEFAULT_CALIBRATION = WORKSPACE_ROOT / "evaluation/calibration/vissim_network_calibration_v2_8seg_20260714.json"
DEFAULT_DETECTOR_MAPPING = WORKSPACE_ROOT / "evaluation/detector_install/detector_local_mapping.json"
LOCAL_OBSERVATION_INTERNAL_STORAGE_FRACTION = 0.35
LOCAL_OBSERVATION_OFFRAMP_STORAGE_FRACTION = 0.50
# 2026-08-15: 결정마다 상태를 다시 지을 때 release 스케줄을 plant 가 짓게 하는 warm-up 길이.
# 0 이면 꺼진다(`RW_WARMSTART_SEC` 로 덮어쓴다). 자세한 근거는 warm_start_release_buffers.
#
# 실런 A/B 3쌍(시드 13, 1800 s, 제어창 [900,1800])에서 전부 개선이라 기본으로 켠다.
#   demand 0.75  ΔJ -7.934 veh·h (-1.37%)
#   demand 1.00  ΔJ -7.468 veh·h (-0.94%)
#   demand 1.25  ΔJ -4.684 veh·h (-0.45%)
# eps_J_vissim 이 1e-6 veh·h 라 가장 작은 -4.684 도 재료성이 460만 배 여유로 확정된다.
# 혼잡할수록 효과가 주는 것은 저류가 차 있을수록 빈 버퍼 왜곡이 작아지기 때문이다.
DEFAULT_WARMSTART_SEC = 900.0

# 생산 저류 용량 측정 근거(jam 168.18). 두 곳이 쓴다.
#   1) execution_fingerprint_sha256 의 증거 목록 - 여기가 낡으면 런이 자기가 쓰지도 않은
#      격자를 썼다고 기록한다(2026-08-16 에 _ovr_20260814 에서 옮겼다).
#   2) `_storage_effective_lanes` 의 차로수 유도.
# 런타임 용량 자체는 tuning config 인라인에서 온다 - 이 파일은 그 값의 출처 증거다.
STORAGE_CAPACITY_EVIDENCE_JSON = WORKSPACE_ROOT / "outputs" / "urban_storage_capacity_jam168_20260815.json"


def _b1a_existing_path(path_text: str) -> Path:
    """Resolve one canonical B1a CLI file below the checked-out workspace."""

    candidate = Path(path_text)
    if candidate.is_absolute():
        candidate = candidate.resolve(strict=True)
        relative = candidate.relative_to(WORKSPACE_ROOT.resolve(strict=True)).as_posix()
    else:
        relative = path_text
    return resolve_canonical_workspace_file(WORKSPACE_ROOT, relative)


def _b1a_destination_path(path_text: str) -> Path:
    candidate = Path(path_text)
    if candidate.is_absolute():
        candidate = candidate.resolve(strict=False)
        relative = candidate.relative_to(WORKSPACE_ROOT.resolve(strict=True)).as_posix()
    else:
        relative = path_text
    return resolve_canonical_workspace_destination(WORKSPACE_ROOT, relative)


def _validate_b1a_adapter_source(manifest) -> None:
    expected = manifest.resolved_paths["producer_sources.adapter"]
    actual = Path(__file__).resolve(strict=True)
    if expected != actual or strict_file_sha256(actual) != manifest.artifact["producer_sources"]["adapter"]["file_sha256"]:
        raise ProjectionReferenceValidationError(["adapter executed-source binding mismatch"])


def _validate_b1a_projection_inputs(
    *,
    run_manifest_path: Path,
    topology_path: Path,
    state_path: Path,
):
    manifest_snapshot = load_bounded_json_snapshot(
        run_manifest_path, max_bytes=MAX_RUN_MANIFEST_BYTES
    )
    manifest = validate_run_manifest(
        manifest_snapshot.value, workspace_root=WORKSPACE_ROOT
    )
    _validate_b1a_adapter_source(manifest)
    approved = manifest.artifact["approved_topology"]
    expected_topology = manifest.resolved_paths["approved_topology.topology_path"]
    approved_topology = load_validated_approved_topology(
        manifest, workspace_root=WORKSPACE_ROOT
    )
    if (
        topology_path != expected_topology
        or topology_path != approved_topology.topology_snapshot.path
        or approved_topology.topology_snapshot.file_sha256
        != approved["topology_file_sha256"]
    ):
        raise ProjectionReferenceValidationError(["caller topology differs from immutable approved topology"])
    state_snapshot = load_bounded_json_snapshot(
        state_path, max_bytes=MAX_STATE_BYTES
    )
    state = state_snapshot.value
    run_id = manifest.artifact["run_id"]
    sim_sec = state.get("sim_sec") if isinstance(state, Mapping) else None
    if type(sim_sec) is not float or not math.isfinite(sim_sec) or sim_sec < 0.0:
        raise ProjectionReferenceValidationError(
            ["state sim_sec must be a finite nonnegative JSON double"]
        )
    manifest = validate_run_manifest(
        manifest_snapshot.value,
        workspace_root=WORKSPACE_ROOT,
        expected_run_id=run_id,
        capture_time=sim_sec,
    )
    provenance = state.get("run_provenance") if isinstance(state, Mapping) else None
    expected_provenance = {
        "run_id": run_id,
        "manifest_path": run_manifest_path.relative_to(WORKSPACE_ROOT).as_posix(),
        "manifest_sha256": manifest_snapshot.file_sha256,
    }
    if not isinstance(provenance, Mapping) or not json_type_strict_equal(
        provenance, expected_provenance
    ):
        raise ProjectionReferenceValidationError(["state/run manifest provenance mismatch"])
    return manifest_snapshot, manifest, approved_topology, state_snapshot


_PROJECTION_VALUE_OPTIONS = (
    "--state-json",
    "--run-manifest",
    "--approved-topology",
    "--out-projection-sidecar",
    "--out-projection-reference",
)
_PROJECTION_OPTIONS = ("--projection-only", *_PROJECTION_VALUE_OPTIONS)


def _parser_accepts_split_value(
    parser: argparse.ArgumentParser, token: str
) -> bool:
    """Use argparse's own option classifier for required split values."""

    return token != "--" and parser._parse_optional(token) is None


def _preparse_projection_roles(
    argv: Sequence[str], parser: argparse.ArgumentParser
) -> dict[str, Any]:
    """Collect projection roles without enforcing unrelated argparse choices."""

    values: dict[str, list[str | None]] = {
        option: [] for option in _PROJECTION_VALUE_OPTIONS
    }
    rejected_role_values: list[str] = []
    projection_only = False
    index = 0
    while index < len(argv):
        token = str(argv[index])
        if token == "--":
            break
        if token == "--projection-only":
            projection_only = True
        matched = False
        for option in _PROJECTION_VALUE_OPTIONS:
            if token == option:
                next_index = index + 1
                value = None
                if next_index < len(argv) and _parser_accepts_split_value(
                    parser, str(argv[next_index])
                ):
                    value = str(argv[next_index])
                    index = next_index
                values[option].append(value)
                matched = True
                break
            prefix = option + "="
            if token.startswith(prefix):
                value = token[len(prefix):]
                values[option].append(value or None)
                matched = True
                break
        if not matched and token.startswith("--"):
            option_text, separator, inline_value = token.partition("=")
            if option_text not in _PROJECTION_OPTIONS and any(
                option.startswith(option_text) for option in _PROJECTION_OPTIONS
            ):
                value = inline_value if separator else None
                next_index = index + 1
                if (
                    value is None
                    and next_index < len(argv)
                    and _parser_accepts_split_value(
                        parser, str(argv[next_index])
                    )
                ):
                    value = str(argv[next_index])
                    index = next_index
                if value:
                    rejected_role_values.append(value)
                matched = True
        index += 1
        if matched:
            continue
    return {
        "projection_only": projection_only,
        "values": values,
        "rejected_role_values": rejected_role_values,
    }


def _last_projection_role(
    preparse: Mapping[str, Any], option: str
) -> str:
    values = preparse.get("values", {}).get(option, [])
    if not isinstance(values, list) or not values:
        return ""
    value = values[-1]
    return value if isinstance(value, str) else ""


def _lexical_workspace_role(path_text: str) -> Path:
    """Preserve authored spelling while retaining existing-file identity."""

    if not isinstance(path_text, str) or not path_text:
        raise ValueError("declared projection role path is empty")
    candidate = Path(path_text)
    return candidate if candidate.is_absolute() else WORKSPACE_ROOT / candidate


def _declared_manifest_role_values(manifest_value: Any) -> dict[str, str]:
    """Collect authored role strings before exact path resolution can reject one."""

    if not isinstance(manifest_value, Mapping):
        return {}
    declared: dict[str, Any] = {}
    approved = manifest_value.get("approved_topology")
    if isinstance(approved, Mapping):
        declared["approval"] = approved.get("approving_manifest_path")
        declared["topology_manifest"] = approved.get("topology_path")
    preflight = manifest_value.get("preflight")
    if isinstance(preflight, Mapping):
        declared["preflight"] = preflight.get("path")
    for container_name in ("producer_sources",):
        container = manifest_value.get(container_name)
        if isinstance(container, Mapping):
            for role, binding in container.items():
                if isinstance(binding, Mapping):
                    declared[f"{container_name}.{role}"] = binding.get("path")
    configuration = manifest_value.get("configuration")
    inputs = configuration.get("inputs") if isinstance(configuration, Mapping) else None
    if isinstance(inputs, Mapping):
        for role, binding in inputs.items():
            if isinstance(binding, Mapping) and binding.get("path") is not None:
                declared[f"configuration.inputs.{role}"] = binding.get("path")
    policy = manifest_value.get("supported_version_policy")
    if isinstance(policy, Mapping):
        declared["supported_version_policy"] = policy.get("path")
    collected: dict[str, str] = {}
    for role, value in declared.items():
        if isinstance(value, str) and value:
            collected[role] = value
    return collected


def _prepare_projection_output_roles(
    args,
    preparse: Mapping[str, Any],
):
    """Authorize the complete immutable universe, then invalidate the reference."""

    if not args.out_projection_reference:
        return None, None, {}, False
    reference_path = _b1a_destination_path(args.out_projection_reference)
    immutable_paths: dict[str, Path] = {
        "adapter_source": Path(__file__).resolve(strict=True),
    }
    effective_roles = (
        ("--state-json", "state_json", "state_effective", True),
        ("--run-manifest", "run_manifest", "run_manifest_effective", True),
        (
            "--approved-topology",
            "approved_topology",
            "topology_effective",
            True,
        ),
        (
            "--out-projection-sidecar",
            "out_projection_sidecar",
            "sidecar_effective",
            False,
        ),
        (
            "--out-projection-reference",
            "out_projection_reference",
            "reference_effective",
            False,
        ),
    )
    for option, attribute, role, is_input in effective_roles:
        value = getattr(args, attribute, "")
        if value and is_input:
            immutable_paths[role] = _lexical_workspace_role(value)
        if value != _last_projection_role(preparse, option):
            raise ProjectionReferenceValidationError(
                [f"projection parser/preparse role mismatch: {option}"]
            )
    if bool(getattr(args, "projection_only", True)) != bool(
        preparse.get("projection_only")
    ):
        raise ProjectionReferenceValidationError(
            ["projection parser/preparse role mismatch: --projection-only"]
        )
    raw_values = preparse.get("values", {})
    rejected_role_values = preparse.get("rejected_role_values", [])
    if not isinstance(rejected_role_values, list):
        raise ProjectionReferenceValidationError(
            ["projection preparse rejected-role set is invalid"]
        )
    for index, value in enumerate(rejected_role_values):
        if isinstance(value, str) and value:
            immutable_paths[f"rejected_role[{index}]"] = (
                _lexical_workspace_role(value)
            )
    for option, role in (
        ("--state-json", "state_cli"),
        ("--run-manifest", "run_manifest_cli"),
        ("--approved-topology", "topology_cli"),
    ):
        values = raw_values.get(option, []) if isinstance(raw_values, Mapping) else []
        if not isinstance(values, list):
            raise ProjectionReferenceValidationError(
                [f"projection preparse role is invalid: {option}"]
            )
        for index, value in enumerate(values):
            if isinstance(value, str) and value:
                immutable_paths[f"{role}[{index}]"] = _lexical_workspace_role(value)

    sidecar_values = (
        raw_values.get("--out-projection-sidecar", [])
        if isinstance(raw_values, Mapping)
        else []
    )
    if not isinstance(sidecar_values, list):
        raise ProjectionReferenceValidationError(
            ["projection sidecar preparse role is invalid"]
        )
    for index, value in enumerate(sidecar_values[:-1]):
        if isinstance(value, str) and value:
            immutable_paths[f"superseded_sidecar[{index}]"] = (
                _lexical_workspace_role(value)
            )
    sidecar_candidate = (
        _lexical_workspace_role(args.out_projection_sidecar)
        if args.out_projection_sidecar
        else None
    )

    reference_values = (
        raw_values.get("--out-projection-reference", [])
        if isinstance(raw_values, Mapping)
        else []
    )
    if not isinstance(reference_values, list):
        raise ProjectionReferenceValidationError(
            ["projection reference preparse role is invalid"]
        )
    for index, value in enumerate(reference_values[:-1]):
        if isinstance(value, str) and value != args.out_projection_reference:
            immutable_paths[f"superseded_reference[{index}]"] = (
                _lexical_workspace_role(value)
            )

    manifest_text = args.run_manifest or _last_projection_role(
        preparse, "--run-manifest"
    )
    if not manifest_text:
        raise ProjectionReferenceValidationError(
            ["run manifest is required to authorize projection outputs"]
        )
    manifest_candidate = _lexical_workspace_role(manifest_text)
    manifest_snapshot = load_bounded_json_snapshot(
        manifest_candidate, max_bytes=MAX_RUN_MANIFEST_BYTES
    )
    immutable_paths["run_manifest_snapshot"] = manifest_snapshot.path
    declared_manifest_roles = _declared_manifest_role_values(
        manifest_snapshot.value
    )
    for role, value in declared_manifest_roles.items():
        immutable_paths[f"manifest.{role}"] = _lexical_workspace_role(value)

    manifest_approved = (
        manifest_snapshot.value.get("approved_topology")
        if isinstance(manifest_snapshot.value, Mapping)
        else None
    )
    if not isinstance(manifest_approved, Mapping):
        raise ProjectionReferenceValidationError(
            ["run manifest approval binding is unavailable"]
        )
    approval_text = manifest_approved.get("approving_manifest_path")
    approval_hash = manifest_approved.get("approving_manifest_sha256")
    if not isinstance(approval_text, str) or not approval_text:
        raise ProjectionReferenceValidationError(
            ["run manifest approval path is invalid"]
        )
    approval_candidate = _lexical_workspace_role(approval_text)
    immutable_paths["approval_declared"] = approval_candidate
    approval_snapshot = load_bounded_json_snapshot(
        approval_candidate, max_bytes=MAX_APPROVAL_BYTES
    )
    if approval_snapshot.file_sha256 != approval_hash:
        raise ProjectionReferenceValidationError(
            ["run manifest approval snapshot hash mismatch"]
        )
    immutable_paths["approval_snapshot"] = approval_snapshot.path

    source_inputs = (
        approval_snapshot.value.get("source_inputs")
        if isinstance(approval_snapshot.value, Mapping)
        else None
    )
    lane_graph_binding = (
        source_inputs.get("lane_graph")
        if isinstance(source_inputs, Mapping)
        else None
    )
    if not isinstance(lane_graph_binding, Mapping) or set(lane_graph_binding) != {
        "path", "file_sha256", "semantic_sha256"
    }:
        raise ProjectionReferenceValidationError(
            ["approval lane graph binding is invalid"]
        )
    lane_graph_text = lane_graph_binding.get("path")
    if not isinstance(lane_graph_text, str) or not lane_graph_text:
        raise ProjectionReferenceValidationError(
            ["approval lane graph path is invalid"]
        )
    lane_graph_candidate = _lexical_workspace_role(lane_graph_text)
    immutable_paths["lane_graph_declared"] = lane_graph_candidate
    lane_graph_snapshot = load_bounded_json_snapshot(
        lane_graph_candidate, max_bytes=MAX_TOPOLOGY_BYTES
    )
    if lane_graph_snapshot.file_sha256 != lane_graph_binding.get("file_sha256"):
        raise ProjectionReferenceValidationError(
            ["approval lane graph snapshot hash mismatch"]
        )
    immutable_paths["lane_graph_snapshot"] = lane_graph_snapshot.path

    manifest = validate_run_manifest(
        manifest_snapshot.value, workspace_root=WORKSPACE_ROOT
    )
    approved_topology = load_validated_approved_topology(
        manifest, workspace_root=WORKSPACE_ROOT
    )
    if (
        approval_snapshot.data != approved_topology.approval_snapshot.data
        or approval_snapshot.file_sha256
        != approved_topology.approval_snapshot.file_sha256
        or lane_graph_snapshot.data != approved_topology.lane_graph_snapshot.data
        or lane_graph_snapshot.file_sha256
        != approved_topology.lane_graph_snapshot.file_sha256
    ):
        raise ProjectionReferenceValidationError(
            ["projection authorization companions changed during validation"]
        )
    immutable_paths.update({
        str(role): path for role, path in manifest.resolved_paths.items()
    })
    immutable_paths.update({
        "approval": approved_topology.approval_snapshot.path,
        "lane_graph": approved_topology.lane_graph_snapshot.path,
        "topology": approved_topology.topology_snapshot.path,
    })
    output_authorization_error = None
    try:
        validate_projection_output_paths(
            sidecar_candidate,
            reference_path,
            immutable_paths=immutable_paths,
        )
    except ProjectionReferenceValidationError as exc:
        output_authorization_error = exc
    validate_projection_output_paths(
        None,
        reference_path,
        immutable_paths=immutable_paths,
    )
    reference_path.unlink(missing_ok=True)
    if output_authorization_error is not None:
        raise output_authorization_error
    sidecar_path = (
        _b1a_destination_path(args.out_projection_sidecar)
        if args.out_projection_sidecar
        else None
    )
    return sidecar_path, reference_path, immutable_paths, True


def _invalidate_projection_reference_after_parser_failure(
    preparse: Mapping[str, Any],
) -> None:
    if not bool(preparse.get("projection_only")):
        return
    reference_text = _last_projection_role(
        preparse, "--out-projection-reference"
    )
    if not reference_text:
        return

    try:
        args = argparse.Namespace(
            projection_only=True,
            state_json=_last_projection_role(preparse, "--state-json"),
            run_manifest=_last_projection_role(preparse, "--run-manifest"),
            approved_topology=_last_projection_role(
                preparse, "--approved-topology"
            ),
            out_projection_sidecar=_last_projection_role(
                preparse, "--out-projection-sidecar"
            ),
            out_projection_reference=reference_text,
        )
        _prepare_projection_output_roles(args, preparse)
    except BaseException:
        # Parser failure remains authoritative; unsafe or incomplete role
        # authorization deliberately leaves every file untouched.
        return


def _projection_provenance(validated) -> dict[str, Any]:
    reference = validated.artifact
    return {
        "schema_version": "physical-projection-action-provenance-v2.1",
        "qualification": thaw_json(reference["qualification"]),
        "run_id": reference["run_id"],
        "sim_sec": reference["sim_sec"],
        "run_manifest_path": validated.run_manifest_snapshot.path.relative_to(WORKSPACE_ROOT).as_posix(),
        "run_manifest_sha256": reference["run_manifest_sha256"],
        "state_path": reference["state_path"],
        "state_file_sha256": reference["state_file_sha256"],
        "topology_path": validated.topology_path.relative_to(WORKSPACE_ROOT).as_posix(),
        "topology_file_sha256": reference["topology_file_sha256"],
        "topology_semantic_sha256": reference["topology_semantic_sha256"],
        "projection_sidecar_path": reference["projection_sidecar_path"],
        "projection_sidecar_file_sha256": reference["projection_sidecar_file_sha256"],
        "projection_sidecar_semantic_sha256": reference["projection_sidecar_semantic_sha256"],
        "projection_reference_path": validated.reference_path.relative_to(WORKSPACE_ROOT).as_posix(),
        "projection_reference_file_sha256": validated.reference_file_sha256,
        "projection_reference_semantic_sha256": reference["semantic_sha256"],
        "normalized_projection_sha256": reference["normalized_projection_sha256"],
        "record_count": reference["record_count"],
        "assigned_count": reference["assigned_count"],
        "stock_total": reference["stock_total"],
        "global_residual": reference["global_residual"],
    }


def _b1a_state_construction_input(validated) -> Mapping[str, Any]:
    """Create the required B1a observation boundary without B1b dynamics."""

    state = thaw_json(validated.state)
    ledger = thaw_json(validated.sidecar)
    records = {
        record["veh_no"]: record
        for record in state["vehicle_records"]["records"]
    }
    link_counts: dict[str, int] = {}
    link_speed_totals: dict[str, float] = {}
    link_stopped: dict[str, int] = {}
    queue_tails: dict[str, float] = {}
    for assignment in ledger["vehicle_assignments"]:
        record = records[assignment["veh_no"]]
        link = str(assignment["source_link_no"])
        link_counts[link] = link_counts.get(link, 0) + 1
        link_speed_totals[link] = link_speed_totals.get(link, 0.0) + record["speed_kph"]
        link_stopped[link] = link_stopped.get(link, 0) + int(record["stopped"])
        queue_tails[link] = min(
            queue_tails.get(link, record["position_m"]), record["position_m"]
        )
    link_speeds = {
        link: link_speed_totals[link] / count
        for link, count in link_counts.items()
    }
    return freeze_json({
        "provenance": _projection_provenance(validated),
        "ledger": ledger,
        "local_observation": {
            "link_counts": link_counts,
            "link_speeds_kph": link_speeds,
            "link_stopped_counts": link_stopped,
            "link_queue_tail_pos_m": queue_tails,
        },
    })


def _state_json_from_b1a_projection(validated) -> tuple[dict[str, Any], Mapping[str, Any]]:
    projection_input = _b1a_state_construction_input(validated)
    state_json = thaw_json(validated.state)
    state_json["local_observation"] = thaw_json(
        projection_input["local_observation"]
    )
    state_json["physical_projection"] = thaw_json(projection_input["ledger"])
    return state_json, projection_input


# 8-seg plant (2026-07-14): one ramp junction per segment, indices in travel
# direction. Matches the Numerical-Sim feature/segment-agents-13p default.yaml
# geometry (segments 8, off 2/4, merge 3/5); see the index-override comment in
# build_config for the westbound swap.
SEGMENT_TO_MODEL = {
    "EB_S0_W_EXT_ENTRY": ("FW_E", 0),
    "EB_S1_W_APPROACH": ("FW_E", 1),
    "EB_S2_D_DIVERGE": ("FW_E", 2),
    "EB_S3_D_MERGE": ("FW_E", 3),
    "EB_S4_F_DIVERGE": ("FW_E", 4),
    "EB_S5_F_MERGE": ("FW_E", 5),
    "EB_S6_POST_F": ("FW_E", 6),
    "EB_S7_E_EXIT": ("FW_E", 7),
    "WB_S0_E_EXT_ENTRY": ("FW_W", 0),
    "WB_S1_E_APPROACH": ("FW_W", 1),
    "WB_S2_F_DIVERGE": ("FW_W", 2),
    "WB_S3_F_MERGE": ("FW_W", 3),
    "WB_S4_D_DIVERGE": ("FW_W", 4),
    "WB_S5_D_MERGE": ("FW_W", 5),
    "WB_S6_POST_D": ("FW_W", 6),
    "WB_S7_W_EXIT": ("FW_W", 7),
}


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def nearest(value: float, candidates: list[float]) -> float:
    return float(min(candidates, key=lambda x: abs(float(x) - float(value))))


def deep_update(base: dict[str, Any], override: Mapping[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(out.get(key), Mapping):
            out[key] = deep_update(dict(out[key]), value)
        else:
            out[key] = value
    return out


def load_optional_json(path_text: str) -> dict[str, Any]:
    if not path_text:
        return {}
    path = Path(path_text)
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return {}
    extends = data.get("extends", "")
    if not extends:
        return data
    parent_path = Path(str(extends))
    if not parent_path.is_absolute():
        parent_path = path.parent / parent_path
    parent = load_optional_json(str(parent_path))
    child = dict(data)
    child.pop("extends", None)
    return deep_update(parent, child)


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _calibration_child(calibration: Mapping[str, Any], section: str, child: str) -> Mapping[str, Any]:
    parent = _mapping(calibration.get(section))
    nested = _mapping(parent.get(child))
    if nested:
        return nested
    return _mapping(calibration.get(child))


def _segment_length_profile_km(calibration: Mapping[str, Any]) -> dict[str, list[float]]:
    physical = _mapping(calibration.get("physical_inventory"))
    raw = _mapping(physical.get("freeway_segment_length_profile_km"))
    profile: dict[str, list[float]] = {}
    for link, values in raw.items():
        lengths: list[float] = []
        if isinstance(values, list):
            lengths = [max(1.0e-6, _as_float(value)) for value in values]
        elif isinstance(values, Mapping):
            for key in sorted(values, key=lambda item: int(item) if str(item).isdigit() else str(item)):
                lengths.append(max(1.0e-6, _as_float(values[key])))
        if lengths:
            profile[str(link)] = lengths
    return profile


def _freeway_segment_lengths_km(cfg, link: str, count: int) -> list[float]:
    net = cfg.network
    profile = getattr(net, "freeway_segment_length_profile_km", {})
    values: list[float] = []
    if isinstance(profile, Mapping):
        raw = profile.get(str(link), profile.get(link, []))
        if isinstance(raw, list):
            values = [max(1.0e-6, _as_float(value)) for value in raw]
    if len(values) >= count:
        return values[:count]
    base = max(1.0e-6, float(getattr(net, "freeway_segment_length_km", 0.58)))
    if values:
        values = values + [base] * max(0, count - len(values))
        return values[:count]
    return [base] * max(0, count)


def _freeway_vehicle_count_by_link(state, cfg) -> dict[str, list[float]]:
    """Return segment vehicle counts using Vissim-specific length profiles when available."""
    net = cfg.network
    state.ensure_freeway_lane_profile(net)
    counts: dict[str, list[float]] = {}
    physical_counts = bool(getattr(net, "physical_vehicle_counts", False))
    lane_floor = 1.0e-9 if physical_counts else 1.0
    lane_profile = getattr(state, "freeway_effective_lanes" if physical_counts else "freeway_lanes", {})
    for link in net.freeway_links:
        key = str(link)
        densities = [float(value) for value in state.freeway_density.get(key, [])]
        lengths = _freeway_segment_lengths_km(cfg, key, len(densities))
        raw_lanes = lane_profile.get(key, []) if isinstance(lane_profile, Mapping) else []
        lanes = [
            max(lane_floor, _as_float(raw_lanes[i], getattr(net, "freeway_lanes", 2)))
            if i < len(raw_lanes)
            else max(lane_floor, float(getattr(net, "freeway_lanes", 2)))
            for i in range(len(densities))
        ]
        counts[key] = [
            max(0.0, rho) * lengths[i] * lanes[i]
            for i, rho in enumerate(densities)
        ]
    return counts


def _vsl_rollout_tuning(tuning: Mapping[str, Any]) -> Mapping[str, Any]:
    adapter = _mapping(tuning.get("adapter"))
    return _mapping(adapter.get("vsl_metanet_rollout"))


def _is_enabled(settings: Mapping[str, Any]) -> bool:
    return str(settings.get("enabled", False)).lower() in {"1", "true", "yes", "on"}


def _off_ramp_ratio_by_segment(cfg, link: str, count: int) -> list[float]:
    net = cfg.network
    out = [0.0 for _ in range(count)]
    for off_ramp in getattr(net, "off_ramps", []):
        if str(net.off_ramp_from_freeway.get(off_ramp, "")) != str(link):
            continue
        raw_idx = getattr(net, "off_ramp_segment_index", {}).get(off_ramp, count - 1)
        idx = int(clamp(_as_float(raw_idx), 0.0, float(max(0, count - 1))))
        out[idx] = clamp(out[idx] + _as_float(net.off_ramp_split_ratio.get(off_ramp), 0.0), 0.0, 1.0)
    return out


def _vsl_aware_link_rollout_terms(
    context: Mapping[str, Any],
    vsl_kph: float,
    cfg,
    metanet_module,
) -> tuple[float, float, float, float, float] | None:
    """Small Vissim-only link rollout used to rank VSL candidates.

    The stock local follower computes candidate freeway TTS before the VSL loop,
    so all VSL candidates inherit the same freeway/density terms. This helper
    gives the adapter a candidate-specific METANET/CTM approximation without
    editing the external Numerical-Sim checkout.
    """
    agent = context.get("agent")
    state = context.get("state")
    forecast = list(context.get("forecast") or [])
    lane_profile = _mapping(context.get("lane_profile"))
    ramp_metering = _mapping(context.get("ramp_metering"))
    upper = _mapping(context.get("upper"))
    if agent is None or state is None or not forecast:
        return None

    net = cfg.network
    link = str(agent.link)
    rhos = [max(0.0, _as_float(value)) for value in state.freeway_density.get(link, [])]
    if not rhos:
        return None
    speeds_raw = state.freeway_speed.get(link, [])
    speeds = [
        max(float(getattr(net, "v_min", 5.0)), _as_float(speeds_raw[i], getattr(net, "v_free", 120.0)))
        if i < len(speeds_raw)
        else float(getattr(net, "v_free", 120.0))
        for i in range(len(rhos))
    ]
    raw_lanes = lane_profile.get(link, []) if isinstance(lane_profile, Mapping) else []
    lanes = [
        max(1.0e-9, _as_float(raw_lanes[i], getattr(net, "freeway_lanes", 4)))
        if i < len(raw_lanes)
        else max(1.0e-9, float(getattr(net, "freeway_lanes", 4)))
        for i in range(len(rhos))
    ]
    lengths = _freeway_segment_lengths_km(cfg, link, len(rhos))
    off_ratios = _off_ramp_ratio_by_segment(cfg, link, len(rhos))
    dt_h = float(cfg.simulation.T_c_h)
    horizon_steps = forecast[: max(1, int(getattr(cfg.mpc, "horizon_steps", 1)))]
    max_vsl = max(float(value) for value in cfg.freeway_follower.vsl_set)
    vsl_active = float(vsl_kph) < max_vsl - 0.5
    merge_idx = int(clamp(
        getattr(agent, "segment_index", len(rhos) // 2),
        0.0,
        float(max(0, len(rhos) - 1)),
    ))
    release = sum(
        min(
            max(0.0, _as_float(ramp_metering.get(ramp))),
            max(0.0, _as_float(upper.get(ramp), ramp_metering.get(ramp, 0.0))),
        )
        for ramp in getattr(agent, "ramps", [])
    )

    vehicle_tts = 0.0
    density_excess_tts = 0.0
    peak_density = max(rhos)
    capacity = max(0.0, float(getattr(net, "freeway_capacity_veh_h", 0.0)))
    for step in horizon_steps:
        q_values = [
            metanet_module.segment_flow_veh_h(rho, speed, lane)
            for rho, speed, lane in zip(rhos, speeds, lanes)
        ]
        if capacity > 0.0:
            q_values = [min(q, capacity) for q in q_values]
        receiving = [
            max(0.0, (float(net.rho_max) - rhos[i]) * lengths[i] * lanes[i] / max(dt_h, 1.0e-9))
            for i in range(len(rhos))
        ]
        sending = [
            (1.0 - off_ratios[i]) * q_values[i]
            for i in range(len(rhos))
        ]
        q_inter = [
            min(sending[i], receiving[i + 1])
            for i in range(len(rhos) - 1)
        ]
        mainline_demand = max(0.0, _as_float(step.freeway_mainline.get(link, 0.0)))
        entry_flow = min(mainline_demand, capacity if capacity > 0.0 else mainline_demand, receiving[0])
        next_rhos: list[float] = []
        next_speeds: list[float] = []
        for i, rho in enumerate(rhos):
            q_in = entry_flow if i == 0 else q_inter[i - 1]
            if i == merge_idx:
                q_in += release
            q_out = sending[i] if i == len(rhos) - 1 else q_inter[i]
            veh_per_density = max(1.0e-9, lengths[i] * lanes[i])
            rho_next = clamp(
                rho + (q_in - q_out) * dt_h / veh_per_density,
                0.0,
                float(net.rho_max),
            )
            vehicle_tts += 0.5 * (rho + rho_next) * veh_per_density * dt_h
            density_excess_tts += 0.5 * (
                max(0.0, rho - float(net.rho_crit)) + max(0.0, rho_next - float(net.rho_crit))
            ) * dt_h
            upstream_speed = float(net.v_free) if i == 0 else speeds[i - 1]
            downstream_rho = rhos[i + 1] if i + 1 < len(rhos) else rhos[i]
            v_eff = metanet_module.effective_desired_speed_kmh(
                rho,
                float(net.v_free),
                float(net.rho_crit),
                float(vsl_kph),
                float(getattr(net, "alpha_vsl", 0.0)),
                bool(vsl_active),
                float(getattr(net, "metanet_a_m", 1.867)),
            )
            v_next = metanet_module.metanet_speed_update_kmh(
                speeds[i],
                upstream_speed,
                rho,
                downstream_rho,
                v_eff,
                dt_h,
                lengths[i],
                float(net.metanet_tau_h),
                metanet_module.select_anticipation_nu(rho, net),
                float(net.metanet_kappa_veh_km_lane),
                float(net.v_min),
            )
            next_rhos.append(float(rho_next))
            next_speeds.append(float(v_next))
        rhos = next_rhos
        speeds = next_speeds
        peak_density = max(peak_density, max(rhos) if rhos else 0.0)
    return (
        float(vehicle_tts),
        float(density_excess_tts),
        float(rhos[merge_idx] if rhos else 0.0),
        float(peak_density),
        float(release),
    )


def install_vsl_metanet_rollout_runtime_patch(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    settings = _vsl_rollout_tuning(tuning)
    if not _is_enabled(settings):
        setattr(cfg, "_vissim_vsl_rollout_enabled", False)
        return {"vsl_metanet_rollout_patch_enabled": 0.0}
    try:
        from src.controllers import distributed_coordinator as dc
        from src.models import metanet as metanet_module
    except Exception:
        return {"vsl_metanet_rollout_patch_enabled": 0.0, "vsl_metanet_rollout_patch_failed": 1.0}

    cls = dc.DistributedCoordinator
    if not hasattr(cls, "_vissim_original_candidate_freeway_tts_terms"):
        cls._vissim_original_candidate_freeway_tts_terms = cls._candidate_freeway_tts_terms
    if not hasattr(cls, "_vissim_original_freeway_agent_objective"):
        cls._vissim_original_freeway_agent_objective = cls._freeway_agent_objective
    if not hasattr(cls, "_vissim_original_solve_for_vsl_consensus"):
        cls._vissim_original_solve_for_vsl_consensus = cls.solve
    original_terms = cls._vissim_original_candidate_freeway_tts_terms
    original_objective = cls._vissim_original_freeway_agent_objective
    original_solve = cls._vissim_original_solve_for_vsl_consensus
    finalize_agent_consensus = str(settings.get("finalize_agent_consensus", False)).strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }

    def patched_candidate_freeway_tts_terms(self, agent, state, ramp_metering, upper, forecast, lane_profile):
        result = original_terms(self, agent, state, ramp_metering, upper, forecast, lane_profile)
        if getattr(self.cfg, "_vissim_vsl_rollout_enabled", False):
            self._vissim_vsl_rollout_context = {
                "agent": agent,
                "state": state,
                "ramp_metering": dict(ramp_metering),
                "upper": dict(upper),
                "forecast": list(forecast),
                "lane_profile": lane_profile,
            }
        return result

    def patched_freeway_agent_objective(
        self,
        rhos,
        density_excess,
        metering_error,
        ramp_metering,
        vsl,
        previous_vsl,
        offramp_forecast_veh,
        offramp_storage_veh,
        offramp_capacity_veh=0.0,
        ramp_queue_tts=0.0,
        onramp_urban_queue_tts=0.0,
        horizon_h=1.0,
        freeway_vehicle_tts=None,
        density_excess_tts=None,
    ):
        if getattr(self.cfg, "_vissim_vsl_rollout_enabled", False):
            context = getattr(self, "_vissim_vsl_rollout_context", None)
            terms = _vsl_aware_link_rollout_terms(context or {}, float(vsl), self.cfg, metanet_module)
            if terms is not None:
                freeway_vehicle_tts = terms[0]
                density_excess_tts = terms[1]
                self._vissim_vsl_rollout_eval_count = (
                    int(getattr(self, "_vissim_vsl_rollout_eval_count", 0)) + 1
                )
        return original_objective(
            self,
            rhos,
            density_excess,
            metering_error,
            ramp_metering,
            vsl,
            previous_vsl,
            offramp_forecast_veh,
            offramp_storage_veh,
            offramp_capacity_veh,
            ramp_queue_tts=ramp_queue_tts,
            onramp_urban_queue_tts=onramp_urban_queue_tts,
            horizon_h=horizon_h,
            freeway_vehicle_tts=freeway_vehicle_tts,
            density_excess_tts=density_excess_tts,
        )

    def patched_solve(self, *args, **kwargs):
        result = original_solve(self, *args, **kwargs)
        if not getattr(self.cfg, "_vissim_vsl_rollout_consensus_enabled", False):
            return result
        control = getattr(result, "control", None)
        if control is None:
            return result
        diagnostics: dict[str, Any] = {}
        raw_result_diag = getattr(result, "diagnostics", None)
        if isinstance(raw_result_diag, Mapping):
            diagnostics.update(raw_result_diag)
        raw_control_diag = getattr(control, "diagnostics", None)
        if isinstance(raw_control_diag, Mapping):
            diagnostics.update(raw_control_diag)
        by_link: dict[str, list[float]] = {str(link): [] for link in self.cfg.network.freeway_links}
        for agent in getattr(self, "freeway_agents", []):
            key = f"agent_{agent.id}_vsl_selected"
            if key not in diagnostics:
                continue
            try:
                by_link.setdefault(str(agent.link), []).append(float(diagnostics[key]))
            except (TypeError, ValueError):
                continue
        selected = {link: float(min(values)) for link, values in by_link.items() if values}
        if not selected:
            return result
        for key in list(getattr(control, "vsl", {}).keys()):
            if "__seg" in str(key):
                control.vsl.pop(key, None)
        control.vsl.update(selected)
        consensus_diag = {
            "vsl_agent_consensus_finalize_active": 1.0,
            "vsl_agent_consensus_finalize_link_count": float(len(selected)),
            "vsl_agent_consensus_finalize_min_kph": float(min(selected.values())),
        }
        for link, value in selected.items():
            consensus_diag[f"vsl_agent_consensus_{link}_kph"] = float(value)
        control.diagnostics.update(consensus_diag)
        if isinstance(raw_result_diag, Mapping):
            raw_result_diag.update(consensus_diag)
        return result

    cls._candidate_freeway_tts_terms = patched_candidate_freeway_tts_terms
    cls._freeway_agent_objective = patched_freeway_agent_objective
    cls.solve = patched_solve
    setattr(cfg, "_vissim_vsl_rollout_enabled", True)
    setattr(cfg, "_vissim_vsl_rollout_consensus_enabled", finalize_agent_consensus)
    return {
        "vsl_metanet_rollout_patch_enabled": 1.0,
        "vsl_agent_consensus_finalize_enabled": float(finalize_agent_consensus),
    }


def _observation_split_parameters(calibration: Mapping[str, Any] | None = None) -> dict[str, float]:
    observation = _mapping((calibration or {}).get("observation"))
    return {
        "internal_storage_fraction": clamp(
            _as_float(
                observation.get("internal_storage_fraction"),
                LOCAL_OBSERVATION_INTERNAL_STORAGE_FRACTION,
            ),
            0.0,
            1.0,
        ),
        "offramp_storage_fraction": clamp(
            _as_float(
                observation.get("offramp_storage_fraction"),
                LOCAL_OBSERVATION_OFFRAMP_STORAGE_FRACTION,
            ),
            0.0,
            1.0,
        ),
    }


def _link_counts_from_local_observation(state_json: Mapping[str, Any]) -> dict[str, float]:
    """링크별 점유 대수. `RW_QUEUE_WINDOW_STAT` 이 켜져 있으면 직전 구간 창 집계를 쓴다.

    **큐 배정이 이 값에서 나온다** — `queue_count = link_counts x (1 - storage_fraction)`.
    `link_stopped_counts` 는 저류 몫의 정지 비율에만 쓰인다. 2026-08-22 에 창 집계를
    정지차에만 걸었다가 결정이 하나도 안 바뀌는 걸 뒤늦게 발견했다(leave-one-out
    리플레이에서 `no_window` 가 `all` 과 현시 0개 차이).

    창을 쓰는 이유는 위상 잠금이다 — 제어주기 150s 가 신호주기 150s 와 같아 관측이 늘
    같은 신호 위상에 떨어진다(SC1 동서: 결정시점 0.1 vs 창평균 3.3 vs 창최대 12.8).
    필드가 없으면 순간값으로 폴백해 **비트 동일**이다."""
    local = state_json.get("local_observation", {})
    if not isinstance(local, Mapping):
        return {}
    raw = local.get("link_counts", {})
    # 2026-09-04. env 전용이던 것을 config 로 — `urban.queue.window_stat` (mean|max).
    # 기본 빈값 = 순간값(현행). 어느 런에서도 켜진 적이 없어 미검증이고, 카운터별 상관이
    # 순시 0.674 -> 30초 창평균 0.967 (62/62 승) 이라 다음 검정 후보다.
    mode = str(_CFG_STRINGS.get("queue_window_stat", "")).strip().lower()  # 2026-09-05 env 폴백 삭제
    if mode in {"mean", "max"}:
        windowed = local.get("link_counts_window_mean")
        samples = _as_float(local.get("queue_window_samples"), 0.0)
        if isinstance(windowed, Mapping) and windowed and samples >= 1.0:
            raw = windowed
    if not isinstance(raw, Mapping):
        return {}
    return {str(k): max(0.0, _as_float(v)) for k, v in raw.items()}


def _link_metric_from_local_observation(
    state_json: Mapping[str, Any],
    key: str,
) -> dict[str, float]:
    local = state_json.get("local_observation", {})
    if not isinstance(local, Mapping):
        return {}
    raw = local.get(key, {})
    if not isinstance(raw, Mapping):
        return {}
    return {str(k): max(0.0, _as_float(v)) for k, v in raw.items()}


def _file_sha256(path: Path) -> str:
    if not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _git_commit(path: Path) -> str:
    # `text=True` 만 주면 파이썬이 **로케일 기본 인코딩**으로 디코딩한다. 이 워크스페이스는
    # 한글 경로(학술/찐찐막)이고 git 은 그 경로를 UTF-8 로 출력하므로, cp949 로케일에서는
    # subprocess 의 reader 스레드가 UnicodeDecodeError 로 죽는다. 그러면 `stdout` 이 None 이
    # 되고 `.stdout.strip()` 이 AttributeError 를 던지는데, 이 예외는 아래 except 에 없어
    # 그대로 전파되어 **어댑터 프로세스 전체가 종료**된다.
    # 2026-08-07 실 런에서 매 decision 마다 이것으로 죽었다(DECISION_EXIT_NONZERO).
    # 인코딩을 명시해 로케일 의존을 제거한다.
    try:
        top_level = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "--show-toplevel"],
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=5,
        ).stdout.strip()
        if Path(top_level).resolve() != path.resolve():
            return ""
        result = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=5,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return result.stdout.strip()


def _snapshot_commit(path: Path) -> str:
    snapshot = path / "SNAPSHOT.md"
    if not snapshot.is_file():
        return ""
    match = re.search(r"(?<![0-9a-f])[0-9a-f]{7,40}(?![0-9a-f])", snapshot.read_text(encoding="utf-8-sig"), re.I)
    return match.group(0) if match else ""


def _source_tree_sha256(path: Path) -> str:
    source_root = path / "src"
    if not source_root.is_dir():
        return ""
    digest = hashlib.sha256()
    for source in sorted(source_root.rglob("*.py"), key=lambda item: item.relative_to(source_root).as_posix()):
        digest.update(source.relative_to(source_root).as_posix().encode("utf-8"))
        digest.update(b"\0")
        digest.update(source.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def build_run_provenance(
    repo_root: Path,
    state_json: Mapping[str, Any],
    state_path: Path,
    mapping_path: Path,
    detector_mapping_path: Path,
    calibration_path: Path,
    tuning_path: Path,
    network_path: Path | None = None,
) -> dict[str, Any]:
    network_path = network_path or (
        WORKSPACE_ROOT / "network" / "real_world_gaepo_modi" / "modi_eval_rw_control.inpx"
    )
    state_run_provenance = _mapping(state_json.get("run_provenance"))
    run_manifest_text = str(state_run_provenance.get("manifest_path", "")).strip()
    run_manifest_path = Path(run_manifest_text) if run_manifest_text else Path("__missing_run_manifest.json")
    inputs = {
        "state_json": state_path,
        "control_mapping_json": mapping_path,
        "detector_mapping_json": detector_mapping_path,
        "calibration_json": calibration_path,
        "tuning_json": tuning_path,
        # 2026-08-27 추가. 정본 파라미터가 여기 없으면 **모든 팔이 공유하는 값 파일이
        # 지문 밖에 있게 된다** — parameters.json 을 한 줄 고치고 같은 config·같은 어댑터로
        # 두 팔을 돌리면 두 런의 execution_fingerprint_sha256 이 완전히 동일해져서,
        # 나중에 결과 차이를 파일 증거로 되짚을 방법이 사라진다.
        "parameters_json": WORKSPACE_ROOT / "evaluation" / "parameters.json",
        "parameters_py": WORKSPACE_ROOT / "evaluation" / "parameters.py",
        "adapter_py": Path(__file__).resolve(),
        "fixed_signal_schedule_py": WORKSPACE_ROOT / "evaluation" / "controllers" / "fixed_signal_schedule.py",
        "strict_signal_program_py": WORKSPACE_ROOT / "plant" / "src" / "vissim_strict" / "signal_program.py",
        "network_inpx": network_path,
        "main_vbs_runner": WORKSPACE_ROOT / "scripts" / "run_real_world_stackelberg_controller.vbs",
        # 2026-08-14: 생산 격자가 pedovrx 로 옮겨 갔다. 이 넷은 모형 입력이 아니라
        # execution_fingerprint_sha256 에 들어가는 **증거**다 - 낡은 채로 두면 모든 런이
        # 자기가 쓰지도 않은 2026-08-05 격자를 썼다고 기록한다.
        "watchdog_wrapper": WORKSPACE_ROOT / "scripts" / "run_real_world_single_watchdog_distributed_pedovrx.ps1",
        "numsim_default_yaml": repo_root / "src" / "config" / "default.yaml",
        "link_assignment_json": WORKSPACE_ROOT / "outputs" / "link_player_assignment_pedfold_20260814.json",
        "intersection_adjacency_json": WORKSPACE_ROOT / "outputs" / "intersection_adjacency_pedfold_20260814.json",
        "storage_capacity_json": STORAGE_CAPACITY_EVIDENCE_JSON,
        "run_manifest_json": run_manifest_path,
    }
    imported_modules = {}
    expected_root = repo_root.resolve()
    for module_name, module in sorted(sys.modules.items()):
        if module_name != "src" and not module_name.startswith("src."):
            continue
        module_text = str(getattr(module, "__file__", "") or "").strip()
        if not module_text:
            continue
        module_path = Path(module_text).resolve()
        if not module_path.is_relative_to(expected_root):
            raise RuntimeError(f"imported {module_name} from {module_path}, expected under {expected_root}")
        imported_modules[module_name] = {
            "path": str(module_path),
            "sha256": _file_sha256(module_path),
        }
    signal_programs = {
        path.name: _file_sha256(path)
        for path in sorted(network_path.parent.glob("*.sig"), key=lambda item: item.name)
    }
    provenance = {
        "schema_version": 2,
        "run_id": str(state_run_provenance.get("run_id", "")),
        "workspace_root": str(WORKSPACE_ROOT.resolve()),
        "workspace_git_commit": _git_commit(WORKSPACE_ROOT),
        "numsim_repo_root": str(repo_root.resolve()),
        "numsim_git_commit": _git_commit(repo_root),
        "numsim_snapshot_commit": _snapshot_commit(repo_root),
        "numsim_src_sha256": _source_tree_sha256(repo_root),
        "imported_modules": imported_modules,
        "signal_program_sha256": signal_programs,
        "inputs": {
            name: {
                "path": str(path.resolve()) if str(path) else "",
                "sha256": _file_sha256(path),
                "exists": path.is_file(),
            }
            for name, path in inputs.items()
        },
    }
    stable_evidence = {
        "numsim_repo_root": provenance["numsim_repo_root"],
        "numsim_git_commit": provenance["numsim_git_commit"],
        "numsim_snapshot_commit": provenance["numsim_snapshot_commit"],
        "numsim_src_sha256": provenance["numsim_src_sha256"],
        "imported_modules": provenance["imported_modules"],
        "signal_program_sha256": provenance["signal_program_sha256"],
        "inputs": {name: value for name, value in provenance["inputs"].items() if name != "state_json"},
    }
    provenance["execution_fingerprint_sha256"] = hashlib.sha256(
        json.dumps(stable_evidence, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return provenance


def _network_path_from_state(state_json: Mapping[str, Any]) -> Path:
    provenance = state_json.get("run_provenance", {})
    if isinstance(provenance, Mapping):
        value = provenance.get("network_path", "")
        if value:
            return Path(str(value))
    value = state_json.get("network_path", "")
    if value:
        return Path(str(value))
    return WORKSPACE_ROOT / "network" / "real_world_gaepo_modi" / "modi_eval_rw_control.inpx"


MOVEMENT_SIGNAL_GROUP_MAP_PATH = (
    WORKSPACE_ROOT / "outputs" / "movement_signal_group_map_v3.json"
)


def load_movement_signal_group_map(path: Path | None = None) -> dict[str, Any] | None:
    """N4-2 매핑 산출물을 읽는다. 없으면 `None` 이고 호출부가 이름 규칙으로 떨어진다.

    없다고 예외를 던지지 않는 이유는 제어 SC 의 폴백이 항상녹색이 아니라 기존 2현시
    경로이기 때문이다(N4-4 의 fail-closed 대상은 monitor 노드다). 대신 폴백 건수를
    `native_phase_share_*_fallback_count` 로 내보내 조용히 지나가지 못하게 한다.
    """
    source = Path(path) if path is not None else MOVEMENT_SIGNAL_GROUP_MAP_PATH
    if not source.is_file():
        return None
    return json.loads(source.read_text(encoding="utf-8"))


def _mainline_plan_enabled() -> bool:
    """액추에이션 계획을 **본선 전용** 사본으로 바꿀지. 기본 꺼짐.

    config `urban.plan.mainline_only`, 폴백 env `RW_MAINLINE_PLAN`.
    """
    return _switch("mainline_plan", "RW_MAINLINE_PLAN")


# 액추에이션 계획. `RW_MAINLINE_PLAN=1` 이면 **미드블록 SG 를 현시에서 뺀** 사본을 읽는다.
#
# ## 왜
#
# 정본 계획은 미드블록 SG 를 모델 현시에 함께 넣는다 — SC5 p1 = ["4","8","12","16","20","24"].
# 그래서 `axis_green_sec["p1"]` 이 **97**(SG20 의 native 창 [50,147])이 되고, 본선 SG4·SG8 이
# native 로 [78,121] 43초라 계획이 그 창을 **43/97 = 0.4433** 분율로 적는다. 결과는
# 컨트롤러가 p1 에 54.5초를 주문해도 본선에 **24.2초만** 배달되는 것이다(1초 되읽기 12주기
# 실측). 컨트롤러의 레버가 자기도 모르게 0.44 배로 감쇠된다.
#
# 본선만 보면 이미 완전한 4현시 순차다 — SC5: p1{4,8}=43 · p2{3,7}=23 · p3{2,6}=47 ·
# p4{1,5}=25, 합 **138 = 모델 예산**, +4x3s 황색 = 150 = 주기.
#
# ## 왜 안전한가
#
# 러너는 `RW_MAINLINE_SG_ONLY=1` 일 때 `IsControlledSignalGroup(sg)=(sg<=8)` 이고 미드블록엔
# ContrByCOM 조차 안 건다(VBS:1820-1833) — VISSIM 자체 프로그램이 그대로 돈다. 즉 **러너는
# 이미 본선만 몰고 있고**, 계획만 아직 미드블록을 현시에 넣어 본선 분율을 왜곡하고 있었다.
# 미드블록은 EXPECTED 계약에는 남으므로 커버리지 검증(VBS:2000-2035)은 통과한다.
#
# 상충 쌍을 잃는 것은 문제가 아니다 — 그 "상충" 은 기하도 intergreen 행렬도 아니고
# "native 에서 한 번도 안 겹쳤다" 는 **추론**이다(signal_group_plan.py:222-228). 본선과
# 미드블록은 **다른 교차로**라 동시녹색이 나도 무방하다(2026-08-25 사용자 판정).
#
# 실측(사본 생성 결과): 전 17 SC 에서 **부분창 0개** — 모든 본선 SG 가 현시 전체를 받는다.
def signal_group_actuation_plan_path() -> Path:
    """읽을 액추에이션 계획. 상수가 아니라 함수인 이유는 import 시점에 굳으면
    `main()` 이 tuning 을 열기 **전**이라 config 스위치를 못 보기 때문이다."""
    name = (
        "signal_group_actuation_plan_mainline_20260825.json"
        if _mainline_plan_enabled()
        else "signal_group_actuation_plan_v3.json"
    )
    return WORKSPACE_ROOT / "outputs" / name
# 러너 원문에서 한 번만 읽는다. 결정마다 읽으면 15 SC x 60 결정 = 900 번 러너를 다시
# 파싱하게 된다. 상수는 런 도중 바뀌지 않는다.
RUNNER_CLEARANCE_SEC = plant_cycle.runner_clearance_sec()


def load_signal_group_actuation_plan(path: Path | None = None) -> dict[str, Any] | None:
    """N4-5 액추에이션 계획을 읽는다. 없으면 `None` 이고 action CSV 는 예전 모양이다.

    여기서 예외를 던지지 않는 이유는 러너 쪽에 짝이 되는 게이트가 있기 때문이다.
    러너의 generated config 에 `RW_SIGNAL_SG_PLAN_SCHEMA` 가 있으면 `signal_sg` 행이
    **반드시** 와야 하고, 없으면 action CSV 전체를 거부한다. 즉 "계획 없이 조용히
    이름 규칙으로 도는" 조합은 러너에서 막힌다.
    """
    source = Path(path) if path is not None else signal_group_actuation_plan_path()
    if not source.is_file():
        return None
    return json.loads(source.read_text(encoding="utf-8"))


def plan_live_phases(plan_table: Mapping[str, Any], sc_no: int) -> tuple[str, ...]:
    """계획이 그 SC 에서 **실제로 켤 수 있는** 현시. 액션의 현시 집합과 같아야 한다.

    SG 가 붙어 있는 것만으로는 부족하다. SC107·108·109 는 한 현시의 SG 가 `.sig` 에서
    영구적색이라 네이티브 녹색이 0 이고, 아무리 녹색을 명령해도 0 초가 실현된다. 그
    현시를 살아 있다고 세면 러너가 clearance 를 한 번 더 물고(주기가 3 s 밀린다) 모델은
    켜지지 않을 현시에 예산을 붓는다(실측 SC107 p1 지시 97.5 s, 실현 0.0 s).
    """
    node = (plan_table.get("controllers") or {}).get(str(int(sc_no)))
    if node is None:
        raise signal_group_plan.SignalGroupPlanError(
            f"actuation plan has no controller {sc_no}"
        )
    groups = node.get("phase_signal_groups") or {}
    native = node.get("axis_green_sec") or {}
    return tuple(
        phase
        for phase in signal_group_plan.MODEL_PHASES
        if tuple(groups.get(phase) or ()) and float(native.get(phase, 0.0)) > 0.0
    )


def signal_group_action_rows(
    plan_table: Mapping[str, Any],
    sc_no: int,
    phase_greens: Mapping[str, float],
    offset: float,
    metadata: str,
) -> list[dict[str, Any]]:
    """한 SC 의 `signal_sg` 행. 열 재사용 규칙은 `action_csv_schema` 가 정본이다.

        dsd_no    -> sg 번호
        link      -> 녹색창 인덱스
        p1_green  -> 녹색창 시작[s] (플랜 주기 좌표)
        p2_green  -> 녹색창 끝[s]
        p3_green  -> 빈 칸       p4_green -> 빈 칸
        offset    -> 그 SC 의 offset (같은 SC 의 `signal` 행과 같아야 한다)
        green_sec -> 플랜 주기[s]

    이 행은 **파생**이다. 정본은 같은 SC 의 `signal` 행이 싣는 현시 4값이고, 러너가
    `green_sec` 을 그 4값으로 다시 계산해 대조한다(어긋나면 CSV 전량 거부).
    """
    node = (plan_table.get("controllers") or {}).get(str(int(sc_no)))
    if node is None:
        raise signal_group_plan.SignalGroupPlanError(
            f"actuation plan has no controller {sc_no}"
        )
    plan = signal_group_plan.node_plan_from_json(node)
    # 액션이 녹색을 준 현시와 계획이 SG 를 붙여 둔 현시가 다르면 창을 만들지 않는다.
    # 여기서 조용히 넘어가면 러너는 주기가 맞는 CSV 를 받고, 녹색을 받기로 한 이동류는
    # 아무 창도 없이 통째로 적색이 된다 - 런 중에도 안 보인다.
    commanded = signal_group_plan.live_phases(phase_greens)
    planned = plan_live_phases(plan_table, sc_no)
    if commanded != planned:
        raise signal_group_plan.SignalGroupPlanError(
            f"sc {sc_no}: action commands green on phases {commanded} but the actuation plan "
            f"has signal groups on {planned}"
        )
    # 계획 표에 없으면 리터럴이 아니라 **러너 원문** 으로 떨어진다. 여기서 나온 주기는
    # 러너가 자기 현시 주기와 대조하는 값이라(:1453), 4 s 만 달라도 그 SC 의 창이 통째로
    # 거부된다. 리터럴을 두면 러너가 clearance 를 바꾼 순간 조용히 그 상태가 된다.
    amber, all_red = RUNNER_CLEARANCE_SEC
    amber = float(plan_table.get("amber_sec", amber))
    all_red = float(plan_table.get("all_red_sec", all_red))
    cycle = signal_group_plan.plan_cycle_sec(phase_greens, amber, all_red)
    windows = signal_group_plan.plan_windows(
        plan,
        phase_greens=phase_greens,
        phase_order=signal_group_plan.phase_layout_order(
            str(node.get("major_maps_to", "p2"))
        ),
        amber_sec=amber,
        all_red_sec=all_red,
    )
    rows: list[dict[str, Any]] = []
    for window in windows:
        row = {
            "kind": "signal_sg",
            "id": f"SC{int(sc_no)}_SG{window.sg_no}_W{int(window.window_index)}",
            "dsd_no": window.sg_no,
            "sc_no": int(sc_no),
            "link": int(window.window_index),
            "lane": 0,
            "speed_kph": 0,
            action_csv_schema.WINDOW_START_FIELD: round(window.start_sec, 6),
            action_csv_schema.WINDOW_END_FIELD: round(window.end_sec, 6),
            "offset": round(float(offset), 3),
            "rate_vph": 0,
            "green_sec": round(cycle, 6),
            "metadata": metadata,
        }
        for field in action_csv_schema.WINDOW_BLANK_FIELDS:
            row[field] = ""
        rows.append(row)
    return rows


class MonitorFixedSignalPatchError(RuntimeError):
    """고정신호 패치를 설치하지 못했다 (v3 N4-4).

    원본 `_phase_green_fraction` 은 phase 가 빈 movement 에 1.0(항상녹색)을 돌려준다.
    패치가 조용히 빠지면 monitor 26개 SC 가 통째로 항상녹색이 되는데 아무도 모른다.
    그래서 실패는 예외다. 정당한 "대상 없음"(uncontrolled·signals 공집합)만 건너뛴다.
    """


_NARROW_SG_CACHE: dict[str, Any] = {}


def _narrowed_signal_groups(spec: Mapping[str, Any], schedule) -> tuple[str, ...] | None:
    """movement 를 **자기 현시의 SG** 로 좁힌다. 못 좁히면 None(기존 해석 유지).

    기본 해석은 origin 링크에 달린 신호두의 SG 를 전부 합집합으로 준다. 신호두의 `lane`
    이 링크 단위라 직진과 보호좌회전이 한 덩어리가 되기 때문이다. movement 의 `phase`
    (예: "SC1_p3")로 `movement_signal_group_map_v3.json` 의 `phase_signal_groups` 를
    찾아 교집합하면 자기 현시만 남는다.

    교집합이 비면 **좁히지 않는다** - 맵이 낡아 SG 이름이 안 맞는 경우가 있고(실측 38건),
    그때 0 을 돌려주면 그 movement 가 영영 방출 못 한다. 과대가 낫지 무방출은 안 된다.
    """
    phase = str(spec.get("phase", ""))
    node = str(spec.get("intersection", ""))
    if not phase or not node:
        return None
    if "map" not in _NARROW_SG_CACHE:
        payload = load_movement_signal_group_map()
        _NARROW_SG_CACHE["map"] = _mapping((payload or {}).get("controllers"))
    controllers = _NARROW_SG_CACHE["map"]
    entry = _mapping(controllers.get(node))
    table = _mapping(entry.get("phase_signal_groups"))
    if not table:
        return None
    key = phase.split("_", 1)[1] if "_" in phase else phase
    own = {str(g) for g in (table.get(key) or [])}
    if not own:
        return None
    current = {str(g) for g in schedule.movement_signal_groups(spec)}
    narrowed = tuple(sorted(current & own)) if current else tuple(sorted(own))
    return narrowed or None


def _validation_fixed_signal_enabled() -> bool:
    """검증 rollout 에서 제어 SC 도 고정시간 신호를 쓸지. **생산에서는 켜지 마라.**

    실제 컨트롤러는 후보의 녹색 배분으로 굴려야 하고 그것이 MPC 다. 이 스위치는
    무제어 rollout 으로 동역학 충실도를 잴 때만 쓴다 - VISSIM 이 실제로 돌린 신호를
    재현해야 모델 오차와 신호 불일치가 갈린다.
    """
    return str(os.environ.get("RW_VALIDATION_FIXED_SIGNAL", "")).strip().lower() in {"1", "true", "on"}


def build_patched_phase_green_fraction(original, schedules, share_table):
    """`_phase_green_fraction` 대체본을 만든다.

    - phase 가 있는 movement(=제어 SC): native 배분이 있으면 원본 값에 곱한다.
      배분이 없거나 정확히 1.0 이면 **원본을 그대로 돌려준다** - N=2 비트동일 경로다.
    - phase 가 빈 movement(=monitor SC): 고정 스케줄로 native 타임라인을 적분한다.
      스케줄이 없으면 항상녹색으로 되돌아가는 대신 예외를 던진다.
    """

    # --- hot path 상수 걷어내기 (2026-09-08) ---------------------------------------
    # 아래 둘은 결정 중에 바뀌지 않는데 종전에는 **매 호출** 다시 만들었다. 21셀 결정 1회에
    # 각각 847만 번(누적 57.6 s · 28.6 s = 결정의 7.7%)이다. 값이 같으므로 결과는 불변이다.
    _validation_fixed = _validation_fixed_signal_enabled()
    _share_cache: dict = {}          # id(spec) -> (spec 강참조, share)

    def _share_of(spec):
        hit = _share_cache.get(id(spec))
        if hit is not None and hit[0] is spec:
            return hit[1]
        value = share_table.share_for(spec)
        _share_cache[id(spec)] = (spec, value)
        return value

    def patched_phase_green_fraction(control, cfg_arg, spec, urban_step_index=None):
        if spec.get("unsignalized"):
            # B5: 정지선 상류 peel-off(램프 연결로) — 신호와 무관, 저수지 공간·연결로 용량으로만 제한
            return 1.0
        if str(spec.get("phase", "")):
            # **검증 전용 경로.** 제어 SC 도 VISSIM 이 실제로 돌린 고정시간 신호를 쓴다.
            #
            # 왜 필요한가: 무제어 rollout 으로 동역학을 검증할 때, 제어 SC 는
            # ControlAction.uncontrolled 의 **주기 균등분할** 녹색을 받는다. 그러면 모델은
            # 모든 movement 를 동시에 평균 녹색률로 방출하는데 VISSIM 은 현시를 순차로 돌려
            # 한 번에 한 무리만 전 속도로 뺀다. 한 주기 적분하면 총량은 같지만 60초 창 안의
            # 공간 분포가 달라서, 그 차이가 모델 오차로 잘못 계상된다.
            #
            # 실측 근거(2026-08-16): 창 정확 녹색을 쓰는 비제어 노드 스텝1 39.4%(G5 42.7%) 대
            # 평균 녹색을 쓰는 제어 노드 48.3%(G5 27.1%). 그리고 포화유율을 낮출수록 적합이
            # 좋아지는 것(400 veh/h 에서 최적)이 "과다 동시 방출" 의 서명이다.
            #
            # **생산에서는 켜면 안 된다.** 실제 컨트롤러는 후보의 녹색 배분으로 굴려야 하고
            # 그것이 MPC 다. 이 경로는 동역학 충실도를 재는 동안만 쓴다.
            if _validation_fixed:
                node = str(spec.get("intersection", ""))
                schedule = schedules.get(node)
                if schedule is not None:
                    # movement 자기 현시의 SG 로 좁힌다. 좁히지 않으면 신호두 lane 이 링크
                    # 단위라 직진이 보호좌회전 녹색까지 받는다(실측: 542개 중 339개가
                    # 녹색창 2~4개에 걸치고 union 이 단일 SG 의 중앙값 1.39배).
                    groups = _narrowed_signal_groups(spec, schedule)
                    if urban_step_index is None:
                        return float(clamp(schedule.movement_green_fraction(spec, group_ids=groups), 0.0, 1.0))
                    duration_sec = float(cfg_arg.simulation.T_u_sec)
                    start_sec = _absolute_urban_step_start_sec(urban_step_index, duration_sec)
                    return float(
                        clamp(
                            schedule.movement_green_fraction(spec, start_sec, duration_sec, group_ids=groups),
                            0.0,
                            1.0,
                        )
                    )
            share = _share_of(spec)
            if share is None:
                return original(control, cfg_arg, spec, urban_step_index)
            return original(control, cfg_arg, spec, urban_step_index) * share
        node = str(spec.get("intersection", ""))
        schedule = schedules.get(node)
        if schedule is None:
            raise MonitorFixedSignalPatchError(
                f"uncontrolled movement at node {node!r} has no fixed signal schedule; "
                "falling back to the original path would make it always-green"
            )
        if urban_step_index is None:
            return float(clamp(schedule.movement_green_fraction(spec), 0.0, 1.0))
        duration_sec = float(cfg_arg.simulation.T_u_sec)
        start_sec = _absolute_urban_step_start_sec(urban_step_index, duration_sec)
        return float(
            clamp(
                schedule.movement_green_fraction(spec, start_sec, duration_sec),
                0.0,
                1.0,
            )
        )

    patched_phase_green_fraction._rw_greenfrac_hotpath = True
    return patched_phase_green_fraction


def install_monitor_fixed_signal_runtime_patch(
    cfg,
    state_json: Mapping[str, Any],
    detector_mapping: Mapping[str, Any],
) -> dict[str, Any]:
    """Use native VISSIG timing for monitor nodes and native green shares for controlled ones."""

    from evaluation.controllers import fixed_signal_schedule
    from evaluation.controllers.native_phase_green import (
        build_native_phase_share_table,
    )

    uncontrolled = {str(node) for node in getattr(cfg.network, "uncontrolled_nodes", [])}
    controlled = {str(node) for node in getattr(cfg.network, "signals", [])}
    targets = uncontrolled | controlled
    network_path = _network_path_from_state(state_json)
    if not targets:
        return {
            "monitor_fixed_signal_patch_enabled": 0.0,
            "monitor_fixed_signal_patch_skip_reason": "no_target_nodes",
            "monitor_fixed_signal_network_path": str(network_path),
            "monitor_fixed_signal_schedule_count": 0.0,
            "monitor_fixed_signal_expected_count": 0.0,
        }
    if not network_path.is_file():
        raise MonitorFixedSignalPatchError(
            f"fixed signal patch needs the run network but it is not a file: {network_path}"
        )
    try:
        schedules, errors = fixed_signal_schedule.compile_fixed_signal_schedules(
            network_path, targets, detector_mapping
        )
    except Exception as exc:
        raise MonitorFixedSignalPatchError(
            f"fixed signal compile failed for {network_path}: {type(exc).__name__}: {exc}"
        ) from exc

    # monitor 노드만 fail-closed 다. 제어 SC 는 스케줄이 없어도 기존 2현시 경로로
    # 떨어질 뿐이라 항상녹색이 되지 않는다 - 그쪽은 진단으로 계상한다.
    missing_monitor = sorted(uncontrolled - set(schedules))
    monitor_errors = {node: text for node, text in sorted(errors.items()) if node in uncontrolled}
    if missing_monitor or monitor_errors:
        raise MonitorFixedSignalPatchError(
            "uncontrolled nodes without a fixed schedule would become always-green: "
            f"missing={missing_monitor} errors={monitor_errors}"
        )

    signal_group_map = load_movement_signal_group_map()
    share_table = build_native_phase_share_table(
        getattr(cfg.network, "urban_movements", {}) or {}, schedules, signal_group_map
    )

    model_module = importlib.import_module("src.models.urban_queue_model")
    original = getattr(
        model_module,
        "_vissim_original_phase_green_fraction",
        model_module._phase_green_fraction,
    )
    setattr(model_module, "_vissim_original_phase_green_fraction", original)
    patched_phase_green_fraction = build_patched_phase_green_fraction(
        original, schedules, share_table
    )

    patched_modules = 0
    for module_name in (
        "src.models.urban_queue_model",
        "src.controllers.distributed_coordinator",
        "src.controllers.local_signal_plant",
        "src.controllers.wu_distributed",
        "src.controllers.wu_faithful_follower",
    ):
        module = importlib.import_module(module_name)
        if hasattr(module, "_phase_green_fraction"):
            setattr(module, "_phase_green_fraction", patched_phase_green_fraction)
            patched_modules += 1
    if patched_modules == 0:
        raise MonitorFixedSignalPatchError(
            "no model module exposes _phase_green_fraction; the patch would be a no-op"
        )

    diagnostics: dict[str, Any] = {
        "monitor_fixed_signal_patch_enabled": 1.0,
        "monitor_fixed_signal_network_path": str(network_path.resolve()),
        "monitor_fixed_signal_schedule_count": float(len(schedules)),
        "monitor_fixed_signal_expected_count": float(len(targets)),
        "monitor_fixed_signal_missing_nodes": ",".join(sorted(targets - set(schedules))),
        "monitor_fixed_signal_compile_errors": dict(errors),
        "monitor_fixed_signal_patched_module_count": float(patched_modules),
        "native_phase_share_map_path": str(MOVEMENT_SIGNAL_GROUP_MAP_PATH),
    }
    diagnostics.update(share_table.diagnostics)
    return diagnostics


PERIMETER_MOVEMENT_KINDS_ADAPTER = {"boundary_in", "boundary_out", "on_ramp", "off_ramp"}


MOVEMENT_MERGE_PLAN_JSON = WORKSPACE_ROOT / "outputs/movement_merge_plan_20260824.json"



# 가격 국소항 패치의 마지막 결정 진단. 스위치가 꺼져 있으면 계속 비어 있다.
_SUS_SIGS: dict = {}  # 2026-09-06 SAT v3: 지속 산출물의 정지선 링크 -> 신호 (증거 밖 차로군 배분용)
_SUS_LANES: dict = {}
_LG_KINDS: set = set()  # 차로군 배분 대상 movement kind (config urban.capacity.lane_group_kinds)
_LTO: dict = {}  # detector mapping link_to_origins (정본 접근로 귀속)
_QPRICE_LAST: dict[str, float] = {}
_RAMPLOCAL_LAST: dict[str, float] = {}
_LEGSPLIT_LAST: dict[str, float] = {}
_RAMP_ERR: dict[str, float] = {}



_GREENBOX_LAST: dict[str, float] = {}


def install_signal_aware_green_box(controller, tuning: Mapping[str, Any]) -> dict[str, float]:
    """신호별 녹색 상자를 **GNE 후보 생성기**와 **가격 방향 생성기**에 흘려준다.

    `urban.green_box.signal_aware` 가 아니면 no-op = 비트 동일.

    ## 왜

    `NetworkConfig.signal_green_max(signal)` 이 신호별 주현시 상한을 낸다 — SC107/108/109 는
    3현시 141 예산이라 **101**, SC7 은 74, SC16 은 67. 그 docstring 자신이 못박아 뒀다:
    "스칼라를 그대로 걸면 컨트롤러가 **고정계획을 재현조차 못 한다**"(state.py:504-522).
    그리고 `clamp_primary_green` 은 **2026-08-22 에 이미 signal 인자를 받도록 고쳤다**
    (state.py:1442-1463, "distribute_phase_green 이 신호별 total 을 쓰면서 여기서는 스칼라를
    쓰던 불일치를 없앤다").

    **그런데 호출부 둘이 아직 안 넘긴다.**

        wu_faithful_follower.py:744   np.linspace(net.green_min, net.green_max, 13)   <- 전역 78
                            :751     clamp_primary_green(net, raw)                   <- signal 없음
        priced_wu_link_controller.py:612-614  _project_to_budget(..., net.green_max)  <- 전역 78
                                              (같은 파일 :310 정련은 signal_green_max 를 쓴다)

    실측(sc7native 37결정). 벽은 **주현시에만** 걸린다:

        SC108_p1   정련전 최대 = 정확히 78.00  ->  커밋 98.00   (신호 상한 101)
        SC107_p3   정련전 100.49  안 걸림 — p1 이 죽어 주현시가 아니다
        SC109_p3   정련전  96.50  안 걸림 — 같은 이유

    즉 GNE 가 답이 있는 영역 **밖**을 훑고, 정련이 6초 걸음으로 기어 나오는 데 라운드를
    쓴다(refine_rounds=12). 그리고 가격은 78 에 갇힌 방향으로 측정되는데 정련은 101 까지
    움직이므로, 가격과 정련이 **서로 다른 상자** 위에 있다.

    ## 무엇을 바꾸나

    (1) 후보 생성기 — 원래 후보를 **그대로 두고**, 전역 상한 위 구간 [green_max, 신호상한]
        을 같은 방식으로 추가로 훑는다. 신호 상한이 전역과 같거나 좁으면 즉시 반환이라
        그 신호에서는 비트 동일이다.
    (2) 가격 방향 — 사영 상자의 상한만 `signal_green_max(signal)` 로 바꾼다. 총합(`total`)은
        이미 그 신호 것을 쓰고 있었다.

    ## 워커 경계

    둘 다 **부모 프로세스 전용**이다. 가격 워커는 `_global_ttt_with_phases` ->
    `evaluate_price_point(..., levers=())` 만 돈다(빈 schedule = previous 를 그대로 hold,
    rollout_endpoint.py:129). 그 경로는 팔로워 `solve` 도 `_urban_green_candidates` 도
    부르지 않는다 — `rollout_endpoint.py` 전체에 팔로워 호출이 없다. 그래서 몽키패치가
    프로세스 경계를 못 넘는 함정(CLAUDE.md)에 닿지 않는다.

    **일부러 안 고친 것 둘** (같은 결함이지만 워커에서 돌거나 offset 경로다):
      * `rollout_endpoint.py:235-236` box-walk 의 `clamp_primary_green(net, ±inf)` —
        `evaluate_price_point` 안이라 **워커에서도 돈다**. 어댑터 패치는 유실되어
        조용히 갈린다(phasepar 사건과 같은 모양). vendor 수정이 필요하다.
      * `stackelberg_wu_metered.py:702-708` `_signal_price_p1_bounds` — leader offset
        directive 경로다. offset 은 사용자와 함께 따로 파기로 했다.
    """
    section = _mapping(_mapping(_mapping(tuning.get("urban")).get("green_box")))
    if not _is_enabled_value(section.get("signal_aware")):
        return {"signal_green_box_enabled": 0.0}

    import numpy as _np
    from src.controllers.priced_wu_link_controller import LinkAgentWuFollower as _Follower
    from src.models.state import (
        clamp_primary_green as _clamp,
        _project_to_budget as _proj,
        MODEL_PHASES as _PHASES,
    )
    from src.controllers.relaxed_quantization import _quantize as _q

    fcls = _Follower
    orig_candidates = fcls._urban_green_candidates

    def patched_candidates(self, signal, state, coupling, snapshot):
        out = list(orig_candidates(self, signal, state, coupling, snapshot))
        net = self.cfg.network
        hi = float(net.signal_green_max(signal))
        gmax = float(net.green_max)
        if hi <= gmax + 1.0e-9:
            return out                      # 이 신호는 전역 상자와 같거나 좁다 = 비트 동일
        mpc = self.cfg.mpc
        quantum = max(float(getattr(mpc, "relaxed_green_quantum_sec", 1.0)), 1.0e-9)
        mode = getattr(mpc, "relaxed_rounding_mode", "nearest")
        added = 0
        for raw in _np.linspace(gmax, hi, 7):
            v = _clamp(net, float(raw), signal)
            if bool(getattr(mpc, "relaxed_quantized_controls", False)):
                v = _clamp(net, float(_q(v, quantum, mode)), signal)
            if not any(abs(v - e) <= 1.0e-9 for e in out):
                out.append(float(v))
                added += 1
        _GREENBOX_LAST["signal_green_box_candidates_added"] = float(
            _GREENBOX_LAST.get("signal_green_box_candidates_added", 0.0) + added
        )
        return out

    fcls._urban_green_candidates = patched_candidates

    ccls = type(controller)
    orig_direction = ccls._phase_direction

    def patched_direction(self, signal, base, target, delta):
        net = self.cfg.network
        live = [pid for pid in net.signal_live_phases(signal) if float(base.get(pid, 0.0)) > 0.0]
        if target not in live or len(live) < 2:
            return None
        share = float(delta) / float(len(live) - 1)
        raw = {pid: float(base.get(pid, 0.0)) for pid in _PHASES}
        raw[target] += float(delta)
        for pid in live:
            if pid != target:
                raw[pid] -= share
        total = sum(float(base.get(pid, 0.0)) for pid in live)
        # **상한만** 신호별로 바꾼다. total 은 이미 그 신호 예산이었다.
        projected = _proj(
            [raw[pid] for pid in live], total,
            float(net.green_min), float(net.signal_green_max(signal)),
        )
        out = {pid: 0.0 for pid in _PHASES}
        for pid, value in zip(live, projected):
            out[pid] = float(value)
        return out

    ccls._phase_direction = patched_direction

    net = controller.cfg.network
    wider = [s for s in net.signals
             if float(net.signal_green_max(s)) > float(net.green_max) + 1.0e-9]
    _GREENBOX_LAST.update({
        "signal_green_box_enabled": 1.0,
        "signal_green_box_wider_signals": float(len(wider)),
        "signal_green_box_max_sec": float(max((net.signal_green_max(s) for s in wider),
                                              default=net.green_max)),
        "signal_green_box_global_max_sec": float(net.green_max),
    })
    return dict(_GREENBOX_LAST)



# ---------------------------------------------------------------------------
# 관측 역압(backpressure) 현시가격 (2026-09-06). 근거·정의는 scratchpad/apply_bp_price.py 머리말과 메모리
# `vissim-env-structural-20260906` 참조. 현행 롤아웃 가격은 지평 내 누적TTT 가 내부 이동에 무감각해
# price ≡ −0.75·ΔL(국소 이득에 대한 세금)이 됐다. 여기서는 관측된 하류 링크의 한계 외부효과(Vickrey)로 잰다.
# ---------------------------------------------------------------------------
MODEL_PHASES_ADAPTER = ("p1", "p2", "p3", "p4")
_BP_CONNECTOR_MAP_CACHE: dict[str, Any] = {}
_BP_RAMP_OF_EXIT = {("SC1001", "onW"): "R_D_W", ("SC1001", "onE"): "R_D_E", ("SC1004", "onW"): "R_F_W", ("SC1004", "onE"): "R_F_E"}
_BP_RAMP_FEED_CONNS = {"R_D_W": ("10480", "10482"), "R_D_E": ("10484", "10490"), "R_F_W": ("10646",), "R_F_E": ("10681", "10639")}


def _bp_load_connector_map() -> Mapping[str, Any]:
    if "map" not in _BP_CONNECTOR_MAP_CACHE:
        path = WORKSPACE_ROOT / "outputs/movement_connector_map_20260824.json"
        try:
            _BP_CONNECTOR_MAP_CACHE["map"] = json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            _BP_CONNECTOR_MAP_CACHE["map"] = {}
    return _mapping(_BP_CONNECTOR_MAP_CACHE["map"])


def _bp_previous_state_paths(previous_action_path, windows: int) -> list:
    """직전 액션 경로(decisions_x/action_%06d.json)에서 직전 k 개 state 경로를 만든다. 없으면 빈 리스트."""
    out = []
    try:
        p = Path(str(previous_action_path))
        m = re.match(r"^action_(\d+)\.json$", p.name)
        if not m:
            return out
        t = int(m.group(1))
        width = len(m.group(1))
        for k in range(int(windows) + 1):
            tk = t - 150 * k
            if tk < 0:
                break
            cand = p.with_name("state_%0*d.json" % (width, tk))
            if cand.is_file():
                out.append(cand)
    except Exception:  # noqa: BLE001
        return []
    return out


def _bp_link_of_records(doc: Mapping[str, Any]) -> dict[int, str]:
    recs = _mapping(doc.get("vehicle_records")).get("records") or []
    out: dict[int, str] = {}
    for r in recs:
        if isinstance(r, Mapping) and r.get("veh_no") is not None and r.get("link_no") is not None:
            out[int(r["veh_no"])] = str(r["link_no"])
    return out


def install_observed_backpressure_price(cfg, tuning: Mapping[str, Any], state_json: Mapping[str, Any], previous_action_path) -> dict[str, float]:
    """관측 역압 현시가격을 계산해 `cfg.network.observed_backpressure_prices` 에 둔다. 게이트 없으면 no-op."""
    section = _mapping(_mapping(tuning).get("phase_price"))
    if str(section.get("mode", "")).strip().lower() != "observed_backpressure":
        return {"observed_backpressure_enabled": 0.0}
    bp = _mapping(section.get("backpressure"))
    weight = _as_float(bp.get("weight"), 1.0)
    sat_source = str(bp.get("sat_source", "model")).strip().lower()
    sat_lane = _as_float(bp.get("sat_lane_veh_h"), 1300.0)
    mu_floor = _as_float(bp.get("mu_floor_veh_h"), 48.0)
    windows = max(1, int(_as_float(bp.get("windows"), 2.0)))
    max_price = _as_float(bp.get("max_price"), 1.0)
    ramp_reservoir = _is_enabled_value(bp.get("ramp_reservoir", True))
    relief_weight = _as_float(bp.get("relief_weight"), 1.0)
    min_abs_price = _as_float(bp.get("min_abs_price"), 0.005)  # 불감대: 잡음 수준 가격(|p| 미만)은 0. 국소비용이 평평해 ±0.004 차이로도 정련이 48 s 를 옮겼다(t=1800 SC1001).
    per_lane_model = _as_float(bp.get("per_lane_veh_h_model"), 206.5)  # s_m = β_m × 접근 차로수 × 차로당 방류 / 3600 (movement 용량 상한 대신)  # 자기 링크 해소 항(e_o) 가중. 0 이면 하류 항만.
    net = cfg.network
    horizon_h = _as_float(bp.get("horizon_h"), float(cfg.mpc.horizon_steps) * float(cfg.simulation.T_c_h))
    window_h = 150.0 / 3600.0
    # --- plant 링크 통계: 재차(현재) · 이탈/유입(직전 k 창 평균)
    local = _mapping(state_json.get("local_observation"))
    counts = {str(k): _as_float(v, 0.0) for k, v in _mapping(local.get("link_counts")).items()}
    now_recs = _bp_link_of_records(state_json)
    prev_paths = _bp_previous_state_paths(previous_action_path, windows)
    dep: dict[str, float] = {}
    arr: dict[str, float] = {}
    used_windows = 0
    later = now_recs
    for path in prev_paths:
        try:
            earlier = _bp_link_of_records(json.loads(Path(path).read_text(encoding="utf-8")))
        except Exception:  # noqa: BLE001
            break
        if not earlier or not later:
            break
        for veh, link in earlier.items():
            if later.get(veh) != link:
                dep[link] = dep.get(link, 0.0) + 1.0
        for veh, link in later.items():
            if earlier.get(veh) != link:
                arr[link] = arr.get(link, 0.0) + 1.0
        used_windows += 1
        later = earlier
    diag: dict[str, float] = {"observed_backpressure_enabled": 1.0, "observed_backpressure_windows": float(used_windows)}
    if used_windows == 0:
        # 첫 결정(직전 state 없음): 방류를 모르면 가격을 매기지 않는다(0 이 아니라 None → 롤아웃 가격 경로로 폴백).
        net.observed_backpressure_prices = None
        diag["observed_backpressure_prev_missing"] = 1.0
        return diag
    def mu_lam(link: str):
        mu = dep.get(link, 0.0) / (used_windows * window_h)
        lam = arr.get(link, 0.0) / (used_windows * window_h)
        return mu, lam
    def ext_of(n: float, mu: float, lam: float) -> tuple:
        if n <= 0.0:
            return 0.0, 0.0
        mu_eff = max(mu, mu_floor)
        t_d = min(n / mu_eff, horizon_h)
        lam_eff = lam if lam > 0.0 else mu_eff
        return lam_eff * t_d / mu_eff, t_d
    # --- 램프 저수지: n = ramp_counts, μ = 직전 미터율, λ = 램프 커넥터 실측 유량
    ramp_ext: dict[str, float] = {}
    if ramp_reservoir:
        ramp_counts = {str(k): _as_float(v, 0.0) for k, v in _mapping(state_json.get("ramp_counts")).items()}
        prev_meter: dict[str, float] = {}
        try:
            prev_doc = json.loads(Path(str(previous_action_path)).read_text(encoding="utf-8"))
            prev_meter = {str(k): _as_float(v, 0.0) for k, v in _mapping(prev_doc.get("ramp_metering")).items()}
        except Exception:  # noqa: BLE001
            prev_meter = {}
        volumes = {str(k): _as_float(v, 0.0) for k, v in _mapping(_mapping(local.get("far_measurement")).get("link_volume_veh_h")).items()}
        for ramp, conns in _BP_RAMP_FEED_CONNS.items():
            n = ramp_counts.get(ramp, 0.0)
            mu = prev_meter.get(ramp, 0.0)
            lam = sum(volumes.get(c, 0.0) for c in conns)
            ramp_ext[ramp] = ext_of(n, mu, lam)[0]
    # --- movement → 하류 (plant 링크 | 램프 저수지)
    cm = _mapping(_bp_load_connector_map().get("approaches"))
    capm = dict(getattr(net, "movement_capacity_by_movement_veh_h", {}) or {})
    specs = dict(net.urban_movements or {})
    prices: dict[str, dict[str, float]] = {}
    mapped = 0
    unmapped = 0
    links_priced = 0
    ext_cache: dict[str, tuple] = {}
    for m, sp in specs.items():
        sig = str(sp.get("intersection") or sp.get("signal") or "")
        phase = str(sp.get("phase", ""))
        pid = phase.split("_", 1)[1] if "_" in phase else ""
        if not sig or pid not in MODEL_PHASES_ADAPTER:
            continue
        exit_leg = str(sp.get("exit", ""))
        approach = str(sp.get("approach", ""))
        targets: list = []  # (ext, share, lanes)
        approach_turns = list(_mapping(cm.get("%s|%s" % (sig, approach))).get("turns") or [])
        if not approach_turns:
            approach_turns = list(_mapping(cm.get("%s|%s_RAMP" % (sig, approach))).get("turns") or [])
        ramp = _BP_RAMP_OF_EXIT.get((sig, exit_leg))
        if ramp is not None:
            targets.append((ramp_ext.get(ramp, 0.0), 1.0, 1))
        else:
            dsc = exit_leg.split("_", 1)[1] if "_SC" in exit_leg else ""
            turns = [t for t in approach_turns if dsc and str(t.get("dest_signal")) == dsc]
            for t in turns:
                link = str(t.get("to_link"))
                if link not in ext_cache:
                    mu, lam = mu_lam(link)
                    ext_cache[link] = ext_of(counts.get(link, 0.0), mu, lam)
                targets.append((ext_cache[link][0], 1.0 / float(len(turns)), int(t.get("lanes") or 1)))
        if not targets:
            unmapped += 1
            continue
        mapped += 1
        # 자기 링크(origin) 해소 항: 접근 링크 o 의 e_o. 차량 하나를 o 에서 빼면 o 뒤에 오는 남들(상류·off-ramp)이 그만큼 덜 기다린다.
        e_o = 0.0
        origin_links = sorted({str(t.get("from_link")) for t in approach_turns if t.get("from_link") is not None})
        if origin_links and relief_weight > 0.0:
            link_o = origin_links[0]
            if link_o not in ext_cache:
                mu_o, lam_o = mu_lam(link_o)
                ext_cache[link_o] = ext_of(counts.get(link_o, 0.0), mu_o, lam_o)
            e_o = float(ext_cache[link_o][0])
        # s_m: 녹색 1초당 그 movement 로 나가는 대수 = 회전분율 β_m × 접근 차로수 × 차로당 방류 / 3600.
        # movement 용량 상한(무신호 게이트 1800 등)을 쓰면 램프행 movement 가 접근 전체를 잠근다(검증 t=3600: SC1001 p3 69→21).
        lanes_o = float(sum(int(t.get("lanes") or 1) for t in approach_turns)) or 1.0
        beta_m = max(0.0, _as_float(sp.get("beta"), 0.0))
        per_lane = sat_lane if sat_source == "observed" else per_lane_model
        s_m = beta_m * lanes_o * per_lane / 3600.0
        value = s_m * (sum(float(e) * float(share) for e, share, _ in targets) - relief_weight * e_o)
        if abs(value) > 0.0:
            links_priced += 1
        prices.setdefault(sig, {})
        prices[sig][pid] = prices[sig].get(pid, 0.0) + value
    for sig in list(prices):
        for pid in list(prices[sig]):
            _v = float(min(max(weight * prices[sig][pid], -max_price), max_price))
            prices[sig][pid] = _v if abs(_v) >= min_abs_price else 0.0
    net.observed_backpressure_prices = prices
    top = max(((v, s, p) for s, d in prices.items() for p, v in d.items()), default=(0.0, "", ""))
    diag.update({
        "observed_backpressure_mapped": float(mapped),
        "observed_backpressure_unmapped": float(unmapped),
        "observed_backpressure_priced_movements": float(links_priced),
        "observed_backpressure_signals": float(len(prices)),
        "observed_backpressure_max_price": float(top[0]),
        "observed_backpressure_min_price": float(min((v for d in prices.values() for v in d.values()), default=0.0)),
        "observed_backpressure_relief_weight": float(relief_weight),
        "observed_backpressure_weight": float(weight),
        "observed_backpressure_sat_model": 1.0 if sat_source != "observed" else 0.0,
    })
    _QPRICE_LAST.update({k: v for k, v in diag.items()})
    return diag


def install_observed_backpressure_controller(controller, tuning: Mapping[str, Any]) -> dict[str, float]:
    """`_refresh_phase_prices` 를 관측 역압 가격으로 바꾼다. 롤아웃을 돌리지 않는다.
    `cfg.network.observed_backpressure_prices` 가 None(첫 결정)이면 기존 경로로 폴백한다."""
    section = _mapping(_mapping(tuning).get("phase_price"))
    if str(section.get("mode", "")).strip().lower() != "observed_backpressure":
        return {"observed_backpressure_controller": 0.0}
    from src.controllers.priced_wu_link_controller import LinkAgentWuFollower as _Follower
    cls = type(controller)
    original = cls._refresh_phase_prices
    controller.phase_price_mode = "observed_backpressure"
    def patched_bp(self, state, forecast, previous) -> None:
        follower = self.nash_solver
        prices_all = getattr(self.cfg.network, "observed_backpressure_prices", None)
        if not isinstance(follower, _Follower) or prices_all is None:
            _QPRICE_LAST["observed_backpressure_fallback_rollout"] = 1.0
            return original(self, state, forecast, previous)
        net = self.cfg.network
        prices: dict = {}
        refs: dict = {}
        for signal in net.signals:
            base = self._phase_vector(previous, signal)
            live = [pid for pid in net.signal_live_phases(signal) if base.get(pid, 0.0) > 0.0]
            if len(live) < 3:
                continue
            pr = _mapping(prices_all.get(signal))
            prices[signal] = {pid: float(pr.get(pid, 0.0)) for pid in live}
            refs[signal] = base
        if bool(getattr(self, "phase_price_ramp_signal_off", False)) and prices:
            _lm = getattr(follower, "_local_models", {}) or {}
            _zeroed = 0
            for _s in list(prices):
                if getattr(_lm.get(_s), "has_ramps", False):
                    prices[_s] = {pid: 0.0 for pid in prices[_s]}
                    _zeroed += 1
            self._ramp_signal_price_zeroed = _zeroed
        follower.signal_phase_price = prices or None
        follower.signal_phase_price_ref = {s: refs[s] for s in prices} or None
        follower.signal_phase_price_weight = float(self.phase_price_weight)
        follower.phase_price_local_cost_model = str(getattr(self, "phase_price_local_cost_model", "drain"))
        follower.green_reference_mode = str(getattr(self, "green_reference_mode", "previous"))
        follower.phase_price_refine_rounds = int(getattr(self, "phase_price_refine_rounds", 1))
        follower.phase_price_in_gne = bool(getattr(self, "phase_price_in_gne", False))
        follower.phase_price_in_gne_rounds = int(getattr(self, "phase_price_in_gne_rounds", 2))
        self._phase_price_rollout_count = 0
        self._phase_price_workers = 0
        _QPRICE_LAST["observed_backpressure_controller"] = 1.0
        _QPRICE_LAST["observed_backpressure_signals_priced"] = float(len(prices))
    cls._refresh_phase_prices = patched_bp
    return {"observed_backpressure_controller": 1.0}


def install_phased_price_local(controller, tuning: Mapping[str, Any]) -> dict[str, float]:
    """현시 가격의 **국소항**을 정련과 같은 phased 물리로 채점한다.

    `urban.phase_price.price_local_model` 이 "phased" 가 아니면 no-op = 비트 동일.

    ## 왜

    가격 규약은 `g_i = (전역 방향미분) - (국소 방향미분)` 이고, 상류 docstring 이
    그 이유를 못박아 뒀다 - "국소분을 빼서 **팔로워가 이미 보는 몫**을 제거한다.
    빼지 않으면 팔로워가 자기 비용을 두 번 센다."

    그런데 그 국소분을 재는 `phase_shape_local_cost` 는 **도착이 없는 순수 배수 모형**이다
    (`q[pid] -= service` 만 있고 유입이 한 줄도 없다). 게다가 현시 포화유율을
    `len(movements) x movement_capacity_veh_h` 로 잡는데,

      * `len(movements)` 는 **선언된 leg 교차곱**이다(CLAUDE.md: SC1 선언 56 / 실제 17)
      * `movement_capacity_veh_h` 는 **전역 스칼라 1800** 이다 - `urban.capacity.per_lane`
        로 심은 movement 별 용량 맵(중앙 207, 등가균일 330)을 아예 안 읽는다

    실측(conv seed13 t=3600, 커밋된 녹색과 투영 큐로 재구성):

        현행  len(mv) x 1800   현시 63개 중 **59개(94%)** 가 첫 스텝에 큐 0
                               그 현시들이 담은 큐가 전체의 67%
        맵을 읽게만 해도        49개(78%) / 53%   <- 용량만으론 안 풀린다
        merge(474->368)        58개(92%)         <- 교차곱만으론 안 풀린다

    즉 94% 의 현시에서 `local - base_local == 0` 이 되어 가격이

        g_i = (전역 dTTT - 0)/delta = **전역 한계값 전체**

    로 떨어진다. 외부효과가 아니라 팔로워 자기 비용까지 포함한 값이고, 규약이 막으려던
    바로 그 이중계상이다. 그 부풀려진 선형항이 정련 목적함수
    `local + w x sum p_i (g_i - ref_i)` 를 지배해 해를 상자 꼭짓점으로 민다.

    ## 무엇을 바꾸나

    정련은 2026-08-22 에 이미 `local_cost_model: "phased"` 로 옮겨 갔다
    (`rollout_local_tts_phased` - 플래툰 도착, 하류 S_eff, offset, movement 별 용량).
    **가격만 그 이전에 남아 있다.** 여기서 같은 채점기를 쓰게 한다.

    ## 워커 경계

    `_phase_price_rollouts` 가 `initargs=(self, ...)` 로 컨트롤러를 피클해 spawn 한다.
    그래서 팔로워에 클로저를 심으면 안 된다(피클 불가). ctx 는 상류가 이미
    `_phase_ctx_cache` 에 담고 `LinkAgentWuFollower.__getstate__` 가 그것을 빼고 피클하므로
    안전하다. 그리고 국소항 계산은 전부 부모 프로세스에서 끝난다 - 워커는 전역 롤아웃만
    돈다. 몽키패치가 프로세스 경계를 못 넘는 함정(CLAUDE.md)에 닿지 않는다.
    """
    section = _mapping((tuning or {}).get("phase_price"))
    mode = str(section.get("price_local_model", "")).strip().lower()
    if mode != "phased":
        return {"price_local_phased_enabled": 0.0}

    from src.controllers.priced_wu_link_controller import LinkAgentWuFollower as _Follower

    cls = type(controller)
    original = cls._refresh_phase_prices

    def patched(self, state, forecast, previous) -> None:
        follower = self.nash_solver
        follower._joint_ctx = (self, forecast, previous)
        follower._two_stage_ctx = (self, forecast, previous)
        if not isinstance(follower, _Follower):
            return original(self, state, forecast, previous)
        # ctx 는 `phase_price_local_cost_model` 이 "phased" 여야 만들어진다. 상류는 그 값을
        # `_refresh_phase_prices` **끝에서** 팔로워에 심으므로 첫 결정에는 아직 "drain" 이다.
        follower.phase_price_local_cost_model = str(
            getattr(self, "phase_price_local_cost_model", "drain")
        )
        ctx = follower._phase_refine_context(state, previous, forecast)
        if ctx is None:
            self._price_local_phased_signals = 0.0
            return original(self, state, forecast, previous)

        net = self.cfg.network
        delta = float(self.phase_price_delta_sec)
        base_ttt = self._global_ttt_with_phases(state, previous, forecast, "", None)

        def local_cost(signal, vec, setup):
            if setup is None:
                return float(follower.phase_shape_local_cost(signal, vec, state))
            return float(follower._phase_local_cost_phased(signal, vec, setup, ctx))

        tasks = []
        meta = {}
        refs = {}
        setups = {}
        phased_signals = 0
        for signal in net.signals:
            base = self._phase_vector(previous, signal)
            live = [pid for pid in net.signal_live_phases(signal) if base.get(pid, 0.0) > 0.0]
            if len(live) < 3:
                continue
            setup = follower._phase_refine_signal_setup(signal, state, ctx)
            setups[signal] = setup
            if setup is not None:
                phased_signals += 1
            base_local = local_cost(signal, base, setup)
            # 진단용으로 옛 모형도 같이 잰다(배수 모형이라 값싸다).
            base_drain = float(follower.phase_shape_local_cost(signal, base, state))
            added = False
            for pid in live:
                moved = self._phase_direction(signal, base, pid, delta)
                if moved is None:
                    continue
                tasks.append((signal, pid, moved))
                meta[(signal, pid)] = (moved, base_local, len(live), base_drain)
                added = True
            if added:
                refs[signal] = base

        rollouts = self._phase_price_rollouts(state, previous, forecast, tasks)

        prices = {}
        drain_flat = 0
        phased_flat = 0
        scored = 0
        for (signal, pid), ttt in rollouts.items():
            moved, base_local, n_live, base_drain = meta[(signal, pid)]
            local = local_cost(signal, moved, setups.get(signal))
            drain = float(follower.phase_shape_local_cost(signal, moved, state))
            scored += 1
            if abs(drain - base_drain) <= 1.0e-9:
                drain_flat += 1
            if abs(local - base_local) <= 1.0e-9:
                phased_flat += 1
            scale = float(n_live - 1) / float(n_live)
            raw_g = ((float(ttt) - base_ttt) - (local - base_local)) / max(delta, 1.0e-9)
            prices.setdefault(signal, {})[pid] = float(raw_g * scale)

        if bool(getattr(self, "phase_price_primary_by_price", False)) and prices:
            self._assign_primary_by_price(prices)
        if bool(getattr(self, "phase_price_ramp_signal_off", False)) and prices:
            _lm = getattr(follower, "_local_models", {}) or {}
            _zeroed = 0
            for _s in list(prices):
                if getattr(_lm.get(_s), "has_ramps", False):
                    prices[_s] = {pid: 0.0 for pid in prices[_s]}
                    _zeroed += 1
            self._ramp_signal_price_zeroed = _zeroed
        follower.signal_phase_price = prices or None
        follower.signal_phase_price_ref = {s: refs[s] for s in prices} or None
        follower.signal_phase_price_weight = float(self.phase_price_weight)
        _LEGSPLIT_LAST["phase_price_ramp_signal_zeroed"] = float(getattr(self, "_ramp_signal_price_zeroed", 0))
        follower.phase_price_local_cost_model = str(
            getattr(self, "phase_price_local_cost_model", "drain")
        )
        follower.green_reference_mode = str(getattr(self, "green_reference_mode", "previous"))
        follower.phase_price_refine_rounds = int(getattr(self, "phase_price_refine_rounds", 1))
        # 이 패치판이 상류 `_refresh_phase_prices` 를 **통째로 대체**하므로, 상류가 팔로워에
        # 심는 항목을 여기서 전부 다시 심어야 한다. 하나라도 빠지면 그 기능이 조용히 죽는다
        # — 2026-08-27 에 phase_price_in_gne 가 정확히 그렇게 빠져 벡터 탐색이 발화조차
        # 안 했다(녹색 L1 차이 0.0, 진단 키 None). 상류에 항목을 더하면 여기도 더해라.
        follower.phase_price_in_gne = bool(getattr(self, "phase_price_in_gne", False))
        follower.phase_price_in_gne_rounds = int(getattr(self, "phase_price_in_gne_rounds", 2))
        self._phase_price_rollout_count = len(tasks) + 1
        self._phase_price_workers = int(getattr(self, "price_parallel_workers", 0) or 0)
        _QPRICE_LAST.clear()
        _QPRICE_LAST.update({
            "price_local_phased_enabled": 1.0,
            "price_local_phased_signals": float(phased_signals),
            "price_local_scored": float(scored),
            # 옛 배수 모형이 국소 미분을 0 으로 뭉갠 현시 수. 이게 곧 결함의 크기다.
            "price_local_drain_flat": float(drain_flat),
            "price_local_phased_flat": float(phased_flat),
            "price_local_drain_flat_frac": float(drain_flat) / max(float(scored), 1.0),
            "price_local_phased_flat_frac": float(phased_flat) / max(float(scored), 1.0),
        })

    cls._refresh_phase_prices = patched

    # 옵션③ 회랑 결합 정련 — 팔로워 apply_phase_price_refinement 뒤에 묶음 패스 (다른 래퍼 위에 겹쳐도 된다).
    _fol_cls_j = None
    try:
        from src.controllers.priced_wu_link_controller import LinkAgentWuFollower as _fol_cls_j
    except Exception:  # noqa: BLE001
        _fol_cls_j = None
    if _fol_cls_j is not None and not getattr(_fol_cls_j, "_joint_wrapped", False):
        _prev_refine_j = _fol_cls_j.apply_phase_price_refinement

        def _joint_refine(self, control, state, demand=None):
            n = _prev_refine_j(self, control, state, demand)
            jctx = getattr(self, "_joint_ctx", None)
            controller = jctx[0] if jctx else None
            groups = list(getattr(controller, "phase_price_joint_groups", []) or []) if controller is not None else []
            if not groups or demand is None:
                return n
            from src.models.state import phase_key as _pk
            MP = ("p1", "p2", "p3", "p4")
            w_j = float(getattr(controller, "phase_price_joint_price_weight", 0.0) or 0.0)
            rounds = max(1, int(getattr(controller, "phase_price_joint_rounds", 6) or 6))
            prices = self.signal_phase_price or {}
            refs = self.signal_phase_price_ref or {}
            steps = tuple(getattr(self.cfg.mpc, "phase_price_exchange_steps_sec", (6.0, 2.0)))
            total_moved = 0.0
            for group in groups:
                group = [g for g in group if any(k.startswith(g + "_p") for k in control.green_times)]
                if len(group) < 2:
                    continue
                def _vec(sig):
                    return {p: float(control.green_times.get(_pk(sig, p), 0.0)) for p in MP}
                def _set(sig, vec):
                    for p in MP:
                        k = _pk(sig, p)
                        if k in control.green_times:
                            control.green_times[k] = float(vec[p])
                def _J():
                    self._phase_ctx_cache = None
                    ctx = self._phase_refine_context(state, control, demand)
                    tot = 0.0
                    for sig in group:
                        vec = _vec(sig)
                        setup = self._phase_refine_signal_setup(sig, state, ctx) if ctx else None
                        loc = self._phase_local_cost_phased(sig, vec, setup, ctx) if setup is not None else self.phase_shape_local_cost(sig, vec, state)
                        pr = prices.get(sig) or {}; ref = refs.get(sig) or vec
                        ext = sum(float(pr.get(p, 0.0)) * (float(vec.get(p, 0.0)) - float(ref.get(p, 0.0))) for p in MP)
                        tot += loc + w_j * ext
                    return tot
                best_J = _J()
                start = {sig: _vec(sig) for sig in group}
                for _r in range(rounds):
                    moved = False
                    for sig in group:
                        base = _vec(sig)
                        for step in steps:
                            for cand in self._phase_exchange_candidates(sig, base, float(step)):
                                _set(sig, cand)
                                val = _J()
                                if val < best_J - 1.0e-9:
                                    best_J = val; base = dict(cand); moved = True
                                else:
                                    _set(sig, base)
                    if not moved:
                        break
                for sig in group:
                    fin = _vec(sig)
                    mv = sum(abs(fin[p] - start[sig][p]) for p in MP)
                    total_moved += mv
                    control.diagnostics["wu_joint_moved_sec_%s" % sig] = float(mv)
                    for p in MP:
                        control.diagnostics["wu_joint_final_%s_%s" % (sig, p)] = float(fin[p])
                control.diagnostics["wu_joint_objective"] = float(best_J)
            control.diagnostics["wu_joint_moved_total_sec"] = float(total_moved)
            self._phase_ctx_cache = None
            return n

        _fol_cls_j.apply_phase_price_refinement = _joint_refine
        _fol_cls_j._joint_wrapped = True

    # 옵션① 2단 정련 — 팔로워 클래스의 apply_phase_price_refinement 를 감싼다.
    _fol_cls = None
    try:
        from src.controllers.priced_wu_link_controller import LinkAgentWuFollower as _fol_cls
    except Exception:  # noqa: BLE001
        _fol_cls = None
    if _fol_cls is not None and not getattr(_fol_cls, "_two_stage_wrapped", False):
        _orig_refine = _fol_cls.apply_phase_price_refinement

        def _two_stage_refine(self, control, state, demand=None):
            ctx = getattr(self, "_two_stage_ctx", None)
            controller = ctx[0] if ctx else None
            if not ctx or not bool(getattr(controller, "phase_price_two_stage", False)):
                return _orig_refine(self, control, state, demand)
            _, forecast, previous = ctx
            w = float(self.signal_phase_price_weight)
            # 1단: 가격 0 → plan A
            self.signal_phase_price_weight = 0.0
            n_a = _orig_refine(self, control, state, demand)
            plan_a = dict(control.green_times)
            for key, val in plan_a.items():
                control.diagnostics["wu_two_stage_planA_%s" % key] = float(val)
            # 가격 재계산: 기준 = plan A
            prev_a = previous.copy()
            prev_a.green_times = dict(previous.green_times)
            prev_a.green_times.update(plan_a)
            controller._refresh_phase_prices(state, forecast, prev_a)
            self._two_stage_ctx = ctx  # refresh 가 덮어써도 유지
            self.signal_phase_price_weight = w
            # 2단: plan A 에서 가격 정련 (ref = plan A)
            n_b = _orig_refine(self, control, state, demand)
            moved = sum(abs(float(control.green_times.get(k, 0.0)) - float(v)) for k, v in plan_a.items())
            control.diagnostics["wu_two_stage_stageA_refined"] = float(n_a)
            control.diagnostics["wu_two_stage_stageB_refined"] = float(n_b)
            control.diagnostics["wu_two_stage_moved_from_planA_sec"] = float(moved)
            return n_b

        _fol_cls.apply_phase_price_refinement = _two_stage_refine
        _fol_cls._two_stage_wrapped = True
    return {"price_local_phased_enabled": 1.0}


def install_ramp_aware_phase_local(controller, tuning: Mapping[str, Any]) -> dict[str, float]:
    """has_ramps 신호의 **현시 국소비용**을 GNE 와 같은 ramp-aware 물리로 채점한다.

    `phase_price.ramp_local_model` 이 "ramp_aware" 가 아니면 no-op = 비트 동일.

    ## 왜

    `priced_wu_link_controller.py:299` 가 `model.has_ramps` 면 setup 을 **None** 으로 낸다.
    그러면 호출부 셋(정련 · in_gne 벡터탐색 · 가격 생성)이 전부
    `phase_shape_local_cost`(도착 없는 배수 모형)로 폴백하는데, 그 모형은 첫 substep 에
    큐를 다 비워 **어떤 녹색 벡터에서도 0.000000** 을 돌려준다 (2026-09-04 실측,
    SC1001·SC1004 의 전 스윕 지점). has_ramps 신호는 이 망에 그 둘뿐이다.

    국소항이 0 이면 현시가격 목적함수가

        obj = local + w * sum_i price_i (g_i - ref_i)  =  0 + 선형항

    이 되어 **순수 선형**이다. 선형함수는 상자 꼭짓점이 항상 최적이라, 두 신호는 매 결정
    trust 폭(6초)만큼 꼭짓점으로 걸어간다 — 실측 커밋이 매번 22.0/22.7/70.7/22.7 이다.
    그리고 그 결과가 **제대로 결합된 GNE 해를 덮어쓴다**(상류 주석: "GNE 가 p1 축만
    최적화 -> 정련이 되돌림"). `phase_price.in_gne` 팔이 진 것(TTT +728, 14.4 sigma)도
    이 평평한 채점기를 스윕 **안**으로 넣어 매 반복을 오염시켰기 때문이다.

    ## 무엇을 바꾸나 — 물리를 새로 짜지 않는다

    GNE 의 녹색 탐색은 **이미** 램프 신호를 `rollout_local_tts_ramp_aware` 로 채점한다
    (`wu_faithful_follower.py:938-952`). 램프 저수지 · off-ramp 저류 · freeway 혼잡을
    전부 받는다. 현시가격 채점만 그 경로를 우회하고 있었다. 여기서 같은 셋업을 만들어
    같은 함수를 부른다. 셋업 구성은 `wu_faithful_follower.py:1855-1905`(램프 신호
    offset 국소탐색)의 복제다 — 새 물리가 아니라 이미 검증된 물리의 재사용이다.

    도시->freeway 결합(`u_on_{ramp}`)은 손대지 않는다. 이미 녹색 벡터에서 유도되고
    Jacobi 스윕마다 재계산된다(2026-09-04 실측: SC1001 p3 22.7/45.0/70.7 ->
    u_on_R_D_W 168.3/209.3/256.5, 단조 증가). 고칠 것은 채점기뿐이었다.

    ## 주의 — ramp_metering_weight 는 이 팔에서 0.0 이다

    그래서 "막힌 freeway 로 보낸 적재" 벌점(local_signal_plant.py:392,
    `released_total * freeway_congestion * ramp_metering_weight`)은 꺼져 있다.
    곡률은 **저수지 포화**(적재가 `ramp_queue_max` 에 붙으면 녹색이 무력해진다)와
    off-ramp 저류에서 나온다. 그 가중치를 켜는 것은 **별건 A/B** 다 — GNE 자기 채점도
    같이 바뀌어 귀속이 흐려진다.
    """
    section = _mapping((tuning or {}).get("phase_price"))
    mode = str(section.get("ramp_local_model", "")).strip().lower()
    if mode != "ramp_aware":
        return {"phase_local_ramp_aware_enabled": 0.0}

    from src.controllers.priced_wu_link_controller import LinkAgentWuFollower as _Follower
    from src.controllers.local_signal_plant import rollout_local_tts_ramp_aware
    from src.models.state import MODEL_PHASES, phase_key

    orig_setup = _Follower._phase_refine_signal_setup
    orig_cost = _Follower._phase_local_cost_phased

    def _bump(key):
        _RAMPLOCAL_LAST[key] = float(_RAMPLOCAL_LAST.get(key, 0.0)) + 1.0

    def patched_setup(self, signal, state, ctx):
        setups = ctx.get("setups") if isinstance(ctx, dict) else None
        if setups is not None and signal in setups:
            return setups[signal]
        model = getattr(self, "_local_models", {}).get(signal)
        if model is None or not getattr(model, "has_ramps", False):
            return orig_setup(self, signal, state, ctx)
        try:
            snapshot = ctx["snapshot"]
            demand = ctx["demand"]
            coupling = ctx["coupling"]
            # 도착: off-ramp 몫을 phase 목표에서 빼고 재정규화 (상류와 같은 순서).
            arr_movement = self._per_movement_arrivals(signal, state, snapshot, demand)
            arr_phase = {
                pid: float(coupling.get("arr_%s" % phase_key(signal, pid), 0.0))
                for pid in MODEL_PHASES
            }
            offramp_inflow = {}
            offramp_contrib = {pid: 0.0 for pid in MODEL_PHASES}
            for off_ramp, movements in model.offramp_movements.items():
                inflow = self._frozen_offramp_inflow(off_ramp, state)
                offramp_inflow[off_ramp] = inflow
                for m in movements:
                    offramp_contrib[model.phase_of[m]] += model.beta_of[m] * inflow
            arr_mv = {}
            for pid in MODEL_PHASES:
                movs = [m for m in model.movements
                        if model.phase_of[m] == pid and model.kind_of[m] != "off_ramp"]
                raw = sum(max(0.0, float(arr_movement.get(m, 0.0))) for m in movs)
                target = max(0.0, arr_phase[pid] - offramp_contrib[pid])
                scale = (target / raw) if raw > 1.0e-12 else 0.0
                for m in movs:
                    arr_mv[m] = max(0.0, float(arr_movement.get(m, 0.0))) * scale
            q0 = {m: max(0.0, float(state.urban_movement_queue.get(m, 0.0)))
                  for m in model.movements}
            s_eff0 = {
                model.receiving_of[m]: float(ctx["s_eff_frozen"].get(model.receiving_of[m], 0.0))
                for m in model.movements if model.receiving_of[m]
            }
            arr_by = self._platoon_arrival_profiles(
                signal, state, snapshot, demand, arr_mv, ctx["substeps"], ctx["start_idx"],
            )
            # off_ramp movement 는 큐 도착이 아니라 storage 유입이다(상류와 같은 필터).
            arr_by = {m: prof for m, prof in arr_by.items()
                      if model.kind_of.get(m) != "off_ramp"}
            setup = {
                "model": model, "q0": q0, "arr": arr_by, "s_eff0": s_eff0,
                # 이 키가 있으면 patched_cost 가 ramp_aware 롤아웃으로 간다.
                "ramp_aware": True,
                "arr_mv": arr_mv,
                "offramp_inflow": offramp_inflow,
                "offramp_occ0": {r: self._offramp_occupancy(r, state)
                                 for r in model.offramp_movements},
                "ramp_queue0": {r: max(0.0, float(state.ramp_queue.get(r, 0.0)))
                                for r in model.onramp_movements},
                # frozen = 스텝 내 불변이라 신호당 1회 캐시가 옳다(상류도 그렇게 쓴다).
                "reservoir_drain": self._frozen_reservoir_drain(state, snapshot, demand),
                "freeway_congestion": self._frozen_freeway_congestion(state),
            }
        except Exception as exc:  # noqa: BLE001
            # 조용히 삼키지 않는다 — 옛 경로로 가되 몇 번 왜 터졌는지 남긴다.
            _bump("phase_local_ramp_setup_error")
            _RAMP_ERR[("%s: %s" % (type(exc).__name__, exc))[:200]] = 1.0
            return orig_setup(self, signal, state, ctx)
        if setups is not None:
            setups[signal] = setup
        _bump("phase_local_ramp_setup_built")
        return setup

    def patched_cost(self, signal, phases, setup, ctx):
        if not (isinstance(setup, dict) and setup.get("ramp_aware")):
            return orig_cost(self, signal, phases, setup, ctx)
        offset = float(ctx["snapshot"].offsets.get(signal, 0.0))
        gf = self._offset_green_fractions_vec(
            signal, phases, offset, ctx["substeps"], ctx["start_idx"],
        )
        _bump("phase_local_ramp_scored")
        return float(rollout_local_tts_ramp_aware(
            setup["model"], setup["q0"], setup["arr_mv"], setup["s_eff0"],
            setup["offramp_inflow"], setup["offramp_occ0"], setup["ramp_queue0"],
            setup["reservoir_drain"], setup["freeway_congestion"],
            float(getattr(self, "ramp_metering_weight", 0.0)),
            {pid: float(phases.get(pid, 0.0)) for pid in MODEL_PHASES},
            ctx["substeps"], ctx["dt_h"],
            arr_by_substep=setup["arr"], gf_by_substep=gf,
        ))

    _Follower._phase_refine_signal_setup = patched_setup
    _Follower._phase_local_cost_phased = patched_cost
    _RAMPLOCAL_LAST["phase_local_ramp_aware_enabled"] = 1.0
    return {"phase_local_ramp_aware_enabled": 1.0}


def install_local_ramp_queue_cap(controller, tuning: Mapping[str, Any]) -> dict[str, float]:
    """국소 신호 모델의 `ramp_queue_max` 를 **램프별 실제 상한**으로 채운다.

    `urban.ramp.local_queue_cap` 이 참이 아니면 no-op = 비트 동일.

    ## 왜 — 2026-09-01 승격의 미완 잔재다

    `local_signal_plant.py:123` 이 `ramp_queue_max=float(net.ramp_queue_max_veh)` 로
    **전역 스칼라**를 읽는다. 2026-09-01 에 그 스칼라를 벤더 기본 180 에서 **0.0** 으로
    내렸다 — "매핑을 빠뜨린 자리는 공간 0 = 즉시 차단이 되어 즉시 드러난다" 는 의도였다.
    그때 살아있는 wu-link 경로 12자리는 `net.ramp_queue_cap(ramp)` 로 바꿨는데,
    이 자리는 **"우리 config 는 on_ramp movement 0개라 미사용"** 이라 판단해 남겨 두었다.

    그런데 2026-09-03 에 `urban_movements` 에 on_ramp movement 를 넣어 승격했다
    (램프 저수지 유입 경로 신설, TTT -483.8). 그 순간부터 이 줄이 **살아났고**,
    국소 램프 모델은 저수지 용량 0 으로 돌고 있었다.

    실측(2026-09-04, ctl_start900 t=900/2700/4500):

        model.ramp_queue_max            0.00        (SC1001 · SC1004 둘 다)
        net.ramp_queue_cap(ramp)        111.2 ~ 174.5
        관측 ramp_queue0                4 ~ 44 veh   (상한 0 을 이미 초과)

    `rollout_local_tts_ramp_aware:387` 이 `res[ramp] = min(model.ramp_queue_max, ...)` 라
    용량 0 이면 적재가 **항상 0 으로 잘린다**. 저수지가 차지 않으니 포화 역압이 없고,
    도시 agent 는 램프로 방류해도 아무 대가를 안 낸다 — 램프 신호의 국소비용이 녹색에
    대해 단조 감소하는 직접 원인이다.

    ## 근사 하나 — min 을 쓴다

    `ramp_queue_max` 는 모델당 **스칼라 한 개**인데 SC1001 은 R_D_E(111.2)·R_D_W(153.2),
    SC1004 는 R_F_E(153.6)·R_F_W(174.5) 둘씩 소유한다. 롤아웃이 램프별로 같은 스칼라를
    읽으므로 정확히 하려면 롤아웃 자체를 고쳐야 한다. 여기서는 **소유 램프 중 최솟값**을
    쓴다 — 큰 쪽을 27% 과소 계상하지만 방향은 보수적(역압이 일찍 걸린다)이고,
    지배적 오차(0 대 111)는 사라진다. 정확한 램프별 상한이 필요해지면 그때
    `rollout_local_tts_ramp_aware` 를 램프별로 읽게 고쳐라.

    ## 파급

    이 값은 `_phase_local_cost_phased`(램프판)뿐 아니라 **GNE 자기 녹색 탐색**
    (`wu_faithful_follower.py:941·950`)과 램프 offset 국소탐색(:1934)도 읽는다.
    즉 이 패치는 팔로워 거동을 바꾼다. 순수 버그 수선이지만 A/B 귀속을 위해 별도 게이트로 둔다.
    """
    section = _mapping(_mapping((tuning or {}).get("urban")).get("ramp"))
    if not _is_enabled_value(section.get("local_queue_cap")):
        return {"local_ramp_queue_cap_enabled": 0.0}
    follower = getattr(controller, "nash_solver", None)
    models = getattr(follower, "_local_models", None)
    if not models:
        return {"local_ramp_queue_cap_enabled": 0.0, "local_ramp_queue_cap_models": 0.0}
    net = controller.cfg.network
    fixed = 0
    zero_before = 0
    for signal, model in models.items():
        ramps = list(getattr(model, "onramp_movements", {}) or {})
        if not ramps:
            continue
        caps = []
        for r in ramps:
            try:
                caps.append(float(net.ramp_queue_cap(r)))
            except Exception:  # noqa: BLE001
                continue
        caps = [c for c in caps if c > 0.0]
        if not caps:
            continue
        if float(getattr(model, "ramp_queue_max", 0.0)) <= 0.0:
            zero_before += 1
        model.ramp_queue_max = float(min(caps))
        fixed += 1
        _RAMPLOCAL_LAST["local_ramp_queue_cap_%s" % signal] = float(min(caps))
    _RAMPLOCAL_LAST["local_ramp_queue_cap_enabled"] = 1.0
    _RAMPLOCAL_LAST["local_ramp_queue_cap_models"] = float(fixed)
    _RAMPLOCAL_LAST["local_ramp_queue_cap_was_zero"] = float(zero_before)
    return {
        "local_ramp_queue_cap_enabled": 1.0,
        "local_ramp_queue_cap_models": float(fixed),
        "local_ramp_queue_cap_was_zero": float(zero_before),
    }


def install_in_gne_demand_fix(controller, tuning: Mapping[str, Any]) -> dict[str, float]:
    """in_gne 벡터 탐색이 `demand` 를 받지 못하던 것을 고친다.

    `phase_price.in_gne` 가 꺼져 있으면 no-op = 비트 동일. 켜져 있을 때만 건다.

    ## 결함

    `priced_wu_link_controller.py:606` 이

        demand = kwargs.get("demand")
        ctx = self._phase_refine_context(state, previous, demand)
        setup = self._phase_refine_signal_setup(signal, state, ctx) if ctx else None

    인데, 호출부(`wu_faithful_follower.py:4340` 등 5곳)는 **demand 를 위치인자로** 넘긴다.

        self._solve_urban_agent_local(
            signal, state, coupling, arr_movement, s_eff_frozen,
            reservoir_drain, freeway_congestion, snapshot, leader,
            lam_fixed, forecast_arrivals, horizon_h, demand,   # <- 13번째 위치인자
            committed_prev=previous,
        )

    그래서 `kwargs.get("demand")` 는 **항상 None** 이고, `_phase_refine_context` 가
    `if demand is None: return None` 로 즉시 빠진다. 결과적으로 in_gne 의 `setup` 이
    **17개 신호 전부 None** 이 되어 채점이 `phase_shape_local_cost`(도착 없는 배수 모형,
    항등 0)로 떨어진다. 목적함수가

        obj = 0 + w * sum_i price_i (g_i - ref_i)

    즉 **순수 선형**이 되고, 선형함수는 상자 꼭짓점이 항상 최적이라 매 결정 전 신호가
    trust 폭만큼 꼭짓점으로 걸어간다.

    바로 위 `previous` 는 `args[5]` 위치 폴백을 갖고 있다 — 작성자가 위치 전달을 알고
    있었고 `demand` 만 빠뜨린 것이다.

    ## 실측 (2026-09-04)

    ```
    arm_ingne900_lcd1000     TTT 8557.4   기준 대비 +728   (in_gne_rounds=2)
    arm_ramplocal_ingne900   TTT 10579.0  기준 대비 +2750  (rounds 12 = 6배 깊이)
    ```

    두 팔 다 `wu_phase_price_in_gne_signals = 17` 로 "돌았다"고 보고하는데, 진단
    `phase_local_ramp_scored = 10` 이 정확히 (SC1001 4현시 + SC1004 4현시 + base 2)
    = **가격 생성부 몫뿐**이었다. in_gne 에서는 램프 채점이 한 번도 안 돌았다.
    깊이에 비례해 나빠지는 것이 "꼭짓점으로 걸어간다" 와 정확히 맞는다.

    ## 무엇을 바꾸나

    `_solve_urban_agent_local` 을 감싸서 11번째 이후 위치인자를 이름인자로 정규화한다.
    앞 10개는 그대로 위치로 둔다 — 상류 override 가 `args[5]`(previous)를 위치로 읽으므로
    자리를 흔들면 안 된다. 이름이 이미 kwargs 에 있으면 그것을 이긴다(`setdefault`).
    vendor 는 한 줄도 안 고친다.
    """
    section = _mapping((tuning or {}).get("phase_price"))
    if not _is_enabled_value(section.get("in_gne")):
        return {"in_gne_demand_fix_enabled": 0.0}

    from src.controllers.priced_wu_link_controller import LinkAgentWuFollower as _Follower

    orig = _Follower._solve_urban_agent_local
    # 상류 시그니처의 11번째 이후 파라미터 이름(wu_faithful_follower.py:758-775).
    TAIL = ("demand", "candidates_override", "committed_prev")

    def patched(self, signal, state, *args, **kwargs):
        if len(args) > 10:
            extra = args[10:]
            args = args[:10]
            kw = dict(kwargs)
            for name, value in zip(TAIL, extra):
                kw.setdefault(name, value)
            kwargs = kw
            _RAMPLOCAL_LAST["in_gne_demand_fix_normalized"] = float(
                _RAMPLOCAL_LAST.get("in_gne_demand_fix_normalized", 0.0)) + 1.0
        return orig(self, signal, state, *args, **kwargs)

    _Follower._solve_urban_agent_local = patched
    _RAMPLOCAL_LAST["in_gne_demand_fix_enabled"] = 1.0
    return {"in_gne_demand_fix_enabled": 1.0}


def _leg_ramp_split_gate(tuning) -> bool:
    section = _mapping(_mapping((tuning or {}).get("urban")).get("ramp"))
    return _is_enabled_value(section.get("leg_split"))


# B5 (2026-09-06): 게이트발 on-ramp 접근 movement — 정지선 상류 peel-off 커넥터와 기본 분율(실측 30결정 평균 근사).
GATE_ONRAMP_QUEUE_MOVEMENTS = {
    "SC1001_W_to_onW": {"conn": "10482", "default_share": 0.30},
    "SC1001_W_to_onE": {"conn": "10490", "default_share": 0.15},
    "SC1004_W_to_onE": {"conn": "10639", "default_share": 0.20},
}

def install_leg_ramp_split_fold(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """B 팔 1/2: on* movement 를 W_out 수신 movement 로 되접는다. `install_merged_movements` 앞에서."""
    if not _leg_ramp_split_gate(tuning):
        return {"leg_ramp_split_enabled": 0.0}
    net = cfg.network
    specs = dict(getattr(net, "urban_movements", {}) or {})
    ramp_specs = {k: v for k, v in specs.items() if isinstance(v, Mapping) and v.get("ramp")}
    folded_into_w = 0
    redistributed = 0
    moved_beta = 0.0
    by_origin: dict[str, list[str]] = {}
    for name, spec in specs.items():
        if name in ramp_specs:
            continue
        by_origin.setdefault(str(spec.get("origin", "")), []).append(name)
    # B5: 게이트발 on-ramp 접근 movement 는 되접지 않고 남긴다(무신호 큐). 등록·β 는 install_gate_onramp_queue 가 한다.
    _gq_on = _is_enabled_value(_mapping(_mapping((tuning or {}).get("urban")).get("ramp")).get("gate_onramp_queue"))
    kept_gate_onramp: list[str] = []
    if _gq_on:
        for _n in list(ramp_specs):
            if _n in GATE_ONRAMP_QUEUE_MOVEMENTS and str(ramp_specs[_n].get("origin", "")).startswith("in_"):
                kept_gate_onramp.append(_n)
                ramp_specs.pop(_n)
                _sp = dict(specs[_n]); _sp["unsignalized"] = True; specs[_n] = _sp
    for name, spec in ramp_specs.items():
        beta = max(0.0, _as_float(spec.get("beta"), 0.0))
        origin = str(spec.get("origin", ""))
        siblings = by_origin.get(origin, [])
        w_sibs = [m for m in siblings if str(specs[m].get("exit", "")) == "W"]
        if w_sibs:
            target = w_sibs[0]
            specs[target] = dict(specs[target])
            specs[target]["beta"] = _as_float(specs[target].get("beta"), 0.0) + beta
            folded_into_w += 1
        elif siblings:
            tot = sum(max(0.0, _as_float(specs[m].get("beta"), 0.0)) for m in siblings)
            for m in siblings:
                specs[m] = dict(specs[m])
                share = (max(0.0, _as_float(specs[m].get("beta"), 0.0)) / tot) if tot > 1e-12 else 1.0 / len(siblings)
                specs[m]["beta"] = _as_float(specs[m].get("beta"), 0.0) + beta * share
            redistributed += 1
        moved_beta += beta
        del specs[name]
    setattr(net, "urban_movements", specs)
    setattr(net, "leg_ramp_split_enabled", True)
    setattr(net, "gate_onramp_queue_kept", list(kept_gate_onramp))
    _LEGSPLIT_LAST["gate_onramp_queue_kept"] = float(len(kept_gate_onramp))
    section = _mapping(_mapping((tuning or {}).get("urban")).get("ramp"))
    # 속도: config 키가 있으면 그것, 없으면 parameters.json network.wout_travel_speed_km_h (코드 기본값 없음).
    spd = section.get("leg_split_wout_speed_kmh")
    if spd is None:
        spd = getattr(net, "wout_travel_speed_km_h", None)
    if spd is None:
        if str(WORKSPACE_ROOT) not in sys.path:
            sys.path.insert(0, str(WORKSPACE_ROOT))
        from evaluation import parameters as _params
        spd = _mapping(_params.require("runtime", "network")).get("wout_travel_speed_km_h")
    if spd is None:
        raise RuntimeError("leg_split: wout_travel_speed_km_h 가 config 에도 parameters.json runtime.network 에도 없다")
    setattr(net, "leg_ramp_split_wout_speed_kmh", float(spd))
    out = {
        "leg_ramp_split_enabled": 1.0,
        "leg_ramp_split_folded_movements": float(len(ramp_specs)),
        "leg_ramp_split_folded_into_w": float(folded_into_w),
        "leg_ramp_split_redistributed": float(redistributed),
        "leg_ramp_split_moved_beta": float(moved_beta),
    }
    _LEGSPLIT_LAST.update(out)
    return out


def _legsplit_arrived_at_link(state, net, link: str, step_idx: int) -> float:
    """vendor 블록(:1053-1064)과 같은 정의: 점유 − 아직 이동 중인 예약. 읽기 전용."""
    cap = float(net.urban_link_storage_veh.get(link, net.boundary_queue_max_veh))
    occupancy = max(0.0, cap - float(state.urban_link_storage.get(link, cap)))
    pending = 0.0
    buf = (getattr(state, "urban_storage_release_buffer", None) or {}).get(link) or {}
    for arrival_step, veh in buf.items():
        if int(arrival_step) > int(step_idx):
            pending += float(veh)
    return max(0.0, occupancy - pending)


def _legsplit_wout_rate(net, link: str, speed_kmh: float) -> float:
    """W_out 링크 점유가 링크 끝에 도착하는 최대율[veh/h] = 점유가 τ 안에 다 도착한다고 볼 때의 상한.
    τ = 길이/속도. 길이는 저류 정본의 urban_link_length_km, 없으면 1.0 km. 반환값은 '재고 1대당' 이 아니라
    호출부에서 min(arrived, rate_per_veh * arrived * dt) 로 쓰기 위한 1/τ [1/h]."""
    # B1' (2026-09-05): 길이는 parameters.json network.boundary_out_link_length_km (정본 값의 단일 출처).
    # 없으면 저류 정본의 urban_link_length_km, 그것도 없으면 1.0 km 로 두고 _LEGSPLIT_LAST 에 표시한다.
    # parameters.json runtime.network.boundary_out_link_length_km 가 apply_runtime 으로 cfg.network 에 붙는다.
    length_km = float(_mapping(getattr(net, "boundary_out_link_length_km", None)).get(link, 0.0) or 0.0)
    if length_km <= 0.0:
        try:
            if str(WORKSPACE_ROOT) not in sys.path:
                sys.path.insert(0, str(WORKSPACE_ROOT))
            from evaluation import parameters as _params
            length_km = float(_mapping(_mapping(_params.require("runtime", "network")).get("boundary_out_link_length_km")).get(link, 0.0) or 0.0)
        except Exception:
            length_km = 0.0
    if length_km <= 0.0:
        lengths = getattr(net, "urban_link_length_km", None) or {}
        length_km = float(lengths.get(link, 0.0) or 0.0) if isinstance(lengths, Mapping) else 0.0
    if length_km <= 0.0:
        length_km = 1.0
        _LEGSPLIT_LAST["leg_ramp_split_length_fallback"] = _LEGSPLIT_LAST.get("leg_ramp_split_length_fallback", 0.0) + 1.0
    _LEGSPLIT_LAST["leg_ramp_split_len_%s" % link] = length_km
    tau_h = max(length_km / max(float(speed_kmh), 5.0), 1.0e-4)
    return 1.0 / tau_h


def _legsplit_wbound_request(state, control, cfg, link: str, horizon_h: float) -> float:
    """W_out(link)로 가는 movement 들이 horizon 동안 녹색으로 내보낼 수 있는 양[veh]."""
    from src.models import urban_queue_model as _uqm
    specs = _uqm.movement_specs(cfg)
    total = 0.0
    for movement, spec in specs.items():
        if str(spec.get("receiving_link", "")) != str(link):
            continue
        available = max(0.0, float(state.urban_movement_queue.get(movement, 0.0)))
        cap_flow = _uqm._movement_capacity_flow(control, cfg, movement, spec)
        gf = _uqm._phase_green_fraction(control, cfg, spec)
        total += min(available, horizon_h * float(gf) * float(cap_flow))
    return total


def install_leg_ramp_split_runtime(cfg) -> dict[str, float]:
    """B 팔 2/2: 모듈 패치. cfg.network.leg_ramp_split_enabled 가 아니면 no-op. 멱등."""
    net = cfg.network
    if not bool(getattr(net, "leg_ramp_split_enabled", False)):
        return {"leg_ramp_split_runtime": 0.0}
    from src.models import urban_queue_model as _uqm
    split_table = dict(getattr(net, "boundary_out_ramp_split", {}) or {})
    if not split_table:
        raise RuntimeError("leg_split 은 urban.boundary_out.ramp_split 이 켜져 있어야 한다 (분할표 없음)")
    # B1 (2026-09-05): W_out 재고를 τ 로 편다. 속도는 fold 단계에서 net.leg_ramp_split_wout_speed_kmh 로 심는다.
    wout_speed = float(getattr(net, "leg_ramp_split_wout_speed_kmh", 40.0) or 40.0)

    if not getattr(_uqm.urban_substep, "_legsplit_wrapped", False):
        _orig_substep = _uqm.urban_substep

        def patched_substep(state, control, demand, cfg_arg, urban_step_index=None, ramp_release_veh_h=None):
            net_a = cfg_arg.network
            table = dict(getattr(net_a, "boundary_out_ramp_split", {}) or {})
            if not table or not bool(getattr(net_a, "leg_ramp_split_enabled", False)):
                return _orig_substep(state, control, demand, cfg_arg, urban_step_index=urban_step_index,
                                     ramp_release_veh_h=ramp_release_veh_h)
            rel = ramp_release_veh_h
            if rel is None:
                rel = dict(getattr(control, "ramp_metering", {}) or {})
            sim = cfg_arg.simulation
            # B3 (2026-09-05): 꼬리 sink(<SC>_W_tail)의 통과속도. vendor _link_delay_steps 는 관측속도가 없으면
            # 전역 urban_avg_speed 로 "가용공간×6 m" 를 통과시켜 빈 꼬리(200대=1.2 km)가 수백 초 이동 중이 된다.
            # W_out 의 관측 유효속도를 그대로 준다(같은 도로의 하류 구간).
            spd_map = getattr(state, "urban_link_speed_kph", None)
            if isinstance(spd_map, dict):
                for link in table:
                    tail = str(link).replace("_W_out", "_W_tail")
                    if tail in net_a.urban_link_storage_veh and spd_map.get(str(link)) and not spd_map.get(tail):
                        spd_map[tail] = float(spd_map[str(link)])
            idx = _uqm._urban_step_index(state, cfg_arg) if urban_step_index is None else int(urban_step_index)
            # ---- B1''' (2026-09-05 19:1x): W_out 인출을 τ 도착량 기준으로 래퍼가 정한다 ----
            # vendor 블록(:1053-1083)의 두 결함: (1) 램프 진입 상한이 min(공간, 미터방출)인데 미터방출은 저수지
            # 큐가 있어야 생겨서 빈 저수지엔 못 들어가는 교착, (2) 자유 진출이 share×재고를 매 substep 다시
            # 계산해 1,600 vph 로 재고 전체(램프행 포함)를 빼간다. 여기서는 이번 substep 에 링크 끝에 닿는
            # 양(reach)만 목적지별로 나누고 램프는 공간·연결로 용량(ramp_capacity)으로만 막는다. 호출 뒤
            # vendor 가 뺀 총량과 의도 총량의 차이를 저류로 되돌리고 램프 몫을 저수지에 넣는다.
            inject: dict[str, float] = {}
            adjust: dict[str, float] = {}   # link -> (의도 인출 − vendor 인출); 양수면 vendor 가 더 뺀 것 → 되돌림
            exit_cap_h = float(getattr(net_a, "boundary_out_capacity_veh_h", 0.0) or 0.0)
            finite_exit = exit_cap_h > 0.0
            conn_caps = dict(getattr(net_a, "ramp_capacity_veh_h", {}) or {})
            for link, spec in table.items():
                arrived = _legsplit_arrived_at_link(state, net_a, str(link), idx)
                if arrived <= 0.0:
                    continue
                spd = float(getattr(net_a, "leg_ramp_split_wout_speed_kmh", 40.0) or 40.0)
                reach = min(arrived, arrived * _legsplit_wout_rate(net_a, str(link), spd) * float(sim.T_u_h))
                free_share = max(0.0, float(spec.get("free", 0.0)))
                exit_cap_veh = exit_cap_h * float(sim.T_u_h)
                vendor_free = min(arrived * free_share, exit_cap_veh) if finite_exit else arrived * free_share
                intended_free = min(reach * free_share, exit_cap_veh) if finite_exit else reach * free_share
                vendor_total = vendor_free
                intended_total = intended_free
                for ramp, share in (spec.get("ramps") or {}).items():
                    sh = max(0.0, float(share))
                    cap_r = float(net_a.ramp_queue_cap(str(ramp)))
                    space = max(0.0, cap_r - max(0.0, float(state.ramp_queue.get(str(ramp), 0.0))))
                    meter = max(0.0, float((rel or {}).get(str(ramp), 0.0))) * float(sim.T_u_h)
                    vendor_total += min(arrived * sh, min(space, meter))
                    conn = max(0.0, float(conn_caps.get(str(ramp), 0.0) or 0.0)) * float(sim.T_u_h)
                    entry_cap = min(space, conn) if conn > 0.0 else space
                    allowed = min(reach * sh, entry_cap)
                    if allowed > 0.0:
                        inject[str(ramp)] = inject.get(str(ramp), 0.0) + allowed
                        intended_total += allowed
                adjust[str(link)] = intended_total - vendor_total
            # B5 v2: 게이트발 on-ramp 큐가 등록된 램프는 도시 착지(ramp_arrival)만 0 — β×게이트 항과 이중계상 방지.
            #   리더의 N_UF 도착 목표는 원래 demand 를 보므로 건드리지 않는다(v1 은 demand_from_state 에서 0 으로 두어 t=900 미터를 조였다).
            _gq_ramps = getattr(net_a, "gate_onramp_queue_ramps", None) or ()
            if _gq_ramps:
                import copy as _copy
                demand = _copy.copy(demand)
                demand.ramp_arrival = {k: (0.0 if str(k) in set(str(x) for x in _gq_ramps) else v) for k, v in dict(getattr(demand, 'ramp_arrival', {}) or {}).items()}
            out = _orig_substep(state, control, demand, cfg_arg, urban_step_index=urban_step_index,
                                ramp_release_veh_h=rel)
            for ramp, veh in inject.items():
                cap_r = float(net_a.ramp_queue_cap(ramp))
                state.ramp_queue[ramp] = min(cap_r, max(0.0, float(state.ramp_queue.get(ramp, 0.0))) + veh)
                _LEGSPLIT_LAST["leg_ramp_split_injected_%s" % ramp] = _LEGSPLIT_LAST.get("leg_ramp_split_injected_%s" % ramp, 0.0) + veh
            # B3 (2026-09-05): 꼬리 sink 의 추가 배출. vendor 는 전역 1,600 vph 로만 내보내 3,600 vph 유입에 쌓인다.
            tail_caps = _mapping(getattr(net_a, "wout_tail_exit_capacity_veh_h", None))
            exit_base_h = float(getattr(net_a, "boundary_out_capacity_veh_h", 0.0) or 0.0)
            for tail, cap_h in tail_caps.items():
                if tail not in net_a.urban_link_storage_veh:
                    continue
                extra_h = max(0.0, float(cap_h) - exit_base_h)
                if extra_h <= 0.0:
                    continue
                cap_t = float(net_a.urban_link_storage_veh[tail])
                arrived_t = _legsplit_arrived_at_link(state, net_a, tail, idx)
                extra = min(arrived_t, extra_h * float(sim.T_u_h))
                if extra > 0.0:
                    state.urban_link_storage[tail] = min(cap_t, float(state.urban_link_storage.get(tail, cap_t)) + extra)
                    _LEGSPLIT_LAST["leg_ramp_split_tail_extra_exit_veh"] = _LEGSPLIT_LAST.get("leg_ramp_split_tail_extra_exit_veh", 0.0) + extra
            for link, delta in adjust.items():
                if abs(delta) <= 1.0e-12:
                    continue
                cap_l = float(net_a.urban_link_storage_veh.get(link, net_a.boundary_queue_max_veh))
                # storage = 가용공간. vendor 가 departed 만큼 늘렸으니 (의도 − vendor) 만큼 더 늘리거나 줄인다.
                state.urban_link_storage[link] = min(cap_l, max(0.0, float(state.urban_link_storage.get(link, cap_l)) + delta))
                _LEGSPLIT_LAST["leg_ramp_split_storage_adjust_veh"] = (
                    _LEGSPLIT_LAST.get("leg_ramp_split_storage_adjust_veh", 0.0) + delta)
            _LEGSPLIT_LAST["leg_ramp_split_injected_veh"] = (
                _LEGSPLIT_LAST.get("leg_ramp_split_injected_veh", 0.0) + sum(inject.values()))
            return out

        patched_substep._legsplit_wrapped = True
        _uqm.urban_substep = patched_substep
        # coupling.py:15 등은 urban_substep 을 **이름으로** import 해 원본을 물고 있다(2026-09-05 19:1x 실측:
        # 결합 롤아웃에서 래퍼가 한 번도 안 돌았다). 이미 import 된 모든 모듈의 같은 이름 속성을 바꾼다.
        rebound = 0
        for _modname, _mod in list(sys.modules.items()):
            if _mod is None or _mod is _uqm:
                continue
            try:
                if getattr(_mod, "urban_substep", None) is _orig_substep:
                    setattr(_mod, "urban_substep", patched_substep)
                    rebound += 1
            except Exception:
                continue
        _LEGSPLIT_LAST["leg_ramp_split_substep_rebound_modules"] = float(rebound)

    def _flows(state, control, demand, cfg_arg, interval_h=None, capped=False, **_kw):
        net_a = cfg_arg.network
        table = dict(getattr(net_a, "boundary_out_ramp_split", {}) or {})
        horizon_h = float(cfg_arg.simulation.T_f_h if interval_h is None else interval_h)
        idx = _uqm._urban_step_index(state, cfg_arg)
        release: dict[str, float] = {}
        for link, spec in table.items():
            arrived = _legsplit_arrived_at_link(state, net_a, str(link), idx)
            req = _legsplit_wbound_request(state, control, cfg_arg, str(link), horizon_h)
            # B1: 재고항은 horizon 안에 링크 끝에 닿는 양만 = min(재고, 재고/τ · h)
            spd = float(getattr(net_a, "leg_ramp_split_wout_speed_kmh", 40.0) or 40.0)
            stock = min(arrived, arrived * _legsplit_wout_rate(net_a, str(link), spd) * horizon_h)
            # B1'' (2026-09-05): u_on 은 링크 유량(재고/τ)만. req(녹색 방류율)는 정상상태에서 같은 유량의 다른
            # 추정치라 더하면 이중계상이고, 정본 용량(206.5/차로)에선 plant 의 1/4 이라 섞으면 과소로 끌린다.
            # 녹색 반응은 plant 롤아웃(래퍼 주입, τ 지연)으로 남는다. req 는 진단에만.
            total = stock
            _LEGSPLIT_LAST["leg_ramp_split_req_last_%s" % link] = float(req)
            for ramp, share in (spec.get("ramps") or {}).items():
                veh = total * max(0.0, float(share))
                if capped:
                    cap_r = float(net_a.ramp_queue_cap(str(ramp)))
                    space = max(0.0, cap_r - max(0.0, float(state.ramp_queue.get(str(ramp), 0.0))))
                    veh = min(veh, space)
                release[str(ramp)] = release.get(str(ramp), 0.0) + veh / max(horizon_h, 1.0e-9)
        # B5: 게이트발 on-ramp 접근 movement 의 기대 서비스(큐 + β×게이트 도착, 연결로 용량·공간 상한)
        for _m in (getattr(net_a, "gate_onramp_queue_kept", None) or []):
            _sp = (getattr(net_a, "urban_movements", {}) or {}).get(_m)
            if not _sp:
                continue
            _r = str(_sp.get("ramp", ""))
            _q = max(0.0, float(state.urban_movement_queue.get(_m, 0.0)))
            _gate = max(0.0, float((getattr(demand, "urban_boundary", {}) or {}).get(str(_sp.get("origin", "")), 0.0)))
            _arr = max(0.0, _as_float(_sp.get("beta"), 0.0)) * _gate * horizon_h
            _cap = float((getattr(net_a, "movement_capacity_by_movement_veh_h", {}) or {}).get(_m, 1800.0)) * horizon_h
            _veh = min(_q + _arr, _cap)
            if capped:
                _space = max(0.0, float(net_a.ramp_queue_cap(_r)) - max(0.0, float(state.ramp_queue.get(_r, 0.0))))
                _veh = min(_veh, _space)
            release[_r] = release.get(_r, 0.0) + _veh / max(horizon_h, 1.0e-9)
        for ramp in getattr(net_a, "ramps", []) or []:
            release.setdefault(str(ramp), 0.0)
        _LEGSPLIT_LAST["leg_ramp_split_u_on_last"] = float(sum(release.values()))
        return release

    def legsplit_reservoir_inflow(state, control, demand, cfg_arg, interval_h=None, **kw):
        return _flows(state, control, demand, cfg_arg, interval_h=interval_h, capped=False)

    def legsplit_green_release_flows(state, control, demand, cfg_arg, interval_h=None, **kw):
        return _flows(state, control, demand, cfg_arg, interval_h=interval_h, capped=True)

    legsplit_reservoir_inflow._legsplit = True
    legsplit_green_release_flows._legsplit = True
    patched_modules = 0
    _uqm.estimate_onramp_reservoir_inflow = legsplit_reservoir_inflow
    _uqm.estimate_onramp_green_release_flows = legsplit_green_release_flows
    patched_modules += 1
    for modname in ("src.controllers.wu_distributed", "src.controllers.leader",
                    "src.controllers.freeway_follower", "src.controllers.distributed_coordinator"):
        try:
            mod = importlib.import_module(modname)
        except Exception:
            continue
        hit = False
        if hasattr(mod, "estimate_onramp_reservoir_inflow"):
            mod.estimate_onramp_reservoir_inflow = legsplit_reservoir_inflow
            hit = True
        if hasattr(mod, "estimate_onramp_green_release_flows"):
            mod.estimate_onramp_green_release_flows = legsplit_green_release_flows
            hit = True
        patched_modules += 1 if hit else 0
    out = {"leg_ramp_split_runtime": 1.0, "leg_ramp_split_patched_modules": float(patched_modules),
           "leg_ramp_split_links": float(len(split_table))}
    _LEGSPLIT_LAST.update(out)
    return out


def install_offramp_direct_landing(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """B4a (2026-09-05): off-ramp 착지 분할 — 유입 시점에 가른다. `urban.ramp.offramp_direct` 없으면 no-op.

    plant: FW_W 의 D off-ramp 는 10491→링크 32(SC1001 신호 접근)와 10479→링크 31(W_out, 램프 분기 하류 871 m, 무신호)로
    갈린다. 실측 30결정 직행 분율 D 0.468 · F 0.484 (`urban.ramp.offramp_direct_share`).
    B3(격리)는 이것을 '무신호 movement 가 저장고 잔여 pool 의 46%' 로 넣었는데 `_drain_offramp_storage` 가 β×잔여점유를
    매 substep 다시 계산하므로 신호 movement 가 적색이어도 저장고가 통째로 비워졌다 → p3 무가치 → SC1001 p1 꼭짓점
    → 링크 32 잠김 → off-ramp 본선 역류(g2 본선 +1002 veh·h).
    B4a: net 에 off-ramp 별 분율·꼬리를 심고 `install_offramp_landing_runtime` 이 `schedule_offramp_arrivals` 를 감싼다.
    `_to_W_RAMP`(SC1001) · `_to_W`(SC1004) 는 정지선에서 W_out 으로 가는 물리 회전이 없어 β 0, 형제 재정규화(합 1).
    병합 뒤 이름으로 작업하므로 install_movement_capacity_by_lanes 뒤에 부른다.
    """
    section = _mapping(_mapping((tuning or {}).get("urban")).get("ramp"))
    if not _is_enabled_value(section.get("offramp_direct")):
        return {"offramp_direct_enabled": 0.0}
    net = cfg.network
    specs = dict(getattr(net, "urban_movements", {}) or {})
    shares = _mapping(section.get("offramp_direct_share")) or {"SC1001": 0.468, "SC1004": 0.484}
    tail_cap = _as_float(section.get("offramp_direct_tail_storage_veh"), 200.0)
    targets = {"SC1001": ("SC1001_offW_to_W_RAMP", "SC1001_offE_to_W_RAMP"),
               "SC1004": ("SC1004_offW_to_W", "SC1004_offE_to_W")}
    storage = dict(getattr(net, "urban_link_storage_veh", {}) or {})
    out_links = list(getattr(net, "boundary_out_links", []) or [])
    off_idx = {k: list(v) for k, v in dict(getattr(net, "off_ramp_to_movement", {}) or {}).items()}
    share_by_offramp: dict[str, float] = {}
    tail_by_offramp: dict[str, str] = {}
    changed = 0
    zeroed = 0.0
    for sc, names in targets.items():
        share = max(0.0, min(1.0, _as_float(shares.get(sc), 0.0)))
        tail = "%s_W_tail" % sc
        tail_out = "%s_W_tail_out" % sc
        storage.setdefault(tail, float(tail_cap))
        if tail_out not in out_links:
            out_links.append(tail_out)
        for name in names:
            spec = specs.get(name)
            if not isinstance(spec, Mapping):
                continue
            origin = str(spec.get("origin", ""))
            sibs = [m for m, sp in specs.items() if m != name and str(sp.get("origin", "")) == origin]
            old = max(0.0, _as_float(spec.get("beta"), 0.0))
            sib_tot = sum(max(0.0, _as_float(specs[m].get("beta"), 0.0)) for m in sibs)
            for m in sibs:
                sp2 = dict(specs[m])
                b = max(0.0, _as_float(sp2.get("beta"), 0.0))
                sp2["beta"] = (b / sib_tot) if sib_tot > 1e-12 else 0.0
                specs[m] = sp2
            sp = dict(spec)
            sp["beta"] = 0.0
            sp.pop("unsignalized", None)
            specs[name] = sp
            zeroed += old
            changed += 1
            for off_ramp, mv in off_idx.items():
                if name in mv:
                    share_by_offramp[str(off_ramp)] = share
                    # B4b (2026-09-05 23:0x): FW_E 쪽 off-ramp(OR_*_E)의 직행 착지(10483@614 · 10682@237)는 램프 분기
                    # 상류라 W행 램프(10480@735 · 10646@352)를 탈 수 있다 → W_out pool. FW_W 쪽(10479@871 · 10645@573)은
                    # 분기 하류 → 꼬리 sink. (링크 31/68 커넥터 전수 .inpx 위치, far 실측 D 신호유입 534 < 램프행 824)
                    tail_by_offramp[str(off_ramp)] = tail if str(off_ramp).endswith("_W") else "%s_W_out" % sc
    setattr(net, "urban_movements", specs)
    setattr(net, "urban_link_storage_veh", storage)
    setattr(net, "boundary_out_links", out_links)
    setattr(net, "offramp_direct_share_by_offramp", share_by_offramp)
    setattr(net, "offramp_direct_tail_by_offramp", tail_by_offramp)
    out = {"offramp_direct_enabled": 1.0, "offramp_direct_movements": float(changed),
           "offramp_direct_beta_zeroed": float(zeroed), "offramp_direct_offramps": float(len(share_by_offramp))}
    _LEGSPLIT_LAST.update(out)
    return out


def install_offramp_landing_runtime(cfg) -> dict[str, float]:
    """B4a: `schedule_offramp_arrivals` 를 감싸 직행 분율을 꼬리 sink 로 보낸다. net 에 분율표가 없으면 no-op.

    coupling.py 가 이름으로 import 하므로 sys.modules 전체에서 같은 객체를 재바인딩한다. 워커(spawn)는
    `install_price_worker_runtime_patches` 가 다시 부른다(분율표는 cfg 와 함께 피클돼 넘어온다).
    """
    net = cfg.network
    share_map = dict(getattr(net, "offramp_direct_share_by_offramp", {}) or {})
    if not share_map:
        return {"offramp_landing_runtime": 0.0}
    from src.models import urban_queue_model as _uqm
    _orig = getattr(_uqm, "_offramp_landing_orig_schedule", None) or _uqm.schedule_offramp_arrivals

    def patched_schedule_offramp_arrivals(state, cfg_arg, off_ramp, vehicles, urban_step_index):
        net_a = cfg_arg.network
        s_ = float((getattr(net_a, "offramp_direct_share_by_offramp", {}) or {}).get(str(off_ramp), 0.0) or 0.0)
        tail = (getattr(net_a, "offramp_direct_tail_by_offramp", {}) or {}).get(str(off_ramp))
        veh = max(0.0, float(vehicles))
        direct_acc = 0.0
        direct_rej = 0.0
        if s_ > 0.0 and tail and tail in net_a.urban_link_storage_veh and veh > 0.0:
            _uqm.ensure_urban_state(state, cfg_arg)
            direct = veh * min(1.0, s_)
            cap_t = float(net_a.urban_link_storage_veh[tail])
            avail = max(0.0, float(state.urban_link_storage.get(tail, cap_t)))
            direct_acc = min(direct, avail)
            direct_rej = direct - direct_acc
            state.urban_link_storage[tail] = max(0.0, avail - direct_acc)
            _LEGSPLIT_LAST["offramp_direct_veh"] = _LEGSPLIT_LAST.get("offramp_direct_veh", 0.0) + direct_acc
            veh = max(0.0, veh - direct)
        accepted, rejected = _orig(state, cfg_arg, off_ramp, veh, urban_step_index)
        return float(accepted) + direct_acc, float(rejected) + direct_rej

    _uqm._offramp_landing_orig_schedule = _orig
    _uqm.schedule_offramp_arrivals = patched_schedule_offramp_arrivals
    rebound = 0
    for _modname, _mod in list(sys.modules.items()):
        if _mod is None or _mod is _uqm:
            continue
        try:
            cur = getattr(_mod, "schedule_offramp_arrivals", None)
        except Exception:
            continue
        if cur is None or not callable(cur):
            continue
        if cur is _orig or getattr(cur, "__name__", "") == "patched_schedule_offramp_arrivals":
            setattr(_mod, "schedule_offramp_arrivals", patched_schedule_offramp_arrivals)
            rebound += 1
    return {"offramp_landing_runtime": 1.0, "offramp_landing_rebound_modules": float(rebound)}

def install_landing_storage(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """B4c (2026-09-06): off-ramp 착지 접근로 점유를 plant 링크 재차에서 심는다. `urban.ramp.landing_storage` 없으면 no-op.

    사양: {off_ramp: {"links": [링크번호...], "queue_prefix": "SC1001_W_", "cap_veh": 296}}.
    저장고 cap 을 착지점→정지선 물리 용량으로 바꾸고(D 링크 32: 1270→1961 m·3차로 ≈ 296, F 링크 70(40→338 m·2차로)+71(81 m·5차로)
    ≈ 143), 매 결정 `traffic_state_from_vissim` 끝에서 점유 = Σ재차 − 귀속 정지 큐 로 심는다(관측 채널 off_ramp_storage_veh 는
    39/39 표본 0 이라 모형이 접근로를 1/5 로 봤다). λ_eff(용량감소) 는 `install_landing_storage_runtime` 이 (큐+저장고)/cap 으로.
    """
    section = _mapping(_mapping((tuning or {}).get("urban")).get("ramp"))
    table = _mapping(section.get("landing_storage"))
    if not table:
        return {"landing_storage_enabled": 0.0}
    net = cfg.network
    storage_map = dict(getattr(net, "off_ramp_storage_link", {}) or {})
    caps = dict(getattr(net, "urban_link_storage_veh", {}) or {})
    spec: dict[str, dict[str, Any]] = {}
    for off_ramp, entry in table.items():
        e = _mapping(entry)
        storage = str(storage_map.get(str(off_ramp), ""))
        if not storage:
            continue
        cap = _as_float(e.get("cap_veh"), 0.0)
        if cap <= 0.0:
            continue
        caps[storage] = float(cap)
        spec[str(off_ramp)] = {
            "storage": storage,
            "links": [str(x) for x in (e.get("links") or [])],
            "queue_prefix": str(e.get("queue_prefix", "")),
            "cap_veh": float(cap),
            # landing_storage_v2 (2026-09-06 01:4x): 같은 링크에 착지하는 off-ramp 들이 재차를 나눠 갖는 분율과 λ_eff 그룹
            "share": max(0.0, _as_float(e.get("share"), 1.0)),
            "group": str(e.get("group", "") or "|".join(str(x) for x in (e.get("links") or []))),
        }
    setattr(net, "urban_link_storage_veh", caps)
    setattr(net, "landing_storage_spec", spec)
    out = {"landing_storage_enabled": 1.0 if spec else 0.0, "landing_storage_offramps": float(len(spec))}
    for off_ramp, sp in spec.items():
        out["landing_storage_cap_%s" % off_ramp] = float(sp["cap_veh"])
    _LEGSPLIT_LAST.update(out)
    return out


def _landing_prefix_queue(state, prefix: str) -> float:
    if not prefix:
        return 0.0
    return float(sum(max(0.0, float(v)) for k, v in (getattr(state, "urban_movement_queue", {}) or {}).items() if str(k).startswith(prefix)))


def _apply_landing_storage(state, cfg, state_json: Mapping[str, Any]) -> None:
    """B4c: 저장고 점유 = Σ링크 재차 − 귀속 정지 큐 (cap 으로 절단)."""
    spec = dict(getattr(cfg.network, "landing_storage_spec", {}) or {})
    if not spec:
        return
    counts = _link_counts_from_local_observation(state_json)
    for off_ramp, sp in spec.items():
        storage = str(sp["storage"])
        cap = float(cfg.network.urban_link_storage_veh.get(storage, sp["cap_veh"]))
        total = float(sum(float(counts.get(str(link), 0.0)) for link in sp["links"]))
        q = _landing_prefix_queue(state, str(sp["queue_prefix"]))
        occ = clamp(float(sp.get("share", 1.0)) * max(0.0, total - q), 0.0, cap)
        state.urban_link_storage[storage] = float(cap) - occ
        _LEGSPLIT_LAST["landing_storage_total_%s" % off_ramp] = total
        _LEGSPLIT_LAST["landing_storage_queue_%s" % off_ramp] = q
        _LEGSPLIT_LAST["landing_storage_occ_%s" % off_ramp] = occ


def install_landing_storage_runtime(cfg) -> dict[str, float]:
    """B4c: metanet.effective_lane_profile 의 λ_eff 점유비를 (귀속 정지 큐 + 저장고)/cap 으로. net 에 사양 없으면 no-op.

    wu_distributed 가 이름으로 import 하므로 sys.modules 전체 재바인딩. 워커(spawn)는 `install_price_worker_runtime_patches` 가 다시 부른다.
    """
    spec = dict(getattr(cfg.network, "landing_storage_spec", {}) or {})
    if not spec:
        return {"landing_storage_runtime": 0.0}
    from src.models import metanet as _mn
    _orig = getattr(_mn, "_landing_orig_effective_lane_profile", None) or _mn.effective_lane_profile

    def patched_effective_lane_profile(state, cfg_arg, demand=None):
        sp_all = dict(getattr(cfg_arg.network, "landing_storage_spec", {}) or {})
        saved: dict[str, float] = {}
        caps_a = cfg_arg.network.urban_link_storage_veh
        # 그룹 총점유 = 정지 큐 + 그룹 내 저장고 점유 합 (= 링크 재차). 저장고 i 의 임시 가용 = cap_i − 총점유.
        group_occ: dict[str, float] = {}
        for off_ramp, sp in sp_all.items():
            storage = str(sp["storage"])
            if storage not in state.urban_link_storage:
                continue
            g = str(sp.get("group", storage))
            cap_i = float(caps_a.get(storage, sp["cap_veh"]))
            occ_i = max(0.0, cap_i - float(state.urban_link_storage[storage]))
            if g not in group_occ:
                group_occ[g] = _landing_prefix_queue(state, str(sp["queue_prefix"]))
            group_occ[g] += occ_i
        for off_ramp, sp in sp_all.items():
            storage = str(sp["storage"])
            if storage not in state.urban_link_storage:
                continue
            g = str(sp.get("group", storage))
            cap_i = float(caps_a.get(storage, sp["cap_veh"]))
            saved[storage] = float(state.urban_link_storage[storage])
            state.urban_link_storage[storage] = max(0.0, cap_i - float(group_occ.get(g, 0.0)))
        try:
            return _orig(state, cfg_arg, demand)
        finally:
            for storage, avail in saved.items():
                state.urban_link_storage[storage] = avail

    _mn._landing_orig_effective_lane_profile = _orig
    _mn.effective_lane_profile = patched_effective_lane_profile
    rebound = 0
    for _modname, _mod in list(sys.modules.items()):
        if _mod is None or _mod is _mn:
            continue
        try:
            cur = getattr(_mod, "effective_lane_profile", None)
        except Exception:
            continue
        if cur is None or not callable(cur):
            continue
        if cur is _orig or getattr(cur, "__name__", "") == "patched_effective_lane_profile":
            setattr(_mod, "effective_lane_profile", patched_effective_lane_profile)
            rebound += 1
    return {"landing_storage_runtime": 1.0, "landing_storage_rebound_modules": float(rebound)}

def install_gate_onramp_queue(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """B5: 되접기가 남긴 게이트발 on-ramp movement 를 `on_ramp_to_movement` 에 등록하고 무신호·연결로 용량으로 둔다.
    게이트 peel-off 실측 차감은 끈다(β 가 대신한다, 결정마다 `_apply_gate_onramp_beta`). 병합·용량 설치 뒤에 부른다."""
    net = cfg.network
    kept = list(getattr(net, "gate_onramp_queue_kept", []) or [])
    if not kept:
        return {"gate_onramp_queue_enabled": 0.0}
    specs = dict(getattr(net, "urban_movements", {}) or {})
    on_idx = {k: list(v) for k, v in dict(getattr(net, "on_ramp_to_movement", {}) or {}).items()}
    capmap = dict(getattr(net, "movement_capacity_by_movement_veh_h", {}) or {})
    section = _mapping(_mapping((tuning or {}).get("urban")).get("ramp"))
    conn_cap = _as_float(section.get("gate_onramp_queue_capacity_veh_h"), 1800.0)
    ramps: list[str] = []
    registered = 0
    for name in kept:
        sp = specs.get(name)
        if not isinstance(sp, Mapping):
            continue
        ramp = str(sp.get("ramp", ""))
        if not ramp:
            continue
        lst = on_idx.setdefault(ramp, [])
        if name not in lst:
            lst.append(name)
        registered += 1
        ramps.append(ramp)
        capmap[name] = float(conn_cap)
        sp2 = dict(sp); sp2["unsignalized"] = True; specs[name] = sp2
    setattr(net, "urban_movements", specs)
    setattr(net, "on_ramp_to_movement", on_idx)
    setattr(net, "movement_capacity_by_movement_veh_h", capmap)
    setattr(net, "gate_onramp_queue_ramps", sorted(set(ramps)))
    setattr(net, "gate_ramp_peeloff", False)   # 실측 차감 대신 β 로 표현
    out = {"gate_onramp_queue_enabled": 1.0, "gate_onramp_queue_registered": float(registered),
           "gate_onramp_queue_ramps": float(len(set(ramps))), "gate_ramp_peeloff_enabled": 0.0}
    _LEGSPLIT_LAST.update(out)
    return out


def _apply_gate_onramp_beta(cfg, state_json: Mapping[str, Any]) -> None:
    """B5: 결정마다 게이트발 on-ramp movement 의 β = 실측 peel 유량 / 게이트 유입량 (형제는 (1−Σβ) 로 재정규화)."""
    net = cfg.network
    kept = list(getattr(net, "gate_onramp_queue_kept", []) or [])
    if not kept:
        return
    specs = dict(getattr(net, "urban_movements", {}) or {})
    fm = _mapping(_mapping(_mapping(state_json).get("local_observation")).get("far_measurement"))
    vols = {str(k): _as_float(v, -1.0) for k, v in _mapping(fm.get("link_volume_veh_h")).items()}
    gates = {str(k): _as_float(v, 0.0) for k, v in _mapping(_mapping(_mapping(state_json).get("demand")).get("urban_volume_vph_by_gate")).items()}
    by_origin: dict[str, list[str]] = {}
    for n, sp in specs.items():
        if isinstance(sp, Mapping):
            by_origin.setdefault(str(sp.get("origin", "")), []).append(n)
    shares: dict[str, float] = {}
    for name in kept:
        sp = specs.get(name)
        if not isinstance(sp, Mapping):
            continue
        meta = GATE_ONRAMP_QUEUE_MOVEMENTS.get(name, {})
        origin = str(sp.get("origin", ""))
        gate_v = gates.get(origin, 0.0)
        v = vols.get(str(meta.get("conn", "")), -1.0)
        if gate_v > 1.0 and v >= 0.0:
            share = clamp(v / gate_v, 0.0, 0.85)
        else:
            share = _as_float(sp.get("beta"), _as_float(meta.get("default_share"), 0.0))
        # 2026-09-07: 관측 폴백(게이트 키 없음 — in_SC1004_W 는 게이트맵이 링크 69 를 미배정으로 둬 항상 폴백) 을 진단에 남긴다.
        _LEGSPLIT_LAST["gate_onramp_beta_fallback_%s" % name] = 0.0 if (gate_v > 1.0 and v >= 0.0) else 1.0
        shares[name] = share
        _LEGSPLIT_LAST["gate_onramp_beta_%s" % name] = float(share)
    for origin, names in by_origin.items():
        kept_here = [n for n in names if n in shares]
        if not kept_here:
            continue
        tot_kept = sum(shares[n] for n in kept_here)
        # 2026-09-07 수정: origin 합 상한. kept 가 둘(SC1001 onW 10482 + onE 10490)이면 개별 0.85 클램프만으로는 합이 1.7 까지 가고
        #   형제 β = b/tot_other·(1−tot_kept) 가 음수가 된다(h7 상태 21/37 에서 Σ>1, t=4500 재현 E_SC1002 β −0.22 → vendor 가
        #   β 를 그대로 곱해 음수 도착). 합을 개별 상한과 같은 0.85 로 비례 축소한다. 진단 gate_onramp_beta_clamped 는 프로세스 누적.
        cap_total = 0.85
        if tot_kept > cap_total:
            scale = cap_total / tot_kept
            for n in kept_here:
                shares[n] = shares[n] * scale
                _LEGSPLIT_LAST["gate_onramp_beta_%s" % n] = float(shares[n])
            _LEGSPLIT_LAST["gate_onramp_beta_clamped"] = float(_LEGSPLIT_LAST.get("gate_onramp_beta_clamped", 0.0)) + 1.0
            tot_kept = cap_total
        _LEGSPLIT_LAST["gate_onramp_beta_total_%s" % origin] = float(tot_kept)
        others = [n for n in names if n not in shares]
        tot_other = sum(max(0.0, _as_float(specs[n].get("beta"), 0.0)) for n in others)
        for n in kept_here:
            sp2 = dict(specs[n]); sp2["beta"] = float(shares[n]); specs[n] = sp2
        for n in others:
            sp2 = dict(specs[n])
            b = max(0.0, _as_float(sp2.get("beta"), 0.0))
            sp2["beta"] = (b / tot_other * (1.0 - tot_kept)) if tot_other > 1e-12 else 0.0
            specs[n] = sp2
    setattr(net, "urban_movements", specs)

def install_lambda_np_cap_override(controller, tuning: Mapping[str, Any]) -> dict[str, float]:
    """λ_P 상한을 config 로 노출한다. `dual.lambda_np_cap` 이 없으면 no-op = 비트 동일.

    ## 왜

    λ_P 는 결합제약 `sum_i nin_i = N_P_star` 의 듀얼이고, 팔로워가 후보 녹색 비용에
    `+ λ_P·nin_i(green)` 을 더한다(`wu_faithful_follower.py:919`). 즉 **17개 신호 전부**의
    국소 채점에 들어가는 전역 항이다.

    2026-09-04 에 `ramp_queue_max` 를 0 -> 111/153 으로 고쳤더니(팔 C) 두 신호의 국소
    모형만 바뀌었는데 녹색이 갈린 곳은 SC7·SC6·SC16·SC109 같은 **비램프** 신호였다.
    전파 경로가 이 듀얼이다 — on_ramp 는 `nin` 의 OUTFLOW 항이므로,

        cap 0  -> on_ramp served == 0  -> 유출항 소멸 -> Sigma nin 과대
        cap 111 -> on_ramp 방류 시작    -> feasible 범위 반토막 (179.9 -> 95.4)
        -> 리더 N_P* 164 -> 30 -> lambda_P 가 더 자주·크게 켜짐
           (평균 2.90 -> 6.13 · 비영 9/31 -> 19/31)
        -> 전 신호 채점 이동 -> 도시 누적 -> 미터 하한 -> TTT +1432

    그 사슬을 끊어 보려면 λ 를 묶어야 하는데, `lambda_np_cap` 은 팔로워
    `__init__` 상수(:445, 기본 10.0)라 config 로 못 만졌다. 여기서 연다.

    `0.0` 을 주면 `_lambda_np_update` 의 `clip(..., 0, cap)` 이 λ 를 영구 0 으로 묶어
    듀얼 항이 사라진다. `use_dual_np` 를 False 로 하는 것과는 다르다 — 그쪽은 레거시
    고정가중 w_P setpoint 패널티로 **갈아타는** 것이라 깨끗한 제거가 아니다.

    ## 주의

    이건 정본 승격 후보가 아니라 **분해 실험용 손잡이**다. λ 를 끄면 리더의 N_P 축이
    팔로워에 닿는 통로가 사라지므로, 반드시 cap 켬/끔 2x2 로 재야 한다 —
    λ 를 끈 것 자체의 효과와 cap 의 효과가 섞이지 않게.
    """
    section = _mapping((tuning or {}).get("dual"))
    if "lambda_np_cap" not in section:
        return {"lambda_np_cap_override_enabled": 0.0}
    cap = _as_float(section.get("lambda_np_cap"), -1.0)
    if cap < 0.0:
        return {"lambda_np_cap_override_enabled": 0.0}
    follower = getattr(controller, "nash_solver", None)
    if follower is None:
        return {"lambda_np_cap_override_enabled": 0.0}
    before = float(getattr(follower, "lambda_np_cap", -1.0))
    follower.lambda_np_cap = float(cap)
    # warm-start λ 도 상한 안으로 끌어온다 — 안 그러면 첫 결정만 옛 값으로 돈다.
    if float(getattr(follower, "_lambda_P", 0.0) or 0.0) > cap:
        follower._lambda_P = float(cap)
    _RAMPLOCAL_LAST["lambda_np_cap_override_enabled"] = 1.0
    _RAMPLOCAL_LAST["lambda_np_cap_value"] = float(cap)
    _RAMPLOCAL_LAST["lambda_np_cap_before"] = before
    return {
        "lambda_np_cap_override_enabled": 1.0,
        "lambda_np_cap_value": float(cap),
        "lambda_np_cap_before": before,
    }


def install_merged_movements(cfg, tuning: Mapping[str, Any],
                             detector_mapping) -> tuple[Any, dict[str, float]]:
    """같은 물리 회전으로 쪼개진 movement 를 합친다. `urban.movements.merge_exits` 없으면 no-op.

    왜. `urban_movements` 474개는 물리 회전이 아니라 **leg 교차곱**이다. 26개 신호 전부에서
    `movement 수 == L x (L-1)` 이 정확히 성립한다(L = 권역 leg). 그런데 권역 leg 는 물리
    접근로보다 많다 — 같은 방위가 경계판/내부판으로 두 번 세어진다. SC1 은
    `E vs E_SC11` 이 링크 27개로 **완전히 같은 집합**이고 N/S/W 는 링크 1개(vehicleInput
    주입점)가 내부판의 부분집합이다. 그래서 4갈래 교차로가 8x7 = 56 movement 가 됐다.
    실제 물리 회전은 4x3 = 12 다.

    **출구 쌍둥이만 합친다.** `SC1_E_to_S` 와 `SC1_E_to_S_SC107` 은 같은 정지선에서 같은
    커넥터를 타는 하나의 회전이다(실측: 남쪽 출구 커넥터가 하나뿐이고 그게 SC107 로
    간다). 진입 쌍둥이(`SC1_E_*` 경계 게이트 유입 / `SC1_E_SC11_*` SC11 유입)는 합치지
    않는다 — `approach_routing` 이 movement 당 origin 하나를 전제하므로, 합치면 게이트
    유입 경로가 끊긴다. 그쪽 이중계상은 용량을 접근로 단위로 묶어서 다뤄야 한다.

    안전 검증(실측으로 전부 0):
      - 병합 그룹 안에서 `origin` 이 갈리는 곳 0 — 도착 배분이 깨지지 않는다.
      - 병합 그룹 안에서 `phase` 가 갈리는 곳 0 — 현시 배정이 모호해지지 않는다.
      `kind` 는 47곳에서 internal/boundary_out 이 섞이는데, 대표 exit 가 내부 leg 이므로
      internal 로 정한다(origin 이 경계면 boundary_in 을 유지한다).

    같이 고쳐야 하는 곳이 둘 더 있다. movement 이름을 참조하는 데가 여기뿐이 아니다:
      - `detector_mapping["link_to_movements"]` (링크 204개)
      - `detector_mapping["agents"][*]["visible_movements"]`
    `on_ramp_to_movement` / `off_ramp_to_movement` 는 빈 dict 라 손댈 게 없다.

    되돌리기: tuning 절을 빼면 비트 동일이다. 병합 계획은
    `outputs/movement_merge_plan_20260824.json` 의 `leg_representative` 를 쓴다
    (규칙 A = 링크 포함/동일, 규칙 B = 유출이 한 leg 로만 향하면 합류).
    """
    section = _mapping(_mapping(tuning.get("urban")).get("movements"))
    if not _is_enabled_value(section.get("merge_exits")):
        return detector_mapping, {"movement_merge_enabled": 0.0}
    if not MOVEMENT_MERGE_PLAN_JSON.is_file():
        return detector_mapping, {"movement_merge_enabled": 0.0,
                                  "movement_merge_source_missing": 1.0}
    plan = json.loads(MOVEMENT_MERGE_PLAN_JSON.read_text(encoding="utf-8"))
    rep = _mapping(plan.get("leg_representative"))
    movements = cfg.network.urban_movements or {}
    if not movements:
        return detector_mapping, {"movement_merge_enabled": 0.0}

    def leg_rep(signal: str, leg: str) -> str:
        return str(rep.get("%s|%s" % (signal, leg), leg))

    # old -> new. exit 만 대표로 바꾼다(approach 는 그대로).
    rename: dict[str, str] = {}
    dropped: list[str] = []
    for name, spec in movements.items():
        sig = str(spec.get("signal", ""))
        app = str(spec.get("approach", ""))
        ext = leg_rep(sig, str(spec.get("exit", "")))
        if leg_rep(sig, app) == ext:
            # 쌍둥이 leg 사이의 자기참조다. 실측 36개 전부 u_turn 이고 물리 회전이 없다.
            dropped.append(name)
            continue
        rename[name] = "%s_%s_to_%s" % (sig, app, ext)

    groups: dict[str, list[str]] = {}
    for old, new in rename.items():
        groups.setdefault(new, []).append(old)

    conflicts: list[str] = []
    merged_specs: dict[str, dict] = {}
    for new, olds in groups.items():
        if len({str(movements[o].get("origin", "")) for o in olds}) > 1:
            conflicts.append("origin:" + new)
            continue
        if len({str(movements[o].get("phase", "")) for o in olds}) > 1:
            conflicts.append("phase:" + new)
            continue
        # 대표 spec: 이름이 그대로 유지되는 것, 없으면 첫 번째.
        base = next((o for o in olds if rename[o] == o), olds[0])
        spec = dict(movements[base])
        sig = str(spec.get("signal", ""))
        spec["exit"] = leg_rep(sig, str(spec.get("exit", "")))
        spec["beta"] = sum(_as_float(movements[o].get("beta"), 0.0) for o in olds)
        kinds = {str(movements[o].get("kind", "")) for o in olds}
        if "boundary_in" in kinds:
            spec["kind"] = "boundary_in"
        elif "internal" in kinds:
            spec["kind"] = "internal"
        else:
            spec["kind"] = sorted(kinds)[0] if kinds else ""
        if len(olds) > 1:
            spec["merged_from"] = sorted(olds)
        merged_specs[new] = spec

    if conflicts:
        raise ValueError("movement 병합 충돌 %d건: %s" % (len(conflicts), conflicts[:5]))

    # 접근로 합이 1 을 넘지 않게 재정규화한다. beta 를 더했으니 합이 변한다.
    by_app: dict[tuple[str, str], list[str]] = {}
    for new, spec in merged_specs.items():
        by_app.setdefault((str(spec.get("signal", "")), str(spec.get("approach", ""))), []).append(new)
    for _key, names in by_app.items():
        total = sum(_as_float(merged_specs[n].get("beta"), 0.0) for n in names)
        if total > 1.0e-9:
            for n in names:
                merged_specs[n]["beta"] = _as_float(merged_specs[n].get("beta"), 0.0) / total

    setattr(cfg.network, "urban_movements", merged_specs)
    setattr(cfg.network, "movement_merge_rename", dict(rename))

    # 램프 인덱스를 **병합 뒤 이름으로 다시 만든다** (2026-09-01).
    #
    # `post_init`(state.py:415-424)이 이 두 인덱스를 병합 **전** 이름으로 만든다.
    # 병합이 이름을 바꾸면(예: SC1001_offW_to_W -> SC1001_offW_to_W_RAMP) 인덱스가
    # 죽은 이름을 가리키고, 소비처 urban_queue_model.py:558 이 `if m in specs` 로
    # **조용히 거른다** — 실패가 아니라 배수 movement 가 사라진다.
    #
    # 실측(canon_farbn_d00_x18_20260901): OR_D_W 와 OR_D_E 가 각각 4개 중 1개
    # (beta 0.1667)를 잃고 있었다. 두 램프의 off-ramp 배수가 그만큼 과소평가된다.
    #
    # 유도식은 post_init 과 **같다** — off_ramp 는 spec["off_ramp"], on_ramp 는
    # spec["ramp"] + kind=="on_ramp". 병합은 그 필드를 보존하므로 재유도가 정본이다.
    off_idx: dict[str, list[str]] = {r: [] for r in (cfg.network.off_ramps or [])}
    on_idx: dict[str, list[str]] = {r: [] for r in (cfg.network.ramps or [])}
    for name, spec in merged_specs.items():
        off_ramp = str(spec.get("off_ramp", ""))
        if off_ramp:
            off_idx.setdefault(off_ramp, []).append(name)
        ramp = str(spec.get("ramp", ""))
        if ramp and str(spec.get("kind", "")) == "on_ramp":
            on_idx.setdefault(ramp, []).append(name)
    prev_off = dict(getattr(cfg.network, "off_ramp_to_movement", {}) or {})
    dead = sum(
        1 for names in prev_off.values() for m in names if m not in merged_specs
    )
    # A/B 분해(2026-09-02). 키가 없으면 재구축 = 현행 비트 동일.
    _rebuild = _is_enabled_value(
        _mapping(_mapping(_mapping(tuning).get("urban")).get("movements"))
        .get("ramp_index_rebuild", True))
    if _rebuild:
        setattr(cfg.network, "off_ramp_to_movement", off_idx)
        setattr(cfg.network, "on_ramp_to_movement", on_idx)
    else:
        # 되돌림: 병합 전 인덱스를 그대로 둔다. 죽은 이름 2건이 되살아난다.
        off_idx = {k: list(v) for k, v in prev_off.items()}
    ramp_index_meta = {
        "movement_merge_ramp_index_rebuilt": 1.0 if _rebuild else 0.0,
        "movement_merge_ramp_index_dead_before": float(dead),
        "movement_merge_off_ramp_movements": float(sum(len(v) for v in off_idx.values())),
        "movement_merge_on_ramp_movements": float(sum(len(v) for v in on_idx.values())),
    }

    # movement 별 용량 맵이 이미 심겨 있으면 같이 접는다. 같은 물리 회전이므로
    # **합산이 아니라 최대**다 — 합치면 한 회전의 차로를 두 번 센다.
    caps = getattr(cfg.network, "movement_capacity_by_movement_veh_h", None)
    if isinstance(caps, dict) and caps:
        folded: dict[str, float] = {}
        for old, value in caps.items():
            new = rename.get(old)
            if new is None:
                continue
            folded[new] = max(folded.get(new, 0.0), float(value))
        setattr(cfg.network, "movement_capacity_by_movement_veh_h", folded)

    # --- 검지 매핑도 같은 이름으로 옮긴다 ---
    #
    # **`link_to_movements` 의 값은 문자열 리스트가 아니라 dict 리스트다.**
    #   "17": [{"movement": "SC7_N_SC11_to_E", "weight": 0.25, "source": ..., "approach": ...}, ...]
    # 문자열로 보고 `str(entry)` 를 키로 쓰면 하나도 안 맞아 204개 링크가 전부 빈
    # 리스트가 되고, movement 큐 주입이 통째로 0 이 된다(실측: 투영 진단의
    # `movement_queue_assigned_veh` 가 1291.7 -> 0.00, 못 간 물량이 storage 로 밀려
    # `storage_assigned_veh` 917 -> 1982). 그래서 **weight 까지 합산**해야 한다 —
    # 두 항목이 같은 병합 대상으로 오면 가중치를 더해야 링크 총량이 보존된다.
    relinked = 0
    if isinstance(detector_mapping, MutableMapping):
        l2m = detector_mapping.get("link_to_movements")
        if isinstance(l2m, MutableMapping):
            for link, entries in list(l2m.items()):
                if not isinstance(entries, list):
                    continue
                folded: dict[str, Any] = {}
                order: list[str] = []
                for entry in entries:
                    if isinstance(entry, Mapping):
                        old = str(entry.get("movement", ""))
                        new = rename.get(old)
                        if new is None:
                            continue
                        if new in folded:
                            folded[new]["weight"] = (_as_float(folded[new].get("weight"), 0.0)
                                                     + _as_float(entry.get("weight"), 0.0))
                            continue
                        item = dict(entry)
                        item["movement"] = new
                        folded[new] = item
                        order.append(new)
                    else:
                        new = rename.get(str(entry))
                        if new is None or new in folded:
                            continue
                        folded[new] = new
                        order.append(new)
                out = [folded[k] for k in order]
                if out != entries:
                    relinked += 1
                l2m[link] = out
        agents = detector_mapping.get("agents")
        if isinstance(agents, MutableMapping):
            for _aid, spec in agents.items():
                if not isinstance(spec, MutableMapping):
                    continue
                vis = spec.get("visible_movements")
                if not isinstance(vis, list):
                    continue
                seen: list[str] = []
                for n in vis:
                    new = rename.get(str(n))
                    if new is None or new in seen:
                        continue
                    seen.append(new)
                spec["visible_movements"] = seen

    return detector_mapping, {
        "movement_merge_enabled": 1.0,
        "movement_merge_before": float(len(movements)),
        "movement_merge_after": float(len(merged_specs)),
        "movement_merge_dropped": float(len(dropped)),
        "movement_merge_groups": float(sum(1 for v in groups.values() if len(v) > 1)),
        "movement_merge_relinked_links": float(relinked),
        **ramp_index_meta,
    }


# 2026-09-03 삭제: 리더 되먹임 carry(LEADER_FEEDBACK_STATE_KEY / restore_/capture_).
# β̂ 와 trailing-regret 의 인스턴스 상태를 150초 결정 사이로 나르는 것이 유일한 목적이었고,
# 그 둘을 지웠으므로 나를 것이 없다. tuning 의 `urban.leader_feedback` 절도 무효다.


def install_movement_capacity_by_lanes(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """movement 방류 용량을 **차로수 비례**로 배분한다. `urban.capacity.per_lane` 없으면 no-op.

    왜. `_movement_capacity_flow` 가 내부 movement 184개 전부에 전역 스칼라 하나를 준다.
    spec 에 차로 수도 포화유율도 없어서 1차로 보호좌회전과 3차로 직진이 같은 값을 받는다.
    3시점 검정에서 전역 600 이 집계는 잘 맞췄지만(잔차 -6.3/+7.5/-10.0%) **상대 용량은
    여전히 틀려 있다** — 신호제어가 쓰는 게 정확히 그 상대값이다.

    유도. 산출물의 길이·jam 으로 링크 차로수를 역산하고, 그 링크에서 출발하는 movement
    들에 회전 분율 `beta` 로 나눈다(실제 차로 배정이 수요 비례인 것과 맞는다).

        lanes(L)  = storage(L) / (length_km(L) x jam_density)
        lanes(m)  = lanes(origin(m)) x beta(m) / sum(beta over same origin)
        cap(m)    = per_lane x lanes(m)

    정규화. `equivalent_uniform_veh_h`(기본 600)를 주면 내부 movement 총 용량이
    N x 그 값과 같아지도록 per_lane 을 정한다. 3시점 검정으로 확보한 집계 적합을 유지한
    채 **배분만** 바꾼다.
    """
    section = _mapping(_mapping(tuning.get("urban")).get("capacity"))
    # `_is_enabled` 는 문자열 집합 비교라 float 1.0 을 "1.0" 으로 만들어 **꺼진 것으로**
    # 읽는다(실측: per_lane:1.0 이 조용히 무시돼 base 와 소수점까지 같은 결과가 나왔다).
    # 설정이 true / 1 / 1.0 / "on" 중 무엇이어도 켜지도록 여기서는 직접 본다.
    _flag = section.get("per_lane", False)
    _on = bool(_flag) if isinstance(_flag, (bool, int, float)) else         str(_flag).strip().lower() in {"1", "true", "yes", "on"}
    if not _on:
        return {"movement_capacity_by_lanes_enabled": 0.0}
    # movement 별 **실측 차로수**. VISSIM 커넥터 기하에서 뽑는다.
    #
    # 이전 판은 `storage/(length x jam)` 로 링크 차로수를 역산해 beta 로 나눴는데 그게
    # 틀렸다. 산출물 정의가 `sum(link_length_km * lanes) * jam` 이라 그 역산은 **권역
    # 구간의 길이가중 평균 차로수**(중앙 2.77, 정수 근처가 11%뿐)지 정지선에서 그 회전을
    # 담당하는 차로수가 아니다. 방류 용량을 정하는 건 후자다.
    #
    # 지금은 leg 권역의 정지선 유출 커넥터를 목적 SC 로 매칭해 커넥터 `lanes` 수를 쓴다.
    # 실측: internal 184개 중 171개(93%) 해결, 직진 중앙 2.0 / 좌·우 중앙 1.0 차로.
    src = WORKSPACE_ROOT / "outputs/movement_lanes_core17legs4b_20260821.json"
    if not src.is_file():
        return {"movement_capacity_by_lanes_enabled": 0.0, "movement_capacity_by_lanes_source_missing": 1.0}
    lanes_by_movement = _mapping(json.loads(src.read_text(encoding="utf-8")).get("movement_lanes"))
    movements = cfg.network.urban_movements or {}
    internal = {m: sp for m, sp in movements.items()
                if str(sp.get("kind", "")) not in PERIMETER_MOVEMENT_KINDS_ADAPTER}
    # 미해결 movement 는 같은 회전 종류의 중앙값으로 채운다(빠뜨리면 전역 스칼라로 떨어져
    # 구조가 반쪽이 된다).
    by_turn: dict[str, list[float]] = {}
    for m, sp in internal.items():
        v = _as_float(lanes_by_movement.get(m), 0.0)
        if v > 0.0:
            by_turn.setdefault(str(sp.get("turn", "")), []).append(v)
    median_by_turn = {t: sorted(v)[len(v) // 2] for t, v in by_turn.items() if v}
    share: dict[str, float] = {}
    for m, sp in internal.items():
        v = _as_float(lanes_by_movement.get(m), 0.0)
        if v <= 0.0:
            v = median_by_turn.get(str(sp.get("turn", "")), 1.0)
        share[m] = float(v)
    if not share:
        return {"movement_capacity_by_lanes_enabled": 0.0, "movement_capacity_by_lanes_empty": 1.0}

    equiv = _as_float(section.get("equivalent_uniform_veh_h"), 600.0)
    total_target = equiv * float(len(share))
    total_share = sum(share.values())
    per_lane = total_target / total_share if total_share > 1.0e-9 else 0.0
    caps = {m: per_lane * v for m, v in share.items()}

    # ---- perimeter 를 같은 척도로 끌어온다 (`urban.capacity.perimeter`) ----
    #
    # 왜. 위 정규화는 **internal 184개만** 다룬다. perimeter 290개는 맵 밖에 남아
    # `_movement_capacity_flow` 가 전역 스칼라 1400 을 준다 — internal 실측 평균이
    # ~330 이라 **없던 4배 비대칭**이 생긴다. lanes 팔 이전엔 둘 다 1400 이라
    # 상대 비교가 최소한 공정했다. 방류가 cap 에 선형이고 리더가 현시를 고를 때 쓰는 게
    # 그 상대값이라, 경계 접근로에 과배분하고 내부를 굶는 방향으로 작용한다.
    # 현시 68개 중 53개가 두 종류를 섞는다.
    #
    # **`per_lane` 은 internal 정규화 값을 그대로 쓴다.** perimeter 를 같은 풀에 넣어
    # 재정규화하면 `equivalent_uniform_veh_h` 가 184개 풀에서 3시점 검정으로 뽑힌
    # 값이라 그 적합이 깨지고, internal 값도 함께 움직여 단일변수가 아니게 된다.
    # 이렇게 하면 **internal 은 비트 동일**하고 perimeter 만 척도가 맞는다.
    #
    #   off       미설정/false. perimeter 는 전역 스칼라 그대로 — 기존과 비트 동일.
    #   resolved  물리 회전(pn_boundary_turns_v1)으로 확인된 것만. 보수적.
    #   all       resolved + 나머지는 같은 turn 종류 중앙값(internal 미해결 처리와 같은 규칙).
    #
    # `resolved` 와 `all` 을 가르는 이유: 모델 perimeter 290개 중 물리 회전과 매칭되는
    # 것은 78개뿐인데, 나머지 212개 중 **206개가 beta > 0.01** 로 실제 큐를 받는다.
    # 물리 회전 목록에 없는 movement 에 수요가 흐른다는 뜻이라(urban_movements 는
    # leg 교차곱 선언이다) 그 212개를 어떻게 다룰지가 별도 변수다. 팔로 가른다.
    peri_mode = str(section.get("perimeter") or "off").strip().lower()
    if peri_mode in {"false", "0", "no"}:
        peri_mode = "off"
    peri_meta: dict[str, float] = {"movement_capacity_perimeter_mode_all": 0.0,
                                   "movement_capacity_perimeter_count": 0.0}
    if peri_mode != "off":
        if peri_mode not in {"resolved", "all"}:
            raise ValueError(f"urban.capacity.perimeter 는 off/resolved/all 중 하나여야 한다: {peri_mode!r}")
        src_p = WORKSPACE_ROOT / "outputs/movement_lanes_perimeter_20260824.json"
        if not src_p.is_file():
            peri_meta["movement_capacity_perimeter_source_missing"] = 1.0
        else:
            doc_p = json.loads(src_p.read_text(encoding="utf-8"))
            lanes_p = _mapping(doc_p.get("movement_lanes_perimeter"))
            keep_out = _is_enabled_value(section.get("perimeter_include_boundary_out", True))
            peri = {m: sp for m, sp in movements.items()
                    if str(sp.get("kind", "")) in PERIMETER_MOVEMENT_KINDS_ADAPTER
                    and (keep_out or str(sp.get("kind", "")) != "boundary_out")}
            # 미해결분을 채울 중앙값은 **해결된 perimeter** 에서 뽑는다. internal 중앙값을
            # 쓰면 다른 모집단의 값을 빌려오는 것이라 근거가 없다.
            peri_by_turn: dict[str, list[float]] = {}
            for m, sp in peri.items():
                v = _as_float(lanes_p.get(m), 0.0)
                if v > 0.0:
                    peri_by_turn.setdefault(str(sp.get("turn", "")), []).append(v)
            peri_median = {t: sorted(v)[len(v) // 2] for t, v in peri_by_turn.items() if v}
            fallback_all = sorted(x for v in peri_by_turn.values() for x in v)
            estimated = 0
            for m, sp in peri.items():
                v = _as_float(lanes_p.get(m), 0.0)
                if v <= 0.0:
                    if peri_mode != "all":
                        continue
                    v = peri_median.get(str(sp.get("turn", "")),
                                        fallback_all[len(fallback_all) // 2] if fallback_all else 1.0)
                    estimated += 1
                caps[m] = per_lane * float(v)
            pvals = sorted(caps[m] for m in peri if m in caps)
            peri_meta = {
                "movement_capacity_perimeter_mode_all": 1.0 if peri_mode == "all" else 0.0,
                "movement_capacity_perimeter_count": float(len(pvals)),
                "movement_capacity_perimeter_estimated": float(estimated),
                "movement_capacity_perimeter_include_boundary_out": 1.0 if keep_out else 0.0,
            }
            if pvals:
                peri_meta["movement_capacity_perimeter_min_veh_h"] = float(pvals[0])
                peri_meta["movement_capacity_perimeter_median_veh_h"] = float(pvals[len(pvals) // 2])
                peri_meta["movement_capacity_perimeter_max_veh_h"] = float(pvals[-1])

    setattr(cfg.network, "movement_capacity_by_movement_veh_h", caps)
    ivals = sorted(per_lane * v for v in share.values())
    out = {
        "movement_capacity_by_lanes_enabled": 1.0,
        "movement_capacity_by_lanes_count": float(len(caps)),
        "movement_capacity_by_lanes_internal_count": float(len(share)),
        "movement_capacity_by_lanes_per_lane_veh_h": float(per_lane),
        "movement_capacity_by_lanes_equivalent_uniform": float(equiv),
        "movement_capacity_by_lanes_min_veh_h": float(ivals[0]),
        "movement_capacity_by_lanes_median_veh_h": float(ivals[len(ivals) // 2]),
        "movement_capacity_by_lanes_max_veh_h": float(ivals[-1]),
    }
    out.update(peri_meta)
    return out


def filter_midblock_links_from_detector_mapping(detector_mapping, tuning: Mapping[str, Any]):
    """미드블록 정지선 링크를 **관측에서** 뺀다. `urban.midblock.exclude_links` 없으면 no-op.

    왜. 권역 정의가 "leg 정지선 접근로 + 상류로 앞 교차로까지" 라, 중간에 미드블록 신호가
    있으면 **그 미드블록의 정지선과 대기 구간까지 본선 leg 가 소유**한다. 그러면 미드블록
    적색에 서 있는 차가 본선 leg 의 큐로 집계되고, 컨트롤러는 "본선 접근로에 큐가 길다"로
    읽어 녹색을 배분한다 — 그 차들은 본선 정지선까지 도달하지도 못한 상태인데.

    실측(2026-08-22): 미드블록 정지선을 품은 leg 이 24개(11개 교차로)이고 SC5 가 5개로
    가장 많다. SC5 본선 배분이 직진 47->10.1초(21%), 좌회전 23->61.7초(268%)로 뒤집혀
    있는 것이 이 오염과 맞는다.

    권역 정본(urban_player_territory_v1)은 **건드리지 않는다** — "재유도하지 않는다,
    읽어서 쓴다" 가 그 파일의 규칙이고 오늘 자동 규칙이 틀린 전례가 있다. 대신 관측
    단계에서 뺀다. 되돌리기 쉽고 정본이 그대로 남는다.

    주의: 31개 중 2개(1220013600, 1220013700)는 본선 신호두도 함께 있어 빼면 본선 관측도
    잃는다. `keep_mixed` 로 남길 수 있다(기본은 규칙대로 전부 뺀다).
    """
    section = _mapping(_mapping(tuning.get("urban")).get("midblock"))
    _flag = section.get("exclude_links", False)
    _on = bool(_flag) if isinstance(_flag, (bool, int, float)) else         str(_flag).strip().lower() in {"1", "true", "yes", "on"}
    if not _on or not detector_mapping:
        return detector_mapping, {"midblock_link_exclusion_enabled": 0.0}
    src = WORKSPACE_ROOT / "outputs/midblock_stopline_links_20260822.json"
    if not src.is_file():
        return detector_mapping, {"midblock_link_exclusion_enabled": 0.0,
                                  "midblock_link_source_missing": 1.0}
    doc = json.loads(src.read_text(encoding="utf-8"))
    drop = {str(k) for k in (_mapping(doc.get("links")) or {})}
    keep_mixed = str(section.get("keep_mixed", "")).strip().lower() in {"1", "true", "yes", "on"}
    if keep_mixed:
        drop -= {str(x) for x in (doc.get("mixed_with_mainline") or [])}
    out = dict(detector_mapping)
    meta = {"midblock_link_exclusion_enabled": 1.0,
            "midblock_link_candidates": float(len(drop)),
            "midblock_keep_mixed": 1.0 if keep_mixed else 0.0}
    for key in ("link_to_origins", "link_to_movements"):
        table = _mapping(detector_mapping.get(key))
        if not table:
            continue
        kept = {k: v for k, v in table.items() if str(k) not in drop}
        meta[f"midblock_dropped_{key}"] = float(len(table) - len(kept))
        out[key] = kept
    obs = detector_mapping.get("observable_links")
    if isinstance(obs, list):
        kept = [x for x in obs if str(x) not in drop]
        meta["midblock_dropped_observable_links"] = float(len(obs) - len(kept))
        out["observable_links"] = kept
    return out, meta


# beta 증거원 둘. 기본은 routing 이다.
#
#   routing : `.inpx` 의 정적 경로결정(vehicleRoutingDecisionStatic) relFlow.
#             VISSIM 이 차량을 배분할 때 쓰는 **입력**이라 신호 타이밍과 무관하다.
#             모델의 beta 와 정의가 같다(링크 끝 도착의 수요 배분).
#   knr     : 노드평가 통과 대수. **내생적이라 쓰지 마라** — 남겨 둔 건 대조용이다.
#             교차로를 통과 완료한 차량은 그 방향에 준 녹색의 결과이므로,
#             컨트롤러가 최적화하는 변수에서 그 입력을 역산하는 자기실현 루프가 된다.
#             실제로 미매칭 6.16%, movement 244개 중 85개가 정확히 0 이 됐고
#             그 중 internal 25개(우회전 17·직진 2)가 섞여 있었다. beta=0 은
#             `urban_queue_model:1018 queue[m] += beta * arrived` 를 영구히 0 으로
#             만들어 그 현시를 굶긴다 — 동서축 관측 실명과 같은 실패 모드다.
BETA_EVIDENCE_JSON = {
    "routing": WORKSPACE_ROOT / "outputs/movement_beta_routing_20260824.json",
    "knr": WORKSPACE_ROOT / "outputs/movement_beta_measured_20260824.json",
}


def install_measured_turn_beta(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """movement 회전분율 `beta` 를 **실측**으로 바꾼다. `urban.beta.measured` 없으면 no-op.

    왜. 모델의 beta 474개가 전부 균등 분배 기본값이다(0.5 / 0.25 / 0.167 / 0.125 / 0.1 —
    전부 1/2, 1/4, 1/6, 1/8, 1/10). 실측 산출물은 저장소에 없었다.

    무엇이 틀어지나 (SC5 동쪽, 무제어 실측 1,694대):

        to_W_SC101 (직진)   0.500 -> 0.764
        to_N_SC102 (우)     0.167 -> 0.125
        to_S_SC11  (좌)     0.167 -> 0.111
        to_S       (경계좌) 0.167 -> **0.000**

    좌회전 수요를 3배로 부풀린다. 그 결과 현시별 "큐/용량" 이
    p4(좌) 102.3초 > p3(직진) 76.8초 로 역전되고, `local` 이 좌회전을 더 급하다고 본다.
    가격이 p3 를 1위(+0.043)로 가리켜도 정련이 못 옮긴다 — conv 런에서 정련은 SC5 를
    48초씩 움직이면서 **p3 만 건너뛴다**. SC5 동쪽 실측 정지차가 231대까지 쌓인다.

    beta 는 관측 투영(링크 큐 -> movement 배분)과 플랜트 라우팅에 함께 쓰이므로
    이 하나가 큐 분포와 동역학을 동시에 왜곡한다.
    """
    section = _mapping(_mapping(tuning.get("urban")).get("beta"))
    if not _is_enabled_value(section.get("measured")):
        return {"measured_beta_enabled": 0.0}
    source = str(section.get("source") or "routing")
    path = BETA_EVIDENCE_JSON.get(source)
    if path is None:
        raise ValueError(f"urban.beta.source 는 {sorted(BETA_EVIDENCE_JSON)} 중 하나여야 한다: {source!r}")
    if not path.is_file():
        return {"measured_beta_enabled": 0.0, "measured_beta_source_missing": 1.0}
    doc = json.loads(path.read_text(encoding="utf-8"))
    beta = _mapping(doc.get("beta"))
    floor = _as_float(section.get("floor"), 0.0)
    applied, changed = 0, 0.0
    for movement, value in beta.items():
        spec = (cfg.network.urban_movements or {}).get(str(movement))
        if not isinstance(spec, MutableMapping):
            continue
        new = max(float(floor), _as_float(value, 0.0))
        changed += abs(new - _as_float(spec.get("beta"), 0.0))
        spec["beta"] = new
        applied += 1
    return {
        "measured_beta_enabled": 1.0,
        "measured_beta_movements": float(applied),
        "measured_beta_total_shift": float(round(changed, 3)),
        "measured_beta_floor": float(floor),
        "measured_beta_source_routing": 1.0 if source == "routing" else 0.0,
    }


def _native_live_phases_by_signal(cfg) -> dict[str, list[str]]:
    """실측 SG 타이밍에서 SC 별 **녹색 0 이 아닌 현시**를 뽑는다.

    NEMA 이름으로 현시를 정한다(진행방향 기준이라 접근로는 반대다):
    NBT/SBT -> p1(주축 직진) · NBL/SBL -> p2(주축 좌) · EBT/WBT -> p3 · EBL/WBL -> p4.
    미드블록(SG 9+)은 뺀다 — 우리가 구동하지 않는다.
    """
    src = WORKSPACE_ROOT / "outputs/signal_group_timing_core17legs4b_20260819.json"
    if not src.is_file():
        return {}
    nema = {"NBT": "p1", "SBT": "p1", "NBL": "p2", "SBL": "p2",
            "EBT": "p3", "WBT": "p3", "EBL": "p4", "WBL": "p4"}
    controlled = {str(x) for x in _controlled_signal_names(cfg)}
    doc = json.loads(src.read_text(encoding="utf-8"))
    out: dict[str, list[str]] = {}
    for entry in doc.get("controllers", []) or []:
        sid = f"SC{entry.get('sc_no')}"
        if sid not in controlled:
            continue
        best: dict[str, float] = {}
        for grp in entry.get("groups", []) or []:
            raw_sg = str(grp.get("sg_id", ""))
            if not raw_sg.isdigit() or int(raw_sg) > 8:
                continue
            pid = nema.get(str(grp.get("name", "")).strip().upper())
            if pid is None:
                continue
            best[pid] = max(best.get(pid, 0.0), _as_float(grp.get("green_sec"), 0.0))
        live = [pid for pid in ("p1", "p2", "p3", "p4") if best.get(pid, 0.0) > 0.0]
        # 전부 0 이면 유도 실패다 — 그 SC 는 손대지 않고 전 현시 폴백으로 둔다.
        if live and len(live) < 4:
            out[sid] = live
    return out


def _is_enabled_value(flag: Any) -> bool:
    """단일 값 on/off. bool·수·문자열을 다 받는다.

    `_is_enabled` 는 설정 절 전체를 받고 문자열 집합으로 비교해서 float 1.0 이
    "1.0" 이 되어 조용히 꺼진 적이 있다(2026-08-21 lanes600). 여기서는 수를 먼저 본다.
    """
    if isinstance(flag, bool):
        return flag
    if isinstance(flag, (int, float)):
        return float(flag) != 0.0
    return str(flag).strip().lower() in {"1", "true", "yes", "on"}


MEASURED_SATURATION_EVIDENCE_JSON = WORKSPACE_ROOT / "outputs/movement_saturation_measured_20260822.json"


def install_measured_movement_capacity(cfg, tuning, state_json, previous_path) -> dict[str, float]:
    """**직전 구간 실측 방류율**로 movement 용량을 갱신한다. `urban.capacity.measured` 없으면 no-op.

    왜. 지금 용량은 가정값이다 — 플랜트/GNE 가 `차로수 x 330`, 정련 채점기가
    `len(movements) x 1400`. 실측(무제어 .knr)은 정지선 차로군이 1,100~4,400 veh/h 라
    전자는 3~5배 과소, 후자는 신호 합이 4배 과대다. 리더가 녹색을 나눌 때 쓰는 게
    movement 간 **상대** 용량이라 이 왜곡이 그대로 배분 왜곡이 된다.

    무엇을 재나. 러너가 5초 스캔에서 차량별 (No, Link) 를 이미 읽으므로 연속 스캔을
    비교해 **정지선 링크를 떠난 대수**를 세고 `link_departures_window` 로 실어 보낸다
    (`RW_QUEUE_WINDOW=1`). 그 링크 차로군의 직전 구간 녹색초로 나누면 방류율이다.

        cap_obs[link] = departures[link] / green_sec[link] x 3600

    수요제약을 어떻게 거르나. 한산한 구간의 `departures/green` 은 용량이 아니라 수요다.
    오프라인 분위수로 거르려 했으나 실패했다(중앙값 기준 차로환산 0.52 — 1차로 미만).
    대신 **감쇠 러닝맥스**를 쓴다:

        cap_est = max(cap_obs, decay x cap_est_prev)

    증거가 나오면 즉시 올라가고 없으면 천천히 잊는다. 포화점이 안정 고정점이라
    아래에서 수렴한다 — 녹색이 줄면 큐가 덜 비어 `departures/green` 이 올라간다.
    어댑터는 결정마다 새 프로세스라 직전 추정치를 **직전 action JSON 진단**으로 나른다.

    씨앗. 첫 결정에는 직전값이 없다. 무제어 런에서 유도한
    `movement_saturation_measured_20260822.json` 의 차로군 값을 쓴다.

    차로군 -> movement 배분. 한 접근로의 직진·좌·우는 **같은 차로를 나눠 쓴다**.
    차로군 총량을 movement 마다 복제하면 그 접근로가 용량의 3배를 방류한다.
    모델 자신의 회전 분율 `beta` 로 나눈다 — 총량이 보존된다.
    """
    section = _mapping(_mapping(tuning.get("urban")).get("capacity"))
    if not _is_enabled_value(section.get("measured")):
        return {"measured_capacity_enabled": 0.0}
    decay = _as_float(section.get("decay"), 0.98)
    local = _mapping(state_json.get("local_observation"))
    departures = {str(k): _as_float(v, 0.0) for k, v in _mapping(local.get("link_departures_window")).items()}

    prev_est: dict[str, float] = {}
    try:
        prev_doc = json.loads(Path(previous_path).read_text(encoding="utf-8"))
        for holder in ("metadata", "diagnostics"):
            for key, value in _mapping(prev_doc.get(holder)).items():
                if key.startswith("sat_est_"):
                    prev_est[key[len("sat_est_"):]] = _as_float(value, 0.0)
    except (OSError, ValueError):
        pass

    groups: list[Mapping[str, Any]] = []
    if MEASURED_SATURATION_EVIDENCE_JSON.is_file():
        doc = json.loads(MEASURED_SATURATION_EVIDENCE_JSON.read_text(encoding="utf-8"))
        groups = [g for g in (doc.get("lane_groups") or []) if isinstance(g, Mapping)]
    # 씨앗. 기본은 **플랜트가 지금 믿는 값**(차로수 x equivalent_uniform, 통상 330)이다.
    #
    # 왜 기하값(차로수 x 1800)을 안 쓰나. `max(실측, 씨앗)` 에서 기하 씨앗은 실측보다
    # 3~8배 커서 사실상 늘 이긴다(실측: 60개 중 2개만 채택). 그러면 "직전 실측을 쓴다"가
    # 아니라 "1800/차로를 가정한다"가 되고, 이 망이 실제로 그 근처도 못 가므로 낙관적이다.
    # 플랜트 현재값에서 출발하면 대부분의 접근로에서 실측이 즉시 이겨 데이터가 지배한다
    # (예: SC6 1220021201 실측 7,912 vs 4차로x330 = 1,320).
    #
    # `seed: "geometric"` 으로 옛 거동(차로수 x 1800)을 되살릴 수 있다.
    seed_mode = str(section.get("seed", "plant")).strip().lower()
    base_caps = dict(getattr(cfg.network, "movement_capacity_by_movement_veh_h", {}) or {})
    seed: dict[str, float] = {}
    # 2026-09-06 차로군(정지선 링크, 현시) 씨앗. observed 모드와 lane_group 배분이 쓴다.
    seed_lg: dict[tuple[str, str], float] = {}
    _nema = {"NBT": "p1", "SBT": "p1", "NBL": "p2", "SBL": "p2", "EBT": "p3", "WBT": "p3", "EBL": "p4", "WBL": "p4"}
    if seed_mode == "observed":
        clip_lo, clip_hi = 0.2, 1.0
        _clip = section.get("observed_clip")
        if isinstance(_clip, (list, tuple)) and len(_clip) == 2:
            clip_lo, clip_hi = float(_clip[0]), float(_clip[1])
        missing_frac = clamp(_as_float(section.get("seed_missing_frac"), 0.5), 0.0, 1.0)
        # 큐가 서는 접근로만 관측 최대를 용량으로 믿는다. 무제어(h0)에서 큐가 안 서던 접근로의 관측 최대는
        # 수요이지 용량이 아니라(과소 → 유령 큐) 물리값(기하)을 쓴다. 분류표 = outputs/link_queue_class_*.json.
        queued: set[str] | None = None
        _qpath = str(section.get("queued_links_json", "") or "")
        if _qpath:
            try:
                _qdoc = json.loads((WORKSPACE_ROOT / _qpath).read_text(encoding="utf-8"))
                queued = {str(x) for x in (_qdoc.get("queued_links") or [])}
            except (OSError, ValueError):
                queued = None
        unqueued_frac = clamp(_as_float(section.get("unqueued_geometric_frac"), 1.0), 0.0, 1.0)
        for g in groups:
            link = str(g.get("stopline_link", ""))
            pid = _nema.get(str(g.get("sg_name", "")).upper())
            if not link or pid is None:
                continue
            geo = _as_float(g.get("geometric_veh_h"), 0.0)
            if geo <= 0.0:
                geo = max(1.0, _as_float(g.get("lanes_from_heads"), 1.0)) * 1800.0
            obs_top = _as_float(g.get("observed_top_veh_h"), 0.0)
            if queued is not None and link not in queued:
                val = geo * unqueued_frac
            else:
                val = clamp(obs_top, clip_lo * geo, clip_hi * geo) if obs_top > 0.0 else geo * missing_frac
            seed[link] = seed.get(link, 0.0) + val
            seed_lg[(link, pid)] = seed_lg.get((link, pid), 0.0) + val
    elif seed_mode == "sustained":
        # 2026-09-06 SAT v2: lcd1000 무제어 차량 레코드의 (정지선 링크, 현시) 지속 방류(큐 창 중앙). 상한 = 기하(차로×1800).
        # 큐가 안 서던 링크(queued_links_json)는 기하값. 지속 자료가 없는 차로군은 기하 × seed_missing_frac.
        _spath = str(section.get("sustained_json", "outputs/lane_group_sustained_h0_20260906.json") or "")
        _stat = str(section.get("sustained_stat", "free") or "free").strip().lower()
        _min_w = int(_as_float(section.get("sustained_min_windows"), 6.0))
        missing_frac = clamp(_as_float(section.get("seed_missing_frac"), 0.5), 0.0, 1.0)
        unqueued_frac = clamp(_as_float(section.get("unqueued_geometric_frac"), 1.0), 0.0, 1.0)
        queued = None
        _qpath = str(section.get("queued_links_json", "") or "")
        if _qpath:
            try:
                queued = {str(x) for x in (json.loads((WORKSPACE_ROOT / _qpath).read_text(encoding="utf-8")).get("queued_links") or [])}
            except (OSError, ValueError):
                queued = None
        sus: dict[tuple[str, str], float] = {}
        _SUS_SIGS.clear(); _SUS_LANES.clear()
        _LG_KINDS.clear(); _LG_KINDS.update({str(x) for x in (section.get("lane_group_kinds") or ["internal"])})
        _LTO.clear()
        try:
            _dmp = str(tuning.get("detector_mapping_json", "") or "")
            if _dmp:
                _LTO.update({str(k): list(v) for k, v in _mapping(json.loads((WORKSPACE_ROOT / _dmp).read_text(encoding="utf-8")).get("link_to_origins")).items()})
        except (OSError, ValueError, TypeError):
            pass
        try:
            _sdoc = json.loads((WORKSPACE_ROOT / _spath).read_text(encoding="utf-8"))
            for _lk, _e in _mapping(_sdoc.get("links")).items():
                _SUS_SIGS[str(_lk)] = str(_mapping(_e).get("signal", ""))
                for _pid, _g in _mapping(_mapping(_e).get("groups")).items():
                    _gm = _mapping(_g)
                    _SUS_LANES[(str(_lk), str(_pid))] = max(1, len(list(_gm.get("lanes") or [])))
                    # 우선순위: free(큐 있고 하류 자유, 창 >= min) → queued(창 >= min) → all(창 >= min). 하류가 막힌 창은 포화가 아니다.
                    _v = None
                    # "all"(전체 창 중앙)은 수요이지 용량이 아니라 씨앗으로 쓰지 않는다 — free/queued 만, 창 수 >= min.
                    for _key, _wkey in (("free", "windows_free"), ("queued", "windows_queued")):
                        if _stat == "queued" and _key == "free":
                            continue
                        _cand = _gm.get("sustained_%s_veh_h" % _key)
                        if _cand is not None and _as_float(_cand, 0.0) > 0.0 and int(_as_float(_gm.get(_wkey), 0.0)) >= _min_w:
                            _v = _as_float(_cand, 0.0)
                            break
                    if _v is not None:
                        sus[(str(_lk), str(_pid))] = _v
        except (OSError, ValueError):
            sus = {}
        for g in groups:
            link = str(g.get("stopline_link", ""))
            pid = _nema.get(str(g.get("sg_name", "")).upper())
            if not link or pid is None:
                continue
            geo = _as_float(g.get("geometric_veh_h"), 0.0)
            if geo <= 0.0:
                geo = max(1.0, _as_float(g.get("lanes_from_heads"), 1.0)) * 1800.0
            _floor = clamp(_as_float(section.get("sustained_floor_frac"), 0.15), 0.0, 1.0) * geo
            if queued is not None and link not in queued:
                val = geo * unqueued_frac
            elif (link, pid) in sus:
                val = clamp(sus[(link, pid)], _floor, geo)
            else:
                val = geo * missing_frac
            seed[link] = seed.get(link, 0.0) + val
            seed_lg[(link, pid)] = seed_lg.get((link, pid), 0.0) + val
        # SAT v3: 증거(08-22) 차로군 목록에 없는 (링크, 현시) 도 지속 산출물에서 씨앗을 만든다. config 게이트(`sustained_extra_groups`) — 없으면 비트 동일.
        _extra_on = _is_enabled_value(section.get("sustained_extra_groups"))
        for (_lk, _pid), _v in (sus.items() if _extra_on else ()):
            if (_lk, _pid) in seed_lg:
                continue
            _geo = float(_SUS_LANES.get((_lk, _pid), 1)) * 1800.0
            _fl = clamp(_as_float(section.get("sustained_floor_frac"), 0.15), 0.0, 1.0) * _geo
            if queued is not None and _lk not in queued:
                _val = _geo * unqueued_frac
            else:
                _val = clamp(_v, _fl, _geo)
            seed[_lk] = seed.get(_lk, 0.0) + _val
            seed_lg[(_lk, _pid)] = _val
    elif seed_mode == "geometric":
        for g in groups:
            link = str(g.get("stopline_link", ""))
            if link:
                seed[link] = seed.get(link, 0.0) + _as_float(g.get("saturation_veh_h"), 0.0)
    else:
        # 접근로 총량 = 그 접근로 movement 들의 현재 용량 합. 이탈 계수(링크 단위)와
        # 같은 단위가 되고, 아래 배분에서 그대로 되돌려 놓으므로 실측이 없으면 무변화다.
        for link, (sig, pids) in _approach_topology(groups).items():
            total = sum(
                float(base_caps.get(m, cfg.network.movement_capacity_veh_h))
                for m, spec in (cfg.network.urban_movements or {}).items()
                if str(spec.get("signal", "")) == sig
                and any(str(spec.get("phase", "")).endswith("_" + pid) for pid in pids)
                and str(spec.get("kind", "")) not in PERIMETER_MOVEMENT_KINDS_ADAPTER
            )
            if total > 0.0:
                seed[link] = total

    # 그 링크 차로군의 직전 구간 녹색초. 커밋한 계획을 쓴다(러너가 그대로 적용한다).
    # 2026-09-06 est 상한 = 링크 기하 용량(차로군 합). 관측 스파이크(h4 sat_est_66 4586)를 물리 위로 못 올린다.
    _cap_geo: dict[str, float] = {}
    if _is_enabled_value(section.get("est_cap_geometric")):
        for g in groups:
            _lk = str(g.get("stopline_link", ""))
            _geo = _as_float(g.get("geometric_veh_h"), 0.0)
            if _geo <= 0.0:
                _geo = max(1.0, _as_float(g.get("lanes_from_heads"), 1.0)) * 1800.0
            if _lk:
                _cap_geo[_lk] = _cap_geo.get(_lk, 0.0) + _geo
        for (_lk2, _pid2), _n in _SUS_LANES.items():
            if _lk2 not in _cap_geo:
                _cap_geo[_lk2] = _cap_geo.get(_lk2, 0.0) + float(_n) * 1800.0
    green_sec = _measured_green_sec_by_link(cfg, groups, previous_path)
    interval = _as_float(state_json.get("control_interval_sec"), 150.0)
    est: dict[str, float] = {}
    observed_used = 0
    for link in set(seed) | set(prev_est) | set(departures):
        g = green_sec.get(link, 0.0)
        obs = 0.0
        if g > 1.0 and link in departures:
            cycles = max(1.0, interval / max(1.0, _as_float(cfg.network.cycle_length, 150.0)))
            obs = departures[link] / (g * cycles) * 3600.0
        carried = decay * prev_est.get(link, seed.get(link, 0.0))
        value = max(obs, carried)
        # 2026-09-06 SAT v2: 큐가 서 있는 창의 관측은 수요가 아니라 용량이다 — 그때는 러닝맥스가 아니라 EWMA 로 곧바로 따라간다.
        if str(section.get("update", "")).strip().lower() == "queued_ewma" and obs > 0.0:
            _stopped_now = _as_float(_mapping(local.get("link_stopped_counts")).get(link), 0.0)
            if _stopped_now >= _as_float(section.get("queued_stopped_min"), 6.0):
                _alpha = clamp(_as_float(section.get("ewma_alpha"), 0.3), 0.0, 1.0)
                _prev = prev_est.get(link, seed.get(link, 0.0))
                value = _alpha * obs + (1.0 - _alpha) * _prev
                observed_used += 1
        if _cap_geo.get(link, 0.0) > 0.0:
            value = min(value, _cap_geo[link])
        if value > 0.0:
            est[link] = value
            if obs >= carried and obs > 0.0:
                observed_used += 1

    caps = dict(getattr(cfg.network, "movement_capacity_by_movement_veh_h", {}) or {})
    distribute_mode = str(section.get("distribute", "approach")).strip().lower()
    if distribute_mode == "lane_group" and seed_lg:
        # 링크 총량 est 를 차로군엔 씨앗 비율로 나눈다(온라인 갱신은 링크 단위 이탈 계수라 차로군을 못 가른다).
        est_lg: dict[tuple[str, str], float] = {}
        for (link, pid), sv in seed_lg.items():
            tot = sum(v for (lk, _p), v in seed_lg.items() if lk == link)
            if link in est and tot > 0.0:
                est_lg[(link, pid)] = float(est[link]) * float(sv) / float(tot)
        applied = _distribute_lane_group_capacity_to_movements(cfg, groups, est_lg, caps)
        # 증거(차로군)가 없는 internal movement: 접근로 링크가 무제어에서 큐가 안 서면 물리값(차로×1800), 큐가 서면
        # 현재값 유지(측정이 없으니 과대 위험 — 온라인 이탈 계수가 올려 준다). origin 링크 매핑이 없는(비핵심 신호) 것은 그대로.
        fallback_mode = str(section.get("fallback", "")).strip().lower()
        if fallback_mode == "geometric":
            fb_frac = clamp(_as_float(section.get("fallback_frac"), 1.0), 0.0, 1.0)
            lanes_src = WORKSPACE_ROOT / "outputs/movement_lanes_core17legs4b_20260821.json"
            lanes_map = {}
            try:
                lanes_map = _mapping(json.loads(lanes_src.read_text(encoding="utf-8")).get("movement_lanes"))
            except (OSError, ValueError):
                lanes_map = {}
            covered_links = {lk for (lk, _p) in seed_lg}
            queued_all: set[str] = set()
            if _qpath:
                try:
                    queued_all = {str(x) for x in (json.loads((WORKSPACE_ROOT / _qpath).read_text(encoding="utf-8")).get("queued_links") or [])}
                except (OSError, ValueError):
                    queued_all = set()
            origin_links_all = _origin_links_by_signal()
            fb_applied = 0
            for m, spec in (cfg.network.urban_movements or {}).items():
                if str(spec.get("kind", "")) != "internal":
                    continue
                links = origin_links_all.get(str(spec.get("signal", "")), {}).get(str(spec.get("origin", "")), set())
                if not links or (links & covered_links):
                    continue
                if links & queued_all:
                    continue
                lanes_m = _as_float(lanes_map.get(m), 0.0)
                if lanes_m <= 0.0:
                    lanes_m = 1.0
                caps[m] = float(lanes_m) * 1800.0 * fb_frac
                fb_applied += 1
            applied += fb_applied
            meta_fb = float(fb_applied)
        else:
            meta_fb = 0.0
    else:
        applied = _distribute_group_capacity_to_movements(cfg, groups, est, caps)
        meta_fb = 0.0
    if applied:
        setattr(cfg.network, "movement_capacity_by_movement_veh_h", caps)
    meta = {
        "measured_capacity_enabled": 1.0,
        "measured_capacity_seed_mode_observed": 1.0 if seed_mode == "observed" else 0.0,
        "measured_capacity_seed_mode_sustained": 1.0 if seed_mode == "sustained" else 0.0,
        "measured_capacity_est_cap_geometric": 1.0 if _cap_geo else 0.0,
        "measured_capacity_update_queued_ewma": 1.0 if str(section.get("update", "")).strip().lower() == "queued_ewma" else 0.0,
        "measured_capacity_distribute_lane_group": 1.0 if (distribute_mode == "lane_group" and seed_lg) else 0.0,
        "measured_capacity_fallback_geometric_movements": float(meta_fb),
        "measured_capacity_links": float(len(est)),
        "measured_capacity_observed_links": float(observed_used),
        "measured_capacity_movements": float(applied),
        "measured_capacity_decay": float(decay),
    }
    for link, value in sorted(est.items()):
        meta[f"sat_est_{link}"] = float(value)
    return meta


def _origin_links_by_signal() -> dict[str, dict[str, set[str]]]:
    """signal -> origin(접근로 이름) -> 정지선 링크 집합. movement_signal_group_map_v3 의 origin_signal_groups."""
    payload = load_movement_signal_group_map() or {}
    out: dict[str, dict[str, set[str]]] = {}
    for sig, entry in _mapping(payload.get("controllers")).items():
        sig_key = str(sig) if str(sig).startswith("SC") else "SC" + str(sig)
        for origin, info in _mapping(_mapping(entry).get("origin_signal_groups")).items():
            links = {str(x) for x in (_mapping(info).get("links") or [])}
            if links:
                out.setdefault(sig_key, {})[str(origin)] = links
    return out


def _distribute_lane_group_capacity_to_movements(cfg, groups, est_lg, caps) -> int:
    """(정지선 링크, 현시) 차로군 용량을 **그 접근로·그 현시의 movement** 들에 β 비율로 나눈다.
    접근로 총량을 현시 가로질러 β 로 나누던 종전 방식은 전용 좌회전 차로군과 직진 차로군을 섞었다
    (SC1002 E: 좌 1차로·직 2차로를 β 0.714 로 나눠 좌회전이 직진 용량을 가져간다). 같은 축 반대 접근로도 섞이지 않는다."""
    sigs: dict[str, str] = {}
    for g in groups:
        link = str(g.get("stopline_link", "")); sig = str(g.get("signal", ""))
        if link and sig:
            sigs[link] = sig
    for _lk, _sg in _SUS_SIGS.items():
        if _lk not in sigs and _sg:
            sigs[_lk] = _sg
    origin_links = _origin_links_by_signal()
    applied = 0
    for (link, pid), total in est_lg.items():
        sig = sigs.get(link)
        if not sig:
            continue
        olinks = origin_links.get(sig, {})
        _kinds = _LG_KINDS or {"internal"}
        # 소속 = detector mapping 의 link_to_origins[link] (정본 접근로 귀속: 32→in_SC1001_W, 66→in_SC1004_S, 329→SC101_to_SC1002) ∪ origin map
        _origins_here = set(_LTO.get(str(link), []) or [])
        members = [
            (m, max(0.0, _as_float(spec.get("beta"), 0.0)))
            for m, spec in (cfg.network.urban_movements or {}).items()
            if str(spec.get("signal", "")) == sig
            and str(spec.get("phase", "")).endswith("_" + pid)
            and (str(spec.get("kind", "")) in _kinds)
            and (str(spec.get("origin", "")) in _origins_here or link in olinks.get(str(spec.get("origin", "")), set()))
        ]
        if not members:
            continue
        weight = sum(w for _, w in members) or float(len(members))
        for m, w in members:
            share = (w / weight) if weight > 0 else 1.0 / len(members)
            caps[m] = float(total) * float(share)
            applied += 1
    return applied


def _approach_topology(groups) -> dict[str, tuple[str, tuple[str, ...]]]:
    """정지선 링크 -> (신호, 그 접근로가 받는 현시들). 링크 하나 = 접근로 하나다."""
    nema = {"NBT": "p1", "SBT": "p1", "NBL": "p2", "SBL": "p2",
            "EBT": "p3", "WBT": "p3", "EBL": "p4", "WBL": "p4"}
    pids: dict[str, set[str]] = {}
    sigs: dict[str, str] = {}
    for g in groups:
        link = str(g.get("stopline_link", ""))
        pid = nema.get(str(g.get("sg_name", "")).upper())
        sig = str(g.get("signal", ""))
        if link and pid and sig:
            pids.setdefault(link, set()).add(pid)
            sigs[link] = sig
    return {lk: (sigs[lk], tuple(sorted(v))) for lk, v in pids.items()}


def _measured_green_sec_by_link(cfg, groups, previous_path) -> dict[str, float]:
    """정지선 링크별 직전 구간 녹색초. 차로군의 SG 이름 -> 현시 -> 커밋 녹색."""
    nema = {"NBT": "p1", "SBT": "p1", "NBL": "p2", "SBL": "p2",
            "EBT": "p3", "WBT": "p3", "EBL": "p4", "WBL": "p4"}
    try:
        prev = json.loads(Path(previous_path).read_text(encoding="utf-8"))
        greens = {str(k): _as_float(v, 0.0) for k, v in _mapping(prev.get("green_times")).items()}
    except (OSError, ValueError):
        greens = {}
    # **합**이지 최대가 아니다. 이탈 계수는 링크 단위라 그 접근로 전체(좌·직·우)의
    # 방출을 센다. 한 링크에 차로군이 둘 붙으면(WBL+WBT) 두 현시의 녹색을 다 받는다.
    # 최대만 쓰면 분모가 작아 방류율이 과대해진다.
    out: dict[str, float] = {}
    seen: set[tuple[str, str]] = set()
    for g in groups:
        link = str(g.get("stopline_link", ""))
        pid = nema.get(str(g.get("sg_name", "")).upper())
        sig = str(g.get("signal", ""))
        if not link or pid is None or not sig or (link, pid) in seen:
            continue
        seen.add((link, pid))
        value = greens.get(f"{sig}_{pid}")
        if value is None:
            value = _as_float(g.get("green_sec"), 0.0)   # 첫 결정: 고정계획 녹색
        out[link] = out.get(link, 0.0) + float(value)
    return out


def _distribute_group_capacity_to_movements(cfg, groups, est, caps) -> int:
    """접근로 용량을 그 접근로 movement 들에 `beta` 비율로 나눈다(총량 보존)."""
    # 링크 하나 = 접근로 하나다. 그 접근로의 좌·직·우는 **같은 차로를 나눠 쓰므로**
    # 용량 총량을 공유한다. 현시(p1·p2)를 가로질러 배분해야 총량이 보존된다 —
    # 현시별로 각각 총량을 주면 그 접근로가 용량의 2배를 방류한다.
    by_key: dict[tuple[str, tuple[str, ...]], float] = {}
    for link, key in _approach_topology(groups).items():
        if link in est:
            by_key[key] = by_key.get(key, 0.0) + float(est[link])
    applied = 0
    for key, total in by_key.items():
        sig, pids = key
        members = [
            (m, max(0.0, _as_float(spec.get("beta"), 0.0)))
            for m, spec in (cfg.network.urban_movements or {}).items()
            if str(spec.get("signal", "")) == sig
            and any(str(spec.get("phase", "")).endswith("_" + pid) for pid in pids)
            and str(spec.get("kind", "")) not in PERIMETER_MOVEMENT_KINDS_ADAPTER
        ]
        if not members:
            continue
        weight = sum(w for _, w in members) or float(len(members))
        for m, w in members:
            share = (w / weight) if weight > 0 else 1.0 / len(members)
            caps[m] = float(total) * float(share)
            applied += 1
    return applied


def install_native_signal_structure(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """망의 **실제 신호 구조**(주기·녹색 예산)를 모델에 심는다. `urban.native_signal` 없으면 no-op.

    왜. 지금까지 컨트롤러는 모든 신호를 주기 150초 · 녹색 예산 138초(4현시)로 다뤘다.
    망의 실제 계획은 그렇지 않다.

        SC107/108/109   141      이미 일치 (live 3현시 -> 150-9)
        SC16            107      컨트롤러가 141 을 줘 **과잉 공급**
        SC5             246      p1 97 + p3 101 = 198 > 150 -> **동시 현시**
        SC7             205      동시 현시 + 주기 120

    링크 단위 분석에서 정체 최악 12개 중 10개가 SC5·SC6 이었다(SC6 은 SC5 하류).
    SC5 가 고정신호의 56%, SC7 이 69% 만 받고 있었다. 나머지 162개 링크는 무제어보다
    좋아졌는데 이 두 곳이 망 전체를 무너뜨린다.

    세 조각.

    (1) 신호별 주기. `cycle_length_by_signal` 에 `native_cycle_sec` 를 넣는다. SC7 이
        120초가 된다. 기반은 이미 있었고 매핑만 비어 있었다.

    (2) 신호별 녹색 예산. `min(계획 총합, C - N x clearance)`. SC16 이 141 -> 107 로
        내려간다. 상한을 두는 이유는 (3) 이다.

    (3) 동시 현시. `_phase_green_fraction` 이 현시를 **순차로 배치**하고
        `end = min(start + green, cycle)` 로 자르므로, 246초를 150초 주기에 넣으면 뒤쪽
        현시가 통째로 잘린다. 동시성을 제대로 넣으려면 "어느 현시가 겹치는지" 를 모델이
        알아야 하는데 그건 별건이다. 대신 **처리량 등가**로 근사한다 — 두 현시가 겹쳐
        켜지면 그 접근로의 시간당 처리량이 그만큼 는다. 그 신호 movement 들의 용량에
        `계획총합 / 예산` 을 곱한다(SC5 1.78, SC7 1.85). 근사임을 명시해 둔다.

    (3) 은 movement 용량 맵을 쓰므로 `install_movement_capacity_by_lanes` **뒤에** 불러야
    한다. 맵이 비어 있으면 전역 스칼라로 씨를 뿌린 뒤 곱한다.
    """
    section = _mapping(_mapping(tuning.get("urban")).get("native_signal"))
    _flag = section.get("enabled", False)
    _on = bool(_flag) if isinstance(_flag, (bool, int, float)) else         str(_flag).strip().lower() in {"1", "true", "yes", "on"}
    if not _on:
        return {"native_signal_structure_enabled": 0.0}
    # **측정값**을 쓴다. 유도(C - N x clearance)는 손실시간을 3초 x live현시수 로 고정하는데
    # 실측은 신호마다 전혀 다르다 — SC5 는 0초(항상 어딘가 녹색, 최대 6 SG 동시), SC16 은
    # 43초다. 유도를 쓰면 SC5 예산이 138(참값 150)이 되고 동시현시 배율의 분모까지 틀린다.
    # `.sig` 원본 유도본을 우선한다(2026-08-23). 구본(`..._measured_20260821.json`)의
    # `plan_total_sec`·`concurrency_factor` 가 원본과 안 맞았다 — SC5 가 246/1.64 인데
    # `.sig` 어디에서도 246 이 안 나온다(주기 150 · SG1-8 합 300 · SG9+ 408 · 전체 708).
    # 원본 유도: SC5 는 0-50-78-124-150 순차라 **겹침 0, 배율 1.00**. 겹침이 있는 건
    # SC7 하나뿐이다(최대 2개 동시, 1.59). 그 배율이 movement 용량에 곱해지므로
    # 검증 안 된 수를 쓰면 `cap4c` 와 같은 기전으로 악화된다.
    src = WORKSPACE_ROOT / "outputs/signal_timeline_from_sig_20260823.json"
    if not src.is_file():
        src = WORKSPACE_ROOT / "outputs/signal_timeline_measured_20260821.json"
    if not src.is_file():
        return {"native_signal_structure_enabled": 0.0, "native_signal_source_missing": 1.0}
    measured = _mapping(json.loads(src.read_text(encoding="utf-8")).get("signals"))

    net = cfg.network
    cycles: dict[str, float] = {}
    budgets: dict[str, float] = {}
    factors: dict[str, float] = {}
    for signal in _controlled_signal_names(cfg):
        entry = _mapping(measured.get(str(signal)))
        if not entry:
            continue
        cyc = _as_float(entry.get("cycle_sec"), 0.0)
        green = _as_float(entry.get("green_sec"), 0.0)
        fac = _as_float(entry.get("concurrency_factor"), 1.0)
        if cyc > 0.0:
            cycles[str(signal)] = cyc
        if green > 0.0:
            budgets[str(signal)] = green
        if fac > 1.0 + 1.0e-9:
            factors[str(signal)] = fac

    if cycles:
        setattr(net, "cycle_length_by_signal", dict(cycles))
    if budgets:
        setattr(net, "effective_green_total_by_signal", dict(budgets))

    # (4) **죽은 현시**. 실 계획에서 녹색 0 인 현시가 있다 — SC7 p3 · SC16 p4 ·
    #     SC107 p1 · SC108 p2 · SC109 p1. 모델이 4현시로 강제하면 없는 현시에 녹색을
    #     주고, 그만큼이 실제 접근로에서 사라진다. `signal_live_phases` 는 이 경우를
    #     위해 만들어져 있었는데 매핑이 비어 있었다.
    #
    #     상한도 같이 풀린다. green_max 는 total - (live-1) x green_min 의 유도값이라
    #     3현시 141 이면 101 이어야 하는데 스칼라 78 이 걸려 SC108(88) · SC109(90) 의
    #     실계획을 재현조차 못 했다(`NetworkConfig.signal_green_max`).
    live_map = _native_live_phases_by_signal(cfg)
    if live_map:
        setattr(net, "live_phases_by_signal", dict(live_map))

    # (3b) **COM 구동 주기로 재산정** (2026-09-01, 사용자 결정).
    #
    # 위 (1)(2)가 심은 `cycle_length_by_signal`·`effective_green_total_by_signal` 은
    # 실측 **native 신호 프로그램**의 값이다(SC7 주기 120·예산 114, SC16 예산 107).
    # 그런데 제어 런은 그 프로그램을 안 쓴다 — 러너가 모든 SG 에 ContrByCOM=True 를 걸어
    # inpx 신호 프로그램을 통째로 우회하고(plant_cycle.py), 컨트롤러가 제어구간으로 구동한다.
    # 그래서 native 주기를 예산 근거로 쓰면 실제로 재생되지 않는 계획에 맞춰 녹색을 배분한다.
    #
    # 구동 주기(150)와 **살아있는 현시 수**로 다시 계산한다:
    #     예산     = 주기 - 현시당 손실시간 x 살아있는 현시
    #     green_max = 예산 - (살아있는 현시 - 1) x green_min   (state.signal_green_max 가 파생)
    # 현시당 손실시간은 정본 전역값(lost_time 12 s / 4현시 = 3 s)에서 나온다.
    #
    # 결과: 4현시 13개 138/78 (불변) · 3현시 5개(SC7·SC16·SC107·SC108·SC109) 141/101.
    # SC107/108/109 는 이미 그 값이었고, 바뀌는 것은 SC7(114/74)·SC16(107/67) 뿐이다.
    # A/B 계측용 스위치(2026-09-01). 기본은 재산정이다 — 끄면 위 (1)(2) 가 심은 실측
    # native 값(SC7 120/114 · SC16 ?/107)이 그대로 남는다. 승격 묶음이 폐루프를 +578
    # 악화시켜 조각별 기여를 가리는 중이라 분해 실험용으로 둔다.
    #
    # 조기반환이 아니라 **블록 가드**여야 한다. 아래 동시현시 배율과 meta 조립은 이
    # 재산정과 무관하게 항상 돌아야 하고, 이 함수의 반환 계약은 dict 하나뿐이다.
    recompute_drive_cycle = _is_enabled_value(section.get("drive_cycle_recompute", True))
    if recompute_drive_cycle:
        drive_cycle = float(net.cycle_length)
        lost_per_phase = float(net.lost_time) / 4.0
        new_cycles: dict[str, float] = {}
        new_budgets: dict[str, float] = {}
        for signal in _controlled_signal_names(cfg):
            sid = str(signal)
            n_live = len(live_map.get(sid, ())) or 4
            new_cycles[sid] = drive_cycle
            new_budgets[sid] = drive_cycle - lost_per_phase * float(n_live)
        setattr(net, "cycle_length_by_signal", new_cycles)
        setattr(net, "effective_green_total_by_signal", new_budgets)

    # 동시 현시 -> 처리량 등가 배율. 순차 배치 모델은 겹침을 담을 수 없으므로
    # 그 신호 movement 들의 용량에 곱한다(배율 = 계획 현시녹색 합 / 실제 녹색초).
    applied_factor = 0
    if factors:
        caps = dict(getattr(net, "movement_capacity_by_movement_veh_h", {}) or {})
        for movement, spec in (net.urban_movements or {}).items():
            if str(spec.get("kind", "")) in PERIMETER_MOVEMENT_KINDS_ADAPTER:
                continue
            caps.setdefault(movement, float(net.movement_capacity_veh_h))
        for movement, spec in (net.urban_movements or {}).items():
            if str(spec.get("kind", "")) in PERIMETER_MOVEMENT_KINDS_ADAPTER:
                continue
            f = factors.get(str(spec.get("signal", "")))
            if f is None:
                continue
            caps[movement] = float(caps[movement]) * float(f)
            applied_factor += 1
        setattr(net, "movement_capacity_by_movement_veh_h", caps)

    meta = {
        "native_signal_structure_enabled": 1.0,
        "native_signal_cycle_count": float(len(cycles)),
        "native_signal_budget_count": float(len(budgets)),
        "native_signal_concurrency_signals": float(len(factors)),
        "native_signal_concurrency_movements": float(applied_factor),
        "native_signal_dead_phase_signals": float(len(live_map)),
        "native_signal_drive_cycle_recompute": 1.0 if recompute_drive_cycle else 0.0,
    }
    for sig, live in sorted(live_map.items()):
        meta[f"native_signal_live_phases_{sig}"] = float(len(live))
        meta[f"native_signal_green_max_{sig}"] = float(net.signal_green_max(sig))
    for sig, f in sorted(factors.items()):
        meta[f"native_signal_concurrency_factor_{sig}"] = float(f)
    return meta


def install_urban_stopline_storage(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """정지선 규모 저류를 유도해 cfg 에 주입한다. `urban.stopline_bay_m` 이 없으면 no-op.

    왜 필요한가. 기존 막힘 제약은 교차로간 링크(0.5~2.1 km, 링크당 중앙 431대) 저류를
    쓴다. 첨두에도 망 전체 4,500대가 185개 링크에 흩어져 점유율 10% 수준이라 제약이
    **절대 안 물린다** — 혼잡기 진단에 저류/막힘 항목이 하나도 안 뜬다. 그래서 모든 큐가
    녹색마다 완전히 비워지고, 참 큐에서 출발해도 150초에 400~550대를 과다 방류한다.
    부족분이 혼잡과 함께 커진다(t=600 -5 대 t=4800 -556).

    실제 막힘은 정지선 앞 대기공간과 좌회전 포켓에서 일어난다. 그 규모를 넣는다.

    유도. 산출물이 링크 길이와 jam 밀도를 들고 있어 차로수를 역산할 수 있다.

        lanes(L)    = storage(L) / (length_km(L) x jam_density)
        stopline(L) = lanes(L) x bay_km x jam_density
                    = storage(L) x bay_km / length_km(L)

    즉 링크 길이에 비례해 줄인다 — 짧은 링크는 덜 줄고 긴 링크는 많이 준다. 물리적으로
    맞다(정지선 대기공간은 링크 길이와 무관하게 일정하다).

    이건 방류율을 낮추는 대증요법(movement_capacity 1400->600)과 다르다. 그쪽은 모든
    movement 를 균일하게 굶겨 **movement 간 상대 비교를 왜곡**한다 — 신호제어가 쓰는 게
    정확히 그 상대 비교다. 이쪽은 혼잡할 때만, 막힌 곳에서만 물린다.
    """
    section = _mapping(_mapping(tuning.get("urban")).get("stopline"))
    bay_m = _as_float(section.get("bay_m"), 0.0)
    if bay_m <= 0.0:
        return {"urban_stopline_storage_enabled": 0.0}
    src = WORKSPACE_ROOT / "outputs/urban_storage_capacity_core17legs4b_20260819.json"
    if not src.is_file():
        return {"urban_stopline_storage_enabled": 0.0, "urban_stopline_storage_source_missing": 1.0}
    doc = json.loads(src.read_text(encoding="utf-8"))
    lengths = _mapping(doc.get("urban_link_length_km"))
    storages = _mapping(doc.get("urban_link_storage_veh"))
    bay_km = bay_m / 1000.0
    out: dict[str, float] = {}
    for link, cap in (cfg.network.urban_link_storage_veh or {}).items():
        base = _as_float(storages.get(link), _as_float(cap, 0.0))
        length_km = _as_float(lengths.get(link), 0.0)
        if base <= 0.0 or length_km <= 0.0:
            continue
        out[str(link)] = float(base) * bay_km / float(length_km)
    if not out:
        return {"urban_stopline_storage_enabled": 0.0, "urban_stopline_storage_empty": 1.0}
    setattr(cfg.network, "urban_stopline_storage_veh", out)
    vals = sorted(out.values())
    return {
        "urban_stopline_storage_enabled": 1.0,
        "urban_stopline_bay_m": float(bay_m),
        "urban_stopline_link_count": float(len(out)),
        "urban_stopline_storage_median_veh": float(vals[len(vals) // 2]),
        "urban_stopline_storage_min_veh": float(vals[0]),
        "urban_stopline_storage_max_veh": float(vals[-1]),
    }


def install_price_worker_runtime_patches(cfg, state_json, detector_mapping):
    """가격 워커가 되살려야 할 **모든** 런타임 패치. 부트스트랩의 func 가 이것이다.

    상류 __setstate__ 는 `func(cfg, state_json, detector_mapping)` 하나만 부른다
    (priced_wu_link_controller.py:542-545). 그래서 되살릴 게 둘 이상이면 여기서 묶어야 한다.

    유실 대상 둘:
      `_phase_green_fraction`  (5개 모듈) — green->유량 변환
      `_link_delay_steps`      (2개 모듈) — tau 물리길이 상한

    안 묶으면 **부모는 상한 tau, 워커 10개는 무상한 tau** 로 가격을 매긴다. 실측 차이:
    TTT6 -85.4 veh*h · 가격벡터 Spearman 0.605 · 부호 30.6% 반전. 조용히 틀린다.

    beta 수정(apply_dead_phase_beta_zero)은 여기 없어도 된다 — cfg.network.urban_movements
    를 바꾸므로 컨트롤러와 함께 피클되어 워커에 그대로 간다.
    """
    from evaluation.controllers.runtime_setup import install_worker_runtime
    return install_worker_runtime(sys.modules[__name__], cfg, state_json, detector_mapping)


def install_price_worker_bootstrap(controller, state_json, detector_mapping) -> dict[str, float]:
    """가격 롤아웃 워커가 되살려야 할 런타임 패치를 컨트롤러에 실어 보낸다.

    워커는 spawn 된 **새 인터프리터**라 이 어댑터가 모듈에 심은 몽키패치를 못 물려받는다.
    유실 대상은 `install_monitor_fixed_signal_runtime_patch` 의 `_phase_green_fraction`
    (5개 모듈) 하나다 — 캘리브레이션 v2 와 VSL/METANET 은 `cfg` 속성으로 들어가므로
    컨트롤러와 함께 피클되어 살아남는다.

    2026-08-20 실측(phasepar). 이걸 안 실어 보낸 병렬 런이 같은 입력 t=600 에서 직렬과
    다른 가격을 냈고(SC5 27%, SC6 부호 반전) SC1002·SC12·SC5 의 녹색을 8초씩 반대로
    커밋했다. green 채널에서만 갈린 것이 이 패치가 green->유량 변환 전용이라는 것과 맞는다.

    페이로드는 최소로 싣는다 — 설치 함수는 `state_json` 에서 `_network_path_from_state`
    로 경로 하나만 읽는다. 상태 전체를 실으면 워커마다 차량 기록을 통째로 피클한다.

    되살리기는 `PricedWuLinkStackelbergController.__setstate__` 가 한다. 실패하면 raise 해
    직렬 재실행 + 카운터로 떨어진다(조용한 경로 없음).
    """
    if int(getattr(controller, "price_parallel_workers", 0) or 0) <= 1:
        return {"price_worker_bootstrap_installed": 0.0}
    controller.price_worker_bootstrap = {
        "sys_path": str(WORKSPACE_ROOT),
        "module": __name__,
        "func": "install_price_worker_runtime_patches",
        "state_json": {"network_path": str(_network_path_from_state(state_json))},
        "detector_mapping": dict(detector_mapping or {}),
        "verify_module": "src.models.urban_queue_model",
        "verify_attr": "_vissim_original_phase_green_fraction",
    }
    return {"price_worker_bootstrap_installed": 1.0}



def _tau_diagnostics(state, cfg, local_summary: dict) -> None:
    """τ 분포와 **플래툰 도착 위상**을 남긴다 — τ 팔은 TTT 하나로 판정할 수 없다.

    τ 는 `urban_arrival_buffer` 의 도착 스텝을 정하므로(urban_queue_model.py:1179)
    하류 approach 의 `available = queue + arrivals` 를 직접 바꾼다. 방출 **률**은
    안 바뀌지만(용량은 차로·포화유율에서 나온다) 방출 **가능량의 시점**이 바뀐다.
    그래서 offset 위상만이 아니라 망 전체 방출 회계가 움직인다 — 세 지표를 같이 봐야 한다.

    여기서 두 개를 낸다: τ 분포(horizon 초과 비율 포함)와 위상 (τ·T_u) mod cycle.
    예측 정합(세 번째 지표)은 런 뒤 비교 스크립트가 낸다.
    """
    try:
        from src.models.urban_queue_model import _link_delay_steps
    except Exception:
        return
    t_u_sec = max(float(cfg.simulation.T_u_h) * 3600.0, 1.0e-9)
    horizon_sec = float(cfg.mpc.horizon_steps) * float(cfg.simulation.T_c_h) * 3600.0
    cycle = max(float(cfg.network.cycle_length), 1.0e-9)
    taus: list[float] = []
    phases: list[float] = []
    for link in cfg.network.urban_link_storage_veh:
        try:
            sec = float(_link_delay_steps(state, cfg, link)) * t_u_sec
        except Exception:
            continue
        taus.append(sec)
        phases.append(sec % cycle)
    if not taus:
        return
    ordered = sorted(taus)
    n = len(ordered)
    local_summary["tau_diagnostics"] = {
        "links": float(n),
        "tau_median_sec": ordered[n // 2],
        "tau_mean_sec": sum(ordered) / n,
        "tau_p90_sec": ordered[min(n - 1, int(0.9 * n))],
        "tau_max_sec": ordered[-1],
        "tau_over_horizon": float(sum(1 for x in ordered if x > horizon_sec)),
        "tau_over_horizon_frac": sum(1 for x in ordered if x > horizon_sec) / n,
        "horizon_sec": horizon_sec,
        # 위상 자체는 평균이 무의미하다(원형 변수) — 분포를 남겨 런끼리 비교한다.
        "phase_cycle_sec": cycle,
        "phase_q1_sec": sorted(phases)[n // 4],
        "phase_median_sec": sorted(phases)[n // 2],
        "phase_q3_sec": sorted(phases)[(3 * n) // 4],
    }

def _absolute_urban_step_start_sec(urban_step_index: int, duration_sec: float) -> float:
    """NumSim urban step indices are already based on absolute state.time_sec."""
    return int(urban_step_index) * float(duration_sec)


def _storage_links_for_observed_origin(cfg, origin: str) -> list[str]:
    net = cfg.network
    value = str(origin)
    if value in net.urban_link_storage_veh:
        return [value]
    storage = str(net.off_ramp_storage_link.get(value, ""))
    if storage and storage in net.urban_link_storage_veh:
        return [storage]
    return []


def _link_storage_split_fraction(cfg, origins: list[str], split_parameters: Mapping[str, Any]) -> float:
    storage_links: list[str] = []
    off_ramp_storage_links = {str(v) for v in cfg.network.off_ramp_storage_link.values()}
    for origin in origins:
        storage_links.extend(_storage_links_for_observed_origin(cfg, origin))
    if not storage_links:
        return 0.0
    if any(link in off_ramp_storage_links for link in storage_links):
        return float(split_parameters.get("offramp_storage_fraction", LOCAL_OBSERVATION_OFFRAMP_STORAGE_FRACTION))
    return float(split_parameters.get("internal_storage_fraction", LOCAL_OBSERVATION_INTERNAL_STORAGE_FRACTION))




# tuning 에서 읽은 런타임 스위치. `main()` 이 tuning 을 연 직후 한 번 채운다.
#
# 왜 config 키가 필요한가. 환경변수는 (a) `extends` 사슬로 상속되지 않고 (b) 러너의
# run_provenance 에 안 남는다. 그래서 팔마다 러너 스크립트에 따로 세워야 했고, 어느 팔이
# 무엇을 켜고 돌았는지 사후에 알 수 없었다. default 스택이 되려면 둘 다 안 된다.
#
# env 는 **폴백으로 남긴다** — 이미 돌린 팔들의 재현과 임시 A/B 를 위해서다.
# tuning 키가 있으면 그것이 이긴다.
_CFG_SWITCHES: dict[str, bool] = {}
_CFG_MISSING: set = set()  # config 에 없어 False 로 떨어진 스위치 이름


_CFG_STRINGS: dict = {}


def _switch(name: str, env_name: str) -> bool:
    """config 전용. 2026-09-05 env 폴백 삭제 — env 게이트는 호출 경로가 바뀌면 조용히 꺼진다
    (RW_MAINLINE_SG_ONLY 사고: Bash 체인 22런이 미드블록 SG 를 COM 적색으로 돌렸다). 키가 없으면
    False 이고 `_CFG_MISSING` 에 남겨 install_config_switches 진단으로 드러난다. env_name 은 호환용 인자."""
    if name in _CFG_SWITCHES:
        return bool(_CFG_SWITCHES[name])
    _CFG_MISSING.add(name)
    return False


def install_config_switches(tuning: Mapping[str, Any]) -> dict[str, float]:
    """tuning 의 런타임 스위치를 모듈에 심는다. 키가 없으면 env 폴백이라 비트 동일."""
    urban = _mapping(tuning.get("urban"))
    pairs = (
        ("moving_speed", _mapping(urban.get("tau")).get("moving_only")),
        ("lane_delay", _mapping(urban.get("tau")).get("lane_delay_correction")),
        ("stopped_split", _mapping(urban.get("queue")).get("stopped_split")),
        ("tau_length_cap", _mapping(urban.get("tau")).get("length_cap")),
        ("boundary_inflow_seed", _mapping(urban.get("boundary")).get("inflow_seed")),
        ("dead_phase_beta_zero", _mapping(urban.get("movements")).get("dead_phase_beta_zero")),
        ("movement_phase_correction", _mapping(urban.get("movements")).get("phase_correction")),
        ("queue_origin_binding", _mapping(urban.get("queue")).get("origin_binding")),
        ("queue_contiguous", _mapping(urban.get("queue")).get("contiguous")),
        ("arrival_seed", _mapping(urban.get("arrival")).get("seed_from_residual")),
        ("storage_lanes_fzp", _mapping(urban.get("tau")).get("storage_lanes_fzp")),
        ("mainline_plan", _mapping(urban.get("plan")).get("mainline_only")),
        ("mainline_share", _mapping(urban.get("plan")).get("mainline_share")),
    )
    # 문자열 스위치(모드 값). env 전용이던 것을 config 로 올린 자리다.
    _CFG_STRINGS["release_buffer_restore"] = str(
        _mapping(urban.get("release_buffer")).get("restore", "") or "").strip().lower()
    _CFG_STRINGS["queue_window_stat"] = str(
        _mapping(urban.get("queue")).get("window_stat", "") or "").strip().lower()
    # 2026-09-06 큐 귀속 가중: "" = detector_mapping weight(비트 동일), "beta" = movement β(목적지 분율).
    _CFG_STRINGS["queue_attribution"] = str(
        _mapping(urban.get("queue")).get("attribution", "") or "").strip().lower()
    out: dict[str, float] = {}
    for key, raw in pairs:
        if raw is None:
            continue
        _CFG_SWITCHES[key] = _is_enabled_value(raw)
        out[f"cfg_switch_{key}"] = 1.0 if _CFG_SWITCHES[key] else 0.0
    # `native_phase_green` 은 tuning 을 못 본다(모델 쪽 순수 모듈이라 인자가 schedule 뿐).
    # 다리를 env 로 놓는다 — 값의 출처는 여전히 config 이고, 진단으로도 남긴다.
    if _CFG_SWITCHES.get("mainline_share"):
        os.environ["RW_MAINLINE_SHARE_SG"] = "1"
    # tau 상한도 env 로 다리를 놓는다. 가격 워커는 spawn 이라 _CFG_SWITCHES 를 못
    # 물려받고 env 만 본다(RW_LANE_DELAY_CORRECTION 과 같은 이유).
    if _CFG_SWITCHES.get("tau_length_cap"):
        os.environ["RW_TAU_LENGTH_CAP"] = "1"
    if _CFG_SWITCHES.get("lane_delay"):
        os.environ["RW_LANE_DELAY_CORRECTION"] = "1"
    return out


def _stopped_split_enabled() -> bool:
    """큐/저류 분할에 **실측 정지대수**를 쓸지. 기본 꺼짐 = 비트 동일.

    config `urban.queue.stopped_split`, 폴백 env `RW_STOPPED_SPLIT`.
    """
    return _switch("stopped_split", "RW_STOPPED_SPLIT")


_QUEUE_WALK_CACHE: dict = {}

# 2026-09-04. 잔차 도착 τ. 실측 중앙값(.fzp, 37결정 x 196링크): 이동 15 s / 정지-비큐 105 s.
# 지평 450 s = horizon 3 x 150 s. 이를 넘는 만기는 버린다(지평 끝 몰아넣기 금지).
STORAGE_LANES_FZP_JSON = WORKSPACE_ROOT / "outputs/storage_effective_lanes_20260904.json"
LINK_GEOMETRY_FZP_JSON = WORKSPACE_ROOT / "outputs/urban_link_geometry_20260904.json"
_LINK_GEOM_CACHE: dict | None = None

# 정지선 큐로 인정할 선두 거리[m]. 이보다 상류에서 시작한 정지 무리는 정지선 행렬이 아니다.
_QUEUE_HEAD_WINDOW_M = 30.0


def _link_lengths_m() -> dict[str, float]:
    """링크별 길이[m] (.fzp max Pos). head window 판정에만 쓴다."""
    global _LINK_GEOM_CACHE
    if _LINK_GEOM_CACHE is not None:
        return _LINK_GEOM_CACHE
    out: dict[str, float] = {}
    doc = load_optional_json(str(LINK_GEOMETRY_FZP_JSON))
    table = doc.get("links") if isinstance(doc, Mapping) else None
    if isinstance(table, Mapping):
        for link, spec in table.items():
            if isinstance(spec, Mapping):
                length = _as_float(spec.get("length_m"), 0.0)
                if length > 0.0:
                    out[str(link)] = length
    _LINK_GEOM_CACHE = out
    return out

_ARRIVAL_TAU_MOVING_SEC = 15.0
_ARRIVAL_TAU_STOPPED_SEC = 105.0
_ARRIVAL_MAX_HORIZON_SEC = 450.0


def _contiguous_stopline_queue(state_json: Mapping[str, Any]) -> dict[str, float]:
    """`queue_bins` 에서 링크별 **정지선 연속 대기행렬**[veh] 을 낸다.

    ## 왜 이 양인가 (2026-09-04)

    현행 `link_stopped_counts` 는 **링크 위 정지차량 전부**다. 그런데 녹색이 방류하는 것은
    정지선에서 이어진 행렬이지, 중간에 따로 막혀 선 차가 아니다. 실측으로 둘은 도시
    link-instant 의 90.3% 에서 같지만, 갈리는 9.7% 가 전체 오차의 32.0pt 를 만든다.
    장링크에서 잔차 평균 대비 MAE:

        링크 32(1,970m)  전체정지 85.6%  ->  연속walk 0.7%
        링크 66(2,660m)        71.6%  ->          0.0%
        링크 40(1,258m)        70.5%  ->          0.1%
        링크 30(  535m)        72.4%  ->         12.1%

    전체정지는 진짜 정지선 큐를 1.44~1.69배 과대하고, 그 과대가 유령 큐로 녹색을 가져갔다
    (링크 32 -> SC1001_p3: 컨트롤러 355~421대, 진실 11~27대, 후반 내내 녹색 59~75초).

    ## 어떻게 끊는가

    **공간 갭에서 끊지 않는다.** 갭 허용 20/40/100/무한이 전부 같은 값(36,085)을 냈다 —
    walk 를 끊는 것은 언제나 **움직이는 차량**이다. 그래서 빈 빈은 건너뛰고, `total > stopped`
    인 빈(= 움직이는 차가 섞인 빈)에서만 멈춘다.

    **차로별로 걷는다.** 차로를 풀링하면 한 차로가 방류하는 순간 링크 전체 큐가 잘린다
    (실측: 풀링 36.8% 대 차로별 48.2%).

    입력은 러너의 `queue_bins` = {"link|lane|bin": [total, stopped]}, 빈 크기 `queue_bin_m`
    (기본 7.0m = 실측 잼 간격 6.3m 에 차량 1대). 정렬은 러너가 하지 않는다 — 스캔이 이미
    런의 33% 라 VBScript 정렬을 붙일 수 없다. 여기서 빈 인덱스로 정렬한다.
    """
    local = _mapping(state_json.get("local_observation"))
    raw = local.get("queue_bins")
    if not isinstance(raw, Mapping) or not raw:
        return {}
    bin_m = _as_float(local.get("queue_bin_m"), 7.0) or 7.0
    by_lane: dict[tuple[str, str], dict[int, tuple[float, float]]] = {}
    for key, value in raw.items():
        parts = str(key).split("|")
        if len(parts) != 3:
            continue
        try:
            idx = int(parts[2])
        except (TypeError, ValueError):
            continue
        if isinstance(value, (list, tuple)) and len(value) >= 2:
            total, stopped = _as_float(value[0], 0.0), _as_float(value[1], 0.0)
        else:
            total, stopped = _as_float(value, 0.0), 0.0
        by_lane.setdefault((parts[0], parts[1]), {})[idx] = (total, stopped)
    lengths = _link_lengths_m()
    out: dict[str, float] = {}
    for (link, _lane), bins in by_lane.items():
        if not bins:
            continue
        occupied_idx = [i for i, (t, _s) in bins.items() if t > 0.0]
        if not occupied_idx:
            continue
        # head window: 행렬 선두가 정지선(링크 하류 끝)에서 멀면 정지선 큐가 아니다.
        # 이 조건이 없으면 링크 중간에 따로 선 정지 무리도 큐로 세어 과대해진다 —
        # arm_qsplit 실측 walk/정지 0.820 대 .fzp 참조 0.569 의 격차가 이것이었다.
        # 길이 정보가 없는 링크는 종전처럼 조건 없이 걷는다(폴백).
        length = lengths.get(str(link), 0.0)
        if length > 0.0:
            head_m = (max(occupied_idx) + 1) * bin_m
            if (length - head_m) > _QUEUE_HEAD_WINDOW_M:
                continue
        queued = 0.0
        for idx in sorted(bins, reverse=True):
            total, stopped = bins[idx]
            if total <= 0.0:
                continue          # 빈 빈은 갭 — 끊지 않는다(감도 0 실측)
            if total > stopped:
                break             # 움직이는 차가 섞였다 = 행렬의 끝
            queued += stopped
        if queued > 0.0:
            out[link] = out.get(link, 0.0) + queued
    return out


def _contiguous_queue_enabled() -> bool:
    """config `urban.queue.contiguous` · env 폴백 `RW_QUEUE_CONTIGUOUS`. 기본 꺼짐=비트 동일."""
    return _switch("queue_contiguous", "RW_QUEUE_CONTIGUOUS")


def _stopped_storage_fraction(link: str, count: float, stopped: Mapping[str, float],
                              fallback: float) -> float:
    """정지비율로 저류 분율을 낸다. 관측이 없으면 fallback(= 종전 고정값).

    현행은 링크 위 **전 차량**에 고정 분율을 곱해 큐를 만든다 — `queue = count x (1 - 0.35)`
    (내부) 또는 `x (1 - 0.50)`(off-ramp). 그런데 `link_stopped_counts` 가 이미 수집돼 있고
    **실런 팔에서는 완전히 죽어 있다**: 그것이 만드는 `urban_link_storage_stopped` 의 유일한
    소비처가 `restore_urban_release_buffers` 인데 그 함수가 `RW_RESTORE_RELEASE_BUFFERS`
    없으면 조기 반환하고 정본 러너는 그 변수를 안 세운다.

    실측(conv seed13 t=3600). 고정 0.65 는 **망 합계로는 맞다** — 관측 2,724대 중 정지
    1,799대(66.0%). 그래서 총량 점검으로는 절대 안 잡힌다. 그런데 분포가 무너져 있다:

        SC7   정지 97% 모델 65%  -32pt      SC1004  17% 65%  +48pt
        SC101      85%      65%  -20pt      SC1003  30% 65%  +35pt
        SC5        83%      65%  -18pt      SC1001  37% 65%  +28pt

    균일 분율은 신호 **내부**에서 공통 배수라 상쇄되지만 현시 배분은 뒤집힌다 —
    SC1005 p3 는 count 로 29.7대인데 정지차는 **1.4대**(점유 -36.7pt).

    왜 정지대수가 맞는 양인가. 모델의 `urban_movement_queue` 는 녹색이 방류하는 저수지이고,
    아직 굴러오는 차는 **저류**에 있다가 링크 통과지연을 거쳐 도착한다 — 구조가 이미 그렇게
    갈라져 있다. 질량은 거의 안 바뀌고 배분만 바뀐다(1,771 -> 1,799).
    """
    if count <= 0.0:
        return float(fallback)
    raw = stopped.get(str(link))
    if raw is None:
        return float(fallback)
    share = min(1.0, max(0.0, float(raw) / float(count)))
    return float(1.0 - share)


_MIDBLOCK_CACHE: dict = {}


STORAGE_GEOMETRY_JSON = WORKSPACE_ROOT / "outputs/urban_storage_geometry_core17legs4f_20260826.json"
_GEOM_CACHE: dict = {}


def _dead_phase_beta_zero_enabled() -> bool:
    """녹색이 구조적으로 0 인 현시의 movement beta 를 0 으로 돌릴지. 기본 꺼짐.

    config `urban.movements.dead_phase_beta_zero` · env `RW_DEAD_PHASE_BETA_ZERO`.

    2026-08-26 실측. 현시 5개(SC107_p1 SC108_p2 SC109_p1 SC16_p4 SC7_p3)는 구성 신호군의
    native_green_sec 이 0 이고 VISSIM 되읽기에서 5400초 내내 RED 다(SC107 SG4/SG8 = RED 181회).
    거기 묶인 movement 17개는 결정당 38.3대를 받아 **영원히 방류되지 않는다** — 롤아웃이
    길어질수록 누적되는 블랙홀이다.

    그 17개의 beta 는 전부 균등 1/n(1/2·1/6·1/8·1/3)이라 `.inpx` 정본이 아니라 옛 균등값
    잔재다(vissim-uniform-beta-defect). 그리고 VISSIM 실측 재고는 해당 접근로에서 초반
    85대 -> 후반 54대로 **줄어든다** — VISSIM 은 그 회전으로 차를 보내지 않는다.

    개루프 6스텝 롤아웃 (bstoA + tau 상한 기준):
        끔    스텝1 38.1%  스텝3 53.7%  스텝6 69.4%  총량6 3179
        켬    스텝1 38.2%  스텝3 52.3%  스텝6 64.6%  총량6 3098   (실측 2650)
    """
    return _switch("dead_phase_beta_zero", "RW_DEAD_PHASE_BETA_ZERO")


MOVEMENT_PHASE_CORRECTION_JSON = (
    WORKSPACE_ROOT / "outputs/movement_phase_correction_20260828.json"
)


def _movement_phase_correction_enabled() -> bool:
    """선언 phase 를 근거 phase 로 고칠지. 기본 꺼짐 = 비트 동일."""
    return _switch("movement_phase_correction", "RW_MOVEMENT_PHASE_CORRECTION")



def apply_nonexistent_movement_beta_zero(cfg, tuning=None) -> dict[str, float]:
    """물리 회전이 없는 movement 의 beta 를 0 으로 하고 같은 origin 의 형제에게 넘긴다.

    `urban_movements` 는 leg 교차곱 선언이라 물리 회전보다 많다(CLAUDE.md). 그중 일부는
    커넥터 지도에 **대응 진출이 아예 없다** — 그런데도 beta 를 받아 흐름을 가져가고,
    하필 죽은 현시에 배정돼 그 몫이 영원히 서비스되지 않는다.

    실측(2026-09-01):
        SC109_N_SC16_to_W_SC108  N_SC16 진출은 10283 -> 1220000803(망 이탈) 하나뿐
        SC7_E_SC16_to_N_SC11     E_SC16 진출은 10332 -> S_SC108, 10333 -> SC108_N_SC7 둘뿐
        SC7_E_to_N_SC11          위와 같음(경계 leg 판)
    셋 다 origin 형제가 정확히 하나이고 beta 가 0.5/0.5 라, 0 으로 만들고 넘기면
    그 origin 이 실제 회전 100% 가 된다.

    목록은 `outputs/movement_phase_correction_20260828.json` 의
    `known_nonexistent_movements` 절이다. 없으면 no-op(비트 동일).
    """
    # A/B 분해(2026-09-02). 키가 없으면 켜짐 = 현행 비트 동일.
    _sec = _mapping(_mapping(_mapping(tuning).get("urban")).get("movements"))
    if "nonexistent_beta_zero" in _sec and not _is_enabled_value(_sec["nonexistent_beta_zero"]):
        return {"nonexistent_movement_beta_zero": 0.0, "nonexistent_movement_disabled": 1.0}
    if not MOVEMENT_PHASE_CORRECTION_JSON.is_file():
        return {"nonexistent_movement_beta_zero": 0.0}
    try:
        doc = json.loads(MOVEMENT_PHASE_CORRECTION_JSON.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"nonexistent_movement_beta_zero": 0.0}
    names = [str(k) for k in _mapping(doc.get("known_nonexistent_movements"))
             if not str(k).startswith("_")]
    if not names:
        return {"nonexistent_movement_beta_zero": 0.0}
    specs = cfg.network.urban_movements or {}
    zeroed = 0
    moved = 0.0
    for name in names:
        spec = specs.get(name)
        if spec is None:
            continue  # 병합으로 이름이 바뀌었거나 사라졌다
        origin = str(spec.get("origin", ""))
        beta = _as_float(spec.get("beta"), 0.0)
        if beta <= 0.0:
            continue
        sibs = [k for k, v in specs.items()
                if k != name and str(v.get("origin", "")) == origin
                and k not in names]
        if not sibs:
            # 넘길 형제가 없으면 손대지 않는다 — 그 origin 의 수요가 통째로 사라진다.
            continue
        share = beta / float(len(sibs))
        for k in sibs:
            specs[k]["beta"] = _as_float(specs[k].get("beta"), 0.0) + share
        specs[name]["beta"] = 0.0
        zeroed += 1
        moved += beta
    return {"nonexistent_movement_beta_zero": 1.0,
            "nonexistent_movement_zeroed": float(zeroed),
            "nonexistent_movement_beta_moved": float(moved)}
def apply_movement_phase_correction(cfg, tuning: Mapping[str, Any] | None = None) -> dict:
    """movement 의 선언 `phase` 를 신호두 근거로 고친다. 꺼져 있으면 no-op(비트 동일).

    `phase` 는 플랜트에서 그 회전이 **어느 현시의 녹색을 받는지** 를 정한다
    (`_phase_green_fraction` 이 `spec["phase"]` 로 `control.green_times` 를 찾는다).
    틀리면 그 회전이 5400초 내내 엉뚱한 현시로 서비스된다.

    근거 사슬 (2026-08-28).

      정지선 커넥터  `outputs/movement_connector_map_20260824.json` 이 movement 마다
                    SG 를 제안한다. 그중 SG 가 **하나로 확정된** 제안만 쓴다.
      신호두 교차검증 `outputs/movement_sg_canonical_20260827.json` 이 그 제안을 inpx
                    `<signalHead lane sg>` 537개와 맞대 **충돌 0** 을 확인했다.
      현시->SG 표    `movement_signal_group_map_v3` 와 `signal_group_actuation_plan_v3`
                    가 17개 SC **전부 일치**한다(2026-08-28 대조). 분모는 다투지 않는다.

    이 셋이 서로 독립인데 같은 답을 내는 자리에서만 고친다 — 확정 SG 30개 중 19개는
    선언과 이미 같고, **11개가 어긋난다.** 그 11개가 이 함수가 고치는 전부다.

    왜 중요한가. `SC16_W_SC7_to_N_SC12` 는 beta 0.677 — 그 접근로 흐름의 68% 가 잘못된
    현시로 간다. 그리고 이것이 `apply_dead_phase_beta_zero` 오판의 원인이기도 하다:
    선언 p2 를 보고 "그 축은 녹색 0" 이라 판정했는데 실제 현시는 p1 이었고, VISSIM 전수
    추적에서 그 movement 들에 차가 실제로 지난다(SC108_S_to_W_SC107 16건 등).
    **그래서 이 보정은 dead_phase 판정보다 먼저 걸려야 한다.**

    선언이 근거 파일이 적은 `declared_phase` 와 다르면 **고치지 않고 흘려보낸다** —
    config 가 바뀌어 산출물이 낡은 경우이고, 그때 덮으면 근거 없는 값을 심게 된다.
    """
    if not _movement_phase_correction_enabled():
        return {"movement_phase_correction_enabled": 0.0}
    path = MOVEMENT_PHASE_CORRECTION_JSON
    if not path.is_file():
        return {"movement_phase_correction_enabled": 0.0,
                "movement_phase_correction_source_missing": 1.0}
    doc = json.loads(path.read_text(encoding="utf-8"))
    table = _mapping(doc.get("corrections"))
    movements = cfg.network.urban_movements or {}

    # **병합 그룹 단위로 건다.** `install_merged_movements` 는 같은 물리 회전으로 합쳐질
    # movement 들의 `phase` 가 갈리면 `ValueError` 로 런을 세운다(fail-closed, 옳은 설계).
    # 커넥터 근거는 회전 하나를 가리키는데 모델은 그 회전을 출구별로 쪼개 놨으므로,
    # 하나만 고치면 형제와 갈려 병합이 터진다 — 2026-08-28 에 실제로 5건에서 터졌다.
    # 물리적으로도 그룹 전체가 같은 정지선·같은 SG 라 phase 가 같아야 맞다.
    groups: dict[str, list[str]] = {}
    merge_on = _is_enabled_value(
        _mapping(_mapping(_mapping(tuning).get("urban")).get("movements")).get("merge_exits")
    )
    if merge_on and MOVEMENT_MERGE_PLAN_JSON.is_file():
        rep = _mapping(
            json.loads(MOVEMENT_MERGE_PLAN_JSON.read_text(encoding="utf-8")).get("leg_representative")
        )
        for nm, sp in movements.items():
            sig = str(sp.get("signal", ""))
            app = str(sp.get("approach", ""))
            raw_exit = str(sp.get("exit", ""))
            ext = str(rep.get("%s|%s" % (sig, raw_exit), raw_exit))
            if str(rep.get("%s|%s" % (sig, app), app)) == ext:
                continue          # 자기참조(u_turn) — 병합에서 빠진다
            groups.setdefault("%s_%s_to_%s" % (sig, app, ext), []).append(str(nm))
    member_of = {nm: key for key, members in groups.items() for nm in members}

    applied, stale, missing, split = 0, 0, 0, 0
    beta_moved = 0.0
    moved_names: list[str] = []
    sibling_count = 0
    # A/B 분해(2026-09-02). `added` 가 이 값인 보정만 건너뛴다. 정본 JSON 은 안 건드린다.
    skip_added = str(_mapping(_mapping(_mapping(tuning).get("urban"))
                              .get("movements")).get("phase_correction_skip_added", "") or "")
    skipped_added = 0
    for name, spec in sorted(table.items()):
        if skip_added and str(_mapping(spec).get("added") or "") == skip_added:
            skipped_added += 1
            continue
        target = movements.get(str(name))
        if not isinstance(target, MutableMapping):
            missing += 1
            continue
        node = str(target.get("intersection") or "")
        declared = str(target.get("phase") or "")
        want_from = "%s_%s" % (node, str(_mapping(spec).get("declared_phase") or ""))
        want_to = "%s_%s" % (node, str(_mapping(spec).get("evidence_phase") or ""))
        if declared != want_from:
            # 산출물이 낡았다. 조용히 덮지 않는다.
            stale += 1
            continue
        key = member_of.get(str(name))
        family = list(groups.get(key, ())) if key else [str(name)]
        if str(name) not in family:
            family.append(str(name))
        # 그룹이 원래부터 갈려 있으면 손대지 않는다 — 일부만 고치면 병합이 터진다.
        if any(str(_mapping(movements.get(o)).get("phase") or "") != want_from for o in family):
            split += 1
            continue
        for o in family:
            sib = movements.get(o)
            if isinstance(sib, MutableMapping):
                sib["phase"] = want_to
                beta_moved += _as_float(sib.get("beta"), 0.0)
        applied += 1
        sibling_count += len(family) - 1
        moved_names.append(str(name))
    out = {
        "movement_phase_correction_enabled": 1.0,
        "movement_phase_correction_applied": float(applied),
        "movement_phase_correction_skipped_added": float(skipped_added),
        "movement_phase_correction_siblings": float(sibling_count),
        "movement_phase_correction_stale": float(stale),
        "movement_phase_correction_group_split": float(split),
        "movement_phase_correction_missing": float(missing),
        "movement_phase_correction_beta_moved": float(beta_moved),
        "movement_phase_correction_movements": ",".join(moved_names),
    }
    return out


def apply_dead_phase_beta_zero(cfg, plan_table: Mapping[str, Any] | None = None) -> dict:
    """구조적으로 죽은 현시를 계획 정본에서 판정해 그 movement 의 beta 를 0 으로 돌린다.

    판정은 **계획 정본**으로 한다 — 런 기록(커밋 녹색)으로 하면 순환이다.
    `outputs/signal_group_actuation_plan_v3.json` 의 `axis_green_sec[phase] <= 0` 이 기준이고,
    2026-08-26 에 커밋 녹색 전수 스캔(37결정)과 5/5 일치를 확인했다.

    beta 를 뺀 뒤 같은 origin 의 나머지 movement 에 **재정규화**한다 — 흐름을 버리지 않는다.
    """
    if not _dead_phase_beta_zero_enabled():
        return {"dead_phase_beta_zero_enabled": 0.0}
    src = WORKSPACE_ROOT / "outputs/signal_group_actuation_plan_v3.json"
    if not src.is_file():
        raise SystemExit("DEAD_PHASE_PLAN_MISSING: %s" % src)
    ctrls = _mapping(json.loads(src.read_text(encoding="utf-8")).get("controllers"))
    dead: set = set()
    for sc_no, spec in ctrls.items():
        node = str(_mapping(spec).get("node_id") or "")
        for pid, g in _mapping(_mapping(spec).get("axis_green_sec")).items():
            if node and _as_float(g, 0.0) <= 0.0:
                dead.add("%s_%s" % (node, pid))
    mv = cfg.network.urban_movements
    trapped = [k for k, v in mv.items() if str(_mapping(v).get("phase")) in dead]
    if not trapped:
        return {"dead_phase_beta_zero_enabled": 1.0, "dead_phase_count": float(len(dead)),
                "dead_phase_movements": 0.0}
    removed = 0.0
    for k in trapped:
        removed += max(0.0, _as_float(_mapping(mv[k]).get("beta"), 0.0))
        mv[k]["beta"] = 0.0
    by_origin: dict = {}
    for k, v in mv.items():
        by_origin.setdefault(str(_mapping(v).get("origin") or ""), []).append(k)
    renorm = 0
    for o, ks in by_origin.items():
        if not o:
            continue
        tot = sum(max(0.0, _as_float(_mapping(mv[k]).get("beta"), 0.0)) for k in ks)
        if tot <= 1.0e-9:
            continue
        for k in ks:
            mv[k]["beta"] = max(0.0, _as_float(_mapping(mv[k]).get("beta"), 0.0)) / tot
        renorm += 1
    return {
        "dead_phase_beta_zero_enabled": 1.0,
        "dead_phase_count": float(len(dead)),
        "dead_phase_movements": float(len(trapped)),
        "dead_phase_beta_removed": float(removed),
        "dead_phase_origins_renormalized": float(renorm),
    }


def _boundary_inflow_seed_enabled() -> bool:
    """관측된 경계 접근로 재고를 모델이 **실제로 쓰는 통**에 심을지. 기본 꺼짐.

    config `urban.boundary.inflow_seed` · env `RW_BOUNDARY_INFLOW_SEED`.

    왜. `in_*` 를 urban_link_storage 에 넣어도 모델은 그 키를 **읽지도 쓰지도 않는다** —
    경계 유입은 `urban_inflow_transit_buffer`(전이) 와 `urban_movement_queue`(정지선)로만
    돈다(urban_queue_model.py:1035-1055). 그래서 저류에 심은 질량은 6스텝 내내 정확히
    고정된다(실측 2026-08-27: 556 -> 556, 변화 0). 초기 스냅샷만 맞고 롤아웃 기여가 0 이다.

    나누는 기준은 **실측 정지수**다. 정지차는 정지선에서 녹색을 기다리는 것이므로
    movement 큐(beta 배분), 주행차는 아직 링크를 통과 중이므로 전이 버퍼에 예약한다.
    예약은 step_idx+1 .. step_idx+delay 에 균등 분배한다 — 링크 위에 고르게 퍼져 있다는
    가정이고, 한 substep 에 몰아넣으면 그 순간 큐가 튄다.
    """
    return _switch("boundary_inflow_seed", "RW_BOUNDARY_INFLOW_SEED")


def seed_boundary_inflow(cfg, state, local_summary: Mapping[str, Any] | None) -> dict:
    """`in_*` 관측 재고를 전이버퍼 + movement 큐로 옮기고 죽은 저류는 비운다."""
    if not _boundary_inflow_seed_enabled():
        return {"boundary_inflow_seed_enabled": 0.0}
    from src.models.urban_queue_model import _inflow_delay_steps, _schedule, _urban_step_index
    summary = _mapping(local_summary)
    occ = _mapping(summary.get("urban_link_storage_occupancy"))
    stopped = _mapping(summary.get("urban_link_storage_stopped"))
    by_origin: dict = {}
    for name, spec in _mapping(cfg.network.urban_movements).items():
        o = str(_mapping(spec).get("origin") or "")
        b = max(0.0, _as_float(_mapping(spec).get("beta"), 0.0))
        if o.startswith("in_") and b > 0.0:
            by_origin.setdefault(o, []).append((str(name), b))
    delay = max(1, int(_inflow_delay_steps(cfg)))
    step0 = int(_urban_step_index(state, cfg))
    to_queue = 0.0
    to_buffer = 0.0
    seeded = 0
    for origin, pairs in by_origin.items():
        total = _as_float(occ.get(origin), 0.0)
        if total <= 0.0:
            continue
        stop = min(total, max(0.0, _as_float(stopped.get(origin), 0.0)))
        move = max(0.0, total - stop)
        wsum = sum(b for _, b in pairs) or 1.0
        for mvn, b in pairs:
            if mvn in state.urban_movement_queue:
                state.urban_movement_queue[mvn] += stop * b / wsum
        share = move / float(delay)
        for d in range(1, delay + 1):
            _schedule(state.urban_inflow_transit_buffer, "gate:%s" % origin, step0 + d, share)
        # 죽은 저류는 비운다 — 안 비우면 이중계상이다.
        if origin in cfg.network.urban_link_storage_veh:
            state.urban_link_storage[origin] = float(cfg.network.urban_link_storage_veh[origin])
        to_queue += stop
        to_buffer += move
        seeded += 1
    return {
        "boundary_inflow_seed_enabled": 1.0,
        "boundary_inflow_seed_origins": float(seeded),
        "boundary_inflow_seed_to_queue_veh": float(to_queue),
        "boundary_inflow_seed_to_buffer_veh": float(to_buffer),
        "boundary_inflow_seed_delay_substeps": float(delay),
    }


def _tau_length_cap_enabled() -> bool:
    """tau 의 이동거리를 **저류의 물리 길이**로 상한할지. 기본 꺼짐 = 비트 동일.

    config `urban.tau.length_cap` · env `RW_TAU_LENGTH_CAP`.

    왜. 현행 tau = available(빈 공간) x 6m / speed 는 상한이 없어 빈 링크에서 폭주한다.
    실측 2026-08-26: SC5_to_SC6 는 실제 1.232km / 자유주행 89초인데 모델 tau 가 **740초**
    (8.3배). 전체 합계로도 자유주행 5,536초 대 모델 11,725초(2.1배)다. 그래서 차가
    horizon 안에 정지선에 도착하지 못하고 모델 재고가 6스텝에 +32% 부푼다(실측은 평평).

    개루프 6스텝 롤아웃 실측 (bstoA 기준선, origin 단위 규칙불변 지표):
        상한 없음   스텝1 42.2%  스텝3 64.7%  스텝6 85.9%  총량6 3741
        상한 있음   스텝1 38.1%  스텝3 53.7%  스텝6 69.4%  총량6 3179   (실측 2650)

    차로보정과 **함께** 켜야 한다. 상한만 켜고 차로보정을 끄면 60.9%(스텝3)로 나빠지고,
    둘 다 끄면 스텝6 오차가 102.5% 로 실측 총량을 넘어선다.
    """
    return _switch("tau_length_cap", "RW_TAU_LENGTH_CAP")


def _storage_length_m() -> dict:
    """저류별 물리 길이[m]. `.inpx` 폴리라인 합에서 유도했다.

    정의는 정본 생성기와 같다 — 그 origin 에 매핑된 **모든 링크**(커넥터 포함) 길이의 합.
    `outputs/urban_storage_capacity_core17legs4b_20260819.json` 의 80개를 비 1.0000 으로
    재현해 확인했다.
    """
    if "len" in _GEOM_CACHE:
        return _GEOM_CACHE["len"]
    out: dict = {}
    if STORAGE_GEOMETRY_JSON.is_file():
        try:
            doc = json.loads(STORAGE_GEOMETRY_JSON.read_text(encoding="utf-8"))
            for k, v in _mapping(doc).items():
                m = _as_float(_mapping(v).get("length_m"), 0.0)
                if m > 0.0:
                    out[str(k)] = m
        except Exception:
            out = {}
    _GEOM_CACHE["len"] = out
    return out


def install_tau_length_cap_patch(cfg) -> dict:
    """`_link_delay_steps` 를 두 모듈에 심는다. 꺼져 있으면 아무것도 안 한다.

    **양쪽에 심어야 한다** — `wu_faithful_follower` 가 이름으로 import 해 두어서
    `urban_queue_model` 만 고치면 팔로워는 옛 함수를 계속 쓴다(기존 `_phase_green_fraction`
    5모듈 패치와 같은 이유). 그리고 spawn 워커는 이 패치를 물려받지 못한다 —
    `__setstate__` 되살리기 경로를 타야 한다.
    """
    if not _tau_length_cap_enabled():
        return {"tau_length_cap_enabled": 0.0}
    import math as _math
    import src.models.urban_queue_model as _uqm
    import src.controllers.wu_faithful_follower as _wff
    from src.models.urban_queue_model import OBSERVED_SPEED_DELAY_CAP_RATIO as _RATIO
    lengths = _storage_length_m()
    if not lengths:
        raise SystemExit("TAU_LENGTH_CAP_NO_GEOMETRY: %s 를 못 읽었다" % STORAGE_GEOMETRY_JSON)
    if not hasattr(_uqm, "_rw_orig_link_delay_steps"):
        _uqm._rw_orig_link_delay_steps = _uqm._link_delay_steps

    def _capped(state, c, storage_link):
        net = c.network
        capacity = net.urban_link_storage_veh.get(storage_link, net.boundary_queue_max_veh)
        available = max(0.0, state.urban_link_storage.get(storage_link, capacity))
        dist_m = available * net.urban_avg_vehicle_length_m
        phys = lengths.get(str(storage_link))
        if phys is not None:
            dist_m = min(dist_m, float(phys))
        nominal = max(net.urban_avg_speed_km_h, 1.0e-9)
        obs = state.urban_link_speed_kph.get(storage_link)
        speed = nominal if obs is None else max(float(obs), nominal / _RATIO)
        travel_h = (dist_m / 1000.0) / speed
        return max(1, int(_math.ceil(travel_h / max(c.simulation.T_u_h, 1.0e-9))))

    _uqm._link_delay_steps = _capped
    _wff._link_delay_steps = _capped
    covered = sum(1 for k in cfg.network.urban_link_storage_veh if str(k) in lengths)
    return {
        "tau_length_cap_enabled": 1.0,
        "tau_length_cap_storages": float(len(lengths)),
        "tau_length_cap_covered": float(covered),
        "tau_length_cap_uncovered": float(len(cfg.network.urban_link_storage_veh) - covered),
    }


def _queue_origin_binding_enabled() -> bool:
    """movement 매핑이 없는 링크의 실측 정지분을 origin+beta 로 큐에 배정할지.

    기본 꺼짐 = 비트 동일. config `urban.queue.origin_binding` · env `RW_QUEUE_ORIGIN_BINDING`.

    현행은 `link_to_movements` 항목이 없으면 storage_fraction 을 1.0 으로 강제해
    **실측 정지대수를 버린다** (2026-08-26 실측 557대/결정 = 모델 큐 990대의 56%).
    그 링크는 대부분 `_to_` 구간이고 그 위 정지차는 하류 교차로 정지선 대기행렬이다.
    저류로 보내면 tau 만큼 늦게 도착해 녹색 배분이 밀린다.
    """
    return _switch("queue_origin_binding", "RW_QUEUE_ORIGIN_BINDING")


def _midblock_stopline_links() -> set:
    """미드블록 신호두가 달린 정지선 링크. 그 위 정지차는 큐가 아니라 저류다.

    모델에 미드블록이 없다(신호 26·현시 68·링크 길이/용량 개념 없음). 미드블록 적색차를
    정지선 큐로 넣으면 컨트롤러가 하류 교차로 녹색으로 뺄 수 있다고 오인한다.
    실측 2026-08-26 오염률: SC7 55% · SC5 36% · SC101 28%.
    """
    if "d" in _MIDBLOCK_CACHE:
        return _MIDBLOCK_CACHE["d"]
    src = WORKSPACE_ROOT / "outputs/midblock_stopline_links_20260822.json"
    out: set = set()
    if src.is_file():
        try:
            out = {str(k) for k in (_mapping(json.loads(src.read_text(encoding="utf-8")).get("links")) or {})}
        except Exception:
            out = set()
    _MIDBLOCK_CACHE["d"] = out
    return out


def _movements_by_origin(cfg) -> dict:
    """origin(상류 저류) -> [(movement, beta)]. beta 는 .inpx 정적경로 정본."""
    cache = getattr(cfg, "_rw_mv_by_origin", None)
    if cache is not None:
        return cache
    idx: dict = {}
    for name, spec in _mapping(cfg.network.urban_movements).items():
        if not isinstance(spec, Mapping):
            continue
        o = str(spec.get("origin") or "")
        b = max(0.0, _as_float(spec.get("beta"), 0.0))
        if o and b > 0.0:
            idx.setdefault(o, []).append((str(name), b))
    try:
        setattr(cfg, "_rw_mv_by_origin", idx)
    except Exception:
        pass
    return idx


def _queue_origin_filter_enabled() -> bool:
    """movement 큐를 그 링크의 저류에서 출발하는 것으로 좁힐지. 기본 꺼짐."""
    return _switch("queue_origin_filter", "RW_QUEUE_ORIGIN_FILTER")


def _lane_delay_correction_enabled() -> bool:
    """저류 통과지연을 차로수로 나눌지. 기본 꺼짐.

    2026-08-27 수정. 이 함수가 `_CFG_SWITCHES` 를 보지 않고 env 만 직독해서,
    config 로 **끌 수가 없었다** — `urban.tau.lane_delay_correction: false` 를 적어도
    같은 셸에 RW_LANE_DELAY_CORRECTION 이 남아 있으면 켜진 채로 돌았다. 그래서
    2026-08-26 에 A/B 두 팔이 비트 동일해진 사고가 났다. `_switch` 는 config 가 값을
    정했으면 그것을 쓰고, 없을 때만 env 로 폴백한다.
    """
    return _switch("lane_delay", "RW_LANE_DELAY_CORRECTION")


_STORAGE_LANES_CACHE: dict[str, float] | None = None


def _storage_effective_lanes() -> dict[str, float]:
    """저류별 **길이가중 평균 차로수** = 용량 / (길이 × jam).

    용량이 `길이 × 차로 × jam` 으로 지어졌으므로 이 나눗셈은 항등식이고 측정이 아니다.
    저류가 여러 링크를 묶으면 정수로 안 떨어진다(중앙 2.69, 범위 1.00~8.37) - 대수를
    종방향 거리로 되돌리는 데 필요한 제수는 바로 이 길이가중 평균이라 그대로 쓴다.
    길이 근거가 없는 램프 저류 4개는 1.0(보정 없음)으로 남는다.
    """
    global _STORAGE_LANES_CACHE
    if _STORAGE_LANES_CACHE is not None:
        return _STORAGE_LANES_CACHE
    lanes: dict[str, float] = {}
    evidence = load_optional_json(str(STORAGE_CAPACITY_EVIDENCE_JSON))
    jam = _as_float(evidence.get("jam_density_veh_km_lane", 0.0))
    capacity = evidence.get("urban_link_storage_veh") or {}
    length_km = evidence.get("urban_link_length_km") or {}
    if jam > 0.0 and isinstance(capacity, Mapping) and isinstance(length_km, Mapping):
        for link, veh in capacity.items():
            km = _as_float(length_km.get(link, 0.0))
            if km > 0.0:
                lanes[str(link)] = max(1.0, _as_float(veh) / (km * jam))
    # 2026-09-04. 증거파일에 길이가 없는 저류 121/226 중 **75개가 실제 개포 링크**이고
    # 저류 점유의 58.29%(934.82 veh/결정)를 든다. 그 저류들은 차로 보정을 못 받아 tau 가
    # 차로수배(보정된 저류 중앙 3.00)만큼 과대해진다. `.fzp` 실측으로 결손만 채운다 —
    # 이미 값이 있는 저류는 손대지 않으므로 그 105개는 비트 동일이다.
    #
    # 유도식은 docstring 이 요구하는 그대로다:
    #     effective_lanes = sum_i(len_i * lanes_i) / sum_i(len_i)   over link_to_origins 구성원
    # len_i = 링크 max Pos, lanes_i = 링크 max Lane index.
    # 교차검증(겹치는 66개): |차이| 중앙 0.158 차로, 상대오차 중앙 5.8% / p90 20.7%.
    if _switch("storage_lanes_fzp", "RW_STORAGE_LANES_FZP"):
        derived = load_optional_json(str(STORAGE_LANES_FZP_JSON))
        table = derived.get("storage_effective_lanes") if isinstance(derived, Mapping) else None
        if isinstance(table, Mapping):
            for link, value in table.items():
                key = str(link)
                if lanes.get(key, 1.0) > 1.0:
                    continue          # 기존 근거가 이긴다
                got = _as_float(value, 0.0)
                if got > 1.0:
                    lanes[key] = got
    _STORAGE_LANES_CACHE = lanes
    return lanes


def _apply_lane_delay_correction(state, cfg, local_summary: dict) -> None:
    """저류 통과지연의 **차원 오류**를 링크별 속도 통로로 정확히 상쇄한다.

    plant 의 `_link_delay_steps` 는 큐 꼬리까지의 거리를
        distance_km = available[veh] × urban_avg_vehicle_length_m / 1000
    로 잡는데, `available` 은 **전 차로 합계 대수**다. 3차로 링크의 여유 300대는 종방향
    600 m 인데 산식은 1,800 m 로 본다. 실측 배수는 정확히 차로수(중앙 2.69, p90 4.04)라
    통과시간이 그만큼 길어지고, 중앙 지연이 MPC 지평(3스텝)을 넘겨 저류가 사실상 얼어붙는다.

    vendor 는 수정 금지라 거리는 못 건드린다. 대신 `urban_link_speed_kph` 가 이 산식
    **한 곳에서만** 쓰이므로(vendor/.../urban_queue_model.py:624) 속도에 차로수를 곱하면
    distance/speed 가 정확히 같은 값이 된다 - 근사가 아니라 항등이다. 그래서 이 필드는
    보정이 켜진 동안 "관측 속도"가 아니라 **유효 속도**를 담는다.

    하한(`OBSERVED_SPEED_DELAY_CAP_RATIO`)이 주입 뒤에 `max()` 로 걸리므로 하한을 여기서
    먼저 적용한 뒤 차로수를 곱한다. 그러면 vendor 의 `max()` 가 무해해지고 의도한 지연
    상한이 차로보정된 거리에 그대로 적용된다.
    """
    if not _lane_delay_correction_enabled():
        # 꺼짐도 **양성으로** 기록한다. 키가 없으면 "꺼져 있었다"와 "환경변수가 어댑터까지
        # 안 왔다"가 구별되지 않고, A/B 에서 ΔJ≈0 이 나왔을 때 그 둘을 사후에 가를 방법이
        # 없다. arm 이 실제로 무엇이었는지는 발사 의도가 아니라 디스크가 말해야 한다.
        local_summary["lane_delay_correction"] = {"enabled": False, "links_corrected": 0}
        return
    from src.models.urban_queue_model import OBSERVED_SPEED_DELAY_CAP_RATIO

    lanes_table = _storage_effective_lanes()
    nominal = max(_as_float(getattr(cfg.network, "urban_avg_speed_km_h", 50.0)), 1.0e-9)
    floor = nominal / max(float(OBSERVED_SPEED_DELAY_CAP_RATIO), 1.0e-9)
    applied = 0
    lane_weighted = 0.0
    for link in cfg.network.urban_link_storage_veh:
        key = str(link)
        lanes = lanes_table.get(key, 1.0)
        if lanes <= 1.0:
            continue
        observed = state.urban_link_speed_kph.get(key)
        base = max(_as_float(observed), floor) if observed is not None else nominal
        state.urban_link_speed_kph[key] = lanes * base
        applied += 1
        lane_weighted += lanes
    local_summary["lane_delay_correction"] = {
        "enabled": True,
        "links_corrected": applied,
        "links_without_length_evidence": sum(
            1 for link in cfg.network.urban_link_storage_veh if str(link) not in lanes_table
        ),
        "mean_lanes_applied": (lane_weighted / applied) if applied else 0.0,
        "evidence": STORAGE_CAPACITY_EVIDENCE_JSON.name,
    }


def _movement_origin(cfg, movement: str) -> str:
    spec = cfg.network.urban_movements.get(movement)
    if isinstance(spec, Mapping):
        return str(spec.get("origin", ""))
    return str(getattr(spec, "origin", "") or "")


def _observed_stopped_counts(state_json: Mapping[str, Any]) -> dict[str, float]:
    """큐 관측을 순간 표본에서 **직전 제어구간 창 집계**로 바꾼다(RW_QUEUE_WINDOW).

    왜. 제어주기 150 s 가 신호주기 150 s 와 같아 결정 시점이 항상 신호 위상의 같은
    지점에 떨어진다 — 무작위 잡음이 아니라 계통 편향이다. 실측(SC1, 무제어 고정계획):

        접근  결정시점  창평균  창최대
        N      15.3     11.0    27.7     (+39%)
        E       0.1      3.3    12.8     (-97%)
        W       0.1      1.4     5.2     (-93%)

    결정 시점이 동서 녹색 직후라 동서가 늘 빈 것으로 읽힌다. 리더가 쓰는 건 현시 간
    **상대** 큐라 이 편향이 그대로 배분 왜곡이 된다(남북:동서 = 99.3:0.7 -> 84:16).

    러너가 5초 스캔을 이미 돌리므로 창 집계에 COM 왕복이 안 붙는다. 필드가 없으면
    (스위치 꺼짐·구 상태 JSON) 순간값으로 폴백해 **비트 동일**하다.
    """
    # 기본은 꺼짐. `link_counts` 쪽과 같은 스위치를 써서 둘이 어긋나지 않게 한다 —
    # 하나만 창값이면 저류/큐 분할 비율이 뒤틀린다.
    # 2026-09-05. 1129 행과 같은 config 키를 읽는다 — 종전엔 여기만 env 를 읽어 둘이 어긋날 수 있었다.
    mode = str(_CFG_STRINGS.get("queue_window_stat", "")).strip().lower()
    if mode in {"mean", "max"}:
        key = f"link_stopped_counts_window_{mode}"
        windowed = _link_metric_from_local_observation(state_json, key)
        if windowed:
            samples = _as_float(
                _mapping(state_json.get("local_observation")).get("queue_window_samples"), 0.0
            )
            if samples >= 1.0:
                return windowed
    return _link_metric_from_local_observation(state_json, "link_stopped_counts")



def _ramp_queue_shares(ramps) -> list[tuple[str, float]]:
    """`ramp_link_to_queues` 의 값을 (램프, 가중치) 목록으로 편다.

    두 형식을 받는다:
      list  ["R_D_E", "R_D_W"]              -> 균등 (기존 동작 그대로, 비트 동일)
      dict  {"R_D_E": 0.25, "R_D_W": 0.75}  -> 가중

    ## 왜 dict 가 필요한가 (2026-08-26)

    기존 8개 항목은 전부 **단일 램프**라 균등 분배가 문제가 안 됐다. link 78·31 이 처음으로
    두 램프에 걸린다 — `78 -10703-> 31` 이고 31 의 정적 경로결정(inpx no=1137)이

        dest 24  relFlow 1.0  -> 10484 -> R_D_E -> FW_E   0.25
        dest 31  relFlow 1.0  -> 10480 -> R_D_W -> FW_W   0.25
        dest 26  relFlow 2.0  -> 10480 -> R_D_W -> FW_W   0.50

    즉 **FW_E 25% · FW_W 75%** 다. 균등(50/50)으로 두면 31.9 veh 중 약 8 veh 가 반대쪽
    램프로 들어가고, 나중에 "왜 FW_E 가 과다한가" 를 다시 파게 된다.

    가중치 합이 0 이면 균등으로 떨어진다 — 조용히 0 을 배분하지 않는다.
    """
    if isinstance(ramps, Mapping):
        pairs = [(str(k), max(0.0, _as_float(v, 0.0))) for k, v in ramps.items()]
        total = sum(w for _, w in pairs)
        if total > 0.0:
            return [(k, w / total) for k, w in pairs if w > 0.0]
        return [(k, 1.0 / len(pairs)) for k, _ in pairs] if pairs else []
    if isinstance(ramps, list) and ramps:
        return [(str(r), 1.0 / len(ramps)) for r in ramps]
    return []

# ─────────────────────────────────────────────────────────────────────────────
# TAU-MOVING (2026-08-25): 링크 관측속도에서 **정지 차량을 뺀다**.
#
# 왜.  러너의 링크속도는 `speedSum / count` 인데(run_real_world_stackelberg_controller.vbs:3131)
#      `count` 가 링크 위 **전 차량**이다. 정지차는 분자에 ~0(정지 임계 1.0 km/h)을 보태고
#      분모에 1 을 보태 평균을 끌어내린다.
#
#      그런데 이 속도가 쓰이는 유일한 곳이 `_link_delay_steps`(urban_queue_model.py:631)이고,
#      그 함수의 거리는 `available`(= 링크 **여유공간**, 큐가 이미 빠진 값)이다.
#      즉 τ 는 "링크 진입 -> 큐 꼬리 도달" 시간이고 그 구간을 지나는 건 **움직이는 차량**이다.
#      거리에서는 큐를 뺐는데 속도에서는 안 뺐다 — 한쪽만 센 것이다.
#
# 실측(default_20260825 t=002250):
#      관측 3,340대 중 정지 1,483대(44%) · 링크당 정지비율 중앙 33%
#      속도 배수 중앙 1.00 · 평균 3.29 · p90 7.50 (최대 40배)
#      20 km/h 하한 잘림 32% -> 11%
#      **플래툰 도착 위상(τ mod 150s) 중앙 37.5 s 이동 = 주기의 25%**
#
# 정지차 속도를 0 으로 보는 근사의 오차는 임계값 상한이다(1.0 km/h × 정지대수 / 이동대수).
# 표본이 전부 정지면 보정을 포기한다(이동대수 0.5 미만) — 무한대를 만들지 않는다.
def _moving_speed_enabled() -> bool:
    """링크 관측속도를 **이동차량 기준**으로 볼지. 기본 꺼짐 = 비트 동일.

    config `urban.tau.moving_only`, 폴백 env `RW_MOVING_SPEED`.
    """
    return _switch("moving_speed", "RW_MOVING_SPEED")


def _moving_only_link_speeds(
    state_json: Mapping[str, Any], link_speeds_kph: Mapping[str, float]
) -> tuple[dict[str, float], dict[str, float]]:
    """`speedSum/count` 를 `speedSum/(count - stopped)` 로 환산한다.

    count·stopped 는 속도와 **같은 출처**(원 `local_observation`, 창 집계 아님)에서 읽는다 —
    속도가 순간값이라 창 평균 대수와 섞으면 비율이 어긋난다.
    """
    local = _mapping(state_json.get("local_observation"))
    counts = _mapping(local.get("link_counts"))
    stopped = _mapping(local.get("link_stopped_counts"))
    out: dict[str, float] = {}
    diag = {"links": 0.0, "adjusted": 0.0, "all_stopped": 0.0, "ratio_sum": 0.0}
    for link, speed in link_speeds_kph.items():
        key = str(link)
        out[key] = float(speed)
        diag["links"] += 1.0
        count = _as_float(counts.get(key), 0.0)
        stop = _as_float(stopped.get(key), 0.0)
        if count <= 0.0:
            continue
        moving = count - stop
        if moving < 0.5:
            # 전 차량이 정지면 이동차 표본이 없다. 원값을 그대로 두고 vendor 하한에 맡긴다.
            diag["all_stopped"] += 1.0
            continue
        ratio = count / moving
        if ratio <= 1.0 + 1.0e-9:
            continue
        out[key] = float(speed) * ratio
        diag["adjusted"] += 1.0
        diag["ratio_sum"] += ratio
    diag["mean_ratio"] = diag["ratio_sum"] / diag["adjusted"] if diag["adjusted"] else 0.0
    return out, diag

def build_local_observation_summary(
    state_json: Mapping[str, Any],
    cfg,
    detector_mapping: Mapping[str, Any],
    calibration: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Convert Vissim detector/local-zone counts into model-local queues.

    The Vissim runner may still use a fast whole-vehicle scan internally, but
    once the counts enter this function they are reduced through the detector
    mapping. Follower-visible state is therefore link/movement/agent scoped
    instead of aggregate global counts.
    """
    link_counts = _link_counts_from_local_observation(state_json)
    if not link_counts:
        return {}

    link_speeds_kph = _link_metric_from_local_observation(state_json, "link_speeds_kph")
    _moving_speed_diag: dict[str, float] = {"enabled": 0.0}
    if _moving_speed_enabled():
        link_speeds_kph, _moving_speed_diag = _moving_only_link_speeds(state_json, link_speeds_kph)
        _moving_speed_diag["enabled"] = 1.0
    link_stopped_counts = _observed_stopped_counts(state_json)
    link_queue_tail_pos_m = _link_metric_from_local_observation(state_json, "link_queue_tail_pos_m")
    split_parameters = _observation_split_parameters(calibration)
    partition = _mapping(detector_mapping.get("link_partition"))
    exit_links = {str(value) for value in partition.get("monitor_only_exit_links", [])}
    freeway_bound_links = {str(value) for value in partition.get("freeway_bound_links", [])}
    freeway_links = {
        str(link) for link in _mapping(detector_mapping.get("freeway_link_to_model_link"))
    }
    ramp_links = {str(link) for link in _mapping(detector_mapping.get("ramp_link_to_queues"))}
    storage_fraction_by_link: dict[str, float] = {}
    # 3단 폴백 재료 (2026-09-04). 러너가 `queue_bins` 를 안 실으면 contiguous_queue 가
    # 빈 dict 라 아래 루프가 그대로 stopped 층으로 떨어진다 = 비트 동일.
    queue_definition_mode = "contiguous" if _contiguous_queue_enabled() else "stopped"
    contiguous_queue = _contiguous_stopline_queue(state_json) if queue_definition_mode == "contiguous" else {}
    queue_source_by_link: dict[str, str] = {}
    queue_count_by_link: dict[str, float] = {}
    storage_count_by_link: dict[str, float] = {}
    _origin_bind_links: set = set()
    storage_assigned_by_link: dict[str, float] = {}
    dedicated_branch_links = set(_mapping(detector_mapping.get("physical_storage_projection")).get("link_to_storage", {}))
    transit_storage_links = set(_mapping(detector_mapping.get("transit_storage_projection")))
    physical_stock_assignment: dict[str, dict[str, float]] = {}
    urban_link_storage_occupancy = {link: 0.0 for link in cfg.network.urban_link_storage_veh}
    # 저류별 **정지 대수**. 투영이 release 버퍼를 복원할 때 "이미 정지선에 도착한 몫" 과
    # "아직 이동 중인 몫" 을 가르는 근거다(traffic_state_from_vissim 의 버퍼 복원 참조).
    # 관측에서 나오므로 추정이 아니다.
    urban_link_storage_stopped = {link: 0.0 for link in cfg.network.urban_link_storage_veh}
    storage_requested_veh = 0.0
    storage_assigned_veh = 0.0
    storage_capacity_clipped_veh = 0.0
    # 관측 링크속도를 모델 storage 링크 키로 접기 위한 대수 가중 누산기(v3 N3-1b).
    speed_weight_by_storage: dict[str, float] = {}
    speed_moment_by_storage: dict[str, float] = {}
    # 링크별 저류 목록. 아래 movement 큐 분배가 "그 링크의 저류에서 출발하는 movement"
    # 로 좁힐 때 쓴다(RW_QUEUE_ORIGIN_FILTER).
    storage_links_by_link: dict[str, list[str]] = {}
    for link, count in link_counts.items():
        if link in freeway_links or link in ramp_links or link in exit_links:
            storage_fraction_by_link[str(link)] = 0.0
            storage_count_by_link[str(link)] = 0.0
            queue_count_by_link[str(link)] = 0.0
            storage_assigned_by_link[str(link)] = 0.0
            continue
        origins = [
            str(value)
            for value in detector_mapping.get("link_to_origins", {}).get(str(link), [])
        ]
        storage_fraction = _link_storage_split_fraction(cfg, origins, split_parameters)
        # 3단 폴백 (2026-09-04): contiguous -> stopped(현행) -> 상수.
        # 링크별로 어느 층이 발동했는지 진단에 남긴다 — 혼합 추정량은 신호마다 편의가
        # 달라지므로 사후에 반드시 확인할 수 있어야 한다.
        _src = "constant"
        if queue_definition_mode == "contiguous":
            _q = contiguous_queue.get(str(link))
            if _q is not None and float(count) > 0.0:
                storage_fraction = max(0.0, 1.0 - min(float(_q), float(count)) / float(count))
                _src = "contiguous"
        if _src == "constant" and _stopped_split_enabled():
            storage_fraction = _stopped_storage_fraction(
                str(link), float(count), link_stopped_counts, storage_fraction
            )
            if str(link) in link_stopped_counts:
                _src = "stopped_instant"
        queue_source_by_link[str(link)] = _src
        # movement 매핑이 없는 링크는 queue_count 가 갈 데가 없어 그냥 증발한다.
        # 아래 link_to_movements 루프가 그 링크를 아예 안 도는 탓이다.
        # 실측 2026-08-05: 관측된 배정 링크 952개 중 **882개**가 매핑이 없어
        # 1,415 대의 queue 분이 사라졌다(도시부 포착률이 50.7% 에서 안 올라간 원인).
        # 그 882개는 신호두 링크가 아니라 링크 본체다 — 정지선 대기행렬이 아니라
        # 링크 저류가 물리적으로 맞으므로 전량 저류로 보낸다.
        if str(link) in dedicated_branch_links or str(link) in transit_storage_links:
            storage_fraction = 1.0
            queue_source_by_link[str(link)] = "physical_branch"
        elif not (detector_mapping.get("link_to_movements", {}) or {}).get(str(link)):
            # 2026-08-26. 켜면 **어느 정지선에 서 있느냐**로 통을 정한다.
            #   미드블록 신호두 링크 -> 전량 저류 (아직 링크 안이다)
            #   그 외             -> origin+beta 로 큐 배정 (아래 두 번째 루프)
            # 해결 가능성을 여기서 판정한다 — 저류 배정이 이 루프 안에서 끝나므로
            # 나중에 되돌리면 늦다.
            _bound = False
            if _queue_origin_binding_enabled() and str(link) not in _midblock_stopline_links():
                _idx = _movements_by_origin(cfg)
                # 후보 키는 저류링크 **와 origin 이름 자체**다. `in_*` 경계 origin 은
                # 저류가 아니라 경계 큐라 _storage_links_for_observed_origin 이 빈 값을
                # 낸다 — 그런데 movement 의 origin 에는 in_* 가 39개 있다(실측 2026-08-26,
                # 그 누락으로 302대/결정이 조용히 저류로 떨어졌다).
                for _o in origins:
                    _keys = list(_storage_links_for_observed_origin(cfg, _o)) + [str(_o)]
                    if any(_idx.get(str(_k)) for _k in _keys):
                        _bound = True
                        break
            if _bound:
                _origin_bind_links.add(str(link))
            else:
                storage_fraction = 1.0
        storage_fraction_by_link[str(link)] = float(storage_fraction)
        storage_count = max(0.0, count * storage_fraction)
        queue_count = max(0.0, count - storage_count)
        storage_count_by_link[str(link)] = float(storage_count)
        queue_count_by_link[str(link)] = float(queue_count)
        storage_links: list[str] = []
        for origin in origins:
            for storage_link in _storage_links_for_observed_origin(cfg, origin):
                if storage_link not in storage_links:
                    storage_links.append(storage_link)
        storage_links_by_link[str(link)] = list(storage_links)
        # 관측 속도는 **표본이 있는 링크만** 기여한다(v3 N3-1b). VBS 의 링크속도는
        # `speed_sum / count` 라 표본이 없으면 0 인데, 그 0 은 "정지" 가 아니라
        # "관측 없음" 이다. count=0 이거나 속도 키 자체가 없으면 건너뛴다.
        if count > 0.0 and str(link) in link_speeds_kph and storage_links:
            observed_kph = float(link_speeds_kph[str(link)])
            for storage_link in storage_links:
                speed_weight_by_storage[storage_link] = (
                    speed_weight_by_storage.get(storage_link, 0.0) + float(count)
                )
                speed_moment_by_storage[storage_link] = (
                    speed_moment_by_storage.get(storage_link, 0.0)
                    + float(count) * observed_kph
                )
        storage_requested_veh += storage_count
        storage_assigned_by_link[str(link)] = 0.0
        if storage_count > 0.0 and storage_links:
            share = storage_count / len(storage_links)
            for storage_link in storage_links:
                capacity = float(cfg.network.urban_link_storage_veh.get(storage_link, 0.0))
                current = urban_link_storage_occupancy.get(storage_link, 0.0)
                assigned = max(0.0, min(share, capacity - current))
                urban_link_storage_occupancy[storage_link] = current + assigned
                storage_assigned_by_link[str(link)] += assigned
                storage_assigned_veh += assigned
                if dedicated_branch_links:
                    observation_projection.record_projection_assignment(physical_stock_assignment, link, "storage:" + storage_link, assigned)
                storage_capacity_clipped_veh += max(0.0, share - assigned)
                # 배정된 몫 중 정지 비율만큼을 정지 대수로 같이 옮긴다.
                if count > 0.0 and assigned > 0.0:
                    stopped_share = min(1.0, max(0.0, float(link_stopped_counts.get(str(link), 0.0)) / count))
                    urban_link_storage_stopped[storage_link] = (
                        urban_link_storage_stopped.get(storage_link, 0.0) + assigned * stopped_share
                    )

    movement_queue = {movement: 0.0 for movement in cfg.network.urban_movements}
    movement_assigned_by_link: dict[str, float] = {}
    for link, entries in detector_mapping.get("link_to_movements", {}).items():
        count = queue_count_by_link.get(str(link), link_counts.get(str(link), 0.0))
        if count <= 0.0 or not isinstance(entries, list):
            continue
        movement_assigned_by_link[str(link)] = 0.0
        # 배정 대상만 먼저 추린다. 두 가지를 고친다(둘 다 RW_QUEUE_ORIGIN_FILTER 로 켠다).
        #
        # (a) **링크와 무관한 movement 로 흩뿌리지 않는다.** detector_mapping 의
        #     link_to_movements 는 링크별이 아니라 **교차로별**이다 - SC1 의 네 접근 링크가
        #     전부 SC1 의 movement 전체를 받는다. 그래서 SC15 쪽 접근에 선 차가 SC107 /
        #     SC9001 / SC11 쪽 큐로도 나뉜다. 62개 링크가 이 상태이고 분수 귀속으로
        #     설명되는 것은 2개뿐이다. 접근 링크에 선 차는 **그 링크의 저류에서 출발하는**
        #     movement 의 큐다 - origin 으로 좁힌다.
        #
        # (b) **건너뛴 movement 몫이 증발하지 않게 한다.** 옛 코드는 weight_sum 을 전체
        #     entries 로 잡고 `movement not in movement_queue` 인 것을 건너뛰어서, 배정
        #     총합이 count 에 못 미쳤다. 모델에 없는 off-ramp movement 를 가리키는 링크가
        #     8개 있고(D_offW_to_N 등) 그만큼 질량이 사라진다(관측의 0.57%).
        usable = [
            item
            for item in entries
            if isinstance(item, Mapping) and str(item.get("movement", "")) in movement_queue
        ]
        if _queue_origin_filter_enabled():
            allowed = set(storage_links_by_link.get(str(link)) or [])
            if allowed:
                scoped = [
                    item
                    for item in usable
                    if str(_movement_origin(cfg, str(item.get("movement", "")))) in allowed
                ]
                # origin 이 하나도 안 맞으면 좁히지 않는다 - 질량을 버리는 것보다 낫다.
                if scoped:
                    usable = scoped
        # β 귀속(2026-09-06): 같은 origin(접근로) 안에서는 β 로, origin 이 여럿이면 origin 별 weight 합 × 그 안의 β 분율.
        _attr_beta = str(_CFG_STRINGS.get("queue_attribution", "")).strip().lower() == "beta"
        if _attr_beta and usable:
            _specs_q = cfg.network.urban_movements or {}
            _w_origin: dict[str, float] = {}
            _b_origin: dict[str, float] = {}
            for item in usable:
                _m = str(item.get("movement", "")); _o = str(_mapping(_specs_q.get(_m)).get("origin", ""))
                _w_origin[_o] = _w_origin.get(_o, 0.0) + max(0.0, _as_float(item.get("weight", 1.0)))
                _b_origin[_o] = _b_origin.get(_o, 0.0) + max(0.0, _as_float(_mapping(_specs_q.get(_m)).get("beta"), 0.0))
            def _weight_of(item) -> float:
                _m = str(item.get("movement", "")); _o = str(_mapping(_specs_q.get(_m)).get("origin", ""))
                _b = max(0.0, _as_float(_mapping(_specs_q.get(_m)).get("beta"), 0.0))
                if _b_origin.get(_o, 0.0) <= 1.0e-9:
                    return max(0.0, _as_float(item.get("weight", 1.0)))
                return _w_origin.get(_o, 0.0) * _b / _b_origin[_o]
        else:
            def _weight_of(item) -> float:
                return max(0.0, _as_float(item.get("weight", 1.0)))
        weight_sum = sum(_weight_of(item) for item in usable)
        if weight_sum <= 1.0e-9:
            weight_sum = float(len(usable)) if usable else 1.0
        for item in usable:
            movement = str(item.get("movement", ""))
            weight = _weight_of(item)
            assigned = count * weight / weight_sum
            movement_queue[movement] += assigned
            movement_assigned_by_link[str(link)] += assigned
            if dedicated_branch_links:
                observation_projection.record_projection_assignment(physical_stock_assignment, link, "movement:" + movement, assigned)

    # link_to_movements 에 없는 링크의 큐 몫을 origin+beta 로 배정한다.
    # 위 루프는 그 표를 순회하므로 표에 없는 링크는 아예 안 돈다.
    origin_bound_veh = 0.0
    origin_bound_links = 0
    origin_bound_unresolved_veh = 0.0
    if _queue_origin_binding_enabled():
        _idx = _movements_by_origin(cfg)
        for link in _origin_bind_links:
            if str(link) in transit_storage_links:
                continue
            qc = float(queue_count_by_link.get(str(link), 0.0))
            if qc <= 0.0:
                continue
            pairs: list = []
            _keys = list(storage_links_by_link.get(str(link)) or [])
            _keys += [str(o) for o in (detector_mapping.get("link_to_origins", {}).get(str(link)) or [])]
            _seen: set = set()
            for _k in _keys:
                if _k in _seen:
                    continue
                _seen.add(_k)
                pairs.extend(_idx.get(str(_k), []))
            wsum = sum(b for _, b in pairs)
            if wsum <= 1.0e-9:
                origin_bound_unresolved_veh += qc
                continue
            for movement, beta in pairs:
                if movement in movement_queue:
                    movement_queue[movement] += qc * beta / wsum
                    if dedicated_branch_links:
                        observation_projection.record_projection_assignment(physical_stock_assignment, link, "movement:" + movement, qc * beta / wsum)
            origin_bound_veh += qc
            origin_bound_links += 1

    ramp_queue = {ramp: 0.0 for ramp in cfg.network.ramps}
    for link, ramps in detector_mapping.get("ramp_link_to_queues", {}).items():
        count = link_counts.get(str(link), 0.0)
        if count <= 0.0:
            continue
        for ramp_key, weight in _ramp_queue_shares(ramps):
            if ramp_key in ramp_queue:
                ramp_queue[ramp_key] += count * weight
                if dedicated_branch_links:
                    observation_projection.record_projection_assignment(physical_stock_assignment, link, "ramp:" + ramp_key, count * weight)

    # 2026-09-07 램프 스필백 관측: 커넥터 상류 전용 검지 링크(ramp_spillback_links)의 정지 차량을 저수지 큐에 더한다.
    #   램프행은 lnChgDist 1000 으로 커넥터 1 km 상류부터 L1 에 붙어 서므로 정지·큐 차로(queue_lanes)·conn_pos_m 이하로 판정.
    #   링크 전체 재차를 넣지 않는다(09-03 rampconn 과대 사고). 스위치 urban.ramp.spillback_obs (없으면 비트 동일).
    ramp_spillback: dict[str, float] = {}
    if bool(getattr(cfg.network, "ramp_spillback_obs", False)):
        _spill_spec = _mapping(detector_mapping.get("ramp_spillback_links"))
        _recs = _mapping(state_json.get("vehicle_records")).get("records") or []
        _by_link: dict[str, list] = {}
        for _r in _recs:
            if isinstance(_r, Mapping):
                _by_link.setdefault(str(_r.get("link_no")), []).append(_r)
        for _ramp_key, _entries in _spill_spec.items():
            if _ramp_key not in ramp_queue or not isinstance(_entries, list):
                continue
            _spill = 0.0
            for _e in _entries:
                _e = _mapping(_e)
                _link = str(_e.get("link", ""))
                _lanes = {int(x) for x in (_e.get("queue_lanes") or [])}
                _pos_max = _as_float(_e.get("conn_pos_m"), -1.0)
                if _recs:
                    _rows = _by_link.get(_link) or []
                    _spill += float(sum(1 for _r in _rows if bool(_r.get("stopped"))
                                        and (not _lanes or int(_as_float(_r.get("lane_no"), 0)) in _lanes)
                                        and (_pos_max < 0.0 or _as_float(_r.get("position_m"), 0.0) <= _pos_max)))
                else:
                    _st = float(link_stopped_counts.get(_link, 0.0))
                    _nl = max(1, int(_as_float(_e.get("lanes"), 1)))
                    _spill += _st * ((len(_lanes) / _nl) if _lanes else 1.0)
            ramp_spillback[_ramp_key] = float(_spill)
            # The approach stock already remains in urban storage/queues.
            # Keep spillback as a guard observation, not a second physical stock.
            if not dedicated_branch_links:
                ramp_queue[_ramp_key] += float(_spill)

    # Legacy boundary_queue is kept for diagnostics/compatibility. The actual
    # urban signal queues above are the follower-visible queue state.
    boundary_queue: dict[str, float] = {}
    for link, key in detector_mapping.get("boundary_link_to_queue", {}).items():
        qkey = str(key)
        boundary_queue[qkey] = boundary_queue.get(qkey, 0.0) + link_counts.get(str(link), 0.0)

    agents: dict[str, Any] = {}
    for agent_id, spec in detector_mapping.get("agents", {}).items():
        if not isinstance(spec, Mapping):
            continue
        visible_links = [str(v) for v in spec.get("visible_links", [])]
        visible_movements = [str(v) for v in spec.get("visible_movements", [])]
        visible_ramps = [str(v) for v in spec.get("visible_ramps", [])]
        agent_summary = {
            "visible_links": visible_links,
            "visible_movements": visible_movements,
            "visible_ramps": visible_ramps,
            "link_counts": {link: link_counts.get(link, 0.0) for link in visible_links},
            "link_speeds_kph": {link: link_speeds_kph.get(link, 0.0) for link in visible_links},
            "link_stopped_counts": {
                link: link_stopped_counts.get(link, 0.0) for link in visible_links
            },
            "link_queue_tail_pos_m": {
                link: link_queue_tail_pos_m.get(link, 0.0) for link in visible_links
            },
            "movement_queue": {
                movement: movement_queue.get(movement, 0.0)
                for movement in visible_movements
            },
            "ramp_queue": {
                ramp: ramp_queue.get(ramp, 0.0)
                for ramp in visible_ramps
            },
        }
        if "control_enabled" in spec:
            agent_summary["control_enabled"] = bool(spec.get("control_enabled", True))
        if "monitoring_only" in spec:
            agent_summary["monitoring_only"] = bool(spec.get("monitoring_only", False))
        agents[str(agent_id)] = agent_summary

    represented_by_link: dict[str, float] = {}
    unrepresented_by_link: dict[str, float] = {}
    exit_excluded_by_link: dict[str, float] = {}
    for link, count in link_counts.items():
        if link in freeway_links or link in ramp_links:
            represented = count
        elif link in exit_links:
            represented = 0.0
            if count > 1.0e-9:
                exit_excluded_by_link[link] = count
        else:
            represented = min(
                count,
                storage_assigned_by_link.get(link, 0.0)
                + movement_assigned_by_link.get(link, 0.0),
            )
        represented_by_link[link] = represented
        missing = max(0.0, count - represented)
        if missing > 1.0e-9 and link not in exit_links:
            unrepresented_by_link[link] = missing

    # storage 링크별 관측 평균속도[km/h] — `TrafficState.urban_link_speed_kph` 로 간다.
    # 표본이 없는 storage 링크는 **항목 자체를 만들지 않는다**(모델이 전역 상수로 폴백).
    urban_link_speed_kph = {
        storage_link: float(speed_moment_by_storage[storage_link] / weight)
        for storage_link, weight in speed_weight_by_storage.items()
        if weight > 1.0e-9
    }

    positive_speeds = [
        speed
        for link, speed in link_speeds_kph.items()
        if link_counts.get(link, 0.0) > 0.0 and speed > 0.0
    ]
    weighted_speed_count = sum(
        link_counts.get(link, 0.0)
        for link, speed in link_speeds_kph.items()
        if speed > 0.0
    )
    weighted_speed_sum = sum(
        speed * link_counts.get(link, 0.0)
        for link, speed in link_speeds_kph.items()
        if speed > 0.0
    )
    input_vehicle_count = float(sum(link_counts.values()))
    represented_vehicle_count = float(sum(represented_by_link.values()))
    exit_excluded_vehicle_count = float(sum(exit_excluded_by_link.values()))
    total_vehicle_count = max(input_vehicle_count, _as_float(state_json.get("total_vehicles"), input_vehicle_count))
    local_observation = _mapping(state_json.get("local_observation"))
    unobservable_vehicle_count = max(
        0.0,
        _as_float(
            local_observation.get("unobservable_vehicle_count"),
            total_vehicle_count - input_vehicle_count,
        ),
    )
    projection_diagnostics = {
        # 2026-09-04. 아래 넷은 요약 최상위에도 있지만 결정 JSON 은 이 dict 만 나른다
        # (adapter:7057). arm_qsplit 런에서 스위치는 켜져 돌았는데 기록으로 확인할 수가
        # 없어 상태 JSON 으로 역산해야 했다 — "켰다"와 "돌았다"를 디스크가 말해야 한다.
        "urban_queue_contiguous_links": float(len(contiguous_queue)),
        "urban_queue_contiguous_veh": float(sum(contiguous_queue.values())),
        "urban_queue_source_contiguous": float(sum(1 for v in queue_source_by_link.values() if v == "contiguous")),
        "urban_queue_source_stopped": float(sum(1 for v in queue_source_by_link.values() if v == "stopped_instant")),
        "urban_queue_source_constant": float(sum(1 for v in queue_source_by_link.values() if v == "constant")),
        "urban_queue_bins_present": 1.0 if _mapping(_mapping(state_json.get("local_observation")).get("queue_bins")) else 0.0,
        "total_vehicle_count_veh": total_vehicle_count,
        "input_link_vehicle_count_veh": input_vehicle_count,
        "represented_vehicle_count_veh": represented_vehicle_count,
        "unrepresented_vehicle_count_veh": float(sum(unrepresented_by_link.values())),
        "exit_excluded_vehicle_count_veh": exit_excluded_vehicle_count,
        "unobservable_vehicle_count_veh": unobservable_vehicle_count,
        "mass_balance_error_veh": float(
            total_vehicle_count
            - represented_vehicle_count
            - exit_excluded_vehicle_count
            - unobservable_vehicle_count
        ),
        "freeway_observation_vehicle_count_veh": float(
            sum(link_counts.get(link, 0.0) for link in freeway_links)
        ),
        "ramp_observation_vehicle_count_veh": float(
            sum(link_counts.get(link, 0.0) for link in ramp_links)
        ),
        "freeway_bound_vehicle_count_veh": float(
            sum(link_counts.get(link, 0.0) for link in freeway_bound_links)
        ),
        "storage_requested_veh": float(storage_requested_veh),
        "storage_assigned_veh": float(storage_assigned_veh),
        "storage_capacity_clipped_veh": float(storage_capacity_clipped_veh),
        "movement_queue_assigned_veh": float(sum(movement_assigned_by_link.values())),
        "ramp_queue_assigned_veh": float(sum(ramp_queue.values())),
        "boundary_queue_assigned_veh": float(sum(boundary_queue.values())),
        "input_link_count": len(link_counts),
        "unrepresented_link_count": len(unrepresented_by_link),
        "exit_excluded_link_count": len(exit_excluded_by_link),
        "link_speed_observed_count": len(positive_speeds),
        "urban_link_speed_observed_count": len(urban_link_speed_kph),
        "moving_speed_correction": dict(_moving_speed_diag),
        "link_stopped_vehicle_count_veh": float(sum(link_stopped_counts.values())),
        "stopped_split_enabled": 1.0 if _stopped_split_enabled() else 0.0,
        "stopped_split_links": float(sum(
            1 for _l, _c in link_counts.items()
            if _c > 0.0 and str(_l) in link_stopped_counts
        )) if _stopped_split_enabled() else 0.0,
        "link_queue_tail_observed_count": sum(
            1 for value in link_queue_tail_pos_m.values() if value > 0.0
        ),
        "observed_mean_link_speed_kph": (
            float(weighted_speed_sum / weighted_speed_count)
            if weighted_speed_count > 1.0e-9
            else 0.0
        ),
    }

    if dedicated_branch_links:
        projection_diagnostics.update(observation_projection.audit_projection_provenance(
            physical_stock_assignment, urban_link_storage_occupancy, movement_queue, ramp_queue))
        projection_diagnostics.update({
            "ramp_spillback_observed_only": 1.0,
            "ramp_spillback_duplicate_avoided_veh": float(sum(ramp_spillback.values())),
        })
    projection_diagnostics.update(observation_projection.audit_physical_branch_projection(
        detector_mapping, link_counts, urban_link_storage_occupancy))

    return {
        "mode": "detector_local_v2_storage_split",
        "link_counts": link_counts,
        "link_speeds_kph": link_speeds_kph,
        "link_stopped_counts": link_stopped_counts,
        "link_queue_tail_pos_m": link_queue_tail_pos_m,
        "queue_count_by_link": queue_count_by_link,
        "storage_count_by_link": storage_count_by_link,
        "storage_fraction_by_link": storage_fraction_by_link,
        "urban_movement_queue": movement_queue,
        "queue_origin_binding": {
            "enabled": 1.0 if _queue_origin_binding_enabled() else 0.0,
            "bound_veh": float(origin_bound_veh),
            "bound_links": float(origin_bound_links),
            "unresolved_veh": float(origin_bound_unresolved_veh),
            "candidate_links": float(len(_origin_bind_links)),
            "midblock_links_forced": float(len(_midblock_stopline_links() & set(link_counts))),
        },
        "urban_link_storage_occupancy": urban_link_storage_occupancy,
        "urban_queue_source_by_link": dict(queue_source_by_link),
        "urban_queue_source_level_hist": {
            level: float(sum(1 for v in queue_source_by_link.values() if v == level))
            for level in ("contiguous", "stopped_instant", "constant")
        },
        "urban_contiguous_queue_links": float(len(contiguous_queue)),
        "urban_contiguous_queue_veh": float(sum(contiguous_queue.values())),
        "urban_link_storage_stopped": urban_link_storage_stopped,
        "urban_link_speed_kph": urban_link_speed_kph,
        "ramp_queue": ramp_queue,
        "ramp_spillback": ramp_spillback,
        "boundary_queue": boundary_queue,
        "projection_diagnostics": projection_diagnostics,
        "unrepresented_by_link": unrepresented_by_link,
        "exit_excluded_by_link": exit_excluded_by_link,
        "agents": agents,
        "split_parameters": {
            "internal_storage_fraction": float(split_parameters["internal_storage_fraction"]),
            "offramp_storage_fraction": float(split_parameters["offramp_storage_fraction"]),
        },
    }


def _movement_allowed_storage_links(cfg, movements: set[str]) -> set[str]:
    allowed: set[str] = set()
    for movement in movements:
        spec = cfg.network.urban_movements.get(movement, {})
        for field in ("origin", "destination", "receiving_link"):
            value = str(spec.get(field, ""))
            if value:
                allowed.add(value)
        ramp = str(spec.get("ramp", ""))
        if ramp:
            for linked in cfg.network.on_ramp_to_movement.get(ramp, []):
                linked_spec = cfg.network.urban_movements.get(linked, {})
                receiving = str(linked_spec.get("receiving_link", ""))
                if receiving:
                    allowed.add(receiving)
        off_ramp = str(spec.get("off_ramp", ""))
        if off_ramp:
            storage = str(cfg.network.off_ramp_storage_link.get(off_ramp, ""))
            if storage:
                allowed.add(storage)
    return allowed


def mask_state_for_agent(state, cfg, agent):
    """Return an agent-local state view for Vissim local-information runs.

    This is a runtime guard around the existing Numerical-Sim distributed
    coordinator. It keeps the plant state global for the leader, but masks the
    state object seen by each follower solve.
    """
    masked = state.copy()
    net = cfg.network
    kind = str(getattr(agent, "kind", ""))

    allowed_movements = set(str(m) for m in getattr(agent, "movements", ()) or ())
    allowed_ramps = set(str(r) for r in getattr(agent, "ramps", ()) or ())
    allowed_off_ramps = set(str(r) for r in getattr(agent, "off_ramps", ()) or ())
    allowed_storage = _movement_allowed_storage_links(cfg, allowed_movements)
    for off_ramp in allowed_off_ramps:
        storage = str(net.off_ramp_storage_link.get(off_ramp, ""))
        if storage:
            allowed_storage.add(storage)

    if kind == "urban":
        masked.urban_movement_queue = {
            key: (float(value) if key in allowed_movements else 0.0)
            for key, value in masked.urban_movement_queue.items()
        }
        masked.ramp_queue = {
            key: (float(value) if key in allowed_ramps else 0.0)
            for key, value in masked.ramp_queue.items()
        }
        boundary_keys = {
            str(net.urban_movements.get(movement, {}).get(field, ""))
            for movement in allowed_movements
            for field in ("origin", "destination")
        }
        masked.boundary_queue = {
            key: (float(value) if key in boundary_keys else 0.0)
            for key, value in masked.boundary_queue.items()
        }
        masked.urban_link_storage = {
            key: (
                float(value)
                if key in allowed_storage
                else float(net.urban_link_storage_veh.get(key, value))
            )
            for key, value in masked.urban_link_storage.items()
        }
        masked.mainline_origin_queue = {key: 0.0 for key in masked.mainline_origin_queue}
        # Urban followers should not directly inspect global freeway density;
        # freeway influence, if enabled, arrives through the coupling response.
        masked.freeway_density = {
            link: [0.0 for _ in values]
            for link, values in masked.freeway_density.items()
        }
        masked.freeway_speed = {
            link: [float(net.v_free) for _ in values]
            for link, values in masked.freeway_speed.items()
        }
        masked.refresh_freeway_flow(net)
        return masked

    if kind == "freeway":
        link = str(getattr(agent, "link", ""))
        segment_index = int(getattr(agent, "segment_index", -1))
        masked.urban_movement_queue = {key: 0.0 for key in masked.urban_movement_queue}
        masked.boundary_queue = {key: 0.0 for key in masked.boundary_queue}
        masked.ramp_queue = {
            key: (float(value) if key in allowed_ramps else 0.0)
            for key, value in masked.ramp_queue.items()
        }
        masked.urban_link_storage = {
            key: (
                float(value)
                if key in allowed_storage
                else float(net.urban_link_storage_veh.get(key, value))
            )
            for key, value in masked.urban_link_storage.items()
        }
        masked.mainline_origin_queue = {
            key: (float(value) if key == link else 0.0)
            for key, value in masked.mainline_origin_queue.items()
        }
        for model_link, values in list(masked.freeway_density.items()):
            speeds = list(masked.freeway_speed.get(model_link, [float(net.v_free) for _ in values]))
            densities = list(values)
            if model_link != link:
                masked.freeway_density[model_link] = [0.0 for _ in densities]
                masked.freeway_speed[model_link] = [float(net.v_free) for _ in densities]
                continue
            for i in range(len(densities)):
                if i != segment_index:
                    densities[i] = 0.0
                    if i < len(speeds):
                        speeds[i] = float(net.v_free)
            masked.freeway_density[model_link] = densities
            masked.freeway_speed[model_link] = speeds
        masked.refresh_freeway_flow(net)
        return masked

    return masked


def install_local_observation_runtime_guards() -> None:
    """Patch distributed follower solves to receive agent-masked state views."""
    from src.controllers import distributed_coordinator as dc

    cls = dc.DistributedCoordinator
    if getattr(cls, "_vissim_local_observation_guard_installed", False):
        return

    original_urban = cls._solve_urban_agent
    original_freeway = cls._solve_freeway_agent

    def guarded_urban(self, agent, state, leader, forecast, freeway_response, current, allocation_plan, coupling):
        return original_urban(
            self,
            agent,
            mask_state_for_agent(state, self.cfg, agent),
            leader,
            forecast,
            freeway_response,
            current,
            allocation_plan,
            coupling,
        )

    def guarded_freeway(self, agent, state, leader, forecast, current, coupling):
        return original_freeway(
            self,
            agent,
            mask_state_for_agent(state, self.cfg, agent),
            leader,
            forecast,
            current,
            coupling,
        )

    cls._solve_urban_agent = guarded_urban
    cls._solve_freeway_agent = guarded_freeway
    cls._vissim_local_observation_guard_installed = True


def install_vissim_calibration_runtime_patches(cfg, calibration: Mapping[str, Any]) -> dict[str, float]:
    """Install Vissim-specific runtime patches without editing Numerical-Sim sources.

    This adapter owns Vissim-only physical corrections so that the Desktop
    Numerical-Sim source tree can stay untouched. The v2 patches are:

    * non-uniform freeway segment lengths from the VSL/control-segment geometry;
    * off-ramp combined spillback capacity. The stock Numerical-Sim function
      adds all downstream turning-movement storage capacities, which
      double-counts shared Vissim approach space for this hypothetical network.
      Calibration v2 replaces that with explicit per-off-ramp physical capacity.
    """
    metadata: dict[str, float] = {}
    physical = _mapping(calibration.get("physical_inventory"))
    length_profile = _segment_length_profile_km(calibration)
    if length_profile:
        setattr(cfg.network, "freeway_segment_length_profile_km", length_profile)
        lengths = [length for values in length_profile.values() for length in values]
        metadata.update({
            "calibration_freeway_segment_length_profile_applied": 1.0,
            "calibration_freeway_segment_length_count": float(len(lengths)),
            "calibration_freeway_segment_length_min_km": float(min(lengths)),
            "calibration_freeway_segment_length_max_km": float(max(lengths)),
            "calibration_freeway_segment_length_mean_km": float(sum(lengths) / len(lengths)),
        })
        try:
            from src.models import state as state_module

            TrafficState = state_module.TrafficState
            if not hasattr(TrafficState, "_vissim_original_freeway_vehicle_count_by_link"):
                TrafficState._vissim_original_freeway_vehicle_count_by_link = (
                    TrafficState.freeway_vehicle_count_by_link
                )
            if not hasattr(TrafficState, "_vissim_original_total_freeway_vehicles"):
                TrafficState._vissim_original_total_freeway_vehicles = TrafficState.total_freeway_vehicles

            def calibrated_freeway_vehicle_count_by_link(self, net):
                self.ensure_freeway_lane_profile(net)
                out: dict[str, list[float]] = {}
                physical_counts = bool(getattr(net, "physical_vehicle_counts", False))
                lane_floor = 1.0e-9 if physical_counts else 1.0
                lane_profile = getattr(self, "freeway_effective_lanes" if physical_counts else "freeway_lanes", {})
                profile = getattr(net, "freeway_segment_length_profile_km", {})
                for link in net.freeway_links:
                    key = str(link)
                    densities = [float(value) for value in self.freeway_density.get(key, [])]
                    raw_lengths = profile.get(key, []) if isinstance(profile, Mapping) else []
                    lengths = [
                        max(1.0e-6, _as_float(value))
                        for value in raw_lengths
                    ] if isinstance(raw_lengths, list) else []
                    base = max(1.0e-6, float(getattr(net, "freeway_segment_length_km", 0.58)))
                    if len(lengths) < len(densities):
                        lengths = lengths + [base] * (len(densities) - len(lengths))
                    raw_lanes = lane_profile.get(key, []) if isinstance(lane_profile, Mapping) else []
                    counts = []
                    for i, rho in enumerate(densities):
                        lanes = (
                            max(lane_floor, _as_float(raw_lanes[i], getattr(net, "freeway_lanes", 2)))
                            if i < len(raw_lanes)
                            else max(lane_floor, float(getattr(net, "freeway_lanes", 2)))
                        )
                        counts.append(max(0.0, float(rho)) * lengths[i] * lanes)
                    out[key] = counts
                return out

            def calibrated_total_freeway_vehicles(self, net) -> float:
                return float(
                    sum(
                        sum(max(0.0, float(value)) for value in values)
                        for values in calibrated_freeway_vehicle_count_by_link(self, net).values()
                    )
                )

            TrafficState.freeway_vehicle_count_by_link = calibrated_freeway_vehicle_count_by_link
            TrafficState.total_freeway_vehicles = calibrated_total_freeway_vehicles
            metadata["calibration_state_vehicle_count_patch_installed"] = 1.0
        except Exception:
            metadata["calibration_state_vehicle_count_patch_installed"] = 0.0

    capacity_map = _mapping(physical.get("off_ramp_combined_capacity_veh"))
    if not capacity_map:
        return metadata

    calibrated_capacity = {
        str(off_ramp): max(0.0, _as_float(value))
        for off_ramp, value in capacity_map.items()
    }
    if not calibrated_capacity:
        return metadata

    from src.controllers import spillback_constraints

    if not hasattr(spillback_constraints, "_vissim_original_offramp_combined_capacity_veh"):
        spillback_constraints._vissim_original_offramp_combined_capacity_veh = (
            spillback_constraints.offramp_combined_capacity_veh
        )
    original = spillback_constraints._vissim_original_offramp_combined_capacity_veh

    def calibrated_offramp_combined_capacity_veh(cfg_arg, off_ramp: str) -> float:
        key = str(off_ramp)
        if key in calibrated_capacity:
            return float(calibrated_capacity[key])
        return float(original(cfg_arg, off_ramp))

    spillback_constraints.offramp_combined_capacity_veh = calibrated_offramp_combined_capacity_veh

    # Usually unnecessary because imported assess_* functions keep their module
    # globals, but patch a direct attribute too if a future module imports it.
    try:
        import src.controllers.distributed_coordinator as distributed_coordinator

        if hasattr(distributed_coordinator, "offramp_combined_capacity_veh"):
            distributed_coordinator.offramp_combined_capacity_veh = calibrated_offramp_combined_capacity_veh
    except Exception:
        pass

    capacities = []
    for off_ramp in getattr(cfg.network, "off_ramps", []):
        capacities.append(calibrated_offramp_combined_capacity_veh(cfg, str(off_ramp)))
    metadata.update({
        "calibration_offramp_capacity_patch_installed": 1.0,
        "calibration_offramp_capacity_min_veh": float(min(capacities)) if capacities else 0.0,
        "calibration_offramp_capacity_max_veh": float(max(capacities)) if capacities else 0.0,
        "calibration_offramp_capacity_total_veh": float(sum(capacities)),
    })
    return metadata


def repo_imports(repo_root: Path):
    expected_root = repo_root.resolve()
    existing_src = sys.modules.get("src")
    existing_file = Path(str(getattr(existing_src, "__file__", ""))) if existing_src is not None else None
    if existing_file and existing_file.is_file() and not existing_file.resolve().is_relative_to(expected_root):
        raise RuntimeError(
            f"preloaded src package is outside NUMSIM_REPO_ROOT: {existing_file} not under {expected_root}"
        )
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from src.controllers.stackelberg_mpc import StackelbergMPCController
    from src.models.demand import DemandStep
    from src.models.state import ControlAction, ExperimentConfig, TrafficState, segment_vsl

    for module_name in ("src.controllers.stackelberg_mpc", "src.models.demand", "src.models.state"):
        module_path = Path(str(getattr(sys.modules[module_name], "__file__", ""))).resolve()
        if not module_path.is_relative_to(expected_root):
            raise RuntimeError(
                f"imported {module_name} from {module_path}, expected under {expected_root}"
            )

    return StackelbergMPCController, DemandStep, ControlAction, ExperimentConfig, TrafficState, segment_vsl


def install_phase_vector_green_patch(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """GNE 의 `p1 -> 비율 전개` 를 현시 벡터로 대체한다. `phase_price.in_gne` 없으면 no-op.

    왜. 상류 GNE 본 루프(`wu_faithful_follower.py:4292-4299`)는 국소 최선응답에서 스칼라
    `p1` 을 받아 `distribute_phase_green(net, p1, ref)` 로 나머지 현시를 **직전 비율대로**
    채운다. 총합 고정 단체의 자유도가 (live 현시 - 1) 인데 탐색은 늘 p1 축 1방향뿐이다.
    그래서 현시별 가격이 옳게 가리켜도 그 방향으로 갈 대역폭이 없었다 — 실측으로 SC5 p3 가
    가격 1위인 결정 14개 전부에서 p3 가 하한에 묶였다.

    패치는 얇다. `LinkAgentWuFollower._solve_urban_agent_local` 이 현시 벡터를 풀어
    `_gne_phase_override[signal]` 에 남기고, 여기 패치된 `distribute_phase_green` 이 그
    신호에 대해 벡터를 그대로 돌려준다. 오버라이드가 없으면 상류 식 그대로다(비트 동일).

    상류 모듈을 수정하지 않는다 — `wu_faithful_follower` 가 `from ... import
    distribute_phase_green` 으로 **이름을 가져가므로** 그 모듈의 전역을 갈아끼운다.
    같은 이유로 `local_signal_plant` 등 다른 소비처도 함께 본다.

    프로세스 경계 주의. 가격 워커는 spawn 이라 이 패치가 안 따라간다.
    `install_price_worker_runtime_patches` 가 워커에서 다시 심는다.
    """
    section = _mapping((tuning or {}).get("phase_price"))
    if not _is_enabled_value(section.get("in_gne")):
        return {"phase_vector_green_enabled": 0.0}

    import importlib

    targets = []
    for name in ("src.models.state",
                 "src.controllers.wu_faithful_follower",
                 "src.controllers.priced_wu_link_controller",
                 "src.controllers.local_signal_plant"):
        try:
            mod = importlib.import_module(name)
        except Exception:
            continue
        if hasattr(mod, "distribute_phase_green"):
            targets.append(mod)
    if not targets:
        return {"phase_vector_green_enabled": 0.0, "phase_vector_green_targets": 0.0}

    original = targets[0].distribute_phase_green
    _stats = {"hits": 0.0, "calls": 0.0}

    # 상류 시그니처를 그대로 따른다(state.py:1501) — `reference` 와 `signal` 이 둘 다
    # 선택인자다. `_offset_green_fractions` 은 reference 없이 signal 만 넘긴다.
    def patched(net, primary, reference=None, signal=None, **kw):
        _stats["calls"] += 1.0
        if signal is not None:
            fol = _PHASE_VECTOR_FOLLOWER.get("ref")
            store = getattr(fol, "_gne_phase_override", None) if fol is not None else None
            vec = (store or {}).get(str(signal))
            if vec:
                _stats["hits"] += 1.0
                return {pid: float(v) for pid, v in vec.items()}
        return original(net, primary, reference, signal=signal, **kw)

    for mod in targets:
        mod.distribute_phase_green = patched
    _PHASE_VECTOR_FOLLOWER["stats"] = _stats
    return {"phase_vector_green_enabled": 1.0,
            "phase_vector_green_targets": float(len(targets))}


# 패치된 `distribute_phase_green` 이 팔로워를 찾아가는 통로. 컨트롤러를 만든 뒤 심는다.
_PHASE_VECTOR_FOLLOWER: dict[str, Any] = {}


def _fd_conflicts(calibration: Mapping[str, Any]) -> list[str]:
    """캘리브레이션이 정본 파라미터와 다른 값을 들고 있으면 목록으로 돌려준다.

    2026-08-27. 주석만 있고 함수가 없던 자리다(감사 지적). `calibration_to_config_overrides`
    가 FD 3종과 N_P_crit 을 더는 읽지 않으므로 그 값들은 **흔적 없이 소멸**한다.
    실제로 canon 4벌이 `calibration_override.operational.network` 에
    120.0 / 30.0 / 6900.0 을, `urban_mfd.N_P_crit_veh_initial` 에 600.0 을 들고 있는데
    전자는 읽히지 않고 후자는 parameters.json 의 509.4488 에 덮인다(-15%).
    값을 바꾸려고 그 자리를 고친 사람은 아무 일도 안 일어나는 이유를 알 길이 없다.
    """
    mod = _canonical_parameters_module()
    net = _calibration_child(calibration, "operational", "network")
    mfd = _calibration_child(calibration, "operational", "urban_mfd")
    pairs = (
        ("network", "v_free", net.get("v_free_kph")),
        ("network", "rho_crit", net.get("rho_crit_veh_km_lane")),
        ("network", "freeway_capacity_veh_h", net.get("freeway_capacity_veh_h")),
        ("network", "metanet_a_m", net.get("desired_speed_shape_a")),
        ("leader", "N_P_crit_veh", mfd.get("N_P_crit_veh_initial")),
    )
    out: list[str] = []
    for sec, key, raw in pairs:
        if raw is None:
            continue
        try:
            want = mod.require(sec, key)
        except Exception:
            continue
        if abs(_as_float(raw) - _as_float(want)) > 1.0e-9:
            out.append("%s.%s: calibration=%s parameters=%s (calibration 값은 버려진다)"
                       % (sec, key, raw, want))
    return out


def _relabel(meta: Mapping[str, Any], suffix: str) -> dict[str, Any]:
    """진단 키에 꼬리표를 붙인다. 같은 설치를 두 번 부를 때 앞 결과를 덮지 않게."""
    return {"%s_%s" % (k, suffix): v for k, v in (meta or {}).items()}


def _canonical_parameters_module():
    """`evaluation/parameters.py` 를 연다. 값의 단일 출처로 가는 유일한 문."""
    import importlib.util as _ilu

    spec = _ilu.spec_from_file_location(
        "canon_parameters", WORKSPACE_ROOT / "evaluation/parameters.py")
    mod = _ilu.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _canonical_runtime_parameters(cfg) -> dict[str, Any]:
    """생성자 필드가 아닌 정본 파라미터를 cfg 에 심는다."""
    return _canonical_parameters_module().apply_runtime(cfg)


def _canonical_parameter_overrides(tuning: Mapping[str, Any]) -> tuple[dict[str, Any], list[str]]:
    """`evaluation/parameters.json` 을 config override 로 바꾼다. 값의 단일 출처.

    돌려주는 둘. (1) override 딕셔너리 (2) tuning 이 그 값을 다르게 덮는 항목 목록.
    (2)가 비어 있지 않다는 건 그 시나리오가 정본값에서 의도적으로 벗어났다는 뜻이고,
    `parameters_overridden_by_tuning` 진단으로 남는다 — 조용히 달라지지 않게 한다.
    """
    mod = _canonical_parameters_module()
    over = {"network": mod.network_overrides(), "mpc": mod.mpc_overrides()}
    leader = mod.section("leader") if "leader" in mod.load() else {}
    if leader:
        over["leader"] = leader
    # 진단은 tuning 이 값을 넣을 수 있는 **모든 경로**를 봐야 한다. 2026-08-27 감사에서
    # config_overrides 만 보고 있어 최상위 network/mpc/leader 절이 사각지대였다 —
    # `tuning_to_config_overrides` 가 그 다섯 절도 읽어 config_overrides 위에 얹는다.
    # 그래서 새 팔을 짜며 최상위에 "mpc": {"horizon_steps": 6} 을 적으면 parameters 를
    # 조용히 이기면서 diff 에도 안 잡혔다(= leader_value_depth 사고의 재발 경로).
    diff: list[str] = []
    effective = tuning_to_config_overrides(tuning)
    for sec, block in over.items():
        tsec = _mapping(effective.get(sec))
        for key, val in block.items():
            if key in tsec and tsec[key] != val:
                top = _mapping(tuning.get(sec))
                where = "최상위 %s 절" % sec if key in top else "config_overrides"
                diff.append("%s.%s: parameters=%r tuning=%r (%s)"
                            % (sec, key, val, tsec[key], where))
    return over, diff


def calibration_to_config_overrides(calibration: Mapping[str, Any]) -> dict[str, Any]:
    network = _calibration_child(calibration, "operational", "network")
    ramp = _calibration_child(calibration, "operational", "ramp_metering")
    signal = _calibration_child(calibration, "operational", "signal")
    mfd = _calibration_child(calibration, "operational", "urban_mfd")
    physical = _mapping(calibration.get("physical_inventory"))

    d_map = ramp.get("D_green_to_release_vph_initial_mpc", {})
    f_map = ramp.get("F_green_to_release_vph_raw", {})
    d_cap = max((float(v) for v in d_map.values()), default=1500.0) if isinstance(d_map, Mapping) else 1500.0
    f_cap = max((float(v) for v in f_map.values()), default=1500.0) if isinstance(f_map, Mapping) else 1500.0
    if str(ramp.get("F_status", "")).lower() == "invalid_for_physical_metering_fit":
        # F is not a valid green-to-release metering curve. Use only the
        # full-green observed discharge as a conservative plant cap; do not
        # optimize against the non-monotone raw maximum.
        f_cap = _release_at_largest_green(f_map, f_cap)

    # 2026-08-27. FD 3종·lost_time·movement 용량·N_P_crit 은 여기서 정하지 않는다.
    #
    # 종전에는 `network.get("v_free_kph", 100.0)` 처럼 "키 없으면 상수" 로 넣었고,
    # 실제 캘리브레이션 파일에 그 키가 **없어서** 폴백 100/33.5/4000 이 이겼다.
    # 그런데 그 폴백이 앞 층(build_config)의 123.825/20.401/4574.818 을 덮었고,
    # 2026-08-02 재적합값 119.505/16.354/4914 는 컨트롤러에 도달한 적이 없다.
    # 실측 밀도 최대가 32.7 이라 rho_crit 33.5 를 한 번도 못 넘었고 VSL 이 켜질 수 없었다.
    #
    # 이제 값의 출처는 `evaluation/parameters.json` 하나다. 캘리브레이션 파일이 같은
    # 키를 갖고 있으면 조용히 덮지 않고 **불일치를 진단으로 남긴다**(아래 _fd_conflicts).
    out: dict[str, Any] = {
        "network": {
            "ramp_capacity_veh_h": {
                "R_D_W": float(d_cap),
                "R_D_E": float(d_cap),
                "R_F_W": float(f_cap),
                "R_F_E": float(f_cap),
            },
        },
        "leader": {
            "N_P_crit_veh": float(mfd.get("N_P_crit_veh_initial", 509.448830418254)),
        },
    }
    length_profile = _segment_length_profile_km(calibration)
    if length_profile:
        lengths = [length for values in length_profile.values() for length in values]
        if lengths:
            out["network"]["freeway_segment_length_km"] = float(sum(lengths) / len(lengths))

    storage_capacity: dict[str, float] = {}
    for key in (
        "urban_link_storage_capacity_veh",
        "on_ramp_storage_capacity_veh",
        "off_ramp_storage_capacity_veh",
    ):
        for link, value in _mapping(physical.get(key)).items():
            storage_capacity[str(link)] = max(0.0, _as_float(value))
    if storage_capacity:
        out["network"]["urban_link_storage_veh"] = storage_capacity

    for scalar_key in ("boundary_queue_max_veh", "ramp_queue_max_veh"):
        if scalar_key in physical:
            out["network"][scalar_key] = max(0.0, _as_float(physical.get(scalar_key)))
    return out


def tuning_to_config_overrides(tuning: Mapping[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if isinstance(tuning.get("config_overrides"), Mapping):
        out = deep_update(out, tuning["config_overrides"])
    for section in ("network", "mpc", "leader", "freeway_follower", "urban_follower"):
        if isinstance(tuning.get(section), Mapping):
            out = deep_update(out, {section: tuning[section]})
    return out


def adapter_actuation_settings(calibration: Mapping[str, Any], tuning: Mapping[str, Any]) -> dict[str, Any]:
    ramp = _calibration_child(calibration, "operational", "ramp_metering")
    actuation = {
        "D_green_to_release_vph": ramp.get("D_green_to_release_vph_initial_mpc", {}),
        "F_green_to_release_vph": ramp.get("F_green_to_release_vph_raw", {}),
        "F_ramp_mode": "always_green",
    }
    if isinstance(tuning.get("actuation"), Mapping):
        actuation = deep_update(actuation, tuning["actuation"])
    f_status = str(ramp.get("F_status", "")).lower()
    allow_invalid = bool(actuation.get("allow_invalid_F_metering", False))
    if f_status == "invalid_for_physical_metering_fit" and not allow_invalid:
        actuation["F_ramp_mode"] = "always_green"
        actuation["F_ramp_invalid_guard_active"] = True
        actuation["F_ramp_guard_reason"] = f_status
    return actuation


# ---------------------------------------------------------------------------
# P-Stack flagship (2026-07-31): NumSim flagship-ms-adapt-clean(HEAD 7f10393)의
# 최종 P-Stack(P-STACK-WU-FAITHFUL-ALLPRICE-JOINT) 운영점을 `pstack-flagship`
# 모드로 이식한 구간. 기준 원문(레시피 문서와 다르면 러너가 정답):
#   NumSim-mine/work/run_claude_style_five_controller.py
#     - make_controller ALLPRICE-JOINT 분기 L244-316 (BIAS_SAMPLE L268-273 포함)
#     - env→cfg 번역 L560-726 (METER_BOX/VSL_BOX/BOX_WALK/NP_PD_ITER/NP_BIAS/FAR_*)
#     - SEG13 L829-844, SUP_PFO L925-959·L1151-1176, FAR_GATE L1001-1099,
#       MS_ADAPT L1018-1026·L1106-1116
#   NumSim-mine/work/run_job.sh (플래그십 env 고정값, NASH_SMAX=10)
# 어댑터는 결정 1회마다 재기동되므로 러너 루프의 스텝 간 상태(직전 링크평균 밀도,
# MS 래치, fargate 래치)는 out-action-json 옆 사이드카 JSON에 영속화한다.
# ---------------------------------------------------------------------------

FLAGSHIP_RUNTIME_FILENAME = "pstack_flagship_runtime.json"
# 플래그십 채택값(2026-07-27 확정 셀): thr10 / hold5 / w0.013.
# 주의 — 러너 코드 기본은 MS_HOLD=3이지만 플래그십 채택 런은 MS_HOLD=5로 실행됐다.
# 여기서는 채택값 5를 하드코딩하고 tuning `adapter.flagship.ms_adapt`로만 조정한다.
FLAGSHIP_MS_ADAPT_DEFAULTS: dict[str, Any] = {"enabled": True, "thr": 10.0, "hold": 5, "w": 0.013}
# FAR_GATE=3(하이브리드). 폐쇄 예보 입력이 VISSIM forecast에 없으므로(아래
# freeway_lane_loss 항상 빈 dict) 실질적으로 mode 2(capdrop 상태 트리거)로 동작한다.
FLAGSHIP_FAR_GATE_DEFAULTS: dict[str, Any] = {"enabled": True, "thr": 0.95}


def flagship_settings(tuning: Mapping[str, Any]) -> Mapping[str, Any]:
    return _mapping(_mapping(tuning.get("adapter")).get("flagship"))


def flagship_config_overrides() -> dict[str, Any]:
    """플래그십 cfg 정식 키(적용 순서 base < flagship < calibration < tuning의 flagship 층).

    러너 build_cfg(L76-99) + run_job.sh env + default.yaml 실효값을 그대로 옮긴다.
    주의: plan.md 레시피는 leader_search_mode='continuous'라고 적었지만 러너 build_cfg
    L81이 "grid"를 강제한다 — 러너 원문이 정답이므로 grid를 쓴다(문서화: context-notes).
    OPT12 2종(leader_skip_local_refinement/leader_rollout_early_stop)은 MPCConfig
    dataclass 필드가 아니라 여기 넣으면 TypeError — build_pstack_flagship_controller의
    setattr로만 주입한다. 플랜트 env(VFREE/RHO_CRIT/TAU_H 등)는 수치실험 플랜트 물리라
    복사 금지(VISSIM 캘리브레이션이 예측모델 기준).
    """
    return {
        "mpc": {
            # 러너 build_cfg L77-84 원문(HORIZON env 미설정 → default.yaml 3 유지).
            "horizon_steps": 3,
            "control_horizon_steps": 3,
            "leader_search_mode": "grid",
            "relaxed_quantized_controls": True,
            "stackelberg_leader_parallel_backend": "serial",
            "grid_parallel_backend": "serial",
            "grid_reuse_process_pool": False,
            # default.yaml 실효값(어댑터 base가 축소해 둔 예산 복원).
            "leader_candidate_count": 49,
            "leader_refinement_candidate_count": 25,
            "max_nash_iter": 10,
            "stackelberg_enable_fallback": True,
            "stackelberg_enable_pfo_incumbent": True,
            "stackelberg_allocation_mode": "direct",
            # leader_value_depth — 2026-08-27 에 3 -> 0 으로 내린다(사용자 지시).
            #
            # 왜. rollout_endpoint.py:188 이 depth = horizon_steps + max(0, leader_value_depth)
            # 를 쓴다. horizon_steps=3 인데 여기서 3 을 주입해 **리더만 6 스텝**을 굴려 왔다
            # (follower 는 depth_override=horizon_steps=3). 플랜트 롤아웃 상대오차가
            # 스텝3 53.8% · 스텝6 73.2% 이므로, 리더의 4~6번째 스텝은 플랜트가 73% 틀린
            # 영역이다. 그 구간 TTT 를 목적함수 base 로 쓰면 terminal value 가 정보가 아니라
            # 잡음이다. 지평은 리더·follower 모두 3 으로 맞춘다.
            #
            # far 를 죽이지 않는다. stackelberg_mpc.py:2421·2447 게이트가
            # `leader_value_depth > 0 or leader_mfd_far_at_d0` 이므로 뒤엣것을 켜서
            # 채점 형태(H-step rollout TTT + far)를 그대로 유지한다. FAR-D0(2026-07-09)
            # 주석이 정확히 이 용도로 그 플래그를 만들었다고 적고 있다.
            #
            # 종전 주석은 "make_controller L252-255: LEADER_V_DEPTH env 없고 cfg 0이면
            # depth 3" 이었는데, 그 make_controller 는 원본 run_job.sh 러너 쪽이고 이
            # 저장소에는 `LEADER_V_DEPTH` 를 읽는 코드가 없다. 컨트롤러 생성 뒤에도 0 이
            # 유지되는 것을 확인했다.
            "leader_value_depth": 0,
            "leader_mfd_far_at_d0": True,
            # run_job.sh env → cfg 번역(러너 L679-704, L894-896, L872-874, L602-628).
            "seg13_meter_box_veh_h": 300.0,     # METER_BOX=300
            "seg13_vsl_box_kmh": 20.0,          # VSL_BOX=15의 VISSIM DSD(20 간격) 보정값
            "leader_rollout_box_walk": True,    # BOX_WALK=1
            "leader_rollout_box_walk_vg": True, # BOX_WALK_VG=1
            "baseline_move_box": True,          # BASELINE_BOX=1
            "np_primal_dual_iters": 4,          # NP_PD_ITER=4
            "np_bias_correction": True,         # NP_BIAS=1
            "leader_mfd_far_state_aware": True, # FAR_STATE_AWARE=1
            "leader_mfd_far_real_speed": True,  # FAR_REAL_V=1
            # BIAS_SAMPLE=1 + BIAS_POW=0.4 (make_controller L268-273; 활성화 자체는
            # build_pstack_flagship_controller의 enable_biased_sampling에서).
            "leader_bias_sample_pow": 0.4,
        },
        "freeway_follower": {
            # 러너 실효 기본(default.yaml): VSL smoothness 0.0.
            # segment_metering_smoothness_weight는 여기서 건드리지 않는다 —
            # 러너와 동일하게 MS_ADAPT per-step 주입만 그 값을 결정한다.
            "vsl_smoothness_weight": 0.0,
        },
    }


def build_priced_wu_link_controller(cfg, tuning: Mapping[str, Any]):
    """가격 리더 + Wu 충실 팔로워, player 입도만 링크 단위 (2026-08-20).

    `build_pstack_flagship_controller` 와 **가격 설정이 같고 `segment_agents` 만 다르다.**
    flagship 은 freeway agent 를 세그먼트 16개로 쪼개는데, 그러면 VSL 은 링크당 1개뿐이라
    8 agent 가 하나를 두고 경합한다(실측 vsl_selected 가 100.0/120.0 로 갈리고 병합은
    out.vsl[link] 한 줄이라 사실상 마지막 승자). 링크 단위면 agent 가 VSL 1 + 램프 2 =
    액션 3개를 정확히 소유한다.

    Wu 팔로워는 그대로다 — 순수 Jacobi, 결합변수 z̃ 동결·동시갱신, 오라클 7개, λ_P/λ_UF.
    `PricedWuLinkStackelbergController` 는 `_make_follower_solver` 한 줄만 오버라이드한다.
    """
    from src.controllers.priced_wu_link_controller import (
        PricedWuLinkStackelbergController,
    )

    settings = flagship_settings(tuning)
    os.environ["NASH_SMAX"] = str(int(_as_float(settings.get("nash_smax"), 10.0)))
    if bool(settings.get("opt12", True)):
        cfg.mpc.leader_skip_local_refinement = True
        cfg.mpc.leader_rollout_early_stop = True

    controller = PricedWuLinkStackelbergController(cfg)
    controller.nash_solver.f1_spillback_weight = 0.0
    # 가격 4채널 — flagship 과 동일. wu 팔로워라 offset 오라클도 있으므로 켠다.
    controller.signal_price_enabled = True
    controller.metering_price_enabled = True
    controller.vsl_price_enabled = True
    controller.offset_price_enabled = True
    controller.offset_price_inner_iters = 4
    controller.green_offset_cross_price_enabled = False
    controller.vsl_meter_cross_price_enabled = False
    # price_far — 이 빌더에는 없었다. 위 독스트링이 "가격 설정이 flagship 과 같다"고
    # 적었지만 `build_pstack_flagship_controller` 만 이 스위치를 갖고 있어서, wu-link 팔에서는
    # `adapter.flagship.price_far` 를 켜도 아무 일도 일어나지 않았다(2026-08-27 확인).
    # 반대 증거는 flagship 쪽 주석에 그대로 있다 — 2026-07-09 ablation 이 gradient 증폭
    # (44~60배)으로 실측 악화를 보고 기본 OFF 로 되돌렸다. 그래서 기본은 여전히 OFF 이고,
    # tuning 이 명시적으로 켤 때만 켜진다.
    if bool(settings.get("price_far", False)):
        controller.price_far_enabled = True
    controller.nash_solver.joint_green_offset_enabled = True
    controller.nash_solver.ramp_offset_enabled = True
    controller.metering_price_delta_veh_h = _as_float(settings.get("metering_price_delta_veh_h"), 300.0)
    controller.metering_price_trust_frac = _as_float(settings.get("metering_price_trust_frac"), 0.20)
    # 녹색 신뢰영역[s]. 기본 6.0 = 기존 거동.
    #
    # 왜 노출하나. 5400초 실런에서 컨트롤러가 무제어보다 나빴는데(TTT +12.4%), SG 단위
    # 녹색이 망의 고정신호 대비 **중앙 65%(최대 129%)** 어긋나 있었다. 총 녹색합은
    # 보존되므로(비 1.000) 용량 손실이 아니라 **재분배 크기**의 문제다. 결정당 ±6초씩
    # 33결정이면 누적 드리프트가 그만큼 커진다. 모델이 큐를 40~73% 과소예측하는 상태에서
    # 그 크기로 재분배하면 손해가 난다는 가설을 이 값으로 검정한다.
    if settings.get("signal_price_trust_sec") is not None:
        controller.signal_price_trust_sec = _as_float(settings.get("signal_price_trust_sec"), 6.0)
    # 가격 롤아웃 병렬화 (tuning 절 `price_parallel`). 기본 10 워커.
    #
    # 가격 FD 는 같은 작동점에서 레버를 하나씩 흔든 **독립 롤아웃**이라 병렬이 자연스럽다.
    # 상류가 green 채널에 이미 기구를 갖고 있고(`_green_price_rollouts`), 독스트링이
    # "병렬이어도 각 롤아웃 인자가 같고 순수 함수이므로 결과가 같다(수집 순서만 다르다)" 를
    # 보증한다. 여기서 현시별 가격(`_phase_price_rollouts`)도 같은 규약으로 병렬화했다.
    #
    # flagship 이 parallel_backend 를 serial 로 두는 것은 "러너 build_cfg 원문" 을 옮긴
    # 것이지 병렬을 배제한 판단이 아니다 — 그 자리에 경고 주석이 없다.
    #
    # 병렬 실패는 조용히 넘어가지 않는다. 직렬로 재실행하되
    # `price_parallel_serial_rerun_count` 와 `price_parallel_last_error` 를 남긴다.
    _par = _mapping((tuning or {}).get("price_parallel"))
    controller.price_parallel_workers = int(_as_float(_par.get("workers"), 10.0))

    # 현시별 교환 가격 (tuning 절 `phase_price`). 기본 꺼짐 — 켜면 리더의 가격 롤아웃이
    # 신호당 2회에서 2 + live현시수 로 늘어 약 3배가 된다. 병렬이 그 비용을 흡수한다.
    # 나머지 현시 배분 기준(tuning `urban.green_reference`). "pressure" 면 큐 비례.
    # 가격이 꺼져 있어도 걸려야 하므로 팔로워(`nash_solver`)에 직접 심는다 —
    # 가격 하달 경로(`_refresh_phase_prices`)는 phase_price.enabled 일 때만 돈다.
    _gref = str(_mapping(_mapping((tuning or {}).get("urban")).get("green_reference"))
                or (_mapping((tuning or {}).get("urban")).get("green_reference") or "")).strip()
    if _gref:
        controller.green_reference_mode = _gref
        follower_obj = getattr(controller, "nash_solver", None)
        if follower_obj is not None:
            follower_obj.green_reference_mode = _gref

    section = _mapping((tuning or {}).get("phase_price"))
    if section:
        if "enabled" in section:
            controller.phase_price_enabled = bool(section["enabled"])
        if "delta_sec" in section:
            controller.phase_price_delta_sec = _as_float(section["delta_sec"], 6.0)
        if "weight" in section:
            controller.phase_price_weight = _as_float(section["weight"], 1.0)
        # RS-off (2026-09-06 02:3x): has_ramps 신호(SC1001·SC1004)의 현시가격을 0 으로 두고 RL 국소(ramp-aware) 채점만으로 정련한다.
        #   근거: t=1500(링크 32 = 186) 에서 국소 압력 −1.31/−1.71 veh·h(정보 유무) 대 가격항 +2.24 → 가격이 이겨 p3 42 유지;
        #   가격 가중 0 이면 p3 72/75. 가격 +0.054/s 는 팔로워 롤아웃 직접 계산(+0.003/s)의 16배 과대(surrogate 결함의 has_ramps 판).
        if "ramp_signal_price" in section:
            controller.phase_price_ramp_signal_off = str(section["ramp_signal_price"]).strip().lower() == "off"
        if "primary_by_price" in section:
            # 주현시를 가격 최고 현시로. `distribute_phase_green` 의 자유도가 1차원이라
            # 그 축이 p1 에 고정돼 있으면 다른 현시를 못 올린다(실측: SC5 p3 가 가격 1위인
            # 결정 14개 전부에서 하한에 묶임).
            controller.phase_price_primary_by_price = _is_enabled_value(section["primary_by_price"])
        if "primary_margin" in section:
            controller.phase_price_primary_margin = _as_float(section["primary_margin"], 0.0)
        if "refine_rounds" in section:
            # 정련을 수렴까지 반복. 목적함수는 이미 TTT 단위인데 탐색 범위가 6초
            # 한 걸음뿐이었다 — 반복하면 최종 배분을 휴리스틱이 아니라 TTT 가 정한다.
            controller.phase_price_refine_rounds = int(_as_float(section["refine_rounds"], 1.0))
        if "local_cost_model" in section:
            # "phased" 면 정련이 GNE 와 같은 국소 물리(rollout_local_tts_phased —
            # 플래툰 도착·하류 S_eff·offset·per-movement 용량)로 후보를 채점한다.
            # 기본 "drain" 은 기존 큐 배수 모형이라 비트 동일.
            controller.phase_price_local_cost_model = str(section["local_cost_model"])
        # 2026-09-06 옵션③: 회랑 결합 정련
        controller.phase_price_joint_groups = [[str(x) for x in g] for g in (section.get("joint_groups") or []) if isinstance(g, (list, tuple)) and len(g) >= 2]
        controller.phase_price_joint_price_weight = float(_as_float(section.get("joint_price_weight"), 0.0))
        controller.phase_price_joint_rounds = int(_as_float(section.get("joint_rounds"), 6.0))
        # 2026-09-06 옵션①: 2단 정련 (국소 균형에서 흔들어 가격)
        controller.phase_price_two_stage = _is_enabled_value(section.get("two_stage"))
        if "in_gne" in section:
            # 2026-08-27, 사용자 지시. 현시가격을 GNE **안**으로 옮긴다.
            #
            # 종전에는 `solve()` 가 GNE 를 끝낸 뒤 `apply_phase_price_refinement` 를 불렀다.
            # 그래서 매 결정 "GNE 가 p1 축만 최적화 -> 정련이 되돌림 -> 다음 결정 GNE 가
            # 다시 뭉갬" 이 반복됐다. Stackelberg 에서 리더 가격은 팔로워의 최적화 문제
            # 안에 있어야 균형이 옮겨간다 — 밖에서 밀면 복원된다. 리더 해와 PFO 해의
            # realized TTT 차가 0.0001 인 것이 그 증상이다.
            #
            # 켜면 국소 최선응답이 p1 축 해를 시드로 현시 벡터를 좌표하강한다.
            # 채점은 정련과 **같은 함수**다(local + Σ price·Δg).
            controller.phase_price_in_gne = _is_enabled_value(section["in_gne"])
        if "in_gne_rounds" in section:
            controller.phase_price_in_gne_rounds = int(_as_float(section["in_gne_rounds"], 2.0))
        elif _is_enabled_value(section.get("in_gne")):
            # in_gne 를 켜면 정련이 꺼진다(팔로워 solve 가 막는다). 그러면 정련이 하던
            # 탐색량을 GNE 안으로 **옮겨야** 한다 — 안 옮기면 탐색이 통째로 얕아진다.
            # 실측 기준 refine_rounds 12 였고, in_gne_rounds 를 2 로 두면 6배 얕다.
            controller.phase_price_in_gne_rounds = int(
                getattr(controller, "phase_price_refine_rounds", 1))
        if "exchange_steps_sec" in section:
            cfg.mpc.phase_price_exchange_steps_sec = tuple(
                float(x) for x in section["exchange_steps_sec"]
            )
        # 가격의 **국소항**을 정련과 같은 phased 물리로 채점한다. 절이 없으면 no-op.
        install_phased_price_local(controller, tuning)
        install_observed_backpressure_controller(controller, tuning)
        # has_ramps 신호의 현시 국소비용을 GNE 와 같은 ramp-aware 물리로. 절 없으면 no-op.
        install_ramp_aware_phase_local(controller, tuning)
    # 국소 램프 모델의 저수지 용량이 전역 스칼라 0.0 을 받는 것을 개별 상한으로.
    # 절 없으면 no-op. **위 if 블록 밖이다** — phase_price 절과 무관하게 걸려야 한다.
    install_local_ramp_queue_cap(controller, tuning)
    # in_gne 벡터 탐색이 demand 를 위치인자로 못 받아 채점기가 통째로 drain 으로
    # 떨어지던 것을 고친다. `phase_price.in_gne` 가 꺼져 있으면 no-op.
    install_in_gne_demand_fix(controller, tuning)
    # λ_P 상한을 config 로. `dual.lambda_np_cap` 없으면 no-op. 분해 실험용.
    install_lambda_np_cap_override(controller, tuning)
    # GNE 의 p1 -> 비율 전개를 현시 벡터로 대체한다. `phase_price.in_gne` 없으면 no-op.
    # 팔로워 참조를 패치가 찾아갈 수 있게 여기서 심는다 — 패치는 모듈 전역이라
    # 컨트롤러 인스턴스를 직접 못 본다.
    _PHASE_VECTOR_FOLLOWER["ref"] = getattr(controller, "nash_solver", None)
    # 신호별 녹색 상자를 GNE 후보·가격 방향에 흘려준다. 절이 없으면 no-op.
    install_signal_aware_green_box(controller, tuning)
    # flagship 이 여기서 segment_agents=True 를 켠다. 이 팔은 켜지 않는다 —
    # LinkAgentWuFollower.__init__ 이 False 로 못박아 두었다.
    #
    # 그래서 **SEG13 전용 설정을 같이 걷어내야 한다.** `flagship_config_overrides()` 가
    # seg13_meter_box_veh_h=300 · seg13_vsl_box_kmh=20 을 넣는데, wu 팔로워가
    # `segment_agents and metering_enabled` 를 요구하며 RuntimeError 로 즉사시킨다
    # (wu_faithful_follower.py:4024-4034). 실측: 2026-08-20 첫 스모크가 전 결정
    # controller_status=fallback_fixed 로 떨어졌고 controller_error 가 정확히 그 메시지였다.
    #
    # 대체 수단은 에러 메시지 자신이 알려준다 — "비-SEG13은 metering_marginal_price_trust_frac
    # 이 이미 묶는다". 위에서 0.20 으로 세워 두었다.
    for _seg13_only in ("seg13_meter_box_veh_h", "seg13_vsl_box_kmh", "freeway_agent_groups"):
        if getattr(cfg.mpc, _seg13_only, None) is not None:
            setattr(cfg.mpc, _seg13_only, None)

    # 램프 미터링을 GNE 합의 루프 안으로 (tuning 절 `agent_topology.metering_in_gne`).
    # 기본 꺼짐 = 비트 동일.
    #
    # 상류는 미터링을 합의 루프 **밖에서 1회만** 푼다(wu_faithful_follower.py:4308,
    # "metering 좌표하강은 비싸므로"). 그래서 되먹임이 한 방향이다 — 도시 agent 가 녹색을
    # 정할 때 그 결정이 만들 미터링을 못 보고, 미터링이 정해질 때는 녹색이 이미 확정이다.
    #
    # 실측(2026-08-29, 수요 sweep): 도시부를 -159~-207 개선하는 만큼 본선이 +165~+267
    # 나빠져 합이 +7.3~+76.8 로 진다. VSL 을 끄고(x2.2 novsl) 미터링을 무제어와 같은
    # 7200 으로 열어둬도 freeway 가 +167.3 남는다 — 레버 값이 아니라 구조가 남는 설명이다.
    #
    # **반드시 SEG13 키를 비운 뒤에 부른다.** 이 스위치는 상류의 `segment_agents` 분기를
    # 타고, 그 플래그가 SEG13 전용 키의 가드도 함께 연다. 위 루프보다 먼저 부르면
    # `seg13_meter_box_veh_h=300`(flagship_config_overrides 가 넣는 값)이 아직 살아 있어
    # 팔로워 가드가 즉사시킨다 — 2026-08-29 에 실제로 그렇게 걸렸고, 그 순서가 이 주석의 이유다.
    if _is_enabled_value(_mapping(tuning.get("agent_topology")).get("metering_in_gne")):
        if not hasattr(controller.nash_solver, "enable_metering_in_gne"):
            raise ValueError(
                "agent_topology.metering_in_gne 를 켰는데 팔로워가 그것을 모른다 — "
                "LinkAgentWuFollower 가 아니면 이 스위치는 아무 일도 안 한다."
            )
        controller.nash_solver.enable_metering_in_gne()
    return controller


def build_pstack_flagship_controller(cfg, tuning: Mapping[str, Any]):
    """P-STACK-WU-FAITHFUL-ALLPRICE-JOINT 컨트롤러 구성(러너 make_controller L244-316 이식).

    cfg 정식 키는 flagship_config_overrides()가 build_config 단계에서 이미 주입했다는
    전제. 여기서는 (1) 프로세스 env, (2) cfg.mpc 동적 속성, (3) controller/nash_solver
    인스턴스 속성을 러너와 같은 순서로 채운다.
    """
    settings = flagship_settings(tuning)
    # NASH_SMAX: src 내부에서 env로만 소비(wu_faithful_follower.py:3908-3912) —
    # min(max_nash_iter, 5) 하드캡 해제. 어댑터는 1회 실행 프로세스라 부작용 없음.
    os.environ["NASH_SMAX"] = str(int(_as_float(settings.get("nash_smax"), 10.0)))
    # OPT12(러너 L259-261): dataclass 필드가 아닌 동적 속성(stackelberg_mpc getattr 소비).
    if bool(settings.get("opt12", True)):
        cfg.mpc.leader_skip_local_refinement = True
        cfg.mpc.leader_rollout_early_stop = True

    from src.controllers.f1_wu_faithful_follower import F1StackelbergWuMeteredController

    controller = F1StackelbergWuMeteredController(cfg)
    # BIAS_SAMPLE(러너 L268-273): Halton 상단 warp. leader_bias_sample_pow(0.4)는 cfg
    # override로 주입 완료. 러너 build_cfg가 grid 검색을 강제하므로 continuous 샘플
    # 경로가 호출되지 않아 사실상 불활성이지만, 러너 원문 그대로 이식해 둔다
    # (tuning으로 leader_search_mode를 continuous로 바꾸면 그대로 발화).
    if bool(settings.get("bias_sample", True)):
        from src.controllers.biasedsample_mpc import enable_biased_sampling

        enable_biased_sampling(controller)
    controller.nash_solver.f1_spillback_weight = 0.0
    controller.signal_price_enabled = True
    controller.metering_price_enabled = True
    controller.vsl_price_enabled = True
    # cross 2종 기본 OFF(2026-07-16 동결 + run_job.sh CROSS_OFF=1).
    controller.green_offset_cross_price_enabled = False
    controller.vsl_meter_cross_price_enabled = False
    controller.nash_solver.joint_green_offset_enabled = True
    # OFFSET_PRICE 기본 ON + SQP식 inner-walk 4회(러너 L298-300).
    controller.offset_price_enabled = True
    controller.offset_price_inner_iters = 4
    # RAMP_OFFSET 기본 ON(러너 L303-304): D/F ramp-aware offset 탐색.
    controller.nash_solver.ramp_offset_enabled = True
    # metering δ=300 + trust_frac=0.20 — 반드시 짝(러너 L305-315).
    controller.metering_price_delta_veh_h = 300.0
    controller.metering_price_trust_frac = 0.20
    # SEG13(러너 L829-834): freeway를 segment agent로 분해 + 예산 simplex 사영.
    if hasattr(controller.nash_solver, "segment_agents"):
        controller.nash_solver.segment_agents = True
    # PRICE_FAR / PRICE_HINGE (2026-08-04, 튜닝 노출). 기본 OFF = 기존과 비트 동일.
    #
    # 왜 노출하는가. 리더는 후보를 `TTT + far` 로 채점하는데(stackelberg_mpc.py:2371-2377,
    # leader_value_depth=3>0 이라 게이트가 열려 있다) 한계가격은 `TTT` 의 기울기다.
    # **최소화하는 함수와 미분하는 함수가 다르다.**
    #
    # 실측(2026-08-04, g6_v6 앵커 t0, 깊이 6=360 s, 수요 정합 튜닝):
    #   미터가 구속하지 않는 운영점(1800/1440)에서는 두 가격이 모두 음수이고 far 배율 ~4 배.
    #   **구속하는 운영점(1080/720)에서 far 를 넣으면 부호가 양수로 뒤집힌다**
    #   (1080: -1.7e-4 -> +8.1e-3, 48.9 배). 순수 TTT 는 "미터를 열수록 좋다"만 말하므로
    #   조일 이유가 기울기에 존재하지 않았다. far 의 램프 항 q^2/(2*merge_rate) 가
    #   본선 혼잡 시 배수 지연을 담아 처음으로 metering 에 값을 만든다.
    #   크기도 |g|*Δm ~ 10 veh*h 로 기준 TTT(90~150)의 7~11 % 가 된다.
    #
    # 반대 증거도 남아 있다. stackelberg_wu_metered.py:157-159 가 2026-07-09 ablation 에서
    # "gradient 크기와 노이즈를 함께 증폭 — 실측 악화" 로 기본 OFF 로 되돌렸다고 적고 있다.
    # 그 실험은 수치 시뮬 환경이고 오늘의 수요 정합 이전이라 그대로 적용하기 어렵지만,
    # 44~60 배 증폭은 실재하므로 **기본 ON 으로 두지 않는다.** 폐루프 A/B 로 판정할 것.
    if bool(settings.get("price_far", False)):
        controller.price_far_enabled = True
    if bool(settings.get("price_hinge", False)):
        controller.price_hinge_enabled = True
        controller.price_hinge_weight = _as_float(settings.get("price_hinge_weight"), 1.0)
    return controller


def load_flagship_runtime(path: Path) -> dict[str, Any]:
    """사이드카 읽기. 부재/파손 시 빈 dict → 러너 첫 스텝과 동일(래치 0, prev 없음)."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return raw
    except Exception:
        pass
    return {}


def save_flagship_runtime(path: Path, data: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(dict(data), ensure_ascii=False, indent=2), encoding="utf-8")


def flagship_link_mean_density(state) -> dict[str, float]:
    """러너 L1107-1108: 링크별 세그먼트 평균 밀도."""
    return {
        str(link): float(sum(values)) / len(values)
        for link, values in (getattr(state, "freeway_density", {}) or {}).items()
        if values
    }


def flagship_ms_adapt_update(
    prev_rho: Mapping[str, float],
    rho_now: Mapping[str, float],
    latch: int,
    thr: float,
    hold: int,
    w: float,
) -> tuple[float, int, float]:
    """MS_ADAPT 래치 갱신(러너 L1109-1113과 동일한 순수 함수 — 단위검증 대상).

    첫 스텝(prev 비어 있음)은 dmax=0 → latch max(0,-1)=0 → weight=w (러너와 동일).
    """
    dmax = max(
        (abs(float(v) - float(prev_rho[lk])) for lk, v in rho_now.items() if lk in prev_rho),
        default=0.0,
    )
    new_latch = int(hold) if dmax > float(thr) else max(0, int(latch) - 1)
    weight = 0.0 if new_latch else float(w)
    return float(dmax), new_latch, float(weight)


def flagship_far_gate_update(
    cfg,
    state,
    forecast,
    stress: bool,
    thr: float,
) -> tuple[bool, bool, bool, bool]:
    """FAR_GATE=3 갱신(러너 L1064-1096): capdrop 실측 히스테리시스 + 폐쇄 예보 선제 ON.

    반환: (fg_new, stress_latch, drop_seen, all_sub).
    VISSIM forecast는 freeway_lane_loss가 항상 비어 있어 예보 분기는 발화하지 않는다
    (실질 mode 2). 폐쇄 예보 입력이 생기면 그대로 mode 3으로 동작한다.
    """
    from src.models.metanet import desired_speed_kmh, segment_flow_veh_h

    rc = float(cfg.network.rho_crit)
    vf = float(cfg.network.v_free)
    all_sub = True
    drop_seen = False
    for link in cfg.network.freeway_links:
        dens = state.freeway_density.get(link, [])
        spds = state.freeway_speed.get(link, [])
        lns = getattr(state, "freeway_effective_lanes", {}).get(link, [])
        for i in range(len(dens)):
            rho = float(dens[i])
            if rho <= rc:
                continue
            all_sub = False
            lam = float(lns[i]) if i < len(lns) else float(cfg.network.freeway_lanes)
            v = float(spds[i]) if i < len(spds) else 0.0
            flow = segment_flow_veh_h(rho, v, lam)
            cap = segment_flow_veh_h(rc, desired_speed_kmh(rc, vf, rc), lam)
            if flow < float(thr) * cap:
                drop_seen = True
    if drop_seen:
        stress = True  # drop 발생 → ON 래치
    elif all_sub:
        stress = False  # 전 세그 임계 아래 = 회복 완료 → OFF
    fg_new = bool(stress)
    # mode 3 하이브리드: 예보 지평 내 차선 폐쇄가 있으면 선제 ON(래치는 불변 — 러너 동일).
    try:
        from src.models.demand import merge_freeway_lane_loss

        merged = merge_freeway_lane_loss(list(forecast))
        if any(float(v) > 0.0 for segs in merged.values() for v in segs.values()):
            fg_new = True
    except Exception:
        pass
    return fg_new, bool(stress), drop_seen, all_sub


def flagship_sup_score(control, state, forecast, cfg) -> float:
    """감독자 공통 채점(러너 _sup_score L947-959): h스텝 결합 rollout TTT + far cost-to-go.

    후보 채점이므로 상류 rollout endpoint 를 거친다(N7 "우회 호출 0"). far cost-to-go 는
    endpoint 의 far_enabled 성분이 그대로 수행한다.
    """
    from src.controllers.rollout_endpoint import ObjectiveSpec, evaluate_price_point

    point = evaluate_price_point(
        state,
        control,
        list(forecast),
        (),
        ObjectiveSpec(
            cfg=cfg,
            depth_override=max(1, int(cfg.mpc.horizon_steps)),
            box_walk=False,
            score_mode="price",
            far_enabled=True,
        ),
    )
    return float(point.objective)


def run_pstack_flagship_decision(
    cfg,
    state,
    forecast,
    previous,
    tuning: Mapping[str, Any],
    runtime_path: Path,
):
    """pstack-flagship 결정 1회: 사이드카 복원 → FAR_GATE/MS_ADAPT → decide → SUP_PFO.

    러너 run_one 루프(L1034-1176)의 한 스텝과 동일한 순서. 반환:
    (control, controller, metadata).
    """
    import copy as _copy

    metadata: dict[str, Any] = {}
    settings = flagship_settings(tuning)
    runtime = load_flagship_runtime(runtime_path)
    first_step = not bool(runtime)
    metadata["flagship_runtime_first_step"] = float(first_step)

    controller = build_pstack_flagship_controller(cfg, tuning)
    metadata.update(install_vissim_terminal_cost_objective(controller, cfg, tuning))
    metadata["flagship_nash_smax_env"] = _as_float(os.environ.get("NASH_SMAX"), 0.0)

    # SUP_PFO 준비(러너 L931-945): per-step cfg 변형(FAR_GATE/MS_ADAPT) **이전** 사본.
    # seg13 전용 박스는 `is not None` 가드라 반드시 None으로 되돌린다. 링크-PFO 이동
    # 한계는 baseline_move_box로 walk-MVG와 동일화.
    sup_settings = _mapping(settings.get("sup_pfo"))
    sup_enabled = bool(sup_settings.get("enabled", True))
    sup_gate = str(sup_settings.get("gate", "fargate"))
    sup_cfg = None
    if sup_enabled:
        sup_cfg = _copy.deepcopy(cfg)
        sup_cfg.mpc.seg13_meter_box_veh_h = None
        if hasattr(sup_cfg.mpc, "seg13_meter_box_up_veh_h"):
            sup_cfg.mpc.seg13_meter_box_up_veh_h = None
        sup_cfg.mpc.seg13_vsl_box_kmh = None
        # ZONE-4(2026-08-01): 감독자 PFO는 링크 모드(segment_agents=False)라 zone 구조를
        # 쓰지 않는다. 남겨두면 follower 진입부 가드가 "groups인데 SEG13이 꺼져 있다"로
        # 즉사시킨다 — seg13 박스 키와 동일 규약으로 되돌린다.
        if hasattr(sup_cfg.mpc, "freeway_agent_groups"):
            sup_cfg.mpc.freeway_agent_groups = None
        sup_cfg.mpc.baseline_move_box = True

    # FAR_GATE=3 (러너 L1048-1099).
    fg_settings = dict(FLAGSHIP_FAR_GATE_DEFAULTS)
    fg_settings.update(_mapping(settings.get("far_gate")))
    fargate_stress = bool(runtime.get("fargate_stress", False))
    if bool(fg_settings.get("enabled", True)):
        fg_new, fargate_stress, drop_seen, all_sub = flagship_far_gate_update(
            cfg,
            state,
            forecast,
            fargate_stress,
            _as_float(fg_settings.get("thr"), 0.95),
        )
        cfg.mpc.leader_mfd_far_enabled = bool(fg_new)
        metadata.update({
            "flagship_fargate_enabled": 1.0,
            "flagship_fargate_capdrop_seen": float(drop_seen),
            "flagship_fargate_all_subcritical": float(all_sub),
            "flagship_fargate_stress_latch": float(fargate_stress),
        })
    else:
        metadata["flagship_fargate_enabled"] = 0.0
    metadata["flagship_fargate_on"] = float(bool(cfg.mpc.leader_mfd_far_enabled))

    # MS_ADAPT (러너 L1106-1116). 결정 전에 마찰 가중을 주입한다.
    ms_settings = dict(FLAGSHIP_MS_ADAPT_DEFAULTS)
    ms_settings.update(_mapping(settings.get("ms_adapt")))
    ms_prev = {
        str(k): _as_float(v)
        for k, v in _mapping(runtime.get("ms_prev_rho")).items()
    }
    ms_latch = int(_as_float(runtime.get("ms_latch"), 0.0))
    rho_now = flagship_link_mean_density(state)
    if bool(ms_settings.get("enabled", True)):
        ms_dmax, ms_latch, ms_weight = flagship_ms_adapt_update(
            ms_prev,
            rho_now,
            ms_latch,
            _as_float(ms_settings.get("thr"), 10.0),
            int(_as_float(ms_settings.get("hold"), 5.0)),
            _as_float(ms_settings.get("w"), 0.013),
        )
        cfg.freeway_follower.segment_metering_smoothness_weight = float(ms_weight)
        metadata.update({
            "flagship_ms_adapt_enabled": 1.0,
            "flagship_ms_dmax": float(ms_dmax),
            "flagship_ms_latch": float(ms_latch),
        })
    else:
        metadata["flagship_ms_adapt_enabled"] = 0.0
    metadata["flagship_ms_friction"] = float(
        getattr(cfg.freeway_follower, "segment_metering_smoothness_weight", 0.0)
    )

    # 사이드카는 decide 이전에 저장 — 결정이 실패(fallback_fixed)해도 상태 전이
    # 관측치(직전 밀도·래치)는 다음 스텝에 이어진다.
    save_flagship_runtime(runtime_path, {
        "schema_version": 1,
        "sim_sec": float(getattr(state, "time_sec", 0.0)),
        "ms_prev_rho": rho_now,
        "ms_latch": int(ms_latch),
        "fargate_stress": bool(fargate_stress),
    })

    result = controller.decide_with_info(state.copy(), forecast, previous, cfg)
    control = result.control
    metadata["leader_objective"] = float(getattr(result, "leader_objective", 0.0))
    metadata["nash_objective"] = float(getattr(getattr(result, "nash", None), "objective_value", 0.0))
    metadata.update({
        f"meta_{k}": float(v)
        for k, v in getattr(result, "metadata", {}).items()
        if isinstance(v, (int, float, bool))
    })

    # SUP_PFO + SUP_GATE=fargate (러너 L1151-1176): far 게이트 ON 스텝은 감독자 OFF
    # (동일한 물리 조건이 far를 부르고 감독자를 쫓아낸다 — 단일 게이트, 이중 스위치).
    sup_off = sup_gate == "fargate" and bool(cfg.mpc.leader_mfd_far_enabled)
    metadata["flagship_sup_enabled"] = float(sup_enabled)
    metadata["flagship_sup_gated_off"] = float(bool(sup_enabled and sup_off))
    if sup_enabled and not sup_off and sup_cfg is not None:
        from src.controllers.wu_faithful_follower import WuFaithfulFollower

        sup_pfo = WuFaithfulFollower(sup_cfg)
        try:
            pfo_control = sup_pfo.solve(state.copy(), None, forecast, previous).control
        finally:
            if hasattr(sup_pfo, "close"):
                try:
                    sup_pfo.close()
                except Exception:
                    pass
        v_ps = flagship_sup_score(control, state, forecast, cfg)
        v_pfo = flagship_sup_score(pfo_control, state, forecast, cfg)
        if v_pfo < v_ps - 1.0e-9:
            pfo_control.diagnostics["sup_pick_pfo"] = 1.0
            pfo_control.diagnostics["sup_v_pstack"] = v_ps
            pfo_control.diagnostics["sup_v_pfo"] = v_pfo
            control = pfo_control
        else:
            control.diagnostics["sup_pick_pfo"] = 0.0
            control.diagnostics["sup_v_pstack"] = v_ps
            control.diagnostics["sup_v_pfo"] = v_pfo
        metadata["flagship_sup_pick_pfo"] = float(control.diagnostics["sup_pick_pfo"])
        metadata["flagship_sup_v_pstack"] = float(v_ps)
        metadata["flagship_sup_v_pfo"] = float(v_pfo)
    return control, controller, metadata


def build_config(
    repo_root: Path,
    control_interval: float,
    sim_period: float,
    mode: str,
    calibration: Mapping[str, Any],
    tuning: Mapping[str, Any],
    local_observation: bool = False,
    flagship: bool = False,
):
    _, _, _, ExperimentConfig, _, _ = repo_imports(repo_root)
    config_path = repo_root / "src/config/default.yaml"
    # This is intentionally a light Vissim-integration profile. The full offline
    # controller can be much heavier; for COM smoke/control-loop use we keep a
    # short horizon and serial execution.
    overrides: dict[str, Any] = {
        "simulation": {
            "T_total": max(float(sim_period), float(control_interval)),
            "T_f": 10.0,
            "T_u": 5.0,
            "control_interval": float(control_interval),
        },
        "network": {
            "freeway_links": ["FW_W", "FW_E"],
            "freeway_segments_per_link": 8,
            "freeway_segment_length_km": 0.444,
            "freeway_lanes": 2,
            "v_free": 123.825,
            "rho_crit": 20.401,
            "freeway_capacity_veh_h": 4574.818,
            "lost_time": 6.0,
            "movement_capacity_veh_h": 1800.0,
            "ramp_capacity_veh_h": {
                "R_D_W": 1414.0,
                "R_F_W": 316.0,
                "R_D_E": 1414.0,
                "R_F_E": 316.0,
            },
            # 아래 두 인덱스는 **가상 8-seg 네트워크(modi_eval_vsl_8seg)** 기본값이다.
            # 실제 개포 real-world 플랜트(modi_eval_rw_control.inpx)의 값이 아니므로
            # tuning(config_overrides.network)이 없는 합성 스모크/계약 검증 경로에서만
            # 쓰인다. 실 플랜트 값은 generate_real_world_control_mapping.py 가 .inpx
            # 커넥터 기하에서 뽑아 control_mapping.json(model_topology_overrides)과
            # evaluation/configs/real_world_modi_pstack_adapter_v0_20260719.json
            # (config_overrides.network)에 쓰고, 후자가 base보다 나중에 적용된다.
            #
            # 실측 개포 토폴로지(2026-08-02 .inpx 커넥터 전수조사 + Link Segment
            # Results 유량 검증, 세그먼트는 진행방향 인덱스):
            #   FW_E(체인 74-10699-2-10702-24): S3 에 OR_F_E(10643/10682) diverge 와
            #        R_F_E(10639/10681) merge 가 **같은 세그먼트**에 있고,
            #        S5 에 OR_D_E(10481/10483) diverge 와 R_D_E(10490/10484) merge.
            #   FW_W(체인 26): S2 에 OR_D_W(10479/10491)+R_D_W(10480/10482),
            #        S4 에 OR_F_W(10645/10638)+R_F_W(10646) — R_F_W 의 두 번째
            #        물리 미터 10644 는 S5 에 합류한다(ramp_meter_groups 의
            #        segment_straddle 참조).
            # 즉 가상망은 각 인터체인지의 diverge/merge 를 다른 세그먼트로 분리했지만
            # (off 2/4, merge 3/5), 실 플랜트는 1,347 m 세그먼트 하나에 둘 다 들어간다.
            "ramp_merge_segment_index": {
                "R_D_W": 5,
                "R_F_W": 3,
                "R_D_E": 3,
                "R_F_E": 5,
            },
            "off_ramp_segment_index": {
                "OR_D_W": 4,
                "OR_F_W": 2,
                "OR_D_E": 2,
                "OR_F_E": 4,
            },
        },
        "mpc": {
            "horizon_steps": 1,
            "control_horizon_steps": 1,
            "follower_solver_mode": "distributed" if local_observation else "two_block",
            "leader_search_mode": "grid",
            "leader_candidate_count": 1 if local_observation and mode == "fast-smoke" else 3,
            "leader_refinement_candidate_count": 1,
            "max_nash_iter": 1,
            "distributed_coupling_tol": 0.05 if local_observation else 0.001,
            "relaxed_quantized_controls": bool(local_observation),
            "stackelberg_allocation_mode": "simplified" if local_observation else "direct",
            "stackelberg_enable_fallback": False,
            "stackelberg_leader_parallel_backend": "serial",
            "grid_parallel_backend": "serial",
            "grid_reuse_process_pool": False,
            "leader_continuous_parallel_multistart": False,
        },
        "leader": {
            "N_P_crit_veh": 390.0,
            "mfd_penalty_mode": "all_urban_halfcap",
            # N_P_star 는 horizon 순유입[veh] 목표다(누적 수준이 아니다).
            #
            # 2026-08-20 재산정. 옛 값 [0.0, 780.0] 은 `Leader._candidate_bounds` 가 매 결정
            # 유도하는 movement-level 도달가능 범위의 **양끝을 다 잘랐다**:
            #
            #   측정(core17legs4b, 18결정)   movement 하한 -216.3 ~ -0.4
            #                                movement 상한   517.1 ~ 2135.9
            #                                사영 순유입   1068.9 ~ 1105.8 (적재 구간)
            #
            # 결과 두 가지. (1) 상한 780 이 자연 순유입 ~1,100 보다 낮아 리더의 모든 선택이
            # "지금 흐르는 것보다 조여라" 가 됐고, 가장 느슨한 780 을 골라도 318 veh 를 조인다
            # — 완료차량이 폴백 대비 14~17% 줄어 가드가 7/7 기각했다. (2) 하한 0 이 18결정
            # 전부에서 물려 리더가 순유출(배수)을 아예 표현하지 못했다.
            #
            # 앵커까지 무너진다 — `_np_anchor_values` 는 movement 양끝과 직전 N_P_star 를
            # 앵커로 쓰는데 셋 다 [0,780] 으로 클립돼 앵커 집합이 {0, 780} 으로 붕괴했다.
            # linspace 는 n_np = round(sqrt(9)) = 3 개뿐이라 앵커가 사실상 후보 전부다.
            #
            # 새 값은 측정된 도달가능 범위를 여유 두고 덮는다(하한 -216.3 -> -250,
            # 상한 2135.9 -> 2400). 상류 설계 의도와도 맞다 — `test_constraints.py:1799` 가
            # 파생 경계는 base 범위 **안에** 들어간다고 검사한다(상류 기본 [-3500, 3500]).
            "N_P_star_range": [-250.0, 2400.0],
            # N_UF_star 는 램프 미터링 합[veh/h] 목표다.
            #
            # 2026-08-20 재산정. 옛 상한 5000.0 은 이 망의 **물리 램프 용량 7,200 의 69%** 였다
            # (ramp_capacity_veh_h = 1800 x 4, `real_world_modi_pstack_adapter_v0_20260719.json`).
            #
            # `Leader._candidate_bounds` 는 자유류에서
            #     feasible_nuf = max(feasible_nuf, total_ramp_capacity)   # = 7200
            #     nuf_upper    = min(N_UF_star_range[1], nuf_upper_target)
            # 을 계산하는데, 상한 5000 이 항상 이겼다 — 실런 전 결정에서
            # `leader_nuf_bound_upper = 5000` 이고 `leader_nuf_heuristic_target` 마저 5000 으로
            # 잘렸다.
            #
            # 결과가 이것이다. 폴백(무제어)은 `ControlAction.uncontrolled` 로 램프를 용량 그대로
            # 열어 7,200 을 실현하는데, 리더는 `_leader_metering_projection` 이 합을 5,000 에
            # 맞춰 **매 결정 램프 유입을 30.6% 강제 차단**당했다. 완료차량이 폴백 대비
            # 14~17% 적었던 직접 원인이고, 가드가 `completed_severe` 로 7/7 기각한 이유다.
            #
            # N_P 축만 넓힌 대조군(npbox, 2026-08-20)에서 리더 의도가 780 -> 1078.7 로 움직여도
            # 완료차량이 1520.61 로 **소수점까지 동일**했다 — 물리는 축은 N_P 가 아니라 N_UF 다.
            #
            # 새 상한은 물리 용량 그 자체다. 리더가 "미터링 안 함" 을 고를 수 있어야
            # 폴백과 같은 출발선에 선다.
            "N_UF_star_range": [0.0, 7200.0],
        },
        "freeway_follower": {
            "vsl_set": [60.0, 70.0, 80.0, 90.0, 100.0, 110.0, 120.0],
            "vsl_max_km_h": 120.0,
            "horizon_beam_width": 1 if local_observation else 2,
            "horizon_ramp_candidate_limit": 1 if local_observation else 3,
            "horizon_vsl_candidate_limit_per_link": 1 if local_observation else 3,
        },
        "urban_follower": {
            "allocation_pso_particles": 4 if local_observation else 18,
            "allocation_pso_iterations": 4 if local_observation else 24,
        },
    }
    if flagship:
        # 적용 순서: base < flagship < calibration < tuning (plan.md 결정).
        overrides = deep_update(overrides, flagship_config_overrides())
    overrides = deep_update(overrides, calibration_to_config_overrides(calibration))
    # 정본 파라미터 층 (2026-08-27). 적용 순서는
    #   base < flagship < calibration < **parameters.json** < tuning
    # 이다. calibration 뒤에 두는 이유는, 그 층이 실제로는 "키 없으면 상수" 폴백
    # 6개를 앞 층에 덮어씌우는 일만 하고 있었기 때문이다 — 살아 있는 캘리브레이션
    # 파일에는 `operational` 절 자체가 없다. tuning 앞에 두는 이유는 시나리오가
    # 명시적으로 다르게 갈 여지를 남기기 위해서다. 다만 그 차이는 조용히 넘어가지
    # 않고 아래에서 진단으로 남는다.
    _params_over, _params_diff = _canonical_parameter_overrides(tuning)
    overrides = deep_update(overrides, _params_over)
    overrides = deep_update(overrides, tuning_to_config_overrides(tuning))
    if mode == "fuller-smoke":
        overrides["mpc"].update({
            "leader_candidate_count": 5,
            "max_nash_iter": 2,
        })
    cfg = ExperimentConfig.from_file(config_path, overrides=overrides)
    # 생성자 필드가 아닌 정본 파라미터(runtime 절)를 심는다. 아래 _plant_* 들이
    # 같은 이름을 다시 쓰면 그쪽이 이기는데, 그건 tuning 이 명시적으로 시킨 경우뿐이다.
    _params_runtime = _canonical_runtime_parameters(cfg)
    cfg.__dict__["_canonical_parameters"] = {
        "runtime_applied": _params_runtime,
        "overridden_by_tuning": _params_diff,
        # 캘리브레이션이 정본과 다른 값을 들고 있으면 여기 남는다. 조용히 버려지지 않게.
        "calibration_conflicts": _fd_conflicts(calibration),
    }
    _plant_phase_counts_into(cfg)
    _plant_phase_shape_into(cfg, tuning)
    _plant_rollout_far_into(cfg, tuning)
    _plant_gate_peeloff_into(cfg, tuning)
    _plant_ramp_observation_into(cfg, tuning)
    _plant_ramp_spillback_into(cfg, tuning)
    _plant_agent_topology_into(cfg, tuning)
    return cfg


def _plant_agent_topology_into(cfg, tuning) -> None:
    """tuning 의 `agent_topology` 절을 런타임 속성으로 심는다 (2026-08-20).

        freeway_granularity   "segment"(기본) | "link"

    **plant 모델을 바꾸지 않는다.** `freeway_segments_per_link` 도 `ramps` 도 그대로라
    METANET 롤아웃은 여전히 2링크 x 8세그먼트 = 16셀 + 램프 4개를 굴린다. 바뀌는 것은
    `build_agent_specs` 의 **agent 분할**뿐이다 — 누가 어느 레버를 소유하고 어느 셀을 보는가.

      segment  agent 16개. 각자 자기 1셀만 본다. VSL 은 링크당 1개뿐이라 8 agent 가
               하나를 공유하고 합의가 안 된다(실측 vsl_selected 100.0/120.0 로 갈림).
      link     agent 2개. 각자 VSL 1 + 램프 2 = 액션 3개를 정확히 소유하고,
               segment_index<0 이라 해석부가 자기 링크 8셀을 **전부** 본다.

    `phase_shape`/`rollout_far` 와 같은 이유로 dataclass 필드를 안 늘린다 —
    `src/models/state.py` 를 건드리면 앵커 등재가 하나 더 는다.
    """
    section = (tuning or {}).get("agent_topology")
    if not isinstance(section, Mapping):
        return
    if "freeway_granularity" in section:
        setattr(cfg.mpc, "freeway_agent_granularity", str(section["freeway_granularity"]))


def _plant_rollout_far_into(cfg, tuning) -> None:
    """tuning 의 `rollout_far` 절을 런타임 속성으로 심는다 (2026-08-20).

    far(MFD tail) terminal cost 는 `mfd_far_cost_to_go` 로 이미 구현돼 있고
    `cfg.mpc.leader_mfd_far_enabled` 도 상류 기본이 True 다. 그런데 분산 경로
    (`distributed_coordinator._evaluate_grid_candidate`)가 `ObjectiveSpec` 을
    `score_mode="raw"` 로 만들어 far 를 계산조차 하지 않았다 — 실런 진단에 far 키가 0건이다.

        enabled     분산 rollout 채점에 far 를 태운다 (기본 False = 비트동일)
        ncrit       urban reservoir 임계 누적[veh] (상류 기본 1700)
        g_free      임계 미만 배수율, g_cong 임계 초과 배수율
        weight      far 가중치 (1.0 이 물리 정확값)

    `phase_shape` 와 같은 이유로 dataclass 필드를 안 늘린다 —
    `src/models/state.py` 를 건드리면 앵커 등재가 하나 더 는다.
    """
    # 2026-08-27. 기본값은 `evaluation/parameters.json` 의 runtime.mpc 가 갖는다 —
    # 여기에 상수를 박지 않는다. 종전에는 절이 없으면 그대로 돌아가서
    # False 로 읽어 far 를 계산조차 하지 않았다. 24단 튜닝 체인 어디에도 `rollout_far`
    # 절이 없었으므로 실런에서 far 는 한 번도 돌지 않았다 — plantfix_20260827 의 결정
    # 37개를 훑으면 far 진단 키가 0회다. far 는 urban(N^2/2G, boundary 큐 포함)과
    # freeway(본선 N^2/2G_fw + ramp 큐 bilinear)를 함께 담는다(state.py:564).
    section = (tuning or {}).get("rollout_far")
    if not isinstance(section, Mapping):
        section = {}
    mpc = cfg.mpc
    # 2026-09-03: `enabled` 키는 무시한다 — 팔로워 far 자체를 삭제했다.
    for key, cast in (("ncrit", float), ("g_free", float), ("g_cong", float),
                      ("g_fw", float), ("weight", float)):
        if key in section:
            setattr(mpc, f"leader_mfd_far_{key}", cast(section[key]))


FAR_MEASUREMENT_LINKS_CSV = WORKSPACE_ROOT / "evaluation/real_world_modi_inventory/far_measurement_links_20260901.csv"

# 씨앗. 첫 결정에는 직전 추정치가 없고, 워밍업 구간의 이탈은 용량이 아니라 수요다
# (실측: t=300 에서 도시 145 veh/T_c, 정상상태 565 의 26%). 씨앗 없이 시작하면 리더가
# 초반 열 번쯤 도시부를 실제보다 4배 비싸게 본다 — far 가 N^2/(2G) 라 G 가 1/4 이면 far 4배다.
# .fzp 정답지의 **구간 최대값**을 쓴다(평균이 아니다 — 러닝맥스가 추정하는 것은 용량이다).
FAR_MEASURED_SEED_JSON = WORKSPACE_ROOT / "outputs/far_rates_fzp_truth_20260901.json"


def _far_measured_seed() -> dict[str, float]:
    """정답지 JSON -> {저수지: 씨앗값}. 없으면 빈 dict(씨앗 없이 0 에서 출발)."""
    if not FAR_MEASURED_SEED_JSON.is_file():
        return {}
    try:
        doc = json.loads(FAR_MEASURED_SEED_JSON.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    sm = _mapping(doc.get("summary"))
    out: dict[str, float] = {}
    for key, src, field in (
        ("urban", "urban_exit_veh_per_Tc", "max_veh_per_Tc"),
        ("fw", "fw_exit_veh_per_Tc", "max_veh_per_Tc"),
    ):
        v = _as_float(_mapping(sm.get(src)).get(field), 0.0)
        if v > 0.0:
            out[key] = v
    for ramp in ("R_D_W", "R_F_W", "R_D_E", "R_F_E"):
        # merge_cross = 전이 계수. conn(커넥터 유일차량)은 체류가 구간 경계를 걸쳐
        # 1.14~1.33배 과대다 — 그쪽을 쓰면 안 된다.
        v = _as_float(_mapping(sm.get("merge_cross_" + ramp)).get("max_veh_h"), 0.0)
        if v > 0.0:
            out["ramp_" + ramp] = v
    return out

# far 는 자유/혼잡 두 배수율을 쓰고 `n_u < n_crit` 로 가른다. 이 망은 **항상 혼잡 쪽**이다 —
# 실측 n_u 가 37/37 결정에서 2,974~13,742 인데 n_crit 은 1,700 이다. 그래서
#   (1) 관측된 방류율은 전부 **혼잡 분기**의 값이다. 실측치는 g_cong 에 넣어야 한다.
#   (2) g_free 는 이 망에서 한 번도 안 쓰인다. vendor 낙차 비(500/640)로 역산해 채워만 둔다.
# 처음엔 반대로 넣었다(측정 -> g_free). 그러면 실제 쓰이는 값이 22% 낮아진다.
FAR_G_CONG_RATIO = 500.0 / 640.0

# 바닥값[veh/T_c]. far 가 N^2/(2G) 라 G 가 작으면 폭발한다(vendor 는 max(G,1) 만 건다).
# warmup·관측 실패로 0 에 가까운 값이 들어오면 리더가 도시부를 무한대로 비싸게 본다.
FAR_RATE_FLOOR_VEH_TC = 50.0
FAR_RAMP_FLOOR_VEH_H = 120.0


def _far_measurement_reservoirs() -> dict[str, list[str]]:
    """측정 지점 대장 -> {저수지: [링크...]}. 생성기 scripts/build_far_measurement_links_20260901.py"""
    out: dict[str, list[str]] = {}
    if not FAR_MEASUREMENT_LINKS_CSV.is_file():
        return out
    import csv as _csv
    with FAR_MEASUREMENT_LINKS_CSV.open(encoding="utf-8", newline="") as fh:
        for row in _csv.DictReader(fh):
            if str(row.get("role", "")).strip() == "drain_departures":
                continue  # 본선은 링크평가가 아니라 집합 이탈로 잰다
            res = str(row.get("reservoir", "")).strip()
            link = str(row.get("link", "")).strip()
            if res and link:
                out.setdefault(res, []).append(link)
    return out



BOUNDARY_OUT_RAMP_SPLIT_JSON = WORKSPACE_ROOT / "outputs/boundary_out_ramp_split_20260901.json"


def install_boundary_out_ramp_split(cfg, tuning) -> dict[str, float]:
    """경계 out 링크의 이탈을 목적지별로 쪼갠다. `urban.boundary_out.ramp_split` 없으면 no-op.

    왜. 경계 out 링크 일부는 하류가 **on-ramp** 다 — `SC1001_W_out` 은 링크 31 로 나가고
    거기서 미터 10480(R_D_W)·10484(R_D_E)로 갈린다. 그런데 이탈이 전부
    `boundary_out_capacity_veh_h`(일괄 1600 vph)로 자유롭게 빠져, **램프가 꽉 차도 도시가
    아무 제약을 못 느낀다.** 소비처는 urban_queue_model 의 유한 출구 블록이고, 거기서
    램프행만 `min(ramp_space, 미터방출)` 로 막는다. 못 나간 차량이 out 링크에 쌓여
    receiving 게이트를 통해 grid 로 backup 이 전파된다.

    비램프 출구는 1600 그대로 둔다(사용자 결정 2026-09-01) — 모델 밖으로 사라지는 도로라
    그 backup 은 목적함수에 영향이 없다.

    SC1004 는 뺀다. leg 이름과 물리 링크가 1:1 이 아니다(`OUT_W` 가 링크 68, `OUT_S` 가
    68·67 양쪽) — 링크 67·68 의 leg 귀속이 권역 정본에 없어 추론으로 채우면
    CLAUDE.md 가 경고한 player 권역 사고의 재발이다.
    """
    section = _mapping(_mapping(_mapping(tuning).get("urban")).get("boundary_out"))
    if not _is_enabled_value(section.get("ramp_split")):
        return {"boundary_out_ramp_split_enabled": 0.0}
    # 2026-09-05. 분할표 경로를 config 로 바꿀 수 있다(`urban.boundary_out.ramp_split_json`, 작업공간 상대경로).
    # 키가 없으면 종전 20260901 표 = 비트 동일. B2(실측 램프 방향 분율)가 이 키 하나로 켜진다.
    split_path = BOUNDARY_OUT_RAMP_SPLIT_JSON
    override = str(section.get("ramp_split_json") or "").strip()
    if override:
        split_path = Path(override) if Path(override).is_absolute() else (WORKSPACE_ROOT / override)
    if not split_path.is_file():
        raise SystemExit("BOUNDARY_OUT_RAMP_SPLIT_MISSING: %s" % split_path)
    doc = json.loads(split_path.read_text(encoding="utf-8"))
    split: dict[str, dict[str, object]] = {}
    ramps = set(cfg.network.ramps or ())
    storage = set(cfg.network.urban_link_storage_veh or {})
    for link, spec in _mapping(doc.get("links")).items():
        link = str(link)
        if link not in storage:
            raise SystemExit("BOUNDARY_OUT_RAMP_SPLIT_UNKNOWN_LINK: %s" % link)
        by_ramp = {str(k): float(v) for k, v in _mapping(spec.get("ramps")).items()}
        unknown = sorted(r for r in by_ramp if r not in ramps)
        if unknown:
            raise SystemExit("BOUNDARY_OUT_RAMP_SPLIT_UNKNOWN_RAMP: %s" % ", ".join(unknown))
        free = float(spec.get("free", 0.0))
        total = free + sum(by_ramp.values())
        if abs(total - 1.0) > 1.0e-6:
            # 합이 1 이 아니면 질량이 새거나 늘어난다. 조용히 정규화하지 않는다.
            raise SystemExit("BOUNDARY_OUT_RAMP_SPLIT_NOT_UNITY: %s 합=%.6f" % (link, total))
        split[link] = {"free": free, "ramps": by_ramp}
    setattr(cfg.network, "boundary_out_ramp_split", split)
    out: dict[str, float] = {"boundary_out_ramp_split_enabled": 1.0,
                             "boundary_out_ramp_split_links": float(len(split))}
    out["boundary_out_ramp_split_json_override"] = 1.0 if override else 0.0
    for link, spec in split.items():
        out["boundary_out_ramp_split_%s_free" % link] = float(spec["free"])
        for ramp, share in spec["ramps"].items():
            out["boundary_out_ramp_split_%s_%s" % (link, ramp)] = float(share)
    return out
def install_measured_far_reservoir_rates(cfg, tuning, state_json, previous_path) -> dict[str, float]:
    """far 의 배수율 셋을 **직전 구간 VISSIM 실측**으로 갈아끼운다.

    `rollout_far.measured` 가 없으면 no-op(비트 동일)이다.

    왜. far(stackelberg_mpc.py:88)의 배수율이 전부 vendor 상수였다 —
    도시 G 640/500 · 본선 g_fw 300 [veh/T_c] · 램프 merge = ramp_capacity(1800) x recv.
    far 는 N^2/(2G) 형태라 G 가 배수 곱이 아니라 **곡률**을 정한다. 상수면 리더가
    저수지를 얼마나 빨리 비울 수 있는지를 데이터가 아니라 가정으로 판단한다.
    실측(.fzp 정답지, outputs/far_rates_fzp_truth_20260901.json): 본선 실측 평균이
    481.9 인데 상수는 300 이라 방류능력을 1.6~2.0배 과소평가하고 있었다.

    무엇을 읽나. 러너 VBS 가 결정마다 `local_observation.far_measurement` 를 싣는다.
      link_volume_veh_h  VISSIM 링크평가 Volume[veh/h]. 커넥터는 짧아 모든 차량이
                         구간 안에서 완주하므로 x interval/3600 이 통과대수와 정확히 같다.
      freeway_exit_count 본선 체인 집합 이탈 대수[veh/구간]. 본선은 하류 끝에서 차량이
                         망을 떠나 잴 커넥터가 없으므로 5초 스캔 전이로 센다.

    수요제약을 어떻게 거르나. 한산한 구간의 이탈은 용량이 아니라 수요다.
    `install_measured_movement_capacity` 와 같은 **감쇠 러닝맥스**를 쓴다 —
    증거가 나오면 즉시 올라가고 없으면 천천히 잊는다. 어댑터는 결정마다 새 프로세스라
    직전 추정치를 **직전 action JSON 진단**으로 나른다.

    램프는 왜 따로 도나. far 는 `net.ramp_capacity_veh_h[ramp]` 를 읽는데 그 dict 는
    far 전용이 아니다 — `_force_open_ramps`(개방=용량) · `_candidate_bounds` 의 N_UF
    상한 · ramp_arrival 클램프 · wu 팔로워 미터 상한이 같은 것을 읽는다. 거기를 낮추면
    배수율이 아니라 **레버 자체**가 잘린다(N_UF 상한 5000 이 매 결정 램프 유입을 30.6%
    차단했던 사고와 같은 자리다). 그래서 값을 `cfg.network.far_ramp_capacity_veh_h` 에
    따로 얹고, `install_far_ramp_capacity_patch` 가 far 호출 동안만 스왑한다.
    """
    section = _mapping(_mapping(tuning).get("rollout_far"))
    if not _is_enabled_value(section.get("measured")):
        return {"far_measured_enabled": 0.0}
    # 감쇠 기본 0.995. `install_measured_movement_capacity` 의 0.98 을 그대로 쓰면 안 된다 —
    # 그쪽은 movement 별 녹색이 매 결정 바뀌므로 빨리 잊는 게 맞지만, 저수지 방류 **용량**은
    # 런 안에서 물리적으로 안 변한다. 0.98 은 36결정에 씨앗의 48% 로 내려간다.
    # 실측(2026-09-01 canon_far_d00): 수요가 꺾이는 후반에 g_cong 이 vendor 상수 500 아래로
    # 12/37 결정 내려갔다(최저 394) — 고치려던 방향의 반대다. 0.995 면 36결정에 83.5% 다.
    # (g_fw 는 상수 300 이 워낙 낮아 37/37 에서 위였다.)
    decay = _as_float(section.get("measured_decay"), 0.995)

    fm = _mapping(_mapping(state_json.get("local_observation")).get("far_measurement"))
    if not fm:
        # 러너가 아직 이 채널을 안 싣는다(옛 VBS). 상수 그대로 두고 시끄럽게 남긴다.
        return {"far_measured_enabled": 1.0, "far_measured_channel_missing": 1.0}
    interval = _as_float(fm.get("interval_sec"), 0.0)
    vols = {str(k): _as_float(v, -1.0) for k, v in _mapping(fm.get("link_volume_veh_h")).items()}
    fw_exit = _as_float(fm.get("freeway_exit_count"), -1.0)
    if interval <= 0.0:
        return {"far_measured_enabled": 1.0, "far_measured_bad_interval": 1.0}

    groups = _far_measurement_reservoirs()
    read_err = sum(1 for v in vols.values() if v < 0.0)

    # 관측 -> 저수지별 이번 구간 값
    obs: dict[str, float] = {}
    urban_links = groups.get("urban") or []
    if urban_links:
        got = [vols[k] for k in urban_links if vols.get(k, -1.0) >= 0.0]
        if got:
            # veh/h 합 -> veh/T_c
            obs["urban"] = sum(got) * interval / 3600.0
    if fw_exit >= 0.0:
        obs["fw"] = fw_exit
    for res, links in groups.items():
        if not res.startswith("ramp_"):
            continue
        got = [vols[k] for k in links if vols.get(k, -1.0) >= 0.0]
        if got:
            obs[res] = sum(got)  # far 는 램프를 veh/h 로 받는다

    # 직전 추정치 (감쇠 러닝맥스 이월)
    prev_est: dict[str, float] = {}
    try:
        prev_doc = json.loads(Path(previous_path).read_text(encoding="utf-8"))
        for holder in ("metadata", "diagnostics"):
            for key, value in _mapping(prev_doc.get(holder)).items():
                if key.startswith("far_rate_est_"):
                    prev_est[key[len("far_rate_est_"):]] = _as_float(value, 0.0)
    except (OSError, ValueError):
        pass
    seeded = 0.0
    if not prev_est and _is_enabled_value(section.get("measured_seed", True)):
        prev_est = _far_measured_seed()
        seeded = float(len(prev_est))

    est: dict[str, float] = {}
    for key in set(list(obs) + list(prev_est)):
        est[key] = max(obs.get(key, 0.0), decay * prev_est.get(key, 0.0))

    out: dict[str, float] = {
        "far_measured_enabled": 1.0,
        "far_measured_interval_sec": interval,
        "far_measured_points": float(len(vols)),
        "far_measured_read_errors": float(read_err),
        "far_measured_seeded": seeded,
    }
    for key, value in sorted(est.items()):
        out["far_rate_est_" + key] = float(value)
    for key, value in sorted(obs.items()):
        out["far_rate_obs_" + key] = float(value)

    mpc = cfg.mpc
    # 도시 G. 바닥 미만이면 손대지 않는다 — 0 에 가까운 G 는 far 를 폭발시킨다.
    g_urban = est.get("urban", 0.0)
    if g_urban >= FAR_RATE_FLOOR_VEH_TC:
        # 실측치 -> g_cong (이 망은 항상 n_u >= n_crit 이라 관측이 전부 혼잡 분기다).
        # g_free 는 안 쓰이지만 두 값의 대소가 뒤집히면 안 되므로 비로 역산해 채운다.
        setattr(mpc, "leader_mfd_far_g_cong", float(g_urban))
        setattr(mpc, "leader_mfd_far_g_free", float(g_urban / FAR_G_CONG_RATIO))
        out["far_measured_g_cong"] = float(g_urban)
        out["far_measured_g_free"] = float(g_urban / FAR_G_CONG_RATIO)
    else:
        out["far_measured_g_urban_below_floor"] = 1.0
    # 본선 g_fw
    g_fw = est.get("fw", 0.0)
    if g_fw >= FAR_RATE_FLOOR_VEH_TC:
        setattr(mpc, "leader_mfd_far_g_fw", float(g_fw))
        out["far_measured_g_fw"] = float(g_fw)
    else:
        out["far_measured_g_fw_below_floor"] = 1.0
    # 램프 merge_rate — far 전용 dict 에만 얹는다
    base = dict(getattr(cfg.network, "ramp_capacity_veh_h", {}) or {})
    far_caps = dict(base)
    applied = 0
    for res, value in est.items():
        if not res.startswith("ramp_"):
            continue
        ramp = res[len("ramp_"):]
        if ramp not in base:
            raise SystemExit("FAR_MEASURED_UNKNOWN_RAMP: %s (config ramps=%s)" % (ramp, sorted(base)))
        if value >= FAR_RAMP_FLOOR_VEH_H:
            far_caps[ramp] = float(value)
            applied += 1
            out["far_measured_merge_%s_veh_h" % ramp] = float(value)
    if applied:
        setattr(cfg.network, "far_ramp_capacity_veh_h", far_caps)
    out["far_measured_ramps_applied"] = float(applied)
    return out


def install_far_ramp_capacity_patch(cfg) -> dict[str, float]:
    """far 만 다른 램프 용량을 보게 한다. cfg 에 값이 없으면 아무것도 안 한다(비트 동일).

    왜 모듈 패치인가. `mfd_far_cost_to_go` 는 stackelberg_mpc 의 **모듈 전역**이고 살아 있는
    호출부 둘이 모두 호출 시점에 그 전역을 다시 찾는다 —
      stackelberg_mpc.py:2463   메서드 본문의 전역 이름 조회
      rollout_endpoint.py:406   함수 안 `from ... import` (실행 시점 해석)
    어느 모듈도 import 시점에 이 이름을 자기 전역으로 묶지 않는다. 속성 하나만 갈아끼우면
    두 곳이 다 덮인다. vendor 는 한 줄도 안 고친다.

    왜 스왑-복원인가. 설치 시점에 cfg.network 를 복사해 두면 뒤에 도는 install_* 들의
    변경이 far 쪽에 안 따라온다. 살아 있는 객체를 호출 동안만 바꾸고 finally 로 되돌린다.
    현행 백엔드가 전부 serial 이라 재진입이 없다 — **스레드 백엔드를 켜면 이 스왑이 경합이 된다.**
    """
    caps = getattr(cfg.network, "far_ramp_capacity_veh_h", None)
    if not caps:
        return {"far_ramp_capacity_override": 0.0}
    far_caps = {str(k): float(v) for k, v in dict(caps).items()}
    import src.controllers.stackelberg_mpc as _sm
    if not hasattr(_sm, "_rw_orig_mfd_far_cost_to_go"):
        _sm._rw_orig_mfd_far_cost_to_go = _sm.mfd_far_cost_to_go
    _orig = _sm._rw_orig_mfd_far_cost_to_go

    def _far_with_measured_ramp_capacity(c, state):
        net = c.network
        saved = net.ramp_capacity_veh_h
        net.ramp_capacity_veh_h = far_caps
        try:
            return _orig(c, state)
        finally:
            net.ramp_capacity_veh_h = saved

    _sm.mfd_far_cost_to_go = _far_with_measured_ramp_capacity
    _sm._rw_far_ramp_capacity_active = True
    out: dict[str, float] = {"far_ramp_capacity_override": 1.0}
    out.update({"far_ramp_capacity_%s_veh_h" % r: v for r, v in sorted(far_caps.items())})
    return out


def _plant_phase_shape_into(cfg, tuning) -> None:
    """tuning 의 `phase_shape` 절을 런타임 속성으로 심는다 (2026-08-20).

    dataclass 필드로 넣지 않는 이유는 `ExperimentConfig.from_dict` 가 strict 라
    `src/models/state.py` 를 건드리게 되고, 그러면 앵커 등재가 하나 늘기 때문이다.
    vendor 쪽은 전부 `getattr(..., 기본값)` 으로만 읽으므로 안 심으면 오늘과 같다.

        mode / weight        압력 shape 주입 (3단계, 아직 vendor 미구현)
        search               쌍교환 탐색 stage 켜기
        steps_sec            교환 스텝 사다리
        signal_top_k         압력 치우침 상위 k 신호만
        candidate_limit      하드캡
    """
    section = (tuning or {}).get("phase_shape")
    if not isinstance(section, Mapping):
        return
    uf = cfg.urban_follower
    if "search" in section:
        setattr(uf, "phase_shape_search", bool(section["search"]))
    if "steps_sec" in section:
        setattr(uf, "phase_shape_steps_sec", tuple(float(x) for x in section["steps_sec"]))
    for key, cast in (("signal_top_k", int), ("candidate_limit", int),
                      ("weight", float), ("mode", str)):
        if key in section:
            setattr(uf, f"phase_shape_{key}", cast(section[key]))


def _plant_phase_counts_into(cfg) -> None:
    """계획이 센 SC별 현시 수를 모델에 심는다.

    이걸 안 심으면 모델은 legacy 스칼라 모드로 떨어져 전 SC 에 같은 예산을 준다. 실 망은
    SC107·108·109 가 3현시라(한 현시의 SG 가 `.sig` 에서 영구적색) 그 셋만 예산이 3 s 더
    커야 한다. 스칼라로 밀면 그 3 s 가 죽은 현시로 흘러가 실현 0 이 된다.

    계획은 config 뒤에 유도되므로 config 생성기가 이 값을 알 수 없다 — 두 산출물을 모두
    쥐고 있는 여기가 유일하게 순환이 없는 자리다. 계획이 없으면 아무것도 안 한다.
    """
    plan = load_signal_group_actuation_plan()
    if not plan:
        return
    live = {
        f"SC{int(sc_no)}": list(plan_live_phases(plan, int(sc_no)))
        for sc_no in (plan.get("controllers") or {})
    }
    if not live:
        return
    cfg.network.live_phases_by_signal = live


# 게이트 상류에서 램프로 빠지는 몫 (2026-09-01).
#
# 왜. 게이트 `in_SC1001_W`(vehicleInput no 1102, 링크 32, 피크 1,400 vph)의 주입량 중
# **70%가 SC1001 정지선에 닿기 전에 본선으로 빠진다.** 램프미터가 정지선보다 상류에 있다 —
#   링크 32 길이 1,963.4 m · SC1001 신호두 pos ~1955(정지선)
#   RM_C10482 pos 1028.6 (정지선 926 m 상류) · RM_C10490 pos 1330.6 (624 m 상류)
# 그 차량은 SC1001 신호를 아예 만나지 않으므로 녹색으로 배분을 바꿀 수 없고,
# 커넥터 10482·10490 은 권역 정본에서 **freeway 플레이어 소유**다.
# 그런데 게이트맵은 1,400 전량을 도시부로 귀속시켜, 모델이 도시망에 ~974 vph 를 과다 주입한다.
#
# 선례. 같은 상황의 링크 69(vehicleInput no 1101, 1,400 vph, 69%가 RM_C10644 로 이탈)는
# 이미 `shared_stem_unmapped` 로 게이트를 안 준다 (CLAUDE.md 'SC1004 서측' 절).
# 링크 32 만 그 처리를 못 받았다. 이 상수는 그 규칙을 일관되게 적용한다.
#
# 왜 통째로 빼지 않고 차감인가. 링크 69 는 무소유 줄기지만 링크 32 는 SC1001 정지선이
# 실제로 있고, 램프로 안 빠진 나머지(~426 vph)는 진짜 SC1001 유입이다.
#
# 왜 실측인가. 미터가 조이면 이탈이 줄어 정지선에 더 도착한다 — 정적 상수는 그걸 못 본다.
# 링크평가 채널(local_observation.far_measurement)이 이 커넥터들을 결정마다 재고 있다.
GATE_UPSTREAM_RAMP_PEELOFF: dict[str, tuple[str, ...]] = {
    "in_SC1001_W": ("10482", "10490"),
}


def apply_gate_ramp_peeloff(state_json, cfg, urban_boundary: dict[str, float]) -> dict[str, float]:
    """게이트 도착에서 **정지선 상류 램프 이탈분**을 뺀다. 꺼져 있으면 no-op(비트 동일)."""
    if not bool(getattr(cfg.network, "gate_ramp_peeloff", False)):
        return {"gate_ramp_peeloff_enabled": 0.0}
    fm = _mapping(_mapping(_mapping(state_json).get("local_observation")).get("far_measurement"))
    vols = {str(k): _as_float(v, -1.0) for k, v in _mapping(fm.get("link_volume_veh_h")).items()}
    if not vols:
        return {"gate_ramp_peeloff_enabled": 1.0, "gate_ramp_peeloff_channel_missing": 1.0}
    out: dict[str, float] = {"gate_ramp_peeloff_enabled": 1.0}
    applied = 0
    for gate, conns in GATE_UPSTREAM_RAMP_PEELOFF.items():
        if gate not in urban_boundary:
            # 게이트 이름이 바뀌면 조용히 넘어가지 않는다 — 보정이 통째로 사라지는 사고를 막는다.
            raise SystemExit("GATE_RAMP_PEELOFF_UNKNOWN_GATE: %s (게이트맵과 어긋난다)" % gate)
        got = [vols[c] for c in conns if vols.get(c, -1.0) >= 0.0]
        if not got:
            out["gate_ramp_peeloff_%s_unread" % gate] = 1.0
            continue
        peel = sum(got)
        before = _as_float(urban_boundary.get(gate), 0.0)
        urban_boundary[gate] = max(0.0, before - peel)
        applied += 1
        out["gate_ramp_peeloff_%s_before_vph" % gate] = float(before)
        out["gate_ramp_peeloff_%s_peel_vph" % gate] = float(peel)
        out["gate_ramp_peeloff_%s_after_vph" % gate] = float(urban_boundary[gate])
    out["gate_ramp_peeloff_gates"] = float(applied)
    return out


def _plant_ramp_observation_into(cfg, tuning) -> None:
    """관측 램프큐를 상한으로 자를지. A/B 분해 전용이고 기본은 자르지 않는다.

    `state.py` dataclass 필드를 늘리지 않는다 — setattr 은 컨트롤러와 함께 피클돼
    가격 워커까지 간다(urban_movements 와 같은 논거).
    """
    section = _mapping(_mapping(tuning.get("urban")).get("ramp"))
    setattr(cfg.network, "ramp_observation_clip_to_cap",
            bool(_is_enabled_value(section.get("observation_clip_to_cap", False))))


def _plant_ramp_spillback_into(cfg, tuning) -> None:
    """tuning `urban.ramp.spillback_obs` 를 cfg 로 나른다 (2026-09-07).

    켜면 build_local_observation_summary 가 검지 매핑 `ramp_spillback_links`(램프 커넥터별 전용 상류 링크)의
    **정지 차량**(queue_lanes, conn_pos_m 이하)을 램프 저수지 큐에 더한다. 커넥터 위 차량만 세던 저수지(상한 153)가
    링크 32/69 위 1 km 역류(진짜 큐 262 vs 모형 140, fzp 진단 2026-09-07)를 못 보던 실명 수정. 없으면 비트 동일."""
    section = _mapping(_mapping(_mapping(tuning).get("urban")).get("ramp"))
    setattr(cfg.network, "ramp_spillback_obs", bool(_is_enabled_value(section.get("spillback_obs", False))))


def install_freeway_segment_lanes(cfg, tuning, mapping) -> dict[str, float]:
    """config `freeway.segment_lanes: "mapping"` → control_mapping 의 세그먼트별 차로를 cfg.network 에 싣는다 (2026-09-07).

    Ver2 망은 본선이 한 모형 링크 안에서 차로가 바뀐다(FW_W: 26 3차로 → 120 4차로, FW_E: 2 4차로 → 119/24 3차로).
    종전엔 모형 링크당 단일값(RW_FW_*_LANES)이라 그 세그먼트들의 밀도·용량이 4/3 배 틀렸다. 값이라 컨트롤러와 함께 피클되어
    가격 워커까지 간다. `segment_params` 가 있으면 함께 실어 둔다(합류 세그먼트별 파라미터 실험용 훅; 지금은 소비처 없음)."""
    section = _mapping(_mapping(tuning).get("freeway"))
    mode = str(section.get("segment_lanes", "") or "").strip().lower()
    if mode != "mapping":
        return {"freeway_segment_lanes_enabled": 0.0}
    links = _mapping(_mapping(mapping).get("freeway_model_links"))
    lanes_by: dict[str, list[float]] = {}
    params_by: dict[str, Any] = {}
    for model, spec in links.items():
        spec = _mapping(spec)
        arr = [float(v) for v in (spec.get("segment_lanes") or []) if _as_float(v, 0.0) > 0.0]
        if not arr:
            segs = [s for s in (_mapping(mapping).get("segments") or []) if isinstance(s, Mapping) and str(s.get("model_link")) == str(model)]
            segs.sort(key=lambda s: int(_as_float(s.get("model_segment_index"), 0)))
            arr = [float(_as_float(s.get("lanes"), 0.0)) for s in segs if _as_float(s.get("lanes"), 0.0) > 0.0]
        if arr:
            lanes_by[str(model)] = arr
        if isinstance(spec.get("segment_params"), list):
            params_by[str(model)] = [dict(r) if isinstance(r, Mapping) else {} for r in spec["segment_params"]]
        elif isinstance(spec.get("segment_params"), Mapping):
            params_by[str(model)] = dict(spec.get("segment_params"))
    # `freeway.segment_params` 가 경로면 보정 산출물에서 세그먼트 배열을 만든다
    # (schema freeway_segment_params_v1: segments["FW_E_S3"] = {파라미터...}).
    _pspec = str(section.get("segment_params", "") or "").strip()
    if _pspec and _pspec.lower() != "mapping":
        _root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        with open(_pspec if os.path.isabs(_pspec) else os.path.join(_root, _pspec), encoding="utf-8") as _pf:
            _pj = json.load(_pf)
        _segs = _mapping(_pj.get("segments"))
        _keys = ("v_free", "rho_crit", "rho_max", "metanet_a_m", "metanet_tau_h", "metanet_nu_km2_h",
                 "metanet_nu_cong_km2_h", "metanet_kappa_veh_km_lane", "segment_length_km")
        for model, arr in lanes_by.items():
            rows = []
            for i in range(len(arr)):
                row = _mapping(_segs.get("%s_S%d" % (model, i)))
                rows.append({k: float(row[k]) for k in _keys
                             if isinstance(row.get(k), (int, float)) and not isinstance(row.get(k), bool)})
            params_by[str(model)] = rows
    setattr(cfg.network, "freeway_segment_lanes", lanes_by)
    setattr(cfg.network, "freeway_segment_params", params_by)
    out = {"freeway_segment_lanes_enabled": 1.0 if lanes_by else 0.0, "freeway_segment_lanes_links": float(len(lanes_by))}
    for model, arr in lanes_by.items():
        out["freeway_segment_lanes_min_%s" % model] = float(min(arr))
        out["freeway_segment_lanes_max_%s" % model] = float(max(arr))
    return out


# ---------------------------------------------------------------------------
# 세그먼트별 본선 파라미터 (2026-09-07) — 값 적재는 install_freeway_segment_lanes,
# 모듈 패치는 install_freeway_segment_runtime. 가격 워커(spawn)는 후자를 다시 부른다.
# ---------------------------------------------------------------------------
_FW_SEG_CTX: dict[str, Any] = {"p": {}, "armed": False}
# effective_lane_profile 패치가 현재 state 를 여기 남겨 두면 차로감소항이 유효 차로를 읽을 수 있다.
_FW_SEG_CTX_STATE: dict[str, Any] = {"profile": None, "lane_drop_fired": 0}


def _fw_seg_param_dict(net, link, idx) -> Mapping:
    """(link, idx) 세그먼트의 파라미터 사전. 없으면 빈 dict → 링크 스칼라 그대로."""
    tbl = getattr(net, "freeway_segment_params", None) or {}
    if not isinstance(tbl, Mapping):
        return {}
    arr = tbl.get(str(link))
    if isinstance(arr, (list, tuple)) and 0 <= int(idx) < len(arr):
        row = arr[int(idx)]
        if isinstance(row, Mapping):
            return row
    return {}


def _fw_rebind(name: str, old, new) -> float:
    """`from ... import name` 으로 이름을 복사해 간 모듈까지 전부 재바인딩(5모듈 패치와 같은 사유)."""
    import sys as _sys
    n = 0
    for mod in list(_sys.modules.values()):
        if mod is None:
            continue
        try:
            if getattr(mod, name, None) is old:
                setattr(mod, name, new)
                n += 1
        except Exception:
            continue
    return float(n)


_FW_VSL_DEDUPE_STATE: dict[str, int] = {"tasks": 0, "rollouts": 0}


def install_freeway_vsl_price_dedupe(cfg, tuning=None) -> dict[str, float]:
    """VSL 가격 코너 중 **실효 제어가 같은** 태스크를 하나로 묶어 롤아웃 수를 줄인다.

    구역이 설치돼 있어야 의미가 있다(머리가 아닌 셀의 섭동이 무효가 되는 것이 전제다).
    반환값은 종전과 같은 (seg_key, 'lo'|'hi') -> 튜플 이고, 값도 같다.
    """
    if not (getattr(cfg.network, "freeway_vsl_zone_head_of_cell", None) or {}):
        return {"fw_vsl_price_dedupe_enabled": 0.0}
    import src.controllers.stackelberg_wu_metered as _swm

    _cls = _swm.StackelbergWuMeteredController if hasattr(
        _swm, "StackelbergWuMeteredController") else None
    if _cls is None:
        for _name in dir(_swm):
            _obj = getattr(_swm, _name)
            if isinstance(_obj, type) and hasattr(_obj, "_vsl_price_rollouts"):
                _cls = _obj
                break
    if _cls is None:
        return {"fw_vsl_price_dedupe_enabled": 0.0}
    _orig = _cls._vsl_price_rollouts
    if getattr(_orig, "_rw_vsl_dedupe", False):
        return {"fw_vsl_price_dedupe_enabled": 1.0, "fw_vsl_price_dedupe_patched": 0.0}
    _worker = _swm._price_worker_vsl

    def _patched_vsl_price_rollouts(self, state, previous, forecast, v_corners, vsl_upper):
        net = self.cfg.network
        head_tbl = _mapping(getattr(net, "freeway_vsl_zone_head_of_cell", None) or {})
        if not head_tbl:
            return _orig(self, state, previous, forecast, v_corners, vsl_upper)

        tasks = []
        for key, (_x0, v_lo, v_hi, link, _req) in v_corners.items():
            if float(v_hi) - float(v_lo) <= 1.0e-9:
                continue
            tasks.append((key, "hi", link, float(v_hi), vsl_upper))
            tasks.append((key, "lo", link, float(v_lo), vsl_upper))
        if not tasks:
            return {}

        prev_vsl = dict(previous.vsl or {})

        def effective(seg_key, link, value):
            base = dict(prev_vsl)
            base[str(seg_key)] = float(value)
            base[str(link)] = min(float(base.get(str(link), value)), float(value))
            arr = head_tbl.get(str(link)) or []
            fallback = float(base.get(str(link), value))
            vec = []
            for j in range(len(arr)):
                vec.append(round(float(base.get("%s__seg%d" % (link, int(arr[j])), fallback)), 9))
            return (str(link), tuple(vec), round(float(base[str(link)]), 9))

        groups: dict = {}
        for t in tasks:
            groups.setdefault(effective(t[0], t[2], t[3]), []).append(t)
        reps = [g[0] for g in groups.values()]

        def serial():
            return {
                (k, w): (self._global_rollout_ttt_with_vsl(
                    state, previous, forecast, link, k, val, up),)
                for k, w, link, val, up in reps
            }

        got = self._price_batch(reps, _worker, serial, state, previous, forecast)
        out = {}
        for members in groups.values():
            rep = members[0]
            value = got.get((rep[0], rep[1]))
            for m in members:
                out[(m[0], m[1])] = value
        _FW_VSL_DEDUPE_STATE["tasks"] = len(tasks)
        _FW_VSL_DEDUPE_STATE["rollouts"] = len(reps)
        return out

    _patched_vsl_price_rollouts._rw_vsl_dedupe = True
    _cls._vsl_price_rollouts = _patched_vsl_price_rollouts
    return {"fw_vsl_price_dedupe_enabled": 1.0, "fw_vsl_price_dedupe_patched": 1.0}


def install_freeway_vsl_zones(cfg, tuning=None) -> dict[str, float]:
    """VSL 자유도를 표지판 구역으로 묶는다. 셀은 자기 구역 머리의 값을 쓴다.

    `freeway.vsl_zone_heads` 가 없으면 아무것도 안 한다(비트 동일).
    """
    section = _mapping(_mapping(tuning).get("freeway")) if tuning is not None else {}
    net = cfg.network
    heads_cfg = _mapping(section.get("vsl_zone_heads"))
    if not heads_cfg:
        # 가격 워커(spawn)는 tuning 을 못 받는다. 값은 cfg.network 로 피클돼 오므로 그걸 되읽어
        # **모듈 패치만** 다시 심는다 - 안 심으면 워커 10개가 셀 단위 VSL 로 가격을 매긴다.
        heads_cfg = _mapping(getattr(net, "freeway_vsl_zone_heads", None) or {})
        if not heads_cfg:
            return {"fw_vsl_zones_enabled": 0.0}

    lanes_tbl = _mapping(getattr(net, "freeway_segment_lanes", None) or {})
    heads: dict = {}
    head_of: dict = {}
    zone_of: dict = {}
    for link in net.freeway_links:
        n = len(lanes_tbl.get(str(link)) or []) or int(net.freeway_segments_per_link)
        hs = sorted({int(x) for x in (heads_cfg.get(str(link)) or [])})
        if not hs:
            continue
        if hs[0] != 0:
            raise ValueError("VSL 구역 머리는 셀 0 을 포함해야 한다: %s %s" % (link, hs))
        if hs[-1] >= n:
            raise ValueError("VSL 구역 머리가 셀 수를 넘는다: %s %s (셀 %d)" % (link, hs, n))
        hd, zo = [], []
        for i in range(n):
            z = 0
            for j, h in enumerate(hs):
                if h <= i:
                    z = j
            zo.append(z)
            hd.append(hs[z])
        heads[str(link)] = hs
        head_of[str(link)] = hd
        zone_of[str(link)] = zo
    if not heads:
        return {"fw_vsl_zones_enabled": 0.0}

    free_cfg = section.get("vsl_zone_free")
    if free_cfg is None:
        free_cfg = getattr(net, "freeway_vsl_zone_free", None)
    n_zone = max(len(v) for v in heads.values())
    free = sorted({int(x) for x in free_cfg}) if free_cfg is not None else list(range(n_zone))

    setattr(net, "freeway_vsl_zone_heads", heads)
    setattr(net, "freeway_vsl_zone_head_of_cell", head_of)
    setattr(net, "freeway_vsl_zone_of_cell", zone_of)
    setattr(net, "freeway_vsl_zone_free", free)

    out = {"fw_vsl_zones_enabled": 1.0, "fw_vsl_zone_count": float(n_zone),
           "fw_vsl_zone_free_count": float(len(free))}
    for link, hs in heads.items():
        out["fw_vsl_zone_heads_%s" % link] = float(len(hs))

    # `segment_vsl` 을 구역 인식으로. 롤아웃·가격·플랜트 쓰기가 전부 이 함수를 거치므로
    # 한 자리에서 셋이 같이 맞는다.
    import src.models.state as _st
    _o_sv = _st.segment_vsl
    if not getattr(_o_sv, "_rw_vsl_zone", False):
        def _zoned_segment_vsl(control, link, i, cfg_):
            tbl = getattr(cfg_.network, "freeway_vsl_zone_head_of_cell", None) or {}
            arr = tbl.get(str(link))
            if arr:
                idx = int(i)
                if 0 <= idx < len(arr):
                    i = int(arr[idx])
            return _o_sv(control, link, i, cfg_)

        _zoned_segment_vsl._rw_vsl_zone = True
        out["fw_vsl_zone_rebind"] = _fw_rebind("segment_vsl", _o_sv, _zoned_segment_vsl)
        _st.segment_vsl = _zoned_segment_vsl

    # `local_vsl_costs` 는 세그먼트 벡터를 `vsl_override` 로 **직접** 먹여 segment_vsl 을
    # 우회한다. 구역 밖 셀을 흔든 벡터가 그대로 들어가면 국소 채점만 구역을 안 지킨다 -
    # 요청 벡터를 구역으로 사영해 맞춘다.
    from src.controllers import wu_faithful_follower as _wff
    _cls = _wff.WuFaithfulFollower
    _o_lvc = getattr(_cls, "local_vsl_costs", None)
    if _o_lvc is not None and not getattr(_o_lvc, "_rw_vsl_zone", False):
        def _zoned_local_vsl_costs(self, requests, state, previous, demand, *a, **k):
            tbl = getattr(self.cfg.network, "freeway_vsl_zone_head_of_cell", None) or {}
            if tbl and isinstance(requests, Mapping):
                proj = {}
                for link, vecs in requests.items():
                    arr = tbl.get(str(link))
                    if not arr:
                        proj[link] = vecs
                        continue
                    proj[link] = [[float(v[int(arr[i])]) if int(arr[i]) < len(v) else float(v[i])
                                   for i in range(len(v))] for v in vecs]
                requests = proj
            return _o_lvc(self, requests, state, previous, demand, *a, **k)

        _zoned_local_vsl_costs._rw_vsl_zone = True
        _cls.local_vsl_costs = _zoned_local_vsl_costs
        out["fw_vsl_zone_local_costs_patched"] = 1.0
    return out


def install_freeway_vsl_sequence_kbest(cfg, tuning=None) -> dict[str, float]:
    """`_freeway_vsl_sequence_candidates` 의 곱 전개를 k-best 지연 생성으로 교체한다.

    자유 세그먼트 s 개 · 세그먼트당 옵션 k 개면 원본은 k^s 를 전부 만든다. 21셀 FW_E 는
    10^8 이라 MemoryError 가 난다(2026-09-08 실측). 정렬 키가 세그먼트별 합의 사전식 비교라
    단조이므로, 힙으로 상위 limit 개만 뽑아도 순서가 같다.
    """
    section = _mapping(_mapping(tuning).get("freeway")) if tuning is not None else {}
    if "vsl_sequence_kbest" in section and not bool(section.get("vsl_sequence_kbest")):
        return {"fw_vsl_kbest_enabled": 0.0}
    max_expand = int(_as_float(section.get("vsl_sequence_max_expand"), 20000.0))
    import heapq as _heapq
    from src.controllers import wu_faithful_follower as _wff

    _cls = _wff.WuFaithfulFollower
    if getattr(_cls._freeway_vsl_sequence_candidates, "_rw_vsl_kbest", False):
        return {"fw_vsl_kbest_enabled": 1.0, "fw_vsl_kbest_patched": 0.0}
    _segment_vsl = _wff.segment_vsl
    _repair = _wff.repair_vsl_value

    def _patched_freeway_vsl_sequence_candidates(self, link, n_seg, previous, base_candidates, horizon):
        ff = self.cfg.freeway_follower
        horizon = max(1, int(horizon))
        sequences = []
        seen = set()

        def add_sequence(sequence):
            normalized = [
                [float(v) for v in vec]
                for vec in (sequence + [sequence[-1]] * max(0, horizon - len(sequence)))
            ][:horizon]
            key = tuple(tuple(round(v, 6) for v in vec) for vec in normalized)
            if key not in seen:
                seen.add(key)
                sequences.append(normalized)

        if not ff.vsl_sequence_search:
            for vec in base_candidates:
                add_sequence([[float(v) for v in vec]])
            return sequences

        vsl_set = sorted(float(v) for v in ff.vsl_set)
        if not vsl_set:
            return sequences
        vsl_max = max(vsl_set)
        max_step = max(0.0, float(ff.max_vsl_step))
        sequence_steps = max(1, min(horizon, int(ff.vsl_sequence_horizon_steps)))
        net = self.cfg.network
        # VSL 구역이 설치돼 있으면 자유 변수는 **구역 머리 셀**이고 나머지 셀은 자기 구역 머리를
        # 물려받는다. 플랜트가 실제로 그렇게 동작한다 - VSL 표지판은 정해진 자리에만 있고,
        # 표지판 사이 구간은 상류 표지판이 지시한 속도를 유지한다(2026-09-08 사용자 지시).
        # 구역이 없으면 종전 규칙(첫 off-ramp 상류)으로 떨어진다 - 비트 동일.
        _head_of = (getattr(net, "freeway_vsl_zone_head_of_cell", None) or {}).get(str(link))
        _zone_of = (getattr(net, "freeway_vsl_zone_of_cell", None) or {}).get(str(link))
        _free_z = getattr(net, "freeway_vsl_zone_free", None)
        if _head_of and _zone_of:
            head_of = [int(x) for x in _head_of]
            free_zones = set(int(z) for z in (_free_z if _free_z is not None else set(_zone_of)))
            upstream_control_idx = {i for i in range(n_seg)
                                    if head_of[i] == i and int(_zone_of[i]) in free_zones}
        else:
            head_of = list(range(n_seg))
            bottleneck_idx = {
                int(net.off_ramp_segment_index.get(off_ramp, n_seg - 1))
                for off_ramp in net.off_ramps
                if net.off_ramp_from_freeway.get(off_ramp) == link
            } or {n_seg - 1}
            upstream_control_idx = {i for i in range(max(0, min(bottleneck_idx)))}

        def sanitize_base_vector(vec):
            sanitized = []
            for index in range(n_seg):
                src = head_of[index]          # 구역 머리 값을 물려받는다(구역 없으면 자기 자신)
                value = float(vec[src]) if src < len(vec) else _segment_vsl(previous, link, src, self.cfg)
                if src not in upstream_control_idx:
                    prev = _segment_vsl(previous, link, src, self.cfg)
                    value = _repair(vsl_max, prev, self.cfg).value
                sanitized.append(float(value))
            return sanitized

        for vec in base_candidates:
            add_sequence([sanitize_base_vector([float(v) for v in vec])])
        limit = max(len(sequences), int(ff.vsl_sequence_candidate_limit))
        # base 후보가 이미 limit 을 채웠으면 원본도 첫 반복에서 break 한다 - 곱을 만들 이유가 없다.
        if len(sequences) >= limit:
            return sequences

        def segment_sequences(index):
            prev = _segment_vsl(previous, link, index, self.cfg)
            if index not in upstream_control_idx:
                repaired = _repair(vsl_max, prev, self.cfg).value
                return [[float(repaired)] * sequence_steps]
            first_values = [
                value for value in vsl_set
                if value <= prev + 1.0e-9 and prev - value <= max_step + 1.0e-9
            ]
            if not first_values:
                first_values = [_repair(prev, prev, self.cfg).value]
            out = []

            def extend(prefix):
                if len(prefix) >= sequence_steps:
                    out.append([float(v) for v in prefix])
                    return
                current = prefix[-1]
                next_values = [
                    value for value in vsl_set
                    if value <= current + 1.0e-9 and current - value <= max_step + 1.0e-9
                ]
                for value in sorted(set(next_values), reverse=True):
                    extend(prefix + [float(value)])

            for value in sorted(set(first_values), reverse=True):
                extend([float(value)])
            return out

        # 세그먼트별 옵션을 자기 키 (합, 마지막, 첫)로 정렬 - 전역 키가 이 셋의 합이라 단조다.
        # 원본은 곱을 만든 뒤 sorted(안정) 하므로 동률이면 **생성 순서**가 이긴다. 그 순서는
        # 세그먼트 0 이 바깥인 원래 옵션 인덱스의 사전식이다 - 키 4번째 성분으로 그대로 넣는다.
        # (세그먼트 안에서 동률인 옵션을 원래 인덱스 오름차순으로 두었으므로 이 성분도 단조다.)
        per_segment = []
        for i in range(n_seg):
            opts = segment_sequences(i)
            if not opts:
                opts = [[float(vsl_max)] * sequence_steps]
            ranked = sorted(range(len(opts)),
                            key=lambda j: (sum(opts[j]), opts[j][-1], opts[j][0], j))
            per_segment.append([(opts[j], j) for j in ranked])

        def key_of(vec_idx):
            s = t = f = 0.0
            orig = []
            for i, j in enumerate(vec_idx):
                o, oj = per_segment[i][j]
                s += sum(o)
                t += o[-1]
                f += o[0]
                orig.append(oj)
            return (s, t, f, tuple(orig))

        start = tuple([0] * n_seg)
        heap = [(key_of(start), start)]
        visited = {start}
        pops = 0
        while heap and len(sequences) < limit and pops < max_expand:
            _k, vec_idx = _heapq.heappop(heap)
            pops += 1
            combo = [per_segment[i][j][0] for i, j in enumerate(vec_idx)]
            # 셀은 자기 구역 머리의 값을 쓴다(구역 없으면 head_of[seg] == seg 라 종전과 같다).
            add_sequence([[float(combo[head_of[seg]][step]) for seg in range(n_seg)]
                          for step in range(sequence_steps)])
            for i in range(n_seg):
                if vec_idx[i] + 1 < len(per_segment[i]):
                    nxt = vec_idx[:i] + (vec_idx[i] + 1,) + vec_idx[i + 1:]
                    if nxt not in visited:
                        visited.add(nxt)
                        _heapq.heappush(heap, (key_of(nxt), nxt))
        return sequences

    _patched_freeway_vsl_sequence_candidates._rw_vsl_kbest = True
    _cls._freeway_vsl_sequence_candidates = _patched_freeway_vsl_sequence_candidates
    return {"fw_vsl_kbest_enabled": 1.0, "fw_vsl_kbest_patched": 1.0,
            "fw_vsl_kbest_max_expand": float(max_expand)}


def install_freeway_two_branch_fd(cfg, tuning) -> dict[str, float]:
    """config `freeway.two_branch` → cfg.network 의 two-branch FD 런타임 속성. 절 없으면 no-op.

    **왜 별도 installer 인가.** vendor 는 `getattr(net, "vsl_fd_two_branch", False)` 와
    `getattr(net, "rho_crit_two_branch", 0.0)` 로만 읽는데(`metanet.py:65, 621`) 둘 다
    `NetworkConfig` **필드가 아니다.** 그래서 `config_overrides.network` 에 넣으면
    `NetworkConfig(**raw)` 언팩에서 `TypeError` 로 죽는다 — 2026-09-09 확인.
    CLAUDE.md 가 적어 둔 "필드 없는 getattr 게이트 = 죽은 코드" 부류였고, 이 함수가 그 배선이다.

    무엇이 켜지나. `vsl_fd_two_branch=True` 면 `effective_rho_crit(net, vsl)` 이 고정
    `net.rho_crit` 대신 **ρ_c(VSL) = w·ρ_jam/(vsl+w)** 를 낸다 — VSL 이 임계밀도를 옮기는
    문헌(METANET-VSL) 기구. `w = v_free·ρ_crit_tb/(ρ_jam − ρ_crit_tb)`.

    **`rho_crit_two_branch` 를 반드시 같이 줘라.** 미설정이면 `two_branch_nominal_rho_crit` 이
    `net.rho_crit`(지수 FD 용, 27)로 폴백하는데 삼각형 용량은 `v_free × ρ_crit` 이라
    4차로 12,960 veh/h = 기존 6937 의 **1.87 배**로 뻥튀기된다(vendor docstring 이 경고한 함정).
    무제어 런 적합값은 15.16 (= q_cap/v_free, 42셀 전부 15.16~15.56).

    spawn 워커에도 간다 — 모듈 패치가 아니라 `cfg.network` 속성이라 컨트롤러와 함께 피클된다
    (`install_vissim_calibration_runtime_patches` 와 같은 부류).
    """
    section = _mapping(_mapping(_mapping(tuning).get("freeway")).get("two_branch"))
    if not section:
        return {"two_branch_fd_enabled": 0.0}
    enabled = bool(section.get("enabled", False))
    setattr(cfg.network, "vsl_fd_two_branch", enabled)
    out = {"two_branch_fd_enabled": 1.0 if enabled else 0.0}
    tb = _as_float(section.get("rho_crit_two_branch"), 0.0)
    if tb > 0.0:
        setattr(cfg.network, "rho_crit_two_branch", float(tb))
        out["two_branch_rho_crit"] = float(tb)
    rj = _as_float(section.get("rho_max"), 0.0)
    if rj > 0.0:
        setattr(cfg.network, "rho_max", float(rj))
        out["two_branch_rho_max"] = float(rj)
    if enabled:
        # 켜졌으면 실효 ρ_c 를 진단으로 남긴다 — "설치됐다"와 "움직인다"를 산출물로 가르기 위해.
        try:
            from src.models.metanet import effective_rho_crit as _erc
            for _v in (120.0, 100.0, 80.0):
                out["two_branch_rho_c_vsl%d" % int(_v)] = float(_erc(cfg.network, _v))
        except Exception:
            pass
    return out


def install_freeway_lane_drop(cfg, tuning) -> dict[str, float]:
    """config `freeway.lane_drop_phi` → cfg.network.freeway_lane_drop_phi. 없거나 0 이면 no-op."""
    section = _mapping(_mapping(tuning).get("freeway"))
    phi = _as_float(section.get("lane_drop_phi"), 0.0)
    setattr(cfg.network, "freeway_lane_drop_phi", float(phi))
    out = {"freeway_lane_drop_phi": float(phi)}
    if phi > 0.0:
        geo = _mapping(getattr(cfg.network, "freeway_segment_lanes", None) or {})
        n = 0
        for link, arr in geo.items():
            for i in range(len(arr) - 1):
                if float(arr[i]) - float(arr[i + 1]) > 1.0e-9:
                    n += 1
                    out["lane_drop_cell_%s" % link] = float(i)
        out["lane_drop_cells"] = float(n)
    return out


def install_freeway_segment_runtime(cfg) -> dict[str, float]:
    """cfg.network 에 실린 세그먼트 기하/파라미터를 vendor 롤아웃에 실제로 먹인다.

    부모와 가격 워커 양쪽에서 불린다 — 값(cfg.network.*)은 피클로 넘어가지만 **모듈 패치는 spawn 을
    못 넘기 때문에** 워커에서 다시 심어야 한다(far 램프 용량 패치와 같은 사유)."""
    import src.models.metanet as _mn
    import src.models.state as _st
    geo = getattr(cfg.network, "freeway_segment_lanes", None) or {}
    par = getattr(cfg.network, "freeway_segment_params", None) or {}
    if isinstance(par, Mapping):
        par = {k: v for k, v in par.items() if isinstance(v, (list, tuple)) and any(v)}
    else:
        par = {}
    out: dict[str, float] = {"fw_seg_geo_links": float(len(geo)), "fw_seg_param_links": float(len(par))}
    if not geo and not par:
        return out

    # (1) 기하 차로 프로파일 — 원본이 적용한 감소분(off-ramp spillback / incident)은 보존하고 바닥만 교체.
    if geo and not getattr(_mn.effective_lane_profile, "_rw_fw_seg_patch", False):
        _orig_elp = _mn.effective_lane_profile

        def _patched_effective_lane_profile(state, cfg_, demand=None):
            profile, diag = _orig_elp(state, cfg_, demand)
            g = getattr(cfg_.network, "freeway_segment_lanes", None) or {}
            if not g:
                return profile, diag
            base = float(cfg_.network.freeway_lanes)
            for link, lanes in profile.items():
                arr = g.get(str(link))
                if not arr:
                    continue
                for i in range(len(lanes)):
                    gi = float(arr[i]) if i < len(arr) else base
                    reduction = max(0.0, base - float(lanes[i]))
                    lanes[i] = max(1.0e-9, gi - reduction)
                if lanes:
                    diag["fw_geo_lanes_%s_min" % link] = float(min(lanes))
                    diag["fw_geo_lanes_%s_max" % link] = float(max(lanes))
            # 차로감소항이 읽을 것은 **이 프로파일**이다. state.freeway_effective_lanes 는 substep 시작 시점에
            # ensure_freeway_lane_profile 이 링크 스칼라([freeway_lanes]*n)로 채워둔 값이라 Δλ 가 0 이 된다
            # (2026-09-08 실측: φ 를 0~16 으로 흔들어도 속도가 비트 동일했다).
            _FW_SEG_CTX_STATE["profile"] = profile
            return profile, diag

        _patched_effective_lane_profile._rw_fw_seg_patch = True
        out["fw_seg_geo_rebind"] = _fw_rebind("effective_lane_profile", _orig_elp, _patched_effective_lane_profile)
        _mn.effective_lane_profile = _patched_effective_lane_profile

        try:
            import src.controllers.local_freeway_plant as _lfp
        except Exception:
            _lfp = None
        if _lfp is not None and not getattr(_lfp._local_lane_profile, "_rw_fw_seg_patch", False):
            _orig_llp = _lfp._local_lane_profile

            def _patched_local_lane_profile(model, occupancy, demand):
                lanes = _orig_llp(model, occupancy, demand)
                net_ = model.cfg.network
                arr = (getattr(net_, "freeway_segment_lanes", None) or {}).get(str(model.link))
                if not arr:
                    return lanes
                base = float(net_.freeway_lanes)
                for i in range(len(lanes)):
                    gi = float(arr[i]) if i < len(arr) else base
                    lanes[i] = max(1.0e-9, gi - max(0.0, base - float(lanes[i])))
                return lanes

            _patched_local_lane_profile._rw_fw_seg_patch = True
            _lfp._local_lane_profile = _patched_local_lane_profile
            out["fw_seg_geo_local_plant"] = 1.0

    # (2) 세그먼트별 FD/동역학 파라미터 — segment_vsl 이 문맥을 무장하고 뒤 셋이 읽는다.
    # 2026-09-08 검토: 종전에는 `par` 있을 때만 무장해 `segment_params` 없는 config(N=8 ver2 계열)에서
    #   차로감소항 φ 가 **조용한 no-op** 이었다. 래퍼는 p 가 비면 링크 스칼라로 안전 퇴화하므로
    #   geo 나 φ 만 있어도 무장한다.
    _phi_cfg = _as_float(getattr(cfg.network, "freeway_lane_drop_phi", 0.0), 0.0)
    if (par or geo or _phi_cfg > 0.0) and not getattr(_st.segment_vsl, "_rw_fw_seg_patch", False):
        _o_sv = _st.segment_vsl
        _o_ed = _mn.effective_desired_speed_kmh
        _o_nu = _mn.select_anticipation_nu
        _o_up = _mn.metanet_speed_update_kmh

        def _patched_segment_vsl(control, link, index, cfg_):
            try:
                _FW_SEG_CTX["p"] = _fw_seg_param_dict(cfg_.network, link, index)
                _FW_SEG_CTX["armed"] = True
                # 차로감소항 재료. Δλ = λ_i − λ_{i+1} (감소일 때만 양수) 와 φ 를 여기서 실어 둔다 —
                # metanet_speed_update_kmh 는 cfg 를 못 본다.
                _phi = _as_float(getattr(cfg_.network, "freeway_lane_drop_phi", 0.0), 0.0)
                _dl = 0.0
                if _phi > 0.0:
                    # 유효 차로(off-ramp 스필백·incident 감소가 반영된 값)를 쓴다. 정적 기하로 읽으면
                    # 하필 차로감소 직후 셀에 off-ramp 감소가 걸릴 때 Δλ 가 절반으로 과소평가된다.
                    _prof = _FW_SEG_CTX_STATE.get("profile")
                    _arr = _prof.get(str(link)) if isinstance(_prof, Mapping) else None
                    if not _arr:
                        _arr = _mapping(getattr(cfg_.network, "freeway_segment_lanes", None) or {}).get(str(link))
                    if isinstance(_arr, (list, tuple)) and 0 <= int(index) + 1 < len(_arr):
                        _dl = max(0.0, float(_arr[int(index)]) - float(_arr[int(index) + 1]))
                _FW_SEG_CTX["phi"] = _phi
                _FW_SEG_CTX["dlam"] = _dl
                _FW_SEG_CTX["lanes"] = float(_arr[int(index)]) if (_phi > 0.0 and _dl > 0.0) else 0.0
                _FW_SEG_CTX["rho_crit_link"] = float(getattr(cfg_.network, "rho_crit", 27.0))
            except Exception:
                _FW_SEG_CTX["p"] = {}
                _FW_SEG_CTX["armed"] = False
                _FW_SEG_CTX["phi"] = 0.0
                _FW_SEG_CTX["dlam"] = 0.0
            return _o_sv(control, link, index, cfg_)

        def _patched_effective_desired_speed_kmh(rho, v_free, rho_crit, vsl, alpha_vsl=0.0,
                                                 vsl_active=True, a=1.867, two_branch=False,
                                                 rho_jam=0.0, rho_crit_tb=0.0):
            p = _FW_SEG_CTX["p"] if _FW_SEG_CTX["armed"] else {}
            if p:
                v_free = float(p.get("v_free", v_free))
                rho_crit = float(p.get("rho_crit", rho_crit))
                a = float(p.get("metanet_a_m", a))
                if _as_float(p.get("rho_max"), 0.0) > 0.0:
                    rho_jam = float(p["rho_max"])
            return _o_ed(rho, v_free, rho_crit, vsl, alpha_vsl, vsl_active, a, two_branch, rho_jam, rho_crit_tb)

        def _patched_select_anticipation_nu(rho, net, vsl=None):
            p = _FW_SEG_CTX["p"] if _FW_SEG_CTX["armed"] else {}
            if not p:
                return _o_nu(rho, net, vsl)
            rho_c = float(p.get("rho_crit", getattr(net, "rho_crit", 0.0)))
            if getattr(net, "capacity_drop_anticipation", False) and rho > rho_c:
                return float(p.get("metanet_nu_cong_km2_h", net.metanet_nu_cong_km2_h))
            return float(p.get("metanet_nu_km2_h", net.metanet_nu_km2_h))

        def _patched_metanet_speed_update_kmh(speed, upstream_speed, rho, downstream_rho, v_eff,
                                              dt_h, length_km, tau_h, nu_km2_h,
                                              kappa_veh_km_lane, v_min):
            # 문맥을 **먼저 지역변수로 받고** 나서 해제한다. 2026-09-08: 해제를 위에 두고 차로감소항이
            # 아래에서 _FW_SEG_CTX 를 다시 읽는 바람에 Δλ 가 항상 0 이 되어 φ 가 한 번도 발화하지 않았다
            # (φ 0~16 에서 속도 비트 동일). 해제 자체는 필요하다 — segment_vsl 없이 오는 완충 셀 호출이
            # 직전 셀의 Δλ 를 물려받으면 엉뚱한 셀에 항이 걸린다.
            _armed = bool(_FW_SEG_CTX["armed"])
            p = _FW_SEG_CTX["p"] if _armed else {}
            _phi = (_FW_SEG_CTX.get("phi") or 0.0) if _armed else 0.0
            _dl = (_FW_SEG_CTX.get("dlam") or 0.0) if _armed else 0.0
            _lam = max(1.0e-9, float(_FW_SEG_CTX.get("lanes") or 1.0))
            _rc_link = float(_FW_SEG_CTX.get("rho_crit_link") or 27.0)
            _FW_SEG_CTX["armed"] = False
            _FW_SEG_CTX["dlam"] = 0.0
            _FW_SEG_CTX["lanes"] = 0.0
            if p:
                tau_h = float(p.get("metanet_tau_h", tau_h))
                kappa_veh_km_lane = float(p.get("metanet_kappa_veh_km_lane", kappa_veh_km_lane))
                length_km = float(p.get("segment_length_km", length_km))
            v_new = _o_up(speed, upstream_speed, rho, downstream_rho, v_eff, dt_h, length_km,
                          tau_h, nu_km2_h, kappa_veh_km_lane, v_min)
            # 차로감소항: Δv = −φ·T·Δλ·ρ·v² / (L·λ·ρ_cr). 차로가 주는 직전 셀에만 걸린다.
            if _phi > 0.0 and _dl > 0.0:
                _FW_SEG_CTX_STATE["lane_drop_fired"] = _FW_SEG_CTX_STATE.get("lane_drop_fired", 0) + 1
                _rc = float(p["rho_crit"]) if (p and "rho_crit" in p) else _rc_link
                v_new = max(v_min, v_new - _phi * dt_h * _dl * max(rho, 0.0) * (speed ** 2)
                            / (max(length_km, 1.0e-9) * _lam * max(_rc, 1.0e-9)))
            return v_new

        for _f in (_patched_segment_vsl, _patched_effective_desired_speed_kmh,
                   _patched_select_anticipation_nu, _patched_metanet_speed_update_kmh):
            _f._rw_fw_seg_patch = True
        out["fw_seg_rebind_vsl"] = _fw_rebind("segment_vsl", _o_sv, _patched_segment_vsl)
        out["fw_seg_rebind_ved"] = _fw_rebind("effective_desired_speed_kmh", _o_ed, _patched_effective_desired_speed_kmh)
        out["fw_seg_rebind_nu"] = _fw_rebind("select_anticipation_nu", _o_nu, _patched_select_anticipation_nu)
        out["fw_seg_rebind_upd"] = _fw_rebind("metanet_speed_update_kmh", _o_up, _patched_metanet_speed_update_kmh)
        _st.segment_vsl = _patched_segment_vsl
        _mn.segment_vsl = _patched_segment_vsl
        _mn.effective_desired_speed_kmh = _patched_effective_desired_speed_kmh
        _mn.select_anticipation_nu = _patched_select_anticipation_nu
        _mn.metanet_speed_update_kmh = _patched_metanet_speed_update_kmh
        out["fw_seg_param_segments"] = float(sum(len(v) for v in par.values()))
    return out


def _plant_gate_peeloff_into(cfg, tuning) -> None:
    """tuning `urban.gate.ramp_peeloff` 를 cfg 로 나른다.

    profiled_demand_rates 가 tuning 을 안 받으므로 cfg 속성으로 넘긴다. 값이라
    컨트롤러와 함께 피클되어 가격 워커까지 간다(코드가 아니라 spawn 안전)."""
    section = _mapping(_mapping(_mapping(tuning).get("urban")).get("gate"))
    setattr(cfg.network, "gate_ramp_peeloff", bool(_is_enabled_value(section.get("ramp_peeloff"))))


RAMP_FEED_MAP_JSON = WORKSPACE_ROOT / "outputs/ramp_feed_map_20260901.json"


def emit_ramp_feed_observation(cfg, state, state_json) -> dict[str, float]:
    """램프 spillback 관측. **제어는 하지 않는다 — 기록 전용이다.**

    왜 필요한가. on-ramp 는 권역 정본에서 freeway 플레이어 소유이고 도시 movement 로
    배선하지 않는다(`grid_node_legs` 의 `W_RAMP.on = {}`, 2026-09-01 사용자 결정 유지).
    그래서 도시 컨트롤러는 램프를 직접 제어하지 않는다.

    그런데 **신호는 램프 유입에 실제로 영향을 준다** — 램프미터가 도시 정지선 하류에 있는
    경로가 램프마다 하나씩 있다(대장 outputs/ramp_feed_map_20260901.json):
        R_D_W·R_D_E  링크 31 <- SC1001 서향 3개  |  링크 32 는 정지선 상류라 제어 불가
        R_F_W·R_F_E  링크 68 <- SC1004 서향 3개  |  링크 69 무소유 · 링크 70 무신호

    나중에 "램프가 차면 그 램프를 먹이는 현시를 조인다" 를 하려면 이 관측이 먼저 쌓여야 한다.
    지금은 값만 남긴다.

    큐 상한은 **램프별**(`ramp_queue_cap`)을 쓴다 — 스칼라 `ramp_queue_max_veh`(180)는
    네 램프의 실제 상한(111.2~174.5) 모두보다 커서 점유율을 과소평가한다.
    """
    if not RAMP_FEED_MAP_JSON.is_file():
        return {"ramp_feed_observation": 0.0}
    try:
        doc = json.loads(RAMP_FEED_MAP_JSON.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"ramp_feed_observation": 0.0}
    fm = _mapping(_mapping(_mapping(state_json).get("local_observation")).get("far_measurement"))
    vols = {str(k): _as_float(v, -1.0) for k, v in _mapping(fm.get("link_volume_veh_h")).items()}
    out: dict[str, float] = {"ramp_feed_observation": 1.0}
    net = cfg.network
    for ramp, spec in _mapping(doc.get("ramps")).items():
        q = max(0.0, _as_float(getattr(state, "ramp_queue", {}).get(ramp), 0.0))
        cap = float(net.ramp_queue_cap(ramp)) if hasattr(net, "ramp_queue_cap") else float(
            getattr(net, "ramp_queue_max_veh", 0.0))
        out["ramp_obs_%s_queue_veh" % ramp] = q
        out["ramp_obs_%s_queue_cap_veh" % ramp] = cap
        out["ramp_obs_%s_occupancy" % ramp] = (q / cap) if cap > 1.0e-9 else 0.0
        ctl = unc = 0.0
        for m in spec.get("meters", []) or []:
            v = vols.get(str(m.get("connector")), -1.0)
            if v < 0.0:
                continue
            if bool(m.get("signal_controllable")):
                ctl += v
            else:
                unc += v
        out["ramp_obs_%s_merge_controllable_veh_h" % ramp] = ctl
        out["ramp_obs_%s_merge_uncontrollable_veh_h" % ramp] = unc
        total = ctl + unc
        out["ramp_obs_%s_controllable_share" % ramp] = (ctl / total) if total > 1.0e-9 else 0.0
    return out
def profiled_demand_rates(
    state_json: Mapping[str, Any],
    cfg,
    calibration: Mapping[str, Any] | None = None,
    detector_mapping: Mapping[str, Any] | None = None,
) -> tuple[dict[str, float], dict[str, float], dict[str, float], str]:
    """Mirror the Vissim runner's demand-profile multipliers in the model forecast.

    `run_stackelberg_vissim_controller.vbs` applies demand profiles at the
    VehicleInput level. Before this adapter-side mirror, the one-step METANET
    prediction treated every freeway direction and every urban boundary input
    as symmetric even when Vissim was running `fw_eb_heavy`, `urban_d_heavy`,
    etc. That creates a biased prediction target before calibration even
    starts.
    """
    demand = state_json.get("demand", {})
    if not isinstance(demand, Mapping):
        demand = {}
    urban_vph = float(demand.get("urban_volume_vph", 60.0))
    freeway_vph = float(demand.get("freeway_volume_vph", 1200.0))
    ramp_vph = float(demand.get("ramp_volume_vph", max(120.0, freeway_vph * 0.12)))
    profile = str(demand.get("demand_profile", "")).lower()
    urban_west_east_ratio = max(1.0e-6, _as_float(demand.get("urban_west_east_ratio"), 1.0))

    freeway_mainline = {str(link): freeway_vph for link in cfg.network.freeway_links}
    gate_keys = [
        str(link)
        for link in list(cfg.network.boundary_in_links) + list(cfg.network.boundary_out_links)
    ]
    # 게이트 앵커링. 러너가 자기 VISSIM vehicle input 을 게이트에 조인해서 게이트별
    # 유량을 넘겨주면 그것을 그대로 쓴다. 없으면(8seg 러너·g6 harness) 예전대로
    # 스칼라 하나를 전 게이트에 복제한다 — evaluation/controllers/demand_contract.md.
    urban_by_gate = demand.get("urban_volume_vph_by_gate")
    gate_anchored = isinstance(urban_by_gate, Mapping) and bool(urban_by_gate)
    if gate_anchored:
        unknown = sorted(str(gate) for gate in urban_by_gate if str(gate) not in set(gate_keys))
        if unknown:
            # 조용히 흘리면 그 유입의 수요가 말없이 사라진다. 대장과 격자가 따로
            # 갱신됐다는 뜻이므로 런을 세운다.
            raise ValueError(
                "state.demand.urban_volume_vph_by_gate has gates the model does not know: "
                + ", ".join(unknown)
            )
        urban_boundary = {key: 0.0 for key in gate_keys}
        for gate, value in urban_by_gate.items():
            urban_boundary[str(gate)] = float(value)
    else:
        urban_boundary = {key: urban_vph for key in gate_keys}
    ramp_arrival = {str(ramp): ramp_vph for ramp in cfg.network.ramps}

    if profile == "fw_eb_heavy":
        freeway_mainline["FW_E"] = freeway_vph * 1.55
        freeway_mainline["FW_W"] = freeway_vph * 0.55
    elif profile == "fw_wb_heavy":
        freeway_mainline["FW_W"] = freeway_vph * 1.55
        freeway_mainline["FW_E"] = freeway_vph * 0.55

    def set_urban_profile(high_links: set[str], high_factor: float, low_factor: float) -> None:
        for link in cfg.network.boundary_in_links:
            urban_boundary[str(link)] = urban_vph * (high_factor if str(link) in high_links else low_factor)
        # boundary_out links are not used as exogenous arrivals by the movement
        # queue model, but keep them populated for diagnostics/compatibility.
        for link in cfg.network.boundary_out_links:
            urban_boundary[str(link)] = urban_vph * low_factor

    # 아래 도시부 공간 프로파일은 스칼라 경로의 heuristic 이다(합성망 게이트 이름 기준).
    # 게이트 앵커링이 켜져 있으면 러너가 이미 vehicle input 단위로 배수를 적용한 값을
    # 주므로, 여기서 다시 흔들면 이중 적용이 된다.
    if not gate_anchored:
        if profile == "urban_west_heavy":
            set_urban_profile({"in_A_left", "in_D_left"}, 1.8, 0.65)
        elif profile == "urban_east_heavy":
            set_urban_profile({"in_C_right", "in_F_right"}, 1.8, 0.65)
        elif profile == "urban_north_heavy":
            set_urban_profile({"in_A_top", "in_B_top", "in_C_top"}, 1.65, 0.6)
        elif profile == "urban_d_heavy":
            set_urban_profile({"in_D_left"}, 2.2, 0.65)
        elif profile == "urban_f_heavy":
            set_urban_profile({"in_F_right"}, 2.2, 0.65)

        if abs(urban_west_east_ratio - 1.0) > 1.0e-9:
            west_factor = 2.0 * urban_west_east_ratio / (1.0 + urban_west_east_ratio)
            east_factor = 2.0 / (1.0 + urban_west_east_ratio)
            for link in cfg.network.boundary_in_links:
                key = str(link)
                if key in {"in_A_left", "in_D_left"}:
                    urban_boundary[key] = urban_boundary.get(key, urban_vph) * west_factor
                elif key in {"in_C_right", "in_F_right"}:
                    urban_boundary[key] = urban_boundary.get(key, urban_vph) * east_factor

    # Route-aware on-ramp forecast (2026-06-30): the hardcoded uniform ramp_vph (250/ramp) under-sizes
    # and mis-directs the on-ramp arrival. The VISSIM static routes send a fixed fraction of each urban
    # origin's demand onto the D on-ramp (link 25 -> FW_WB -> R_D_W) and F on-ramp (link 31 -> FW_EB ->
    # R_F_E); at u1400 this is ~1032 vph per direction (~2x the 1000 vph total forecast). Sizing N_UF to
    # the under-forecast made the leader meter the on-ramps below the real demand -> ramp queues -> harm.
    # ramp_share_of_urban_in[ramp] = (routing fraction onto that ramp) so ramp_arrival = share x total
    # urban boundary-in demand (which already carries the profile multipliers above).
    onramp_fc = _mapping(_mapping(calibration or {}).get("prediction")).get("onramp_route_forecast", {})
    if bool(_mapping(onramp_fc).get("enabled", False)):
        total_urban_in = sum(
            _as_float(urban_boundary.get(str(link), 0.0)) for link in cfg.network.boundary_in_links
        )
        shares = _mapping(_mapping(onramp_fc).get("ramp_share_of_urban_in"))
        for ramp in cfg.network.ramps:
            ramp_arrival[str(ramp)] = max(0.0, _as_float(shares.get(str(ramp), 0.0))) * total_urban_in

    route_bias = _mapping(_mapping(calibration or {}).get("prediction")).get("route_bias_forecast", {})
    route_bias = _mapping(route_bias)
    route_bias_enabled = bool(route_bias.get("enabled", True))
    route_bias_version = int(_as_float(route_bias.get("version"), 1.0))
    target_share = clamp(_as_float(route_bias.get("target_share"), 0.98), 0.5, 1.0)

    # v1 (legacy, demoted candidate): preserve total ramp demand and split the target node's ramp
    # pair by target_share. This is direction-agnostic and ties magnitude to a hardcoded ramp_vph.
    def apply_ramp_route_bias_v1(target_node: str) -> None:
        ramps = [str(ramp) for ramp in cfg.network.ramps]
        if not ramps:
            return
        target_prefix = f"R_{target_node}_"
        target_ramps = [ramp for ramp in ramps if ramp.startswith(target_prefix)]
        other_ramps = [ramp for ramp in ramps if ramp not in target_ramps]
        if not target_ramps or not other_ramps:
            return
        total_arrival_vph = ramp_vph * float(len(ramps))
        target_each = total_arrival_vph * target_share / float(len(target_ramps))
        other_each = total_arrival_vph * (1.0 - target_share) / float(len(other_ramps))
        for ramp in target_ramps:
            ramp_arrival[ramp] = target_each
        for ramp in other_ramps:
            ramp_arrival[ramp] = other_each

    # v2 (direction-aware, 2026-06-29 audit follow-up): VISSIM d/f_ramp_bias funnels biased flow
    # through ONE physical on-ramp toward ONE freeway direction (link 25 -> FW_WB, link 31 -> FW_EB;
    # run_stackelberg_vissim_controller.vbs ApplyRouteBias). v1 wrongly split the boost across both
    # directional ramps of the node and preserved a hardcoded total. v2 loads the direction-feeding
    # ramp with a fittable multiplier on ramp_vph, gives the same-node cross-direction ramp a small
    # share, and starves the other node's ramps. Total ramp demand is intentionally NOT preserved.
    v2 = _mapping(route_bias.get("v2"))
    v2_target_multiplier = max(0.0, _as_float(v2.get("target_multiplier"), 4.0))
    v2_cross_share = max(0.0, _as_float(v2.get("cross_share"), 0.15))
    v2_off_share = max(0.0, _as_float(v2.get("off_share"), 0.02))
    v2_direction_feed = _mapping(v2.get("direction_feed"))

    def apply_ramp_route_bias_v2(target_node: str) -> None:
        ramps = [str(ramp) for ramp in cfg.network.ramps]
        if not ramps:
            return
        target_prefix = f"R_{target_node}_"
        node_ramps = [ramp for ramp in ramps if ramp.startswith(target_prefix)]
        if not node_ramps:
            return
        ramp_to_freeway = getattr(cfg.network, "ramp_to_freeway", {}) or {}
        feed = str(v2_direction_feed.get(profile, ""))
        if feed not in node_ramps:
            wanted_dir = "FW_W" if target_node == "D" else "FW_E"
            feed = next(
                (r for r in node_ramps if str(ramp_to_freeway.get(r, "")) == wanted_dir),
                node_ramps[0],
            )
        for ramp in ramps:
            if ramp == feed:
                ramp_arrival[ramp] = ramp_vph * v2_target_multiplier
            elif ramp in node_ramps:
                ramp_arrival[ramp] = ramp_vph * v2_cross_share
            else:
                ramp_arrival[ramp] = ramp_vph * v2_off_share

    apply_ramp_route_bias = (
        apply_ramp_route_bias_v2 if route_bias_version >= 2 else apply_ramp_route_bias_v1
    )
    if route_bias_enabled:
        if profile in {"d_ramp_bias", "d_ramp_heavy"}:
            apply_ramp_route_bias("D")
        elif profile in {"f_ramp_bias", "f_ramp_heavy"}:
            apply_ramp_route_bias("F")

    local_fc = _mapping(_mapping(calibration or {}).get("prediction")).get(
        "local_ramp_arrival_forecast",
        {},
    )
    local_fc = _mapping(local_fc)
    if bool(local_fc.get("enabled", False)):
        observed_counts = {str(ramp): 0.0 for ramp in cfg.network.ramps}
        direct_counts = _mapping(state_json.get("ramp_counts"))
        has_model_ramp_counts = any(str(ramp) in direct_counts for ramp in observed_counts)
        if has_model_ramp_counts:
            for ramp in observed_counts:
                observed_counts[ramp] = max(0.0, _as_float(direct_counts.get(ramp), 0.0))
        else:
            d_count = max(0.0, _as_float(direct_counts.get("D"), 0.0))
            f_count = max(0.0, _as_float(direct_counts.get("F"), 0.0))
            for ramp in observed_counts:
                if ramp.startswith("R_D_"):
                    observed_counts[ramp] = d_count / 2.0
                elif ramp.startswith("R_F_"):
                    observed_counts[ramp] = f_count / 2.0
        if not any(value > 0.0 for value in observed_counts.values()) and detector_mapping:
            link_counts = _link_counts_from_local_observation(state_json)
            for link, ramps in _mapping(detector_mapping.get("ramp_link_to_queues")).items():
                count = max(0.0, _as_float(link_counts.get(str(link)), 0.0))
                if count <= 0.0:
                    continue
                for ramp_key, weight in _ramp_queue_shares(ramps):
                    if ramp_key in observed_counts:
                        observed_counts[ramp_key] += count * weight
        queue_drain_horizon_sec = max(1.0, _as_float(local_fc.get("queue_drain_horizon_sec"), 120.0))
        multiplier = max(0.0, _as_float(local_fc.get("multiplier"), 1.0))
        min_vph = max(0.0, _as_float(local_fc.get("min_vph_if_observed"), 120.0))
        max_default = max(0.0, _as_float(local_fc.get("max_vph_per_ramp"), 900.0))
        max_by_ramp = _mapping(local_fc.get("max_vph_by_ramp"))
        # 램프별 배수 지평(2026-08-04). 스칼라 120 s 고정은 점유에 일률적으로 30 을 곱하는데,
        # 실제 커넥터 통과시간은 길이·속도에 따라 다르다 — 실측 역산값이 R_F_E 25.7 s ~
        # R_F_W 116.6 s 로 4.5배 벌어진다(scripts/measure_ramp_connector_flow.py 기준).
        # 이 때문에 모델 ramp_arrival 이 플랜트의 3.5분의 1로 나왔고, 모델 세계에서만
        # 미터가 수요를 구속하지 않아 dTTT/d(meter) 가 정의상 0 이 됐다(G6 램프 축 붕괴 원인).
        # max_vph_by_ramp 와 동일 규약 — dict 미지정이면 스칼라 폴백이라 비트동일.
        drain_by_ramp = _mapping(local_fc.get("queue_drain_horizon_sec_by_ramp"))
        blend = str(local_fc.get("blend", "max")).lower()
        for ramp, count in observed_counts.items():
            if count <= 0.0:
                continue
            drain_sec = max(1.0, _as_float(drain_by_ramp.get(ramp), queue_drain_horizon_sec))
            observed_vph = count * 3600.0 / drain_sec * multiplier
            if observed_vph > 0.0:
                observed_vph = max(min_vph, observed_vph)
            cap_fallback = float(cfg.network.ramp_capacity_veh_h.get(ramp, max_default))
            cap = max(0.0, _as_float(max_by_ramp.get(ramp), max_default or cap_fallback))
            if cap <= 0.0:
                cap = cap_fallback
            observed_vph = clamp(observed_vph, 0.0, cap)
            if blend == "replace":
                ramp_arrival[ramp] = observed_vph
            elif blend == "add":
                ramp_arrival[ramp] = max(0.0, float(ramp_arrival.get(ramp, 0.0)) + observed_vph)
            else:
                ramp_arrival[ramp] = max(float(ramp_arrival.get(ramp, 0.0)), observed_vph)

    # 게이트 상류 램프 이탈분 차감. `urban.gate.ramp_peeloff` 없으면 no-op.
    # ramp_arrival 보정보다 **뒤**여야 한다 — 그쪽이 같은 커넥터의 관측을 쓰므로
    # 여기서 먼저 게이트를 깎으면 순환 참조가 된다.
    _peel_meta = apply_gate_ramp_peeloff(state_json, cfg, urban_boundary)
    globals()["_LAST_GATE_PEELOFF_META"] = _peel_meta
    return freeway_mainline, urban_boundary, ramp_arrival, profile


def demand_from_state(
    state_json: dict[str, Any],
    cfg,
    DemandStep,
    horizon_steps: int,
    calibration: Mapping[str, Any] | None = None,
    detector_mapping: Mapping[str, Any] | None = None,
):
    freeway_mainline, urban_boundary, ramp_arrival, _profile = profiled_demand_rates(
        state_json,
        cfg,
        calibration,
        detector_mapping,
    )
    step = DemandStep(
        freeway_mainline=freeway_mainline,
        urban_boundary=urban_boundary,
        ramp_arrival=ramp_arrival,
        incident_capacity_factor=1.0,
        freeway_lane_loss={},
    )
    return [step for _ in range(max(1, int(horizon_steps)))]


def warm_start_release_buffers(state, cfg, state_json: Mapping[str, Any], calibration, detector_mapping):
    """release 스케줄을 **plant 가 스스로 짓게** 한 뒤 관측 점유량으로 되돌린다.

    ## 왜

    투영은 저류 점유량만 싣고 `urban_storage_release_buffer` 를 비워 둔다. plant 의 방출은
    전적으로 그 버퍼에 물려 있어(urban_queue_model.py:962-973, :994) 빈 버퍼로 시작하면
    내부 링크는 동결되고 sink 는 즉시 전량 방출된다. **어댑터는 결정마다 상태를 다시
    짓기 때문에 모든 제어 결정이 그 상태에서 출발한다.**

    버퍼를 손으로 지어 넣는 것은 실패했다(유출만 복원되어 -37.4% 로 무너진다). 대신
    현재 관측에서 W 초를 무제어로 굴려 plant 가 자기 규약대로 스케줄을 만들게 하고,
    점유량은 관측값으로 되돌린다. 스케줄은 **같은 비율로** 줄여 모양을 보존한다.

    ## 실측 (보존 단위, anchor 1500/2100, 3셀, 스텝 1 / G5 통과 / 부호)

        기준선(꺼짐)      51.7%   29.2%   -25.8%
        self warm 300     47.5%   37.1%   -11.8%
        self warm 900     42.9%   38.8%    -6.7%

    남는 ~43% 는 plant 대 VISSIM 의 실재하는 동역학 오차이고 이 함수의 몫이 아니다.

    ## 비용

    모델 한 스텝이 약 0.21 초라 15 스텝이 결정당 ~3 초다. 60 초 제어주기 안에서 감당된다.

    기본은 **꺼짐**이다. `RW_WARMSTART_SEC` 에 초를 넣으면 켜진다(예: 900).
    """
    stats = {"warmstart_sec": 0.0, "steps": 0.0, "rescaled_links": 0.0}
    try:
        warm_sec = float(str(os.environ.get("RW_WARMSTART_SEC", str(DEFAULT_WARMSTART_SEC))).strip() or 0.0)
        # 2026-09-04. 잔차 도착 시더와 동시에 켜면 같은 차량이 두 번 예약된다 —
        # warm_start 는 plant 자기 롤아웃으로 82링크 492.4 veh 를 예약하고 지평 내내
        # sink 게이트를 억제한다. 시더가 켜져 있으면 warm_start 를 끄고 그 사실을 남긴다.
        if warm_sec > 0.0 and _switch("arrival_seed", "RW_ARRIVAL_SEED"):
            warm_sec = 0.0
            _warmstart_suppressed_by_arrival_seed = True
        else:
            _warmstart_suppressed_by_arrival_seed = False
    except ValueError:
        warm_sec = 0.0
    if warm_sec <= 0.0:
        return stats
    # 바깥 `simulation` 도 가드한다. 실 cfg 는 항상 갖고 있어 거동은 같고, 이 필드가 없는
    # 축약 cfg(테스트 스텁 등)에서 warm-start 기본 켜짐이 통째로 터지던 것을 막는다.
    interval = float(getattr(getattr(cfg, "simulation", None), "control_interval", 60.0) or 60.0)
    steps = max(1, int(round(warm_sec / max(interval, 1.0e-9))))
    try:
        from src.controllers.rollout_endpoint import ObjectiveSpec, evaluate_price_point

        repo_root = Path(DEFAULT_REPO_ROOT)
        _c, DemandStep, ControlAction, _e, _t, _v = repo_imports(repo_root)
        actuation = adapter_actuation_settings(calibration or {}, {})
        control = _guarded_no_control_baseline(ControlAction, cfg, state, dict(state_json), actuation)
        forecast = demand_from_state(dict(state_json), cfg, DemandStep, steps, calibration, detector_mapping)
        warmed = evaluate_price_point(
            state, control, list(forecast), (),
            ObjectiveSpec(cfg=cfg, depth_override=steps, box_walk=False),
        ).states[-1]
    except Exception as exc:  # noqa: BLE001 - warm-start 실패가 결정을 막으면 안 된다
        stats["error"] = f"{type(exc).__name__}: {exc}"
        return stats

    # 지은 스케줄을 현재 상태로 옮기고, 점유량은 관측값으로 되돌리며 예약을 같은 비율로 줄인다.
    capacity = cfg.network.urban_link_storage_veh
    observed_remaining = dict(getattr(state, "urban_link_storage", {}) or {})
    warm_buffer = getattr(warmed, "urban_storage_release_buffer", {}) or {}
    target_buffer = getattr(state, "urban_storage_release_buffer", None)
    if not isinstance(target_buffer, dict):
        return stats
    for link, cap in capacity.items():
        cap = float(cap)
        target_occ = max(0.0, cap - float(observed_remaining.get(link, cap)))
        warm_occ = max(0.0, cap - float((getattr(warmed, "urban_link_storage", {}) or {}).get(link, cap)))
        pending = warm_buffer.get(str(link)) or {}
        if not pending:
            continue
        ratio = (target_occ / warm_occ) if warm_occ > 1.0e-9 else 0.0
        if ratio <= 0.0:
            continue
        target_buffer[str(link)] = {int(k): float(v) * ratio for k, v in pending.items()}
        stats["rescaled_links"] += 1.0
    stats["warmstart_sec"] = warm_sec
    stats["steps"] = float(steps)
    return stats


def seed_urban_arrival_buffer(state, cfg, local_summary: Mapping[str, Any]) -> dict[str, float]:
    """관측 잔차(= 링크 위 비-대기 차량)를 `urban_arrival_buffer` 에 만기 예약한다.

    ## 왜 (2026-09-04, 실행으로 확인한 결함)

    어댑터는 `urban_arrival_buffer` 를 **한 번도 쓰지 않는다**(쓰기 0곳). plant 는 그것과
    `urban_storage_release_buffer` 를 빈 dict 로 초기화하고, 저류가 movement 큐로 가는
    유일한 통로가 이 arrival buffer 다. 결과:

        관측 저류를 싣고 수요 0 으로 90 substep(=450 s) 롤 -> movement_queue **정확히 0.00 veh**

    즉 분리가 결정하는 것은 '대기 대 접근'이 아니라 **'서비스 가능 재고 대 지평 내 폐기'**
    였다. 실제로는 잔차의 75.6% 가 450 s 안에 정지선에 닿는다(중앙 25 s).

    ## 왜 τ 가 둘인가

    잔차는 이봉이다 - 한 상수로는 못 나른다(링크별 상수도 표본외 MAE 약 160 s):

        움직이는 43.2%      관측 도착 중앙  15 s   150 s 내 86.9%
        정지-비큐 56.8%                  105 s   450 s 내 62.6%   (7.0배 격차)

    `urban_link_storage_stopped` 가 정확히 그 '정지했지만 큐에 없는' 집단이라 분할이 공짜다.

    ## 안전장치

    - 기본 꺼짐. config `urban.arrival.seed_from_residual` (env 폴백 `RW_ARRIVAL_SEED`).
      꺼져 있으면 아무것도 안 한다 = 비트 동일.
    - 450 s 를 넘는 만기는 **버린다**(`censor_drop`). 지평 밖 도착을 지평 끝에 몰아넣으면
      실재하지 않는 재고가 생긴다.
    - `approach_routing` 에 없는 링크는 건너뛴다 - plant 가 그 키를 소비하지 않는다.
    - `warm_start_release_buffers` 와 동시에 켜지 마라. 그쪽이 이미 82링크 492.4 veh 를
      예약해 두고 지평 내내 sink 게이트를 억제한다. 이중계상 미검증.
    """
    stats = {"links": 0.0, "moving_veh": 0.0, "stopped_veh": 0.0, "dropped_veh": 0.0}
    if not _switch("arrival_seed", "RW_ARRIVAL_SEED"):
        return stats
    buffer = getattr(state, "urban_arrival_buffer", None)
    if not isinstance(buffer, dict):
        return stats
    try:
        from src.models.urban_queue_model import _schedule, approach_routing
    except Exception:  # noqa: BLE001 - 상류 스냅샷에 없으면 조용히 건너뛴다
        return stats

    occupancy_by_link = _mapping(local_summary.get("urban_link_storage_occupancy"))
    stopped_by_link = _mapping(local_summary.get("urban_link_storage_stopped"))
    routing = set(approach_routing(cfg))
    step_sec = max(float(cfg.simulation.T_u_sec), 1.0e-9)
    start_step = int(round(float(getattr(state, "time_sec", 0.0)) / step_sec))
    tau_moving = _ARRIVAL_TAU_MOVING_SEC
    tau_stopped = _ARRIVAL_TAU_STOPPED_SEC
    horizon = _ARRIVAL_MAX_HORIZON_SEC

    for link in cfg.network.urban_link_storage_veh:
        key = str(link)
        if key not in routing:
            continue
        occupied = max(0.0, _as_float(occupancy_by_link.get(link, 0.0)))
        if occupied <= 0.0:
            continue
        stopped = min(occupied, max(0.0, _as_float(stopped_by_link.get(link, 0.0))))
        moving = max(0.0, occupied - stopped)
        touched = False
        for veh, tau in ((moving, tau_moving), (stopped, tau_stopped)):
            if veh <= 0.0:
                continue
            if tau > horizon:
                stats["dropped_veh"] += veh
                continue
            _schedule(buffer, key, start_step + max(1, int(round(tau / step_sec))), veh)
            touched = True
        stats["moving_veh"] += moving
        stats["stopped_veh"] += stopped
        if touched:
            stats["links"] += 1.0
    return stats


def restore_urban_release_buffers(state, cfg, local_summary: Mapping[str, Any]) -> dict[str, float]:
    """관측에서 저류의 **이동 중 예약**을 복원한다.

    ## 왜 필요한가 (2026-08-15 실측으로 밝힌 결함)

    투영은 저류 **점유량만** 싣고 `urban_storage_release_buffer` 를 비워 둔다. 그런데
    plant 의 방출은 전적으로 그 버퍼에 물려 있다.

        내부 링크   `released = _pop_buffer(...)` 가 >0 일 때만 available 복원
                    (urban_queue_model.py:962-973) -> 버퍼가 비면 **영원히 안 빠진다**
        sink(_out)  `arrived = occupancy - _pending_in_transit(...)` (:994)
                    -> 버퍼가 비면 **점유 전량이 즉시 방출 후보**가 된다

    그래서 첫 스텝에 내부 링크는 동결되어 유입만 쌓이고(+114~208%), sink 는 통째로
    비워진다(정확히 -100%). 저류별 APE 중앙값이 스텝 0 에서 0.0% 인데 스텝 1 에서
    54.8% 로 튀고 그 뒤 평평한 것이 이 재배치다.

    sink 코드의 주석이 그 뺄셈을 넣은 이유를 직접 적어 놨다 - 안 빼면 "진입 substep 에
    곧바로 이탈해 out 링크 통행시간이 0". 버퍼가 비면 그 옛 버그가 그대로 재현된다.

    ## 어떻게 복원하는가

    추정하지 않는다. 관측이 정지/이동을 갈라 준다.

        정지 대수      정지선에 이미 도착한 몫. 예약 없이 둔다(즉시 방출 가능).
        점유 - 정지    아직 이동 중. plant 자신의 `_link_delay_steps` 로 만기 스텝을
                       구해 1..delay 에 **균등 분산**한다. 정상류가 계속 진입해 온
                       링크의 정상상태 분포가 균등이기 때문이다.

    내부 링크는 예약이 없으면 동결되므로 정지 몫도 다음 substep 에 만기로 넣는다.
    sink 는 정지 몫을 예약하지 않아야 출구 게이트가 내보낸다.

    되돌릴 수 있게 기본은 **꺼짐**이다. `RW_RESTORE_RELEASE_BUFFERS=1` 로 켠다.
    """
    stats = {"links": 0.0, "in_transit_veh": 0.0, "arrived_veh": 0.0}
    # 2026-09-04. env 전용이던 게이트를 config 로 올린다 — `urban.release_buffer.restore`.
    # env 는 폴백으로만 남긴다. 기본은 여전히 off: 이 스위치를 켠 런이 39개 기록 중 0개라
    # 폐루프 부호가 미검증이고, 2단계(arrival 시더)가 이미 도착 경로를 열었으므로 둘의
    # 상호작용부터 재야 한다. **게이트를 보이게 만드는 것과 기능을 켜는 것은 다르다.**
    mode = str(_CFG_STRINGS.get("release_buffer_restore", "")).strip().lower()  # 2026-09-05 env 폴백 삭제
    # off(기본) / sinks(sink 만) / all(전부). 실측상 all 은 더 나쁘다 - 아래 주석 참조.
    if mode in {"", "0", "off", "false"}:
        return stats
    if mode in {"1", "true"}:
        mode = "all"
    if mode not in {"sinks", "all"}:
        return stats
    buffer = getattr(state, "urban_storage_release_buffer", None)
    if not isinstance(buffer, dict):
        return stats
    try:
        from src.models.urban_queue_model import _link_delay_steps, _schedule, sink_storage_links
    except Exception:  # noqa: BLE001 - 상류 스냅샷에 없으면 조용히 건너뛴다(기존 거동 유지)
        return stats

    occupancy_by_link = _mapping(local_summary.get("urban_link_storage_occupancy"))
    stopped_by_link = _mapping(local_summary.get("urban_link_storage_stopped"))
    sinks = set(sink_storage_links(cfg))
    step_sec = max(float(cfg.simulation.T_u_sec), 1.0e-9)
    start_step = int(round(float(getattr(state, "time_sec", 0.0)) / step_sec))

    for link in cfg.network.urban_link_storage_veh:
        if mode == "sinks" and str(link) not in sinks:
            continue
        occupied = max(0.0, _as_float(occupancy_by_link.get(link, 0.0)))
        if occupied <= 0.0:
            continue
        stopped = min(occupied, max(0.0, _as_float(stopped_by_link.get(link, 0.0))))
        moving = max(0.0, occupied - stopped)
        # 지연은 plant 자신의 산식으로 잰다 - 여기서 다른 규칙을 쓰면 첫 스텝에 또 어긋난다.
        delay = max(1, int(_link_delay_steps(state, cfg, str(link))))
        if moving > 0.0:
            per = moving / float(delay)
            for k in range(1, delay + 1):
                _schedule(buffer, str(link), start_step + k, per)
            stats["in_transit_veh"] += moving
        if stopped > 0.0 and str(link) not in sinks:
            # 내부 링크는 예약이 없으면 동결된다. 도착분은 바로 다음 substep 만기.
            _schedule(buffer, str(link), start_step + 1, stopped)
        stats["arrived_veh"] += stopped
        stats["links"] += 1.0
    return stats


def traffic_state_from_vissim(
    state_json: dict[str, Any],
    cfg,
    TrafficState,
    detector_mapping: Mapping[str, Any] | None = None,
    calibration: Mapping[str, Any] | None = None,
    physical_projection_input: Mapping[str, Any] | None = None,
):
    state = TrafficState.initial(cfg)
    state.time_sec = float(state_json.get("sim_sec", 0.0))
    state.ensure_freeway_lane_profile(cfg.network)

    segs = state_json.get("freeway_segments", {})
    for link in cfg.network.freeway_links:
        rows = list(segs.get(link, []))
        densities: list[float] = []
        speeds: list[float] = []
        flows: list[float] = []
        lanes_profile: list[float] = []
        for i in range(cfg.network.freeway_segments_per_link):
            row = rows[i] if i < len(rows) and isinstance(rows[i], dict) else {}
            count = max(0.0, float(row.get("count", 0.0)))
            speed_sum = max(0.0, float(row.get("speed_sum", 0.0)))
            length_km = max(1.0e-6, float(row.get("length_km", cfg.network.freeway_segment_length_km)))
            lanes = max(1.0, float(row.get("lanes", cfg.network.freeway_lanes)))
            # 2026-09-07 세그먼트별 차로(freeway.segment_lanes=mapping): VBS 의 모형 링크 단일값 대신 매핑의 세그먼트 차로로
            #   밀도를 count/(length·lanes_i) 로 다시 잰다. state.freeway_effective_lanes 에도 그대로 실린다.
            _seg_lanes = _mapping(getattr(cfg.network, "freeway_segment_lanes", None) or {}).get(str(link))
            if isinstance(_seg_lanes, list) and i < len(_seg_lanes) and _as_float(_seg_lanes[i], 0.0) > 0.0:
                lanes = max(1.0, float(_seg_lanes[i]))
            speed = speed_sum / count if count > 1.0e-9 else float(cfg.network.v_free)
            density = count / (length_km * lanes)
            densities.append(float(density))
            speeds.append(float(speed))
            flows.append(float(density * speed * lanes))
            lanes_profile.append(float(lanes))
        state.freeway_density[link] = densities
        state.freeway_speed[link] = speeds
        state.freeway_flow[link] = flows
        state.freeway_effective_lanes[link] = lanes_profile

    local_summary = (
        build_local_observation_summary(
            state_json, cfg, detector_mapping or {}, calibration
        )
        if detector_mapping or physical_projection_input is not None
        else {}
    )
    if local_summary:
        for key in state.ramp_queue:
            state.ramp_queue[key] = float(local_summary["ramp_queue"].get(key, 0.0))
        for key in state.boundary_queue:
            state.boundary_queue[key] = float(local_summary["boundary_queue"].get(key, 0.0))
        for key in state.urban_movement_queue:
            state.urban_movement_queue[key] = float(local_summary["urban_movement_queue"].get(key, 0.0))
        storage_occupancy = local_summary.get("urban_link_storage_occupancy", {})
        if isinstance(storage_occupancy, Mapping):
            for link, capacity in cfg.network.urban_link_storage_veh.items():
                occupied = clamp(
                    _as_float(storage_occupancy.get(link, 0.0)),
                    0.0,
                    float(capacity),
                )
                state.urban_link_storage[link] = float(capacity) - occupied
        # 관측 링크속도를 상태에 싣는다(v3 N3-1b). `_link_delay_steps` 가 이걸 보고
        # 전역 `urban_avg_speed_km_h` 대신 링크별 통과시간을 잰다.
        # `hasattr` 가드가 필요한 이유 — 실런 기본 모델 저장소가 `vendor/NumSim-mine`
        # (해시고정 스냅샷, DEFAULT_REPO_ROOT:55-59)이고 그 TrafficState 에는 아직 이 필드가
        # 없다. 상류 재스냅샷 전까지는 조용히 건너뛰고 기존 거동(전역 상수)을 유지한다.
        observed_speeds = local_summary.get("urban_link_speed_kph", {})
        if isinstance(observed_speeds, Mapping) and hasattr(state, "urban_link_speed_kph"):
            for link, speed_kph in observed_speeds.items():
                if str(link) in cfg.network.urban_link_storage_veh:
                    state.urban_link_speed_kph[str(link)] = max(0.0, _as_float(speed_kph))
            _apply_lane_delay_correction(state, cfg, local_summary)
            # 경계 유입 재고를 모델이 쓰는 통(전이버퍼 + movement 큐)으로 옮긴다.
            # 꺼져 있으면 아무것도 안 한다(비트 동일).
            local_summary["boundary_inflow_seed"] = seed_boundary_inflow(cfg, state, local_summary)
            # 차로 보정 **뒤에** 잰다 — 실제로 모델이 쓸 τ 가 여기서 확정된다.
            _tau_diagnostics(state, cfg, local_summary)
        # 잔차를 도착 버퍼에 예약한다. 꺼져 있으면 무동작 = 비트 동일.
        local_summary["urban_arrival_seed"] = seed_urban_arrival_buffer(state, cfg, local_summary)
        restore_urban_release_buffers(state, cfg, local_summary)
        # 버퍼를 손으로 짓지 않고 plant 가 짓게 하는 경로. 기본 꺼짐(RW_WARMSTART_SEC).
        state.warmstart_diagnostics = warm_start_release_buffers(
            state, cfg, state_json, calibration, detector_mapping
        )
        state.local_observation_summary = local_summary
    else:
        ramp_counts = state_json.get("ramp_counts", {})
        if isinstance(ramp_counts, Mapping) and any(str(key) in ramp_counts for key in state.ramp_queue):
            for key in state.ramp_queue:
                state.ramp_queue[key] = max(0.0, _as_float(ramp_counts.get(str(key), 0.0)))
        else:
            d_queue = max(0.0, float(ramp_counts.get("D", 0.0)))
            f_queue = max(0.0, float(ramp_counts.get("F", 0.0)))
            state.ramp_queue.update({
                "R_D_W": d_queue / 2.0,
                "R_D_E": d_queue / 2.0,
                "R_F_W": f_queue / 2.0,
                "R_F_E": f_queue / 2.0,
            })

        # Legacy global-state fallback for old state files. Local detector
        # observation must be preferred whenever it is present.
        urban_total = max(0.0, float(state_json.get("urban_vehicles", 0.0)))
        boundary_total = max(0.0, float(state_json.get("boundary_vehicles", 0.0)))
        if state.boundary_queue:
            per = boundary_total / max(1, len(state.boundary_queue))
            for key in state.boundary_queue:
                state.boundary_queue[key] = per
        if state.urban_movement_queue:
            protected_kinds = {"internal", "boundary_out", "off_ramp"}
            protected_movements = [
                movement
                for movement, spec in cfg.network.urban_movements.items()
                if str(spec.get("kind", "")) in protected_kinds
                and movement in state.urban_movement_queue
            ]
            boundary_in_movements = [
                movement
                for movement, spec in cfg.network.urban_movements.items()
                if str(spec.get("kind", "")) == "boundary_in"
                and movement in state.urban_movement_queue
            ]
            for key in state.urban_movement_queue:
                state.urban_movement_queue[key] = 0.0
            if protected_movements:
                per_protected = urban_total / max(1, len(protected_movements))
                for key in protected_movements:
                    state.urban_movement_queue[key] = per_protected
            elif state.urban_movement_queue:
                per = urban_total / max(1, len(state.urban_movement_queue))
                for key in state.urban_movement_queue:
                    state.urban_movement_queue[key] = per
            if boundary_in_movements:
                per_boundary = boundary_total / max(1, len(boundary_in_movements))
                for key in boundary_in_movements:
                    state.urban_movement_queue[key] = per_boundary
    if physical_projection_input is not None:
        # The B1a ledger is a required state-construction input. B1b remains
        # responsible for defining stock-to-dynamics transfer semantics.
        state.physical_projection_input = physical_projection_input
        state.physical_projection_ledger = physical_projection_input["ledger"]
    # B4c (2026-09-06): 착지 접근로 점유를 plant 링크 재차에서 심는다 (사양 없으면 no-op).
    _apply_landing_storage(state, cfg, state_json)
    _apply_gate_onramp_beta(cfg, state_json)
    return state


def control_from_json(path: Path, cfg, ControlAction):
    if not path.exists():
        return ControlAction.fixed(cfg)
    raw = json.loads(path.read_text(encoding="utf-8"))
    return ControlAction(
        N_P_star=float(raw.get("N_P_star", 0.0)),
        N_UF_star=float(raw.get("N_UF_star", 0.0)),
        ramp_metering={str(k): float(v) for k, v in raw.get("ramp_metering", {}).items()},
        vsl={str(k): float(v) for k, v in raw.get("vsl", {}).items()},
        green_times={str(k): float(v) for k, v in raw.get("green_times", {}).items()},
        offsets={str(k): float(v) for k, v in raw.get("offsets", {}).items()},
        inflow_outflow_allocation={
            str(k): float(v) for k, v in raw.get("inflow_outflow_allocation", {}).items()
        },
        diagnostics=dict(raw.get("diagnostics", {})),
    )


def control_to_json_dict(
    control,
    metadata: dict[str, Any],
    prediction: dict[str, Any] | None = None,
    prediction_error: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = {
        "N_P_star": float(control.N_P_star),
        "N_UF_star": float(control.N_UF_star),
        "ramp_metering": {str(k): float(v) for k, v in control.ramp_metering.items()},
        "vsl": {str(k): float(v) for k, v in control.vsl.items()},
        "green_times": {str(k): float(v) for k, v in control.green_times.items()},
        "offsets": {str(k): float(v) for k, v in control.offsets.items()},
        "inflow_outflow_allocation": {
            str(k): float(v) for k, v in control.inflow_outflow_allocation.items()
        },
        "diagnostics": {**dict(control.diagnostics), **_QPRICE_LAST, **_RAMPLOCAL_LAST, **_LEGSPLIT_LAST, **_GREENBOX_LAST,
                        "mainline_plan_enabled": 1.0 if _mainline_plan_enabled() else 0.0,
                        "mainline_share_enabled": 1.0 if str(os.environ.get(
                            "RW_MAINLINE_SHARE_SG", "")).strip().lower() in {"1", "true", "on"} else 0.0},
        "metadata": metadata,
    }
    run_provenance = metadata.get("run_provenance")
    if isinstance(run_provenance, Mapping):
        payload["run_provenance"] = dict(run_provenance)
    projection_diagnostics = metadata.get("projection_diagnostics")
    if isinstance(projection_diagnostics, Mapping):
        payload["projection_diagnostics"] = dict(projection_diagnostics)
    projection_provenance = metadata.get("physical_projection_provenance")
    if isinstance(projection_provenance, Mapping):
        payload["physical_projection_provenance"] = dict(projection_provenance)
    if prediction:
        payload["prediction"] = prediction
    if prediction_error:
        payload["prediction_error"] = prediction_error
    return payload


PREDICTION_AUDIT_SCALARS = [
    "total_model_vehicles",
    "urban_total_veh",
    "protected_accumulation_veh",
    "urban_queue_plus_link_occupancy_total_veh",
    "urban_movement_queue_total_veh",
    "urban_link_occupancy_total_veh",
    "boundary_queue_total_veh",
    "freeway_total_veh",
    "freeway_segment_total_veh",
    "off_ramp_storage_veh",
    "ramp_queue_total_veh",
    "mainline_origin_queue_total_veh",
    "freeway_mean_density_veh_km_lane",
    "freeway_mean_speed_kph",
]


def summarize_model_state(state, cfg) -> dict[str, Any]:
    net = cfg.network
    state.ensure_freeway_lane_profile(net)
    freeway_counts = _freeway_vehicle_count_by_link(state, cfg)
    freeway_segment_counts = {
        link: [float(v) for v in freeway_counts.get(link, [])]
        for link in net.freeway_links
    }
    freeway_segment_total = float(sum(sum(values) for values in freeway_segment_counts.values()))
    speed_weight = 0.0
    vehicle_weight = 0.0
    density_sum = 0.0
    density_n = 0
    for link in net.freeway_links:
        speeds = list(state.freeway_speed.get(link, []))
        densities = list(state.freeway_density.get(link, []))
        counts = freeway_counts.get(link, [])
        for i, rho in enumerate(densities):
            density_sum += float(rho)
            density_n += 1
            count = float(counts[i]) if i < len(counts) else 0.0
            speed = float(speeds[i]) if i < len(speeds) else float(net.v_free)
            speed_weight += speed * max(0.0, count)
            vehicle_weight += max(0.0, count)
    urban_link_occupancy = 0.0
    for link, capacity in net.urban_link_storage_veh.items():
        urban_link_occupancy += max(0.0, float(capacity) - float(state.urban_link_storage.get(link, capacity)))
    ramp_queue_total = float(sum(max(0.0, float(v)) for v in state.ramp_queue.values()))
    mainline_origin_queue_total = float(
        sum(max(0.0, float(v)) for v in state.mainline_origin_queue.values())
    )
    urban_total = float(state.total_urban_vehicles(net))
    freeway_total = freeway_segment_total
    off_ramp_storage = float(state.off_ramp_storage_occupancy_veh(net))
    return {
        "time_sec": float(getattr(state, "time_sec", 0.0)),
        "total_model_vehicles": float(urban_total + freeway_total + off_ramp_storage),
        "urban_total_veh": urban_total,
        "protected_accumulation_veh": float(state.protected_accumulation_veh(net)),
        "urban_queue_plus_link_occupancy_total_veh": float(
            sum(max(0.0, float(v)) for v in state.urban_movement_queue.values())
            + urban_link_occupancy
        ),
        "urban_movement_queue_total_veh": float(
            sum(max(0.0, float(v)) for v in state.urban_movement_queue.values())
        ),
        "urban_link_occupancy_total_veh": float(urban_link_occupancy),
        "boundary_queue_total_veh": float(sum(max(0.0, float(v)) for v in state.boundary_queue.values())),
        "freeway_total_veh": freeway_total,
        "freeway_segment_total_veh": freeway_segment_total,
        "off_ramp_storage_veh": off_ramp_storage,
        "ramp_queue_total_veh": ramp_queue_total,
        "mainline_origin_queue_total_veh": mainline_origin_queue_total,
        "freeway_mean_density_veh_km_lane": float(density_sum / density_n) if density_n else 0.0,
        "freeway_mean_speed_kph": float(speed_weight / vehicle_weight) if vehicle_weight > 1.0e-9 else float(net.v_free),
        "ramp_queue": {str(k): float(v) for k, v in sorted(state.ramp_queue.items())},
        "freeway_segment_vehicles": freeway_segment_counts,
    }


def apply_prediction_audit_calibration(
    summary: Mapping[str, Any],
    calibration: Mapping[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, float]]:
    prediction = _mapping((calibration or {}).get("prediction"))
    audit = _mapping(prediction.get("audit_calibration"))
    if not audit:
        return {}, {}

    enabled = bool(audit.get("enabled", True))
    if not enabled:
        return {}, {}

    freeway_scale = _as_float(
        audit.get("freeway_total_scale", audit.get("freeway_total_observed_over_predicted_mean")),
        1.0,
    )
    urban_mass_scale = _as_float(
        audit.get(
            "urban_queue_plus_storage_scale",
            audit.get("urban_queue_plus_storage_observed_over_predicted_mean"),
        ),
        1.0,
    )
    if not (0.05 <= freeway_scale <= 5.0):
        freeway_scale = 1.0
    if not (0.05 <= urban_mass_scale <= 5.0):
        urban_mass_scale = 1.0

    calibrated = dict(summary)
    metadata: dict[str, float] = {}
    old_freeway = _as_float(summary.get("freeway_total_veh"), 0.0)
    old_freeway_segment = _as_float(summary.get("freeway_segment_total_veh"), old_freeway)
    new_freeway = old_freeway * freeway_scale
    new_freeway_segment = old_freeway_segment * freeway_scale
    calibrated["freeway_total_veh"] = float(new_freeway)
    calibrated["freeway_segment_total_veh"] = float(new_freeway_segment)
    calibrated["freeway_mean_density_veh_km_lane"] = float(
        _as_float(summary.get("freeway_mean_density_veh_km_lane"), 0.0) * freeway_scale
    )
    calibrated["total_model_vehicles"] = float(
        _as_float(summary.get("total_model_vehicles"), 0.0) + (new_freeway - old_freeway)
    )
    segment_vehicles = summary.get("freeway_segment_vehicles", {})
    if isinstance(segment_vehicles, Mapping):
        calibrated["freeway_segment_vehicles"] = {
            str(link): [
                float(_as_float(value) * freeway_scale)
                for value in values
            ]
            for link, values in segment_vehicles.items()
            if isinstance(values, list)
        }

    component_scales = _mapping(audit.get("component_scales"))
    recompute_queue_storage = bool(
        audit.get(
            "recompute_urban_queue_plus_storage_from_components",
            audit.get("preserve_component_consistency", False),
        )
    )
    recompute_urban_total = bool(
        audit.get(
            "recompute_urban_total_from_components",
            audit.get("preserve_component_consistency", False),
        )
    )
    recompute_model_total = bool(
        audit.get(
            "recompute_total_model_vehicles_from_components",
            audit.get("preserve_component_consistency", False),
        )
    )
    scale_aliases = {
        "total_model_vehicles": "total_model_vehicles_scale",
        "urban_total_veh": "urban_total_scale",
        "protected_accumulation_veh": "protected_accumulation_scale",
        "urban_movement_queue_total_veh": "urban_movement_queue_scale",
        "urban_link_occupancy_total_veh": "urban_link_occupancy_scale",
        "boundary_queue_total_veh": "boundary_queue_scale",
        "off_ramp_storage_veh": "off_ramp_storage_scale",
        "ramp_queue_total_veh": "ramp_queue_scale",
        "mainline_origin_queue_total_veh": "mainline_origin_queue_scale",
        "freeway_mean_speed_kph": "freeway_mean_speed_scale",
    }
    already_scaled = {
        "freeway_total_veh",
        "freeway_segment_total_veh",
        "freeway_mean_density_veh_km_lane",
        "urban_queue_plus_link_occupancy_total_veh",
    }
    scaled_metrics: set[str] = set()
    for metric, alias in scale_aliases.items():
        raw_scale = component_scales.get(metric, audit.get(alias))
        if raw_scale is None or metric in already_scaled or metric not in summary:
            continue
        scale = _as_float(raw_scale, 1.0)
        if not (0.05 <= scale <= 5.0):
            continue
        calibrated[metric] = float(_as_float(summary.get(metric), 0.0) * scale)
        metadata[f"prediction_audit_{metric}_scale"] = float(scale)
        scaled_metrics.add(metric)

    if "urban_queue_plus_link_occupancy_total_veh" in summary:
        if recompute_queue_storage and {
            "urban_movement_queue_total_veh",
            "urban_link_occupancy_total_veh",
        } & scaled_metrics:
            calibrated["urban_queue_plus_link_occupancy_total_veh"] = float(
                _as_float(calibrated.get("urban_movement_queue_total_veh"), 0.0)
                + _as_float(calibrated.get("urban_link_occupancy_total_veh"), 0.0)
            )
            metadata["prediction_audit_urban_queue_plus_storage_recomputed"] = 1.0
        else:
            calibrated["urban_queue_plus_link_occupancy_total_veh"] = float(
                _as_float(summary.get("urban_queue_plus_link_occupancy_total_veh"), 0.0)
                * urban_mass_scale
            )

    if recompute_urban_total and {
        "urban_movement_queue_total_veh",
        "urban_link_occupancy_total_veh",
        "off_ramp_storage_veh",
    } & scaled_metrics:
        movement = _as_float(calibrated.get("urban_movement_queue_total_veh"), 0.0)
        link_occupancy = _as_float(calibrated.get("urban_link_occupancy_total_veh"), 0.0)
        off_ramp_storage = _as_float(calibrated.get("off_ramp_storage_veh"), 0.0)
        calibrated["urban_total_veh"] = float(movement + max(0.0, link_occupancy - off_ramp_storage))
        metadata["prediction_audit_urban_total_recomputed"] = 1.0

    if recompute_model_total and {
        "urban_total_veh",
        "freeway_total_veh",
        "off_ramp_storage_veh",
        "urban_movement_queue_total_veh",
        "urban_link_occupancy_total_veh",
    } & (scaled_metrics | {"freeway_total_veh"}):
        calibrated["total_model_vehicles"] = float(
            _as_float(calibrated.get("urban_total_veh"), 0.0)
            + _as_float(calibrated.get("freeway_total_veh"), 0.0)
            + _as_float(calibrated.get("off_ramp_storage_veh"), 0.0)
        )
        metadata["prediction_audit_total_model_vehicles_recomputed"] = 1.0

    metadata.update({
        "prediction_audit_calibration_applied": 1.0,
        "prediction_audit_freeway_total_scale": float(freeway_scale),
        "prediction_audit_urban_queue_plus_storage_scale": float(urban_mass_scale),
    })
    return calibrated, metadata


def _workspace_path(path_text: str, default: Path | None = None) -> Path:
    if not path_text:
        return default if default is not None else WORKSPACE_ROOT
    path = Path(path_text)
    if path.is_absolute():
        return path
    return WORKSPACE_ROOT / path


def install_adapter_calibration_fingerprints(cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    """Mark canary-protected components as calibrated for the current VISSIM geometry.

    The upstream controller stores component calibration fingerprints as module
    globals. In this workspace we cannot edit the external Numerical-Sim checkout,
    so VISSIM-specific tuning can explicitly declare that those components have
    been revalidated against the current 8-seg merge map.
    """
    settings = _mapping(_mapping(tuning.get("adapter")).get("calibration_fingerprints"))
    if str(settings.get("mode", "")).lower() != "current_vissim_geometry":
        return {}
    components = settings.get("components", ["leader_hinge", "np_deadband", "leader_mfd_far"])
    if not isinstance(components, list):
        components = ["leader_hinge", "np_deadband", "leader_mfd_far"]
    merge_map = {
        str(key): int(value)
        for key, value in dict(getattr(cfg.network, "ramp_merge_segment_index", {}) or {}).items()
    }
    if not merge_map:
        return {}
    try:
        from src.controllers import stackelberg_mpc as stackelberg_module

        for component in components:
            stackelberg_module.CALIBRATION_FINGERPRINTS[str(component)] = {
                "ramp_merge": dict(merge_map),
            }
        if hasattr(stackelberg_module, "_calib_fingerprint_warned"):
            stackelberg_module._calib_fingerprint_warned.clear()
    except Exception:
        return {"adapter_calibration_fingerprint_override_failed": 1.0}
    return {
        "adapter_calibration_fingerprint_override_active": 1.0,
        "adapter_calibration_fingerprint_component_count": float(len(components)),
        "adapter_calibration_fingerprint_merge_R_D_W": float(merge_map.get("R_D_W", -1)),
        "adapter_calibration_fingerprint_merge_R_F_W": float(merge_map.get("R_F_W", -1)),
        "adapter_calibration_fingerprint_merge_R_D_E": float(merge_map.get("R_D_E", -1)),
        "adapter_calibration_fingerprint_merge_R_F_E": float(merge_map.get("R_F_E", -1)),
    }


def _freeway_excess_vehicle_proxy(state, cfg) -> float:
    net = cfg.network
    state.ensure_freeway_lane_profile(net)
    excess = 0.0
    for link, densities in getattr(state, "freeway_density", {}).items():
        lanes = getattr(state, "freeway_effective_lanes", {}).get(link, [])
        for idx, rho in enumerate(densities):
            lane_count = float(lanes[idx]) if idx < len(lanes) else float(net.freeway_lanes)
            excess += (
                max(0.0, _as_float(rho) - float(net.rho_crit))
                * float(net.freeway_segment_length_km)
                * max(1.0e-9, lane_count)
            )
    return float(excess)


def vissim_terminal_feature_vector(state, cfg) -> dict[str, float]:
    """Map a model-predicted state to the aggregate fields used by VISSIM CSV fits."""
    net = cfg.network
    summary = summarize_model_state(state, cfg)
    freeway = max(0.0, _as_float(summary.get("freeway_segment_total_veh")))
    ramp = max(0.0, _as_float(summary.get("ramp_queue_total_veh"))) + max(
        0.0, _as_float(summary.get("off_ramp_storage_veh"))
    )
    boundary = max(0.0, _boundary_in_queue_veh(state, cfg))
    urban_total = max(0.0, _as_float(summary.get("urban_total_veh")))
    urban = max(0.0, urban_total - boundary)
    mainline_origin = max(0.0, _as_float(summary.get("mainline_origin_queue_total_veh")))
    total = freeway + urban + ramp + boundary + mainline_origin
    urban_queue = max(0.0, _as_float(summary.get("urban_movement_queue_total_veh")))
    stopped = min(
        total,
        ramp
        + boundary
        + 0.5 * max(0.0, urban_queue - boundary)
        + _freeway_excess_vehicle_proxy(state, cfg),
    )
    freeway_speed = max(0.0, _as_float(summary.get("freeway_mean_speed_kph"), float(net.v_free)))
    urban_speed = max(0.0, float(getattr(net, "urban_avg_speed_km_h", 50.0)))
    ramp_speed = 15.0
    boundary_speed = 5.0
    mean_speed = (
        freeway * freeway_speed
        + urban * urban_speed
        + ramp * ramp_speed
        + boundary * boundary_speed
    ) / max(total, 1.0e-9)
    return {
        "total_vehicles": float(total),
        "urban_vehicles": float(urban),
        "freeway_vehicles": float(freeway),
        "ramp_vehicles": float(ramp),
        "boundary_vehicles": float(boundary),
        "stopped_vehicles": float(stopped),
        "mean_speed_kph": float(mean_speed),
        "freeway_mean_speed_kph": float(freeway_speed),
    }


def vissim_terminal_feature_vector_from_summary(summary: Mapping[str, Any], cfg) -> dict[str, float]:
    """Best-effort terminal features from a serialized prediction summary."""
    net = cfg.network
    freeway = max(0.0, _as_float(summary.get("freeway_segment_total_veh")))
    ramp = max(0.0, _as_float(summary.get("ramp_queue_total_veh"))) + max(
        0.0, _as_float(summary.get("off_ramp_storage_veh"))
    )
    boundary = max(0.0, _as_float(summary.get("boundary_queue_total_veh")))
    urban_total = max(0.0, _as_float(summary.get("urban_total_veh")))
    urban = max(0.0, urban_total - boundary)
    mainline_origin = max(0.0, _as_float(summary.get("mainline_origin_queue_total_veh")))
    total = freeway + urban + ramp + boundary + mainline_origin
    urban_queue = max(0.0, _as_float(summary.get("urban_movement_queue_total_veh")))
    stopped = _as_float(summary.get("stopped_vehicles"), -1.0)
    if stopped < 0.0:
        stopped = min(total, ramp + boundary + 0.5 * max(0.0, urban_queue - boundary))
    else:
        stopped = max(0.0, stopped)
    freeway_speed = max(0.0, _as_float(summary.get("freeway_mean_speed_kph"), float(net.v_free)))
    urban_speed = max(0.0, float(getattr(net, "urban_avg_speed_km_h", 50.0)))
    ramp_speed = 15.0
    boundary_speed = 5.0
    mean_speed = (
        freeway * freeway_speed
        + urban * urban_speed
        + ramp * ramp_speed
        + boundary * boundary_speed
    ) / max(total, 1.0e-9)
    return {
        "total_vehicles": float(total),
        "urban_vehicles": float(urban),
        "freeway_vehicles": float(freeway),
        "ramp_vehicles": float(ramp),
        "boundary_vehicles": float(boundary),
        "stopped_vehicles": float(stopped),
        "mean_speed_kph": float(mean_speed),
        "freeway_mean_speed_kph": float(freeway_speed),
    }


def install_vissim_terminal_cost_objective(controller, cfg, tuning: Mapping[str, Any]) -> dict[str, float]:
    settings = _mapping(_mapping(tuning.get("adapter")).get("terminal_cost"))
    if not bool(settings.get("enabled", False)):
        return {}
    fit_path = _workspace_path(
        str(settings.get("fit_json", "evaluation/calibration/vissim_terminal_cost_fit_20260715.json"))
    )
    try:
        fit = json.loads(fit_path.read_text(encoding="utf-8"))
    except Exception:
        return {"adapter_vissim_terminal_cost_load_failed": 1.0}
    raw_coefficients = _mapping(fit.get("raw_coefficients"))
    features = settings.get("features", fit.get("features", []))
    if not isinstance(features, list):
        features = list(raw_coefficients)
    coefficient_mode = str(settings.get("coefficient_mode", "positive_only")).lower()
    include_intercept = bool(settings.get("include_intercept", False))
    clamp_nonnegative = bool(settings.get("clamp_nonnegative", True))
    weight = _as_float(settings.get("weight"), 1.0)
    intercept = _as_float(fit.get("raw_intercept"), 0.0) if include_intercept else 0.0
    used: dict[str, float] = {}
    for feature in features:
        name = str(feature)
        coef = _as_float(raw_coefficients.get(name), 0.0)
        if coefficient_mode == "positive_only" and coef <= 0.0:
            continue
        used[name] = float(coef)
    if not used and abs(intercept) <= 1.0e-12:
        return {"adapter_vissim_terminal_cost_empty": 1.0}

    original_objective_terms = controller.leader.objective_terms

    def objective_terms_with_vissim_terminal(
        predicted_states,
        action,
        previous,
        follower_objective,
        nash_converged,
        nash_residual_objective=0.0,
        nash_residual_control=0.0,
    ):
        states = list(predicted_states)
        terms = original_objective_terms(
            states,
            action,
            previous,
            follower_objective,
            nash_converged,
            nash_residual_objective,
            nash_residual_control,
        )
        if not states:
            return terms
        vector = vissim_terminal_feature_vector(states[-1], cfg)
        raw = float(intercept)
        for feature, coef in used.items():
            value = float(vector.get(feature, 0.0))
            raw += coef * value
            terms[f"leader_vissim_terminal_feature_{feature}"] = value
            terms[f"leader_vissim_terminal_coef_{feature}"] = float(coef)
        if clamp_nonnegative:
            raw = max(0.0, raw)
        penalty = weight * raw
        terms["leader_vissim_terminal_cost_active"] = 1.0
        terms["leader_vissim_terminal_cost_raw_veh_h"] = float(raw)
        terms["leader_vissim_terminal_cost_weight"] = float(weight)
        terms["leader_vissim_terminal_cost_penalty"] = float(penalty)
        terms["leader_vissim_terminal_cost_feature_count"] = float(len(used))
        terms["leader_total_objective"] = float(terms.get("leader_total_objective", 0.0)) + penalty
        return terms

    controller.leader.objective_terms = objective_terms_with_vissim_terminal
    return {
        "adapter_vissim_terminal_cost_active": 1.0,
        "adapter_vissim_terminal_cost_weight": float(weight),
        "adapter_vissim_terminal_cost_feature_count": float(len(used)),
        "adapter_vissim_terminal_cost_horizon_sec": _as_float(fit.get("horizon_sec"), 0.0),
        "adapter_vissim_terminal_cost_fit_r2": _as_float(_mapping(fit.get("metrics")).get("r2"), 0.0),
    }


def build_one_step_prediction(state, control, forecast, cfg, calibration: Mapping[str, Any] | None = None) -> dict[str, Any]:
    started = time.perf_counter()
    try:
        from src.controllers.rollout_endpoint import ObjectiveSpec, evaluate_price_point

        demand = list(forecast)[0]
        # 한스텝 예측도 상류 rollout endpoint 를 거친다(N7 "우회 호출 0").
        predicted = evaluate_price_point(
            state,
            control,
            [demand],
            (),
            ObjectiveSpec(cfg=cfg, depth_override=1, box_walk=False),
        ).states[-1]
        predicted.time_sec = float(getattr(state, "time_sec", 0.0)) + float(cfg.simulation.control_interval)
        state_summary = summarize_model_state(predicted, cfg)
        try:
            terminal_features = vissim_terminal_feature_vector(predicted, cfg)
        except Exception:
            terminal_features = vissim_terminal_feature_vector_from_summary(state_summary, cfg)
        calibrated_summary, audit_metadata = apply_prediction_audit_calibration(state_summary, calibration)
        payload = {
            "schema_version": 1,
            "status": "ok",
            "mode": "coupled_interval_one_step",
            "from_sim_sec": float(getattr(state, "time_sec", 0.0)),
            "target_sim_sec": float(predicted.time_sec),
            "control_interval_sec": float(cfg.simulation.control_interval),
            "wall_sec": round(time.perf_counter() - started, 6),
            "state_summary": state_summary,
            "terminal_features": terminal_features,
        }
        if calibrated_summary:
            payload["calibrated_state_summary"] = calibrated_summary
            payload["audit_calibration"] = audit_metadata
        return payload
    except Exception as exc:
        return {
            "schema_version": 1,
            "status": "error",
            "mode": "coupled_interval_one_step",
            "from_sim_sec": float(getattr(state, "time_sec", 0.0)),
            "control_interval_sec": float(cfg.simulation.control_interval),
            "wall_sec": round(time.perf_counter() - started, 6),
            "error_type": type(exc).__name__,
            "error": str(exc),
        }


def prediction_error_from_previous(previous_path: Path, observed_summary: Mapping[str, Any]) -> dict[str, Any]:
    if not previous_path.exists():
        return {}
    try:
        raw = json.loads(previous_path.read_text(encoding="utf-8"))
        prediction = raw.get("prediction", {})
        if not isinstance(prediction, Mapping) or prediction.get("status") != "ok":
            return {}
        predicted_summary = prediction.get("calibrated_state_summary", prediction.get("state_summary", {}))
        if not isinstance(predicted_summary, Mapping):
            return {}
        prediction_summary_kind = (
            "calibrated_state_summary"
            if isinstance(prediction.get("calibrated_state_summary"), Mapping)
            else "state_summary"
        )
        scalar_errors: dict[str, dict[str, float]] = {}
        abs_sum = 0.0
        count = 0
        for key in PREDICTION_AUDIT_SCALARS:
            if key not in predicted_summary or key not in observed_summary:
                continue
            predicted = float(predicted_summary.get(key, 0.0))
            observed = float(observed_summary.get(key, 0.0))
            error = observed - predicted
            scalar_errors[key] = {
                "predicted": predicted,
                "observed": observed,
                "error": error,
                "abs_error": abs(error),
                "relative_error": error / max(1.0, abs(predicted)),
            }
            abs_sum += abs(error)
            count += 1
        return {
            "schema_version": 1,
            "status": "ok",
            "source_action_json": str(previous_path),
            "predicted_from_sim_sec": float(prediction.get("from_sim_sec", 0.0)),
            "predicted_for_sim_sec": float(prediction.get("target_sim_sec", 0.0)),
            "observed_sim_sec": float(observed_summary.get("time_sec", 0.0)),
            "target_lag_sec": float(observed_summary.get("time_sec", 0.0)) - float(prediction.get("target_sim_sec", 0.0)),
            "prediction_summary_kind": prediction_summary_kind,
            "mean_abs_scalar_error": float(abs_sum / count) if count else 0.0,
            "scalar_errors": scalar_errors,
        }
    except Exception as exc:
        return {
            "schema_version": 1,
            "status": "error",
            "source_action_json": str(previous_path),
            "error_type": type(exc).__name__,
            "error": str(exc),
        }


def green_from_release_map(rate_vph: float, curve: Mapping[str, Any], default_green: float = 10.0) -> float:
    points: list[tuple[float, float]] = []
    for green, release in curve.items():
        try:
            points.append((float(green), float(release)))
        except (TypeError, ValueError):
            continue
    if not points:
        return float(default_green)
    points = sorted(points, key=lambda item: item[0])
    monotone: list[tuple[float, float]] = []
    best_release = -1.0
    for green, release in points:
        best_release = max(best_release, release)
        monotone.append((green, best_release))
    rate = max(0.0, float(rate_vph))
    if rate <= monotone[0][1]:
        return monotone[0][0]
    for (g0, r0), (g1, r1) in zip(monotone, monotone[1:]):
        if rate <= r1:
            if r1 <= r0:
                return g1
            frac = (rate - r0) / (r1 - r0)
            return g0 + frac * (g1 - g0)
    return monotone[-1][0]


def physical_ramp_actions(control, cfg, actuation: Mapping[str, Any]) -> dict[str, dict[str, float]]:
    cap = cfg.network.ramp_capacity_veh_h
    d_rate = (
        float(control.ramp_metering.get("R_D_W", cap.get("R_D_W", 1500.0)))
        + float(control.ramp_metering.get("R_D_E", cap.get("R_D_E", 1500.0)))
    ) / 2.0
    f_rate = (
        float(control.ramp_metering.get("R_F_W", cap.get("R_F_W", 1500.0)))
        + float(control.ramp_metering.get("R_F_E", cap.get("R_F_E", 1500.0)))
    ) / 2.0
    out = {}
    d_curve = actuation.get("D_green_to_release_vph", {})
    f_curve = actuation.get("F_green_to_release_vph", {})
    f_mode = str(actuation.get("F_ramp_mode", "always_green")).lower()
    d_rate = clamp(d_rate, 0.0, max((float(v) for v in d_curve.values()), default=1500.0) if isinstance(d_curve, Mapping) else 1500.0)
    d_green = green_from_release_map(d_rate, d_curve if isinstance(d_curve, Mapping) else {}, default_green=10.0)
    out["D"] = {"rate_vph": float(d_rate), "green_sec": float(clamp(round(d_green), 0.0, 10.0))}
    f_rate = clamp(f_rate, 0.0, max((float(v) for v in f_curve.values()), default=1500.0) if isinstance(f_curve, Mapping) else 1500.0)
    if f_mode in ("always_green", "monitor_only", "disabled"):
        f_green = 10.0
    else:
        f_green = green_from_release_map(f_rate, f_curve if isinstance(f_curve, Mapping) else {}, default_green=10.0)
    out["F"] = {"rate_vph": float(f_rate), "green_sec": float(clamp(round(f_green), 0.0, 10.0))}
    return out



# 2026-09-06 미터 액추에이션 전달함수. 차로당 10 s 주기당 방류 대수 n(g) — g=2·3 은 실측 중앙(n=198·110),
# g>=4 는 시동손실 뒤 포화 차두 ~2.2 s 로 외삽. g=10(열림)은 구속이 아니라 되쓰지 않는다.
METER_PER_LANE_VEH_PER_CYCLE_DEFAULT = {
    "2": 0.71, "3": 0.99, "4": 1.44, "5": 1.89, "6": 2.34, "7": 2.79, "8": 3.24, "9": 3.69, "10": 4.20,
}
METER_LANES_DEFAULT = {"RM_C10482": 2, "RM_C10681": 2}


def _meter_flow_vph(lanes: float, green: int, table: Mapping[str, float], cycle: float) -> float:
    if green <= 0:
        return 0.0
    n = table.get(str(int(green)))
    if n is None:
        keys = sorted(int(k) for k in table)
        if not keys:
            return 0.0
        # 표에 없는 green 은 가장 가까운 아래 항목으로
        below = [k for k in keys if k <= green]
        n = table[str(below[-1] if below else keys[0])]
    return float(lanes) * float(n) * 3600.0 / max(cycle, 1.0e-9)


def _measured_meter_allocation(control, cfg, settings: Mapping[str, Any], meters, demand: "Mapping[str, float] | None" = None) -> "dict[str, Any] | None":
    """allocation == "measured_table" 일 때 저수지별 커넥터 green 조합. 아니면 None(= 비트 동일).
    같은 결정 안에서 두 번 불려도(되쓰기 → CSV) 진단에 남긴 green 을 재사용해 같은 답을 낸다."""
    if str(settings.get("allocation", "")).strip().lower() != "measured_table":
        return None
    cycle = max(1.0e-6, _as_float(settings.get("cycle_sec"), 10.0))
    min_green = int(round(clamp(_as_float(settings.get("min_green_sec"), 2.0), 0.0, cycle)))
    max_green = int(round(clamp(_as_float(settings.get("max_green_sec"), cycle), float(min_green), cycle)))
    table = {str(k): float(v) for k, v in _mapping(settings.get("per_lane_veh_per_cycle") or METER_PER_LANE_VEH_PER_CYCLE_DEFAULT).items()}
    lanes_by = {str(k): float(v) for k, v in _mapping(settings.get("meter_lanes") or METER_LANES_DEFAULT).items()}
    close_below = clamp(_as_float(settings.get("close_below_frac"), 0.5), 0.0, 1.0)
    close_penalty = max(0.0, _as_float(settings.get("close_penalty_vph"), 100.0))
    diag = getattr(control, "diagnostics", None)
    if not isinstance(diag, dict):
        diag = {}
        try:
            control.diagnostics = diag
        except Exception:  # noqa: BLE001
            pass
    groups: dict[str, list[dict[str, Any]]] = {}
    for meter in meters:
        if not isinstance(meter, Mapping):
            continue
        mid = str(meter.get("id", meter.get("control_id", "")))
        key = str(meter.get("model_ramp_key", ""))
        if not mid or not key:
            continue
        groups.setdefault(key, []).append({"id": mid, "lanes": lanes_by.get(mid, 1.0),
                                           "demand": (float(demand[mid]) if (demand and mid in demand) else None)})
    green_out: dict[str, float] = {}
    realized: dict[str, float] = {}
    requested: dict[str, float] = {}
    capacities = getattr(cfg.network, "ramp_capacity_veh_h", {}) or {}
    greens = [0] + list(range(max(1, min_green), max_green + 1))
    for key, ms in groups.items():
        # 재사용: 이미 이 결정에서 배정했으면 그대로
        if all(("rw_meter_green_%s" % m["id"]) in diag for m in ms) and ("rw_meter_realized_%s" % key) in diag:
            for m in ms:
                green_out[m["id"]] = float(diag["rw_meter_green_%s" % m["id"]])
            realized[key] = float(diag["rw_meter_realized_%s" % key])
            requested[key] = float(diag.get("rw_meter_requested_%s" % key, realized[key]))
            continue
        cap_group = _as_float(capacities.get(key), 0.0)
        r = _as_float(control.ramp_metering.get(key), cap_group if cap_group > 0 else 1.0e9)
        r = max(0.0, r)
        requested[key] = r
        def _f(m, g):
            v = _meter_flow_vph(m["lanes"], g, table, cycle)
            return min(v, m["demand"]) if (m.get("demand") is not None and g > 0) else v
        open_total = sum(_f(m, max_green) for m in ms)
        if r >= open_total - 1.0e-9:
            for m in ms:
                green_out[m["id"]] = float(max_green)
            realized[key] = r  # 열림은 구속이 아니다 — 모형 요청값 유지
            diag["rw_meter_open_%s" % key] = 1.0
        else:
            best = None
            # 가능한 조합 전수 (커넥터 2개면 <= 100)
            def combos(idx: int, cur: list[int]):
                if idx == len(ms):
                    yield list(cur)
                    return
                for g in greens:
                    cur.append(g)
                    yield from combos(idx + 1, cur)
                    cur.pop()
            for gs in combos(0, []):
                total = sum(_f(m, g) for m, g in zip(ms, gs))
                err = abs(total - r)
                zeros = sum(1 for g in gs if g == 0)
                # 2026-09-07 F1: 커넥터를 닫는 벌점 = 그 커넥터의 수요 힌트(바닥 close_penalty). plant 는 경로결정으로 커넥터가 정해져
                #   닫힌 커넥터의 차량은 다른 커넥터로 못 옮긴다 — 수요 755 인 2차로 10482 를 닫고 1차로 10480 에 몰아준 b1 사고
                #   (링크 32 238→496, b1 실런 31결정 중 13결정이 한쪽 닫힘). 균일 100 벌점은 오차 |total−r| 에 묻혔다.
                #   config `actuation.real_world_ramp_metering.close_penalty_mode: "demand"` 로만 켠다(없으면 비트 동일).
                if str(settings.get("close_penalty_mode", "")).strip().lower() == "demand":
                    pen = sum(max(close_penalty, float(m.get("demand") or 0.0)) for m, g in zip(ms, gs) if g == 0)
                else:
                    pen = close_penalty * zeros
                score = (round(err + pen, 6), zeros, -sum(gs))
                if best is None or score < best[0]:
                    best = (score, gs, total)
            gs, total = best[1], best[2]
            nonzero = [_f(m, min_green) for m in ms]
            smallest = min(x for x in nonzero if x > 0) if any(x > 0 for x in nonzero) else 0.0
            if smallest > 0 and r < close_below * smallest:
                gs, total = [0 for _ in ms], 0.0
            for m, g in zip(ms, gs):
                green_out[m["id"]] = float(g)
            realized[key] = float(total)
            diag["rw_meter_open_%s" % key] = 0.0
        diag["rw_meter_requested_%s" % key] = float(requested[key])
        diag["rw_meter_realized_%s" % key] = float(realized[key])
        for m in ms:
            diag["rw_meter_green_%s" % m["id"]] = float(green_out[m["id"]])
    return {"green": green_out, "realized": realized, "requested": requested}


def apply_ramp_spillback_guard(control, cfg, state, actuation: Mapping[str, Any], metadata=None) -> dict[str, float]:
    """램프 스필백 제약 (2026-09-07): 검지 링크 위 정지 큐(ramp_spillback)가 문턱을 넘으면 그 램프의 미터 rate 를 floor 로 강제
    개방한다 — 커넥터 + 전용 상류 검지 링크 이상으로 스필백을 쌓아두지 않는다(사용자 요구). 되쓰기(write-back) **앞**에 불러
    강제값이 green 배정으로 실현되게 한다. `actuation.real_world_ramp_metering.spillback_guard` 가 없으면 no-op = 비트 동일."""
    settings = _mapping(_mapping(actuation.get("real_world_ramp_metering")).get("spillback_guard"))
    if not _is_enabled_value(settings.get("enabled", False)):
        return {}
    thr = max(0.0, _as_float(settings.get("spill_threshold_veh"), 8.0))
    floor = max(0.0, _as_float(settings.get("floor_vph"), 1800.0))
    summ = _mapping(getattr(state, "local_observation_summary", None) or {})
    spill = _mapping(summ.get("ramp_spillback"))
    out: dict[str, float] = {}
    for ramp, sv in spill.items():
        sv = _as_float(sv, 0.0)
        cur = _as_float(control.ramp_metering.get(ramp), 0.0)
        forced = bool(sv > thr and cur < floor)
        if forced:
            control.ramp_metering[ramp] = float(floor)
        out[ramp] = 1.0 if forced else 0.0
        if isinstance(metadata, dict):
            metadata["rw_spill_%s_veh" % ramp] = float(sv)
            metadata["rw_spill_guard_%s" % ramp] = 1.0 if forced else 0.0
            if forced:
                metadata["rw_spill_guard_%s_from_vph" % ramp] = float(cur)
    if isinstance(metadata, dict):
        metadata["rw_spill_guard_threshold_veh"] = thr
        metadata["rw_spill_guard_forced_count"] = float(sum(out.values()))
    return out


def real_world_ramp_meter_write_back(control, cfg, actuation: Mapping[str, Any], mapping: Mapping[str, Any], metadata=None,
                                     state_json=None, previous=None) -> dict[str, float]:
    """액션 JSON 을 쓰기 **전에** 실현 가능한 미터 유량을 control.ramp_metering 에 되쓴다. 게이트 밖이면 no-op."""
    meters = mapping.get("ramp_meters", []) if isinstance(mapping, Mapping) else []
    if not isinstance(meters, list) or not meters:
        return {}
    settings = _mapping(actuation.get("real_world_ramp_metering"))
    if str(settings.get("allocation", "")).strip().lower() != "measured_table":
        return {}
    # 커넥터별 수요 힌트 = max(직전 구간 실측 유량, decay × 이전 결정의 힌트), 바닥 demand_floor.
    decay = clamp(_as_float(settings.get("demand_decay"), 0.9), 0.0, 1.0)
    floor = max(0.0, _as_float(settings.get("demand_floor_vph"), 150.0))
    measured = {}
    if isinstance(state_json, Mapping):
        fm = _mapping(_mapping(state_json.get("local_observation")).get("far_measurement"))
        measured = {str(k): _as_float(v, 0.0) for k, v in _mapping(fm.get("link_volume_veh_h")).items()}
    prev_diag = dict(getattr(previous, "diagnostics", {}) or {}) if previous is not None else {}
    prior = {str(k): _as_float(v, 0.0) for k, v in _mapping(settings.get("demand_prior_vph")).items()}
    max_green = _as_float(settings.get("max_green_sec"), _as_float(settings.get("cycle_sec"), 10.0))
    demand: dict[str, float] = {}
    for meter in meters:
        if not isinstance(meter, Mapping):
            continue
        mid = str(meter.get("id", meter.get("control_id", "")))
        conn = str(int(_as_float(meter.get("connector"), 0.0)))
        now = measured.get(conn)
        prev = _as_float(prev_diag.get("rw_meter_demand_%s" % mid), prior.get(mid, 0.0))
        # 직전 결정에서 이 커넥터가 구속 중이었으면(green < max) 실측은 수요가 아니다 — 감쇠하지 않는다.
        prev_green = _as_float(prev_diag.get("rw_meter_green_%s" % mid), max_green)
        keep = 1.0 if prev_green < max_green - 1.0e-9 else decay
        est = max(float(now) if now is not None else 0.0, keep * prev, floor)
        demand[mid] = est
        control.diagnostics["rw_meter_demand_%s" % mid] = float(est)
    alloc = _measured_meter_allocation(control, cfg, settings, meters, demand=demand)
    if alloc is None:
        return {}
    out: dict[str, float] = {}
    if bool(settings.get("write_back_realized", True)):
        for key, val in alloc["realized"].items():
            if key in control.ramp_metering:
                control.ramp_metering[key] = float(val)
                out[key] = float(val)
    if isinstance(metadata, dict):
        metadata["rw_meter_allocation"] = "measured_table"
        metadata["rw_meter_write_back_count"] = float(len(out))
    return out

def real_world_ramp_meter_actions(
    control,
    cfg,
    actuation: Mapping[str, Any],
    mapping: Mapping[str, Any],
) -> dict[str, dict[str, float | str]]:
    """Map model ramp releases to physical real-world ramp-meter controllers."""
    diagnostic_rows = diagnostic_profile.physical_meter_actions(control, cfg, actuation, mapping)
    if diagnostic_rows is not None:
        return diagnostic_rows
    meters = mapping.get("ramp_meters", [])
    if not isinstance(meters, list) or not meters:
        return {}

    settings = _mapping(actuation.get("real_world_ramp_metering"))
    cycle = max(1.0e-6, _as_float(settings.get("cycle_sec"), 10.0))
    min_green = clamp(_as_float(settings.get("min_green_sec"), 0.0), 0.0, cycle)
    max_green = clamp(_as_float(settings.get("max_green_sec"), cycle), min_green, cycle)
    default_per_meter_capacity = max(1.0e-6, _as_float(settings.get("per_meter_capacity_vph"), 900.0))
    distribute = bool(settings.get("distribute_model_rate_across_meters", True))
    # measured_table 이면 커넥터별 green 을 전달함수로 배정한다(진단에 남긴 값 재사용).
    alloc = _measured_meter_allocation(control, cfg, settings, meters)

    group_counts: dict[str, int] = {}
    for meter in meters:
        if not isinstance(meter, Mapping):
            continue
        key = str(meter.get("model_ramp_key", ""))
        if key:
            group_counts[key] = group_counts.get(key, 0) + 1

    capacities = getattr(cfg.network, "ramp_capacity_veh_h", {}) or {}
    out: dict[str, dict[str, float | str]] = {}
    for meter in meters:
        if not isinstance(meter, Mapping):
            continue
        meter_id = str(meter.get("id", meter.get("control_id", "")))
        if not meter_id:
            continue
        key = str(meter.get("model_ramp_key", ""))
        group_count = max(1, int(group_counts.get(key, 1)))
        per_meter_capacity = max(
            1.0e-6,
            _as_float(meter.get("capacity_vph"), default_per_meter_capacity),
        )
        default_group_capacity = per_meter_capacity * group_count
        group_capacity = max(
            1.0e-6,
            _as_float(capacities.get(key, default_group_capacity), default_group_capacity),
        )
        group_rate = clamp(
            _as_float(control.ramp_metering.get(key, group_capacity), group_capacity),
            0.0,
            group_capacity,
        )
        per_meter_rate = group_rate / float(group_count) if distribute else group_rate
        if alloc is not None and meter_id in alloc["green"]:
            # 전달함수 배정: green 이 먼저고 rate 는 VBS 검사(green == round(cycle·rate/cap))에 맞춰 되맞춘다.
            green = float(alloc["green"][meter_id])
            per_meter_rate = green * per_meter_capacity / cycle
            out[meter_id] = {
                "sc_no": float(_as_float(meter.get("sc_no"), 0.0)),
                "sg_no": float(_as_float(meter.get("sg_no"), 1.0)),
                "rate_vph": float(per_meter_rate),
                "group_rate_vph": float(alloc["realized"].get(key, group_rate)),
                "green_sec": float(green),
                "model_ramp_key": key,
            }
            continue
        # 2026-08-27. 하한·상한을 **녹색이 아니라 rate 에** 건다.
        #
        # 왜. 러너 VBS 의 `RampActionValid`(:1276-1277)가
        #     expectedGreen = Round(RAMP_CYCLE_SEC * rate / capacity)
        #     |green - expectedGreen| > 0.001 이면 무효
        # 로 rate 와 green 의 **정확한 비례**를 요구한다. 종전처럼 green 을 낸 뒤
        # `clamp(green, min_green, max_green)` 을 씌우면 그 비례가 깨진다 — CSV 에 나가는
        # rate 는 안 바뀌는데 green 만 올라가기 때문이다.
        #
        # 실측으로 rate 0 에 green 2.0 이 나가 canon_gne_nofar 의 sim_sec=1 이
        # ramp=4/8 · invalid=4 로 걸렸고, 37결정을 다 돌고도 RUN_INTEGRITY_FAILURE 로
        # 끝났다. 계약 재현 검사로 보면 rate 0 뿐 아니라 **0 < rate < 90 구간 전체**가
        # 같은 이유로 무효였다(예: rate 45 -> round(1.0)=1 인데 min_green 2.0 이 올림).
        # 종전에 안 드러난 것은 미터링이 늘 용량 근처였기 때문이지 안전해서가 아니다.
        #
        # rate 를 먼저 상자에 넣고 green 을 그로부터 유도하면 둘이 항상 정합한다.
        # rate 0(램프를 닫으라는 명령)은 하한을 적용하지 않는다 — min_green 은 **여는**
        # 경우의 최소 녹색이지 닫는 경우의 바닥이 아니다.
        if per_meter_rate <= 1.0e-9:
            per_meter_rate = 0.0
            green = 0.0
        else:
            lo_rate = min_green * per_meter_capacity / cycle
            hi_rate = max_green * per_meter_capacity / cycle
            per_meter_rate = clamp(per_meter_rate, lo_rate, hi_rate)
            green = round(cycle * per_meter_rate / per_meter_capacity)
            # 반올림 뒤 rate 를 green 에 되맞춘다 — VBS 는 Round(cycle*rate/cap) 로 검사한다.
            per_meter_rate = green * per_meter_capacity / cycle
        group_rate = per_meter_rate * float(group_count) if distribute else per_meter_rate
        out[meter_id] = {
            "sc_no": float(_as_float(meter.get("sc_no"), 0.0)),
            "sg_no": float(_as_float(meter.get("sg_no"), 1.0)),
            "rate_vph": float(per_meter_rate),
            "group_rate_vph": float(group_rate),
            "green_sec": float(green),
            "model_ramp_key": key,
        }
    return out


def _segment_model_coordinates(segment_id: str, segment: Mapping[str, Any]) -> tuple[str, int]:
    model_link = segment.get("model_link")
    model_idx = segment.get("model_segment_index")
    if model_link is not None and model_idx is not None:
        return str(model_link), int(_as_float(model_idx))
    return SEGMENT_TO_MODEL[segment_id]


def _segment_dsd_controls(segment: Mapping[str, Any]) -> list[dict[str, Any]]:
    controls: list[dict[str, Any]] = []
    by_lane = segment.get("dsd_by_lane", {})
    if isinstance(by_lane, Mapping):
        for lane_key, value in by_lane.items():
            if not isinstance(value, Mapping):
                continue
            row = dict(value)
            row.setdefault("lane", lane_key)
            controls.append(row)
    extras = segment.get("extra_dsd_controls", [])
    if isinstance(extras, list):
        for value in extras:
            if isinstance(value, Mapping):
                controls.append(dict(value))

    def sort_key(item: Mapping[str, Any]) -> tuple[int, int]:
        lane = int(_as_float(item.get("lane"), 9999.0))
        dsd_no = int(_as_float(item.get("dsd_no"), 0.0))
        return lane, dsd_no

    return sorted(controls, key=sort_key)


def _signal_rows_for_mapping(mapping: Mapping[str, Any]) -> list[dict[str, Any]]:
    if "signals" not in mapping:
        return [{"id": signal, "sc_no": sc_no} for signal, sc_no in {"A": 1, "B": 2, "C": 3, "D": 4, "F": 5}.items()]
    raw = mapping.get("signals", [])
    if not isinstance(raw, list):
        return []
    rows: list[dict[str, Any]] = []
    for item in raw:
        if isinstance(item, Mapping):
            # major_maps_to — 이 컨트롤러의 VISSIM MAJOR(SG1) 접근이 모델의 어느 phase 인가.
            # 일반 간선 교차로는 MAJOR 가 EW 간선이고 모델도 그것을 p2 로 서비스한다.
            # freeway 인터페이스 교차로는 MAJOR 가 off-ramp 유출이고, 모델은 램프 leg 를
            # NS 축으로 보아 p1 에 둔다(NumSim grid_topology._token_leg_dir: off*/on* -> "S").
            # 이 값이 없으면 간선 규약(p2)으로 본다 - 기존 동작과 같다.
            maps_to = str(item.get("major_maps_to", "p2")).strip().lower()
            if maps_to not in ("p1", "p2"):
                maps_to = "p2"
            rows.append({
                "id": str(item.get("id", "")),
                "sc_no": int(_as_float(item.get("sc_no"), 0.0)),
                "major_maps_to": maps_to,
            })
    return [row for row in rows if row["id"] and row["sc_no"] > 0]


def _release_at_largest_green(curve: Any, fallback: float) -> float:
    if not isinstance(curve, Mapping) or not curve:
        return float(fallback)
    points: list[tuple[float, float]] = []
    for green, release in curve.items():
        try:
            points.append((float(green), float(release)))
        except (TypeError, ValueError):
            continue
    if not points:
        return float(fallback)
    green, release = max(points, key=lambda item: item[0])
    return max(0.0, float(release))


def apply_actuation_guards_to_control(control, cfg, actuation: Mapping[str, Any]) -> dict[str, float]:
    """Force action JSON/prediction to respect calibration-level actuator guards."""
    metadata: dict[str, float] = {}
    active_mask = _mapping(actuation.get("active_lever_mask"))
    active_mask_enabled = bool(active_mask.get("enabled", False))
    vsl_segment_override_policy = str(actuation.get("vsl_segment_override_policy", "")).strip().lower()
    if vsl_segment_override_policy in {"clear_all", "clear_when_mask_disabled"}:
        if vsl_segment_override_policy == "clear_all" or not active_mask_enabled:
            stale_vsl_segments = [key for key in list(getattr(control, "vsl", {}).keys()) if "__seg" in str(key)]
            for key in stale_vsl_segments:
                control.vsl.pop(key, None)
            if stale_vsl_segments:
                control.diagnostics["vsl_segment_overrides_cleared"] = float(len(stale_vsl_segments))
                metadata["vsl_segment_overrides_cleared"] = float(len(stale_vsl_segments))
    if active_mask_enabled:
        allowed_vsl_links = {str(value) for value in active_mask.get("allowed_vsl_links", []) or []}
        allowed_vsl_segments = {str(value) for value in active_mask.get("allowed_vsl_segments", []) or []}
        max_vsl = max(float(value) for value in cfg.freeway_follower.vsl_set)
        disabled_vsl_segments = 0
        for link in cfg.network.freeway_links:
            link_key = str(link)
            for idx in range(int(cfg.network.freeway_segments_per_link)):
                segment_key = f"{link_key}__seg{idx}"
                readable_key = f"RW_{link_key}_S{idx}"
                if link_key in allowed_vsl_links or segment_key in allowed_vsl_segments or readable_key in allowed_vsl_segments:
                    continue
                control.vsl[segment_key] = float(max_vsl)
                disabled_vsl_segments += 1
        allowed_ramps = {str(value) for value in active_mask.get("allowed_ramps", []) or []}
        if "allowed_ramps" in active_mask:
            for ramp, capacity in _ramp_capacities(cfg).items():
                if ramp not in allowed_ramps:
                    control.ramp_metering[ramp] = float(capacity)
        control.diagnostics["active_lever_mask_enabled"] = 1.0
        control.diagnostics["active_lever_mask_disabled_vsl_segments"] = float(disabled_vsl_segments)
        control.diagnostics["active_lever_mask_allowed_ramp_count"] = float(len(allowed_ramps))
        metadata.update({
            "active_lever_mask_enabled": 1.0,
            "active_lever_mask_disabled_vsl_segments": float(disabled_vsl_segments),
            "active_lever_mask_allowed_ramp_count": float(len(allowed_ramps)),
        })
    signal_freeze = _mapping(actuation.get("signal_green_freeze"))
    if bool(signal_freeze.get("enabled", False)):
        green = _as_float(signal_freeze.get("green_sec"), 57.0)
        major = _as_float(signal_freeze.get("major_green_sec"), green)
        minor = _as_float(signal_freeze.get("minor_green_sec"), green)
        offset = _as_float(signal_freeze.get("offset_sec"), 0.0)
        signals = signal_freeze.get("signals")
        if not isinstance(signals, list) or not signals:
            signals = _controlled_signal_names(cfg)
        for signal in signals:
            name = str(signal)
            control.green_times[f"{name}_p1"] = float(minor)
            control.green_times[f"{name}_p2"] = float(major)
            control.offsets[name] = float(offset)
        control.diagnostics["signal_green_freeze_active"] = 1.0
        control.diagnostics["signal_green_freeze_major_sec"] = float(major)
        control.diagnostics["signal_green_freeze_minor_sec"] = float(minor)
        control.diagnostics["signal_green_freeze_offset_sec"] = float(offset)
        metadata.update({
            "signal_green_freeze_active": 1.0,
            "signal_green_freeze_major_sec": float(major),
            "signal_green_freeze_minor_sec": float(minor),
            "signal_green_freeze_offset_sec": float(offset),
        })
    if bool(actuation.get("F_ramp_invalid_guard_active", False)):
        cap = cfg.network.ramp_capacity_veh_h
        fallback = (
            float(cap.get("R_F_W", 0.0))
            + float(cap.get("R_F_E", 0.0))
        ) / 2.0
        release = _release_at_largest_green(actuation.get("F_green_to_release_vph", {}), fallback)
        for ramp in ("R_F_W", "R_F_E"):
            control.ramp_metering[ramp] = float(release)
        control.diagnostics["F_ramp_invalid_guard_active"] = 1.0
        control.diagnostics["F_ramp_guard_release_vph"] = float(release)
        metadata.update({
            "F_ramp_invalid_guard_active": 1.0,
            "F_ramp_guard_release_vph": float(release),
        })
    return metadata


def _total_ramp_queue_veh(state) -> float:
    ramp_queue = getattr(state, "ramp_queue", {})
    if not isinstance(ramp_queue, Mapping):
        return 0.0
    return float(sum(max(0.0, _as_float(value)) for value in ramp_queue.values()))


def _boundary_in_queue_veh(state, cfg) -> float:
    try:
        return float(state.boundary_in_queue_vehicles(cfg.network))
    except Exception:
        return 0.0


def _max_freeway_density_ratio(state, cfg) -> float:
    rho_crit = max(1.0e-9, float(getattr(cfg.network, "rho_crit", 1.0)))
    values: list[float] = []
    freeway_density = getattr(state, "freeway_density", {})
    if isinstance(freeway_density, Mapping):
        for densities in freeway_density.values():
            if isinstance(densities, list):
                values.extend(max(0.0, _as_float(value)) / rho_crit for value in densities)
    return float(max(values)) if values else 0.0


def _ramp_capacities(cfg) -> dict[str, float]:
    raw = getattr(cfg.network, "ramp_capacity_veh_h", {})
    if not isinstance(raw, Mapping):
        return {}
    return {str(key): max(0.0, _as_float(value)) for key, value in raw.items()}


def _release_sum(control, capacities: Mapping[str, float]) -> float:
    return float(sum(
        max(0.0, _as_float(control.ramp_metering.get(ramp, capacities.get(ramp, 0.0))))
        for ramp in capacities
    ))


def _release_floor_ratio(
    guard: Mapping[str, Any],
    ramp_queue_veh: float,
    boundary_queue_veh: float,
    stopped_veh: float,
) -> float:
    ratio = clamp(_as_float(guard.get("min_release_ratio_of_capacity"), 0.0), 0.0, 1.0)
    high_ratio = clamp(
        _as_float(guard.get("queue_high_release_ratio_of_capacity"), ratio),
        0.0,
        1.0,
    )
    if ramp_queue_veh >= _as_float(guard.get("ramp_queue_threshold_veh"), float("inf")):
        ratio = max(ratio, high_ratio)
    if boundary_queue_veh >= _as_float(guard.get("boundary_queue_threshold_veh"), float("inf")):
        ratio = max(ratio, high_ratio)
    if stopped_veh >= _as_float(guard.get("stopped_threshold_veh"), float("inf")):
        ratio = max(ratio, high_ratio)
    return float(ratio)


def _make_no_control(ControlAction, cfg):
    if hasattr(ControlAction, "uncontrolled"):
        return ControlAction.uncontrolled(cfg)
    return ControlAction.fixed(cfg)


def apply_vissim_policy_guards(
    control,
    cfg,
    state,
    state_json: Mapping[str, Any],
    actuation: Mapping[str, Any],
    ControlAction,
) -> tuple[Any, dict[str, float]]:
    """Plant-aware action guards applied before bridge-level actuator guards.

    These guards are intentionally conservative. They do not try to improve the
    Stackelberg objective; they prevent Vissim-facing ramp actions from hiding
    too much queue in ramp/boundary storage when the predicted benefit is small.
    """
    if bool(_mapping(getattr(control, "diagnostics", {})).get("diagnostic_bypass_policy_guards", False)):
        return control, {"ramp_release_guard_bypassed_for_diagnostic": 1.0}

    guard = _mapping(actuation.get("ramp_release_guard"))
    if not bool(guard.get("enabled", False)):
        return control, {}

    capacities = _ramp_capacities(cfg)
    if not capacities:
        return control, {}

    ramp_queue_veh = _total_ramp_queue_veh(state)
    boundary_queue_veh = _boundary_in_queue_veh(state, cfg)
    stopped_veh = max(0.0, _as_float(state_json.get("stopped_vehicles")))
    density_ratio = _max_freeway_density_ratio(state, cfg)
    floor_ratio = _release_floor_ratio(guard, ramp_queue_veh, boundary_queue_veh, stopped_veh)
    before_sum = _release_sum(control, capacities)
    cap_sum = float(sum(capacities.values()))
    no_control_sum = cap_sum
    mean_ratio_before = before_sum / max(no_control_sum, 1.0e-9)

    fallback = _mapping(guard.get("no_control_fallback"))
    fallback_enabled = bool(fallback.get("enabled", False))
    fallback_release_ratio = clamp(
        _as_float(
            fallback.get("min_release_ratio_of_uncontrolled"),
            guard.get("fallback_min_release_ratio_of_uncontrolled", 0.0),
        ),
        0.0,
        1.0,
    )
    density_limit = _as_float(
        fallback.get("max_density_ratio_for_fallback"),
        guard.get("max_density_ratio_for_fallback", float("inf")),
    )
    queue_required = bool(fallback.get("require_queue_or_stopped", False))
    has_queue_risk = (
        ramp_queue_veh >= _as_float(guard.get("ramp_queue_threshold_veh"), float("inf"))
        or boundary_queue_veh >= _as_float(guard.get("boundary_queue_threshold_veh"), float("inf"))
        or stopped_veh >= _as_float(guard.get("stopped_threshold_veh"), float("inf"))
    )
    should_fallback = (
        fallback_enabled
        and mean_ratio_before < fallback_release_ratio
        and density_ratio <= density_limit
        and (has_queue_risk or not queue_required)
    )

    metadata: dict[str, float] = {
        "ramp_release_guard_active": 1.0,
        "ramp_release_guard_floor_ratio": float(floor_ratio),
        "ramp_release_guard_before_sum_vph": float(before_sum),
        "ramp_release_guard_before_ratio": float(mean_ratio_before),
        "ramp_release_guard_ramp_queue_veh": float(ramp_queue_veh),
        "ramp_release_guard_boundary_queue_veh": float(boundary_queue_veh),
        "ramp_release_guard_stopped_veh": float(stopped_veh),
        "ramp_release_guard_density_ratio_max": float(density_ratio),
        "ramp_release_guard_no_control_fallback": float(should_fallback),
    }

    if should_fallback:
        control = _make_no_control(ControlAction, cfg)
        control.diagnostics["ramp_release_guard_no_control_fallback"] = 1.0
        control.diagnostics["ramp_release_guard_before_ratio"] = float(mean_ratio_before)
    else:
        adjusted = 0
        ramp_overrides = _mapping(guard.get("per_ramp_min_release_ratio_of_capacity"))
        for ramp, capacity in capacities.items():
            ratio = clamp(_as_float(ramp_overrides.get(ramp), floor_ratio), 0.0, 1.0)
            floor = float(capacity) * ratio
            current = max(0.0, _as_float(control.ramp_metering.get(ramp), capacity))
            if current < floor:
                control.ramp_metering[ramp] = float(floor)
                adjusted += 1
        control.diagnostics["ramp_release_guard_adjusted_count"] = float(adjusted)
        control.diagnostics["ramp_release_guard_floor_ratio"] = float(floor_ratio)
        metadata["ramp_release_guard_adjusted_count"] = float(adjusted)

    after_sum = _release_sum(control, capacities)
    control.N_UF_star = float(after_sum)
    control.diagnostics["ramp_release_guard_after_sum_vph"] = float(after_sum)
    control.diagnostics["ramp_release_guard_N_UF_resynced"] = 1.0
    metadata.update({
        "ramp_release_guard_after_sum_vph": float(after_sum),
        "ramp_release_guard_after_ratio": float(after_sum / max(no_control_sum, 1.0e-9)),
        "ramp_release_guard_N_UF_resynced": 1.0,
    })
    return control, metadata


def _post_guard_safety_settings(tuning: Mapping[str, Any]) -> Mapping[str, Any]:
    return _mapping(_mapping(tuning.get("adapter")).get("post_guard_safety"))


def _post_guard_terminal_score_settings(
    tuning: Mapping[str, Any],
    safety: Mapping[str, Any],
) -> Mapping[str, Any]:
    base = dict(_mapping(_mapping(tuning.get("adapter")).get("terminal_cost")))
    score = _mapping(safety.get("score"))
    if not score:
        score = _mapping(safety.get("terminal_cost"))
    if score:
        base = deep_update(base, score)
    if "fit_json" not in base:
        base["fit_json"] = "evaluation/calibration/vissim_terminal_cost_fit_20260715.json"
    return base


def _load_terminal_score_spec(settings: Mapping[str, Any]) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    fit_path = _workspace_path(
        str(settings.get("fit_json", "evaluation/calibration/vissim_terminal_cost_fit_20260715.json"))
    )
    try:
        fit = json.loads(fit_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return None, {
            "post_guard_safety_status": "terminal_fit_load_failed",
            "post_guard_safety_error_type": type(exc).__name__,
        }

    raw_coefficients = _mapping(fit.get("raw_coefficients"))
    features = settings.get("features", fit.get("features", []))
    if not isinstance(features, list):
        features = list(raw_coefficients)
    coefficient_mode = str(settings.get("coefficient_mode", "positive_only")).lower()
    include_intercept = bool(settings.get("include_intercept", False))
    intercept = _as_float(fit.get("raw_intercept"), 0.0) if include_intercept else 0.0
    used: dict[str, float] = {}
    for feature in features:
        name = str(feature)
        coef = _as_float(raw_coefficients.get(name), 0.0)
        if coefficient_mode == "positive_only" and coef <= 0.0:
            continue
        used[name] = float(coef)
    if not used and abs(intercept) <= 1.0e-12:
        return None, {"post_guard_safety_status": "terminal_fit_empty"}

    return {
        "coefficients": used,
        "intercept": float(intercept),
        "weight": _as_float(settings.get("weight"), 1.0),
        "clamp_nonnegative": bool(settings.get("clamp_nonnegative", True)),
        "use_calibrated_prediction": bool(settings.get("use_calibrated_prediction", True)),
        "component_penalty": _mapping(settings.get("component_penalty")),
        "fit_path": str(fit_path),
        "fit_r2": _as_float(_mapping(fit.get("metrics")).get("r2"), 0.0),
    }, {
        "post_guard_terminal_score_feature_count": float(len(used)),
        "post_guard_terminal_score_fit_r2": _as_float(_mapping(fit.get("metrics")).get("r2"), 0.0),
        "post_guard_terminal_score_weight": _as_float(settings.get("weight"), 1.0),
    }


def _prediction_terminal_features(
    prediction: Mapping[str, Any],
    cfg,
    spec: Mapping[str, Any],
) -> tuple[dict[str, float], str]:
    if bool(spec.get("use_calibrated_prediction", True)):
        calibrated = _mapping(prediction.get("calibrated_state_summary"))
        if calibrated:
            return vissim_terminal_feature_vector_from_summary(calibrated, cfg), "calibrated_state_summary"
    terminal_features = _mapping(prediction.get("terminal_features"))
    if terminal_features:
        return {str(k): _as_float(v) for k, v in terminal_features.items()}, "terminal_features"
    summary = _mapping(prediction.get("state_summary"))
    return vissim_terminal_feature_vector_from_summary(summary, cfg), "state_summary"


def _prediction_component_summary(
    prediction: Mapping[str, Any],
    settings: Mapping[str, Any],
) -> tuple[Mapping[str, Any], str]:
    if bool(settings.get("use_calibrated_prediction", True)):
        calibrated = _mapping(prediction.get("calibrated_state_summary"))
        if calibrated:
            return calibrated, "calibrated_state_summary"
    summary = _mapping(prediction.get("state_summary"))
    return summary, "state_summary"


def _component_penalty_score(
    prediction: Mapping[str, Any],
    settings: Mapping[str, Any],
) -> tuple[float, str, int]:
    component = _mapping(settings.get("component_penalty"))
    if not bool(component.get("enabled", False)):
        return 0.0, "disabled", 0
    terms = component.get("terms", [])
    if not isinstance(terms, list):
        return 0.0, "empty", 0
    summary, summary_kind = _prediction_component_summary(prediction, component)
    total = 0.0
    used = 0
    for raw_term in terms:
        term = _mapping(raw_term)
        metric = str(term.get("metric", ""))
        if not metric:
            continue
        value = _as_float(summary.get(metric), 0.0)
        target = _as_float(term.get("target", term.get("threshold", 0.0)), 0.0)
        mode = str(term.get("mode", "above")).lower()
        if mode in ("above", "excess", "over"):
            amount = max(0.0, value - target)
        elif mode in ("below", "deficit", "under"):
            amount = max(0.0, target - value)
        elif mode in ("absolute", "abs"):
            amount = abs(value - target)
        elif mode in ("value", "raw"):
            amount = max(0.0, value)
        else:
            amount = 0.0
        weight = _as_float(term.get("weight"), 0.0)
        total += weight * amount
        used += 1
    return float(total), summary_kind, used


def _score_prediction_with_terminal_fit(
    prediction: Mapping[str, Any],
    cfg,
    spec: Mapping[str, Any],
) -> tuple[dict[str, Any] | None, str]:
    if str(prediction.get("status", "")) != "ok":
        return None, "prediction_unavailable"
    features, summary_kind = _prediction_terminal_features(prediction, cfg, spec)
    raw = _as_float(spec.get("intercept"), 0.0)
    for feature, coef in _mapping(spec.get("coefficients")).items():
        raw += float(coef) * float(features.get(str(feature), 0.0))
    if bool(spec.get("clamp_nonnegative", True)):
        raw = max(0.0, raw)
    component_penalty, component_summary_kind, component_term_count = _component_penalty_score(prediction, spec)
    weight = _as_float(spec.get("weight"), 1.0)
    return {
        "score": float(weight * raw + component_penalty),
        "raw_veh_h": float(raw),
        "summary_kind": summary_kind,
        "component_penalty": float(component_penalty),
        "component_summary_kind": component_summary_kind,
        "component_term_count": float(component_term_count),
    }, "ok"


def _add_score_metadata(
    metadata: dict[str, Any],
    prefix: str,
    score: Mapping[str, Any] | None,
    status: str,
) -> None:
    metadata[f"{prefix}_score_status"] = status
    if score is None:
        return
    metadata[f"{prefix}_terminal_score"] = float(score.get("score", 0.0))
    metadata[f"{prefix}_terminal_score_raw_veh_h"] = float(score.get("raw_veh_h", 0.0))
    metadata[f"{prefix}_score_summary_kind"] = str(score.get("summary_kind", ""))
    metadata[f"{prefix}_component_penalty"] = float(score.get("component_penalty", 0.0))
    metadata[f"{prefix}_component_penalty_term_count"] = float(score.get("component_term_count", 0.0))
    metadata[f"{prefix}_component_penalty_summary_kind"] = str(score.get("component_summary_kind", ""))


def _physical_action_metadata(prefix: str, control, cfg, actuation: Mapping[str, Any]) -> dict[str, float]:
    metadata: dict[str, float] = {}
    try:
        actions = physical_ramp_actions(control, cfg, actuation)
    except Exception:
        return metadata
    for ramp, spec in actions.items():
        metadata[f"{prefix}_physical_ramp_{ramp}_rate_vph"] = _as_float(spec.get("rate_vph"))
        metadata[f"{prefix}_physical_ramp_{ramp}_green_sec"] = _as_float(spec.get("green_sec"))
    return metadata


def _guarded_no_control_baseline(ControlAction, cfg, state, state_json, actuation: Mapping[str, Any]):
    control = _make_no_control(ControlAction, cfg)
    control.diagnostics["post_guard_no_control_baseline"] = 1.0
    control, _ = apply_vissim_policy_guards(control, cfg, state, state_json, actuation, ControlAction)
    apply_actuation_guards_to_control(control, cfg, actuation)
    return control


def _guarded_pfo_baseline(cfg, state, forecast, previous, state_json, actuation: Mapping[str, Any], ControlAction):
    started = time.perf_counter()
    metadata: dict[str, Any] = {}
    controller = None
    try:
        from src.controllers.distributed_coordinator import DistributedCoordinator

        controller = DistributedCoordinator(cfg)
        result = controller.solve(state.copy(), None, forecast, previous)
        control = result.control
        control.diagnostics["post_guard_pfo_baseline"] = 1.0
        metadata.update({
            "post_guard_pfo_iterations": float(getattr(result, "iterations", 0)),
            "post_guard_pfo_converged": float(bool(getattr(result, "converged", False))),
            "post_guard_pfo_objective": float(getattr(result, "objective_value", 0.0)),
        })
        control, _ = apply_vissim_policy_guards(control, cfg, state, state_json, actuation, ControlAction)
        apply_actuation_guards_to_control(control, cfg, actuation)
        metadata["post_guard_pfo_baseline_status"] = "ok"
        metadata["post_guard_pfo_wall_sec"] = round(time.perf_counter() - started, 6)
        return control, metadata
    except Exception as exc:
        metadata.update({
            "post_guard_pfo_baseline_status": "error",
            "post_guard_pfo_error_type": type(exc).__name__,
            "post_guard_pfo_wall_sec": round(time.perf_counter() - started, 6),
        })
        return None, metadata
    finally:
        if controller is not None and hasattr(controller, "close"):
            try:
                controller.close()
            except Exception:
                pass


def apply_post_guard_safety_evaluation(
    control,
    cfg,
    state,
    state_json: Mapping[str, Any],
    forecast,
    previous,
    calibration: Mapping[str, Any],
    tuning: Mapping[str, Any],
    actuation: Mapping[str, Any],
    ControlAction,
    prediction: Mapping[str, Any],
) -> tuple[Any, dict[str, Any], Mapping[str, Any]]:
    """Evaluate guarded plant-facing action against explicit safety baselines."""
    if bool(_mapping(getattr(control, "diagnostics", {})).get("diagnostic_bypass_policy_guards", False)):
        return control, {"post_guard_safety_bypassed_for_diagnostic": 1.0}, prediction

    safety = _post_guard_safety_settings(tuning)
    if not bool(safety.get("enabled", False)):
        return control, {}, prediction

    metadata: dict[str, Any] = {
        "post_guard_safety_enabled": 1.0,
        "post_guard_safety_status": "ok",
        "post_guard_safety_fallback_occurred": 0.0,
        "post_guard_no_control_fallback": 0.0,
    }
    metadata.update(_physical_action_metadata("post_guard", control, cfg, actuation))

    spec, spec_metadata = _load_terminal_score_spec(_post_guard_terminal_score_settings(tuning, safety))
    metadata.update(spec_metadata)
    if spec is None:
        return control, metadata, prediction

    post_score, post_status = _score_prediction_with_terminal_fit(prediction, cfg, spec)
    _add_score_metadata(metadata, "post_guard", post_score, post_status)
    if post_score is None:
        metadata["post_guard_safety_status"] = post_status
        return control, metadata, prediction

    no_control_settings = _mapping(safety.get("no_control_baseline"))
    if not no_control_settings:
        no_control_settings = _mapping(safety.get("no_control"))
    no_control_enabled = bool(no_control_settings.get("enabled", True))
    metadata["post_guard_no_control_baseline_enabled"] = float(no_control_enabled)
    no_control_prediction: Mapping[str, Any] | None = None
    no_control_control = None
    if no_control_enabled:
        no_control_control = _guarded_no_control_baseline(ControlAction, cfg, state, state_json, actuation)
        metadata.update(_physical_action_metadata("post_guard_no_control", no_control_control, cfg, actuation))
        no_control_prediction = build_one_step_prediction(state, no_control_control, forecast, cfg, calibration)
        no_score, no_status = _score_prediction_with_terminal_fit(no_control_prediction, cfg, spec)
        _add_score_metadata(metadata, "post_guard_no_control", no_score, no_status)
        if no_score is not None:
            gap = float(post_score["score"] - no_score["score"])
            metadata["post_guard_no_control_score_gap"] = gap
            metadata["post_guard_vs_no_control_score_gap"] = gap
            margin = max(
                0.0,
                _as_float(
                    no_control_settings.get(
                        "fallback_margin_score",
                        safety.get("no_control_fallback_margin_score", 0.0),
                    ),
                ),
            )
            metadata["post_guard_no_control_fallback_margin_score"] = float(margin)
            fallback_enabled = bool(
                no_control_settings.get(
                    "fallback_enabled",
                    safety.get("fallback_to_no_control", False),
                )
            )
            prefer_less_restrictive = bool(
                no_control_settings.get(
                    "prefer_less_restrictive_on_tie",
                    no_control_settings.get("prefer_no_control_on_tie", False),
                )
            )
            tie_margin = max(
                0.0,
                _as_float(
                    no_control_settings.get(
                        "tie_margin_score",
                        no_control_settings.get("prefer_no_control_tie_margin_score", 0.0),
                    ),
                ),
            )
            min_release_gap = max(
                0.0,
                _as_float(
                    no_control_settings.get(
                        "min_release_gap_vph",
                        no_control_settings.get("prefer_no_control_min_release_gap_vph", 0.0),
                    ),
                ),
            )
            post_physical = physical_ramp_actions(control, cfg, actuation)
            no_physical = physical_ramp_actions(no_control_control, cfg, actuation)
            release_gap = 0.0
            for ramp in sorted(set(post_physical) | set(no_physical)):
                release_gap += max(
                    0.0,
                    _as_float(_mapping(no_physical.get(ramp)).get("rate_vph"))
                    - _as_float(_mapping(post_physical.get(ramp)).get("rate_vph")),
                )
            tie_fallback = (
                prefer_less_restrictive
                and gap >= -tie_margin
                and release_gap >= min_release_gap
            )
            metadata["post_guard_no_control_prefer_less_restrictive_on_tie"] = float(prefer_less_restrictive)
            metadata["post_guard_no_control_tie_margin_score"] = float(tie_margin)
            metadata["post_guard_no_control_release_gap_vph"] = float(release_gap)
            metadata["post_guard_no_control_tie_fallback"] = float(tie_fallback)
            should_fallback = fallback_enabled and (gap > margin or tie_fallback)
            metadata["post_guard_no_control_fallback"] = float(should_fallback)
            if should_fallback and no_control_prediction is not None:
                no_control_control.diagnostics["post_guard_safety_no_control_fallback"] = 1.0
                no_control_control.diagnostics["post_guard_no_control_score_gap"] = float(gap)
                no_control_control.diagnostics["post_guard_no_control_tie_fallback"] = float(tie_fallback)
                metadata["post_guard_safety_fallback_occurred"] = 1.0
                metadata["post_guard_safety_fallback_baseline"] = "no_control"
                metadata["post_guard_safety_status"] = "fallback_no_control"
                metadata.update(_physical_action_metadata("post_guard_final", no_control_control, cfg, actuation))
                return no_control_control, metadata, no_control_prediction
    else:
        metadata["post_guard_no_control_score_status"] = "disabled"

    pfo_settings = _mapping(safety.get("pfo_baseline"))
    pfo_enabled = bool(pfo_settings.get("enabled", False))
    metadata["post_guard_pfo_baseline_enabled"] = float(pfo_enabled)
    if pfo_enabled:
        pfo_control, pfo_metadata = _guarded_pfo_baseline(
            cfg,
            state,
            forecast,
            previous,
            state_json,
            actuation,
            ControlAction,
        )
        metadata.update(pfo_metadata)
        if pfo_control is not None:
            metadata.update(_physical_action_metadata("post_guard_pfo", pfo_control, cfg, actuation))
            pfo_prediction = build_one_step_prediction(state, pfo_control, forecast, cfg, calibration)
            pfo_score, pfo_status = _score_prediction_with_terminal_fit(pfo_prediction, cfg, spec)
            _add_score_metadata(metadata, "post_guard_pfo", pfo_score, pfo_status)
            if pfo_score is not None:
                gap = float(post_score["score"] - pfo_score["score"])
                metadata["post_guard_pfo_score_gap"] = gap
                metadata["post_guard_vs_pfo_score_gap"] = gap
    metadata.update(_physical_action_metadata("post_guard_final", control, cfg, actuation))
    return control, metadata, prediction


DIAGNOSTIC_SIGNALS = ("A", "B", "C", "D", "F")


def _controlled_signal_names(cfg) -> list[str]:
    signals = getattr(getattr(cfg, "network", None), "signals", None)
    out = [str(signal) for signal in (signals or []) if str(signal)]
    return out if out else list(DIAGNOSTIC_SIGNALS)


def _diagnostic_fixed_control(
    cfg,
    ControlAction,
    *,
    vsl_kph: float = 120.0,
    d_ramp_rate_vph: float | None = None,
    f_ramp_rate_vph: float | None = None,
    major_green_sec: float = 57.0,
    minor_green_sec: float = 57.0,
    offset_sec: float = 0.0,
):
    control = ControlAction.fixed(cfg)
    cap = cfg.network.ramp_capacity_veh_h
    control.vsl = {link: float(vsl_kph) for link in cfg.network.freeway_links}
    for link in cfg.network.freeway_links:
        for i in range(int(getattr(cfg.network, "freeway_segments_per_link", 0))):
            control.vsl[f"{link}__seg{i}"] = float(vsl_kph)
    d_rate = (
        float(d_ramp_rate_vph)
        if d_ramp_rate_vph is not None
        else (float(cap.get("R_D_W", 0.0)) + float(cap.get("R_D_E", 0.0))) / 2.0
    )
    f_rate = (
        float(f_ramp_rate_vph)
        if f_ramp_rate_vph is not None
        else (float(cap.get("R_F_W", 0.0)) + float(cap.get("R_F_E", 0.0))) / 2.0
    )
    control.ramp_metering = {
        "R_D_W": float(d_rate),
        "R_D_E": float(d_rate),
        "R_F_W": float(f_rate),
        "R_F_E": float(f_rate),
    }
    for signal in _controlled_signal_names(cfg):
        control.green_times[f"{signal}_p1"] = float(minor_green_sec)
        control.green_times[f"{signal}_p2"] = float(major_green_sec)
        control.offsets[signal] = float(offset_sec)
    control.diagnostics.update({
        "diagnostic_fixed_actuation_active": 1.0,
        "diagnostic_forced_vsl_kph": float(vsl_kph),
        "diagnostic_forced_d_ramp_rate_vph": float(d_rate),
        "diagnostic_forced_f_ramp_rate_vph": float(f_rate),
        "diagnostic_forced_signal_major_green_sec": float(major_green_sec),
        "diagnostic_forced_signal_minor_green_sec": float(minor_green_sec),
        "diagnostic_forced_signal_offset_sec": float(offset_sec),
        "diagnostic_bypass_policy_guards": 1.0,
    })
    return control


def _force_all_vsl(control, cfg, vsl_kph: float) -> None:
    control.vsl = {link: float(vsl_kph) for link in cfg.network.freeway_links}
    for link in cfg.network.freeway_links:
        for i in range(int(getattr(cfg.network, "freeway_segments_per_link", 0))):
            control.vsl[f"{link}__seg{i}"] = float(vsl_kph)


def _force_open_ramps(control, cfg) -> None:
    cap = getattr(cfg.network, "ramp_capacity_veh_h", {}) or {}
    ramps = list(getattr(cfg.network, "ramps", ()) or cap.keys())
    control.ramp_metering = {
        str(ramp): float(cap.get(str(ramp), 1800.0))
        for ramp in ramps
    }


def _diagnostic_open_ramp_original_signal_control(cfg, ControlAction):
    control = ControlAction.uncontrolled(cfg)
    _force_all_vsl(control, cfg, 120.0)
    _force_open_ramps(control, cfg)
    control.diagnostics.update({
        "diagnostic_pure_lever_baseline": 1.0,
        "diagnostic_forced_vsl_kph": 120.0,
        "diagnostic_ramps_forced_open": 1.0,
        "diagnostic_signal_original_vissim": 1.0,
    })
    return control


def diagnostic_vsl60_only_control(cfg, ControlAction):
    control = _diagnostic_open_ramp_original_signal_control(cfg, ControlAction)
    _force_all_vsl(control, cfg, 60.0)
    control.diagnostics["diagnostic_vsl60_only_active"] = 1.0
    control.diagnostics["diagnostic_forced_vsl_kph"] = 60.0
    return control


def diagnostic_vsl80_only_control(cfg, ControlAction):
    control = _diagnostic_open_ramp_original_signal_control(cfg, ControlAction)
    _force_all_vsl(control, cfg, 80.0)
    control.diagnostics["diagnostic_vsl80_only_active"] = 1.0
    control.diagnostics["diagnostic_forced_vsl_kph"] = 80.0
    return control


def _diagnostic_signal_only_control(
    cfg,
    ControlAction,
    *,
    major_green_sec: float,
    minor_green_sec: float,
    offset_sec: float = 0.0,
):
    control = _diagnostic_open_ramp_original_signal_control(cfg, ControlAction)
    for signal in _controlled_signal_names(cfg):
        control.green_times[f"{signal}_p1"] = float(minor_green_sec)
        control.green_times[f"{signal}_p2"] = float(major_green_sec)
        control.offsets[signal] = float(offset_sec)
    control.diagnostics.update({
        "diagnostic_signal_only_active": 1.0,
        "diagnostic_forced_signal_major_green_sec": float(major_green_sec),
        "diagnostic_forced_signal_minor_green_sec": float(minor_green_sec),
        "diagnostic_forced_signal_offset_sec": float(offset_sec),
    })
    return control


def diagnostic_signal_major90_only_control(cfg, ControlAction):
    control = _diagnostic_signal_only_control(
        cfg,
        ControlAction,
        major_green_sec=90.0,
        minor_green_sec=5.0,
    )
    control.diagnostics["diagnostic_signal_major90_only_active"] = 1.0
    return control


def diagnostic_signal_minor90_only_control(cfg, ControlAction):
    control = _diagnostic_signal_only_control(
        cfg,
        ControlAction,
        major_green_sec=5.0,
        minor_green_sec=90.0,
    )
    control.diagnostics["diagnostic_signal_minor90_only_active"] = 1.0
    return control


def diagnostic_signal_offset60_only_control(cfg, ControlAction):
    control = _diagnostic_signal_only_control(
        cfg,
        ControlAction,
        major_green_sec=57.0,
        minor_green_sec=57.0,
        offset_sec=60.0,
    )
    control.diagnostics["diagnostic_signal_offset60_only_active"] = 1.0
    return control


def diagnostic_vsl_rm_control(cfg, ControlAction):
    """Forced actuator diagnostic: lower VSL and meter both D/F ramps together.

    This is intentionally not an optimizer policy. It verifies that the Vissim
    bridge can apply VSL and ramp-metering actuation simultaneously before we
    attribute non-movement to the controller objective/calibration.
    """
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        vsl_kph=80.0,
        d_ramp_rate_vph=min(1253.0, float(cfg.network.ramp_capacity_veh_h.get("R_D_W", 1253.0))),
        f_ramp_rate_vph=min(284.0, float(cfg.network.ramp_capacity_veh_h.get("R_F_W", 284.0))),
    )
    control.diagnostics["diagnostic_forced_vsl_rm_active"] = 1.0
    control.diagnostics["diagnostic_forced_ramp_green_target_sec"] = 4.0
    return control


def native_fixed_control(cfg, ControlAction):
    """망의 **실제 고정신호 계획**을 그대로 ControlAction 으로 낸다.

    왜. "모델이 고정신호가 더 낫다는 걸 볼 수 있는가" 를 묻기 위해서다. 답에 따라 진단이
    갈린다 — 모델도 고정신호가 낫다고 하면 리더의 **탐색**이 문제고, 모델이 제어안을 더
    낫게 채점하면 **모델**이 문제다.

    출처는 `outputs/signal_group_actuation_plan_v3.json` 의 `axis_green_sec` 다. 이미
    모델 현시(p1..p4) 단위로 정리돼 있고, .sig 에서 SG 별 union green 을 뽑은 값과
    일치한다(SC1: SG4=54->p1, SG3=21->p2, SG2=32->p3, SG1=31->p4).

    주의: 고정 계획에는 **녹색이 0 인 현시**가 있다(SC7 p3, SC16 p4, SC107 p1, SC108 p2,
    SC109 p1). 그대로 0 을 넣는다 — 컨트롤러도 그 현시에 0 을 준다(실측 확인).
    VSL·metering 은 무제어와 같은 자유 방출로 둬 신호만 비교되게 한다.
    """
    control = ControlAction.uncontrolled(cfg)
    src = WORKSPACE_ROOT / "outputs/signal_group_actuation_plan_v3.json"
    doc = json.loads(src.read_text(encoding="utf-8"))
    plan = {str(v.get("node_id")): v for v in (doc.get("controllers") or {}).values()}
    applied = 0
    for signal in _controlled_signal_names(cfg):
        entry = plan.get(str(signal))
        if entry is None:
            continue
        greens = _mapping(entry.get("axis_green_sec"))
        for pid in ("p1", "p2", "p3", "p4"):
            key = f"{signal}_{pid}"
            if key in control.green_times or greens.get(pid) is not None:
                control.green_times[key] = max(0.0, _as_float(greens.get(pid), 0.0))
        control.offsets[signal] = 0.0
        applied += 1
    control.diagnostics.update({
        "native_fixed_actuation_active": 1.0,
        "native_fixed_signals_applied": float(applied),
    })
    return control


def diagnostic_fixed57_control(cfg, ControlAction):
    return _diagnostic_fixed_control(cfg, ControlAction)


def diagnostic_ramp_hold_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        d_ramp_rate_vph=691.0,
    )
    control.diagnostics["diagnostic_ramp_hold_active"] = 1.0
    control.diagnostics["diagnostic_ramp_hold_target_green_sec"] = 2.0
    return control


def diagnostic_ramp_d1364_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        d_ramp_rate_vph=1364.0,
    )
    control.diagnostics["diagnostic_ramp_d1364_active"] = 1.0
    control.diagnostics["diagnostic_ramp_d1364_target_green_sec"] = 6.0
    return control


def diagnostic_ramp_d1253_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        d_ramp_rate_vph=1253.0,
    )
    control.diagnostics["diagnostic_ramp_d1253_active"] = 1.0
    control.diagnostics["diagnostic_ramp_d1253_target_green_sec"] = 4.0
    return control


def diagnostic_vsl80_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction, vsl_kph=80.0)
    control.diagnostics["diagnostic_vsl80_active"] = 1.0
    return control


# VSL 90/70/60/50 — 실측 속도 분포에 맞춘 선택지. 기존 [80,100,120] 은 상단이 무의미했다
# (속도>120 표본 1.23%, 혼잡 구간 앵커 평균속도 75.3 km/h). 혼잡 하단(v최저 19.0)을 덮으려면
# 50~70 이 필요하고, 그 결과 c01_vsl110 과 c02_vsl100 이 관측상 구분되지 않던 문제도 사라진다.
# 램프 미터링 후보 — 네 그룹(R_D_E/R_D_W/R_F_E/R_F_W)을 **전부** 설정한다.
#
# 기존 diagnostic-ramp-d1364/d1253/hold 는 d_ramp_rate_vph 만 지정해 R_D_W 그룹(물리 미터
# RM_C10480, RM_C10482) 에만 걸렸고(액션 CSV 488 행 중 64 행), 그 미터율마저 실제 램프 수요보다
# 높아 구속하지 않았다. 그래서 관측 목적함수가 후보를 구분하지 못했다.
#
# 2026-08-04 실측 램프 수요(mixed_critical, t>=2700):
#   10646=816  10681=741  10480=668  10490=619  10644=560  10482=492  10639=354  10484=307 veh/h
# 그룹 미터율은 물리 미터 2 개에 절반씩 갈리므로(그룹 1364 -> 미터당 682) 아래 값은
# 미터당 500 / 400 / 300 이 된다. 실무 램프 미터링의 통상 범위 안이다.
#
# 그리고 합류부 검정에서 8 곳 중 4 곳이 이미 용량 초과다(FW_W S2 107 %, S4 102 %, FW_E S3 100 %).
# 붕괴 위험이 실재하므로 이 미터율은 조작이 아니라 정상화다.
def diagnostic_ramp_all500_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction,
                                        d_ramp_rate_vph=1000.0, f_ramp_rate_vph=1000.0)
    control.diagnostics["diagnostic_ramp_all500_active"] = 1.0
    return control


def diagnostic_ramp_all400_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction,
                                        d_ramp_rate_vph=800.0, f_ramp_rate_vph=800.0)
    control.diagnostics["diagnostic_ramp_all400_active"] = 1.0
    return control


def diagnostic_ramp_all300_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction,
                                        d_ramp_rate_vph=600.0, f_ramp_rate_vph=600.0)
    control.diagnostics["diagnostic_ramp_all300_active"] = 1.0
    return control


def diagnostic_vsl90_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction, vsl_kph=90.0)
    control.diagnostics["diagnostic_vsl90_active"] = 1.0
    return control


def diagnostic_vsl70_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction, vsl_kph=70.0)
    control.diagnostics["diagnostic_vsl70_active"] = 1.0
    return control


def diagnostic_vsl60_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction, vsl_kph=60.0)
    control.diagnostics["diagnostic_vsl60_active"] = 1.0
    return control


def diagnostic_vsl50_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction, vsl_kph=50.0)
    control.diagnostics["diagnostic_vsl50_active"] = 1.0
    return control


def diagnostic_vsl80_original_signal_control(cfg, ControlAction):
    control = diagnostic_vsl80_control(cfg, ControlAction)
    control.diagnostics["diagnostic_original_signal_active"] = 1.0
    return control


def diagnostic_ramp_all735_original_signal_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        d_ramp_rate_vph=735.0,
        f_ramp_rate_vph=735.0,
    )
    control.diagnostics["diagnostic_ramp_all735_original_signal_active"] = 1.0
    return control


def diagnostic_ramp_all360_original_signal_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        d_ramp_rate_vph=360.0,
        f_ramp_rate_vph=360.0,
    )
    control.diagnostics["diagnostic_ramp_all360_original_signal_active"] = 1.0
    return control


def diagnostic_vsl110_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction, vsl_kph=110.0)
    control.diagnostics["diagnostic_vsl110_active"] = 1.0
    return control


def diagnostic_vsl100_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(cfg, ControlAction, vsl_kph=100.0)
    control.diagnostics["diagnostic_vsl100_active"] = 1.0
    return control


def diagnostic_signal_major_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        major_green_sec=75.0,
        minor_green_sec=25.0,
    )
    control.diagnostics["diagnostic_signal_major_active"] = 1.0
    return control


def diagnostic_signal_minor_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        major_green_sec=25.0,
        minor_green_sec=75.0,
    )
    control.diagnostics["diagnostic_signal_minor_active"] = 1.0
    return control


def diagnostic_signal_major62_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        major_green_sec=62.0,
        minor_green_sec=52.0,
    )
    control.diagnostics["diagnostic_signal_major62_active"] = 1.0
    return control


def diagnostic_signal_minor62_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        major_green_sec=52.0,
        minor_green_sec=62.0,
    )
    control.diagnostics["diagnostic_signal_minor62_active"] = 1.0
    return control


def diagnostic_signal_offset30_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        major_green_sec=57.0,
        minor_green_sec=57.0,
        offset_sec=30.0,
    )
    control.diagnostics["diagnostic_signal_offset30_active"] = 1.0
    return control


def diagnostic_combined_strong_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        vsl_kph=80.0,
        d_ramp_rate_vph=691.0,
        major_green_sec=75.0,
        minor_green_sec=25.0,
    )
    control.diagnostics["diagnostic_combined_strong_active"] = 1.0
    return control


def diagnostic_combined_extreme_control(cfg, ControlAction):
    control = _diagnostic_fixed_control(
        cfg,
        ControlAction,
        vsl_kph=60.0,
        d_ramp_rate_vph=360.0,
        f_ramp_rate_vph=360.0,
        major_green_sec=90.0,
        minor_green_sec=5.0,
    )
    control.diagnostics["diagnostic_combined_extreme_active"] = 1.0
    return control


def _action_csv_metadata(
    metadata: Mapping[str, Any],
    row_metadata: Mapping[str, Any] | None = None,
) -> str:
    status = str(metadata.get("controller_status", ""))
    provenance = metadata.get("physical_projection_provenance")
    if not isinstance(provenance, Mapping):
        if not row_metadata:
            return status
        suffix = ";".join(f"{key}={value}" for key, value in row_metadata.items())
        return f"{status};{suffix}"
    payload: dict[str, Any] = {
        "controller_status": status,
        "physical_projection_provenance": thaw_json(provenance),
    }
    if row_metadata:
        payload["action_row"] = thaw_json(row_metadata)
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def write_action_csv(
    path: Path,
    control,
    cfg,
    mapping: dict[str, Any],
    segment_vsl_func,
    metadata: dict[str, Any],
    actuation: Mapping[str, Any],
    signal_group_plan_table: Mapping[str, Any] | None = None,
    offset_writer: str = offset_promotion.WRITER_INTENT_ONLY,
) -> None:
    # N4-7. `offset_writer` 의 기본값이 intent_only 인 것이 fail-closed 의 요점이다.
    # 이 함수를 아무 말 없이 부르면 offset 은 절대 플랜트로 나가지 않는다.
    path.parent.mkdir(parents=True, exist_ok=True)
    vsl_set = [float(v) for v in cfg.freeway_follower.vsl_set]
    if 120.0 not in vsl_set:
        # Allow no-control-ish 120 km/h on Vissim when previous/control provides it.
        vsl_set = sorted(set(vsl_set + [120.0]))
    # Action CSV fields are ASCII-compatible. Omitting a BOM lets the VBS
    # consumer validate the complete header token-for-token.
    with path.open("w", newline="", encoding="utf-8") as f:
        csv_metadata = _action_csv_metadata(metadata)
        # 열 목록은 `action_csv_schema` 가 정본이다. 여기에 리터럴로 두면 러너 헤더와
        # 조용히 갈라진다(러너는 헤더를 토큰 단위로 대조해 전량 거부한다).
        fields = list(action_csv_schema.ACTION_CSV_FIELDS)
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for seg in mapping["segments"]:
            segment_id = seg["segment_id"]
            model_link, idx = _segment_model_coordinates(str(segment_id), seg)
            value = nearest(segment_vsl_func(control, model_link, idx, cfg), vsl_set)
            for dsd in _segment_dsd_controls(seg):
                lane = dsd.get("lane", "")
                writer.writerow({
                    "kind": "vsl",
                    "id": segment_id,
                    "dsd_no": dsd["dsd_no"],
                    "link": seg["link"],
                    "lane": lane,
                    "speed_kph": value,
                    "metadata": csv_metadata,
                })
        signal_settings = _mapping(actuation.get("real_world_signal_control"))
        write_signal_rows = bool(signal_settings.get("enabled", True))
        if str(metadata.get("controller_variant", "")) == "no-control" and not bool(
            signal_settings.get("apply_to_no_control", False)
        ):
            write_signal_rows = False
        if bool(metadata.get("suppress_signal_rows", False)):
            write_signal_rows = False
        if write_signal_rows:
            offset_promotion.guard_forced_arm(control, offset_writer)
            for signal_row in _signal_rows_for_mapping(mapping):
                signal = str(signal_row["id"])
                sc_no = int(signal_row["sc_no"])
                # Phase-axis fix (2026-06-30): VISSIM SG1(MAJOR) controls the E-W/arterial approaches,
                # which the model serves in phase p2; SG2(MINOR) controls the N-S/cross approaches = model
                # phase p1. Verified against evaluation/signal_install/signal_manifest.csv (20/20 approach
                # links). The previous mapping (major<-p1, minor<-p2) axis-swapped every signal's green
                # allocation in VISSIM, so the controller's green was applied to the wrong axis.
                # 진단(fixed-action) 컨트롤러는 모델 신호명(cfg.network.signals)으로 green_times 를
                # 채우는데, 매핑의 signal id 는 별개 이름공간이다. 기본 control_mapping.json 은
                # id 가 "D" 라 모델 신호명과 우연히 일치했지만 distributed 매핑은 "SC1"/"SC5"/... 라
                # 전부 기본값으로 떨어져 **앵커와 green 후보의 액션이 완전히 같아졌다**
                # (2026-08-04 실측: 바뀐 셀 0 개, 관측 응답 0.000 km/h).
                # 강제값이 diagnostics 에 있으면 그것을 기본값으로 쓴다.
                _dg = getattr(control, "diagnostics", {}) or {}
                _maj_default = float(_dg.get("diagnostic_forced_signal_major_green_sec", 40.0))
                _min_default = float(_dg.get("diagnostic_forced_signal_minor_green_sec", 40.0))
                # 컨트롤러별 축 대응 (2026-08-04). VISSIM MAJOR(SG1) 가 모델의 어느 phase 인지는
                # 교차로마다 다르다. 일반 간선 교차로는 MAJOR=EW 간선=모델 p2 이지만,
                # freeway 인터페이스 교차로(SC 1001)는 MAJOR 접근이 **off-ramp 유출**이고
                # 모델은 램프 leg 를 NS 축으로 보아 p1 에 둔다.
                #   확인 근거 - SC1001 정지선 신호두는 link 32 위이고, link 32 유입 커넥터는
                #   conn 10481(본선 2에서) / conn 10491(본선 26에서) **뿐**이다.
                #   NumSim grid_topology._token_leg_dir 은 off*/on* 토큰을 "S" 로 보아 p1 에 배정한다.
                # 이전에는 major<-p2 로 일괄 매핑해 인터페이스 교차로에서 부호가 뒤집혔고,
                # G6 에서 major green 증가를 모델은 J 악화(+2084), 플랜트는 개선(-263)으로 냈다.
                #
                # N4-0 이후 이 축 대응은 **여기서 값을 고르는 데 쓰이지 않는다.** 열이 현시
                # 이름이라 어느 열에 무엇이 실리는지가 축 대응과 무관해졌고, 창 배치 순서만
                # 계획 산출물의 `major_maps_to`(같은 매핑 JSON 에서 나온 값)가 정한다.
                # 즉 매핑과 계획이 어긋나도 값이 뒤바뀌는 경로는 사라졌다.
                # 기본값은 **라벨이 아니라 phase 를 따라가야 한다.**
                # _diagnostic_fixed_control 은 모델 신호명 기준으로 p1<-minor, p2<-major 를 넣는데
                # 그 키는 매핑 signal id 와 이름공간이 달라 조회가 항상 빗나간다. 그래서 기본값이
                # 실제로 쓰이는데, 여기서 major<-강제major 로 두면 축을 바꿔도 결과가 같아진다.
                # phase 별 기본값을 모델이 그 phase 에 넣었을 값과 맞춰야 인터페이스 교차로에서
                # freeway 접속 이동류가 모델·플랜트 양쪽에서 같은 녹색을 받는다.
                # N4-0 4현시. 축(major/minor)은 더 이상 CSV 열이 아니다. 축 대응은
                # 여기서 **기본값을 고를 때만** 살아 있고, 실려 나가는 것은 현시 이름이다.
                # 남는 현시(p3/p4)의 기본값이 0.0 인 것은 조용한 폴백이 아니다 - 계획이
                # 그 현시에 SG 를 붙여 두었으면 `signal_group_action_rows` 가 현시 집합
                # 불일치로 죽는다(부분 적용 없음).
                _phase_default = {"p1": _min_default, "p2": _maj_default}
                # 클램프는 plant_cycle 이 단일 출처다. 여기 리터럴로 두면 모델 주기와
                # 플랜트 주기가 같은지 재는 쪽(tests/test_model_plant_cycle_identity)이
                # 실제로 실리는 값이 아니라 사본을 재게 된다.
                phase_green: dict[str, float] = {}
                for _phase in signal_group_plan.MODEL_PHASES:
                    _raw = control.green_times.get(
                        f"{signal}_{_phase}", _phase_default.get(_phase, 0.0)
                    )
                    _value = float(_raw)
                    # 녹색 0 = 그 현시를 쓰지 않는다는 뜻이라 클램프 하한을 물리면 안 된다.
                    phase_green[_phase] = (
                        plant_cycle.written_axis_green_sec(_value) if _value > 0.0 else 0.0
                    )
                # N4-7 offset 승격 잠금. 최적화기가 고른 offset(control.offsets)은
                # 삼중 잠금이 열리기 전에는 이 열에 실리지 않는다. 의도는 버려지지 않고
                # action JSON 의 `offsets` 에 그대로 남는다 - 그것이 intent_only 다.
                offset = offset_promotion.written_offset_sec(signal, control, offset_writer)
                signal_row_out = {
                    "kind": "signal",
                    "id": signal,
                    "sc_no": sc_no,
                    "offset": round(offset, 3),
                    "metadata": csv_metadata,
                }
                for _phase, _field in zip(
                    signal_group_plan.MODEL_PHASES, action_csv_schema.PHASE_GREEN_FIELDS
                ):
                    signal_row_out[_field] = round(phase_green[_phase], 3)
                writer.writerow(signal_row_out)
                # N4-5. 현시 녹색을 SG 단위로 쪼갠 행(파생). 계획이 없으면 행도 없고,
                # 그 조합은 러너의 RW_SIGNAL_SG_PLAN_SCHEMA 게이트가 fail-closed 로 막는다.
                if signal_group_plan_table is not None:
                    for sg_row in signal_group_action_rows(
                        signal_group_plan_table,
                        sc_no=sc_no,
                        phase_greens={
                            _phase: round(phase_green[_phase], 3)
                            for _phase in signal_group_plan.MODEL_PHASES
                        },
                        offset=round(offset, 3),
                        metadata=csv_metadata,
                    ):
                        writer.writerow(sg_row)
        if isinstance(mapping.get("ramp_meters"), list) and mapping.get("ramp_meters"):
            for ramp, spec in real_world_ramp_meter_actions(control, cfg, actuation, mapping).items():
                writer.writerow({
                    "kind": "ramp_meter",
                    "id": ramp,
                    "sc_no": int(_as_float(spec.get("sc_no"), 0.0)),
                    "rate_vph": round(_as_float(spec.get("rate_vph"), 0.0), 3),
                    "green_sec": round(_as_float(spec.get("green_sec"), 10.0), 3),
                    "metadata": _action_csv_metadata(metadata, {
                        "model_ramp_key": spec.get("model_ramp_key", ""),
                        "group_rate_vph": round(
                            _as_float(spec.get("group_rate_vph"), 0.0), 3
                        ),
                    }),
                })
        else:
            ramp_to_sc = {"D": 6, "F": 7}
            for ramp, spec in physical_ramp_actions(control, cfg, actuation).items():
                writer.writerow({
                    "kind": "ramp_meter",
                    "id": ramp,
                    "sc_no": ramp_to_sc[ramp],
                    "rate_vph": round(spec["rate_vph"], 3),
                    "green_sec": round(spec["green_sec"], 3),
                    "metadata": csv_metadata,
                })


def main() -> None:
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--state-json", default="")
    parser.add_argument("--previous-action-json", default="")
    parser.add_argument("--out-action-json", default="")
    parser.add_argument("--out-action-csv", default="")
    parser.add_argument("--b1a-required", action="store_true")
    parser.add_argument("--projection-only", action="store_true")
    parser.add_argument("--run-manifest", default="")
    parser.add_argument("--approved-topology", default="")
    parser.add_argument("--out-projection-sidecar", default="")
    parser.add_argument("--out-projection-reference", default="")
    parser.add_argument("--projection-reference", default="")
    parser.add_argument("--projection-reference-sha256", default="")
    parser.add_argument("--repo-root", default=str(DEFAULT_REPO_ROOT))
    parser.add_argument("--mapping-json", default=str(DEFAULT_MAPPING))
    parser.add_argument("--detector-mapping-json", default=str(DEFAULT_DETECTOR_MAPPING))
    parser.add_argument("--mode", choices=["fast-smoke", "fuller-smoke"], default="fast-smoke")
    parser.add_argument(
        "--controller",
        choices=[
            "stackelberg",
            "stackelberg-wu-metered",
            "pstack-flagship",
            "wu-link",
            "pfo",
            "wu",
            "wu-leader",
            "no-control",
            "diagnostic-vsl-rm",
            "native-fixed",
            "diagnostic-fixed57",
            "diagnostic-ramp-hold",
            "diagnostic-ramp-d1364",
            "diagnostic-ramp-d1253",
            "diagnostic-ramp-all500",
            "diagnostic-ramp-all400",
            "diagnostic-ramp-all300",
            "diagnostic-vsl60-only",
            "diagnostic-vsl80-only",
            diagnostic_profile.CONTROLLER,
            diagnostic_profile.RAMP_CONTROLLER,
            diagnostic_signal_profile.CONTROLLER,
            "diagnostic-vsl110",
            "diagnostic-vsl100",
            "diagnostic-vsl90",
            "diagnostic-vsl80",
            "diagnostic-vsl70",
            "diagnostic-vsl60",
            "diagnostic-vsl50",
            "diagnostic-vsl80-original",
            "diagnostic-ramp-all735-original",
            "diagnostic-ramp-all360-original",
            "diagnostic-signal-major90-only",
            "diagnostic-signal-minor90-only",
            "diagnostic-signal-offset60-only",
            "diagnostic-signal-major62",
            "diagnostic-signal-minor62",
            "diagnostic-signal-major",
            "diagnostic-signal-minor",
            "diagnostic-signal-offset30",
            "diagnostic-combined-strong",
            "diagnostic-combined-extreme",
        ],
        default="stackelberg",
    )
    parser.add_argument("--calibration-json", default=str(DEFAULT_CALIBRATION))
    parser.add_argument("--tuning-json", default="")
    parser.add_argument("--diagnostic-allowed-vsl-speeds", default="", help=argparse.SUPPRESS)
    projection_preparse = _preparse_projection_roles(sys.argv[1:], parser)
    try:
        args = parser.parse_args()
    except SystemExit as exc:
        if exc.code not in (None, 0):
            _invalidate_projection_reference_after_parser_failure(
                projection_preparse
            )
        raise

    if args.projection_only:
        sidecar_path = None
        reference_path = None
        immutable_paths: dict[str, Path] = {}
        reference_invalidatable = False
        try:
            (
                sidecar_path,
                reference_path,
                immutable_paths,
                reference_invalidatable,
            ) = _prepare_projection_output_roles(args, projection_preparse)
            required = {
                "--state-json": args.state_json,
                "--run-manifest": args.run_manifest,
                "--approved-topology": args.approved_topology,
                "--out-projection-sidecar": args.out_projection_sidecar,
                "--out-projection-reference": args.out_projection_reference,
            }
            missing = [name for name, value in required.items() if not value]
            if missing:
                raise ProjectionReferenceValidationError(
                    ["projection-only requires " + ", ".join(missing)]
                )
            state_path = _b1a_existing_path(args.state_json)
            run_manifest_path = _b1a_existing_path(args.run_manifest)
            topology_path = _b1a_existing_path(args.approved_topology)
            if sidecar_path is None or reference_path is None:
                raise ProjectionReferenceValidationError(
                    ["projection output roles were not established"]
                )
            (
                manifest_snapshot,
                manifest,
                approved_topology,
                state_snapshot,
            ) = _validate_b1a_projection_inputs(
                run_manifest_path=run_manifest_path,
                topology_path=topology_path,
                state_path=state_path,
            )
            immutable_paths.update({
                "state": state_snapshot.path,
                "run_manifest": manifest_snapshot.path,
                "approval": approved_topology.approval_snapshot.path,
                "lane_graph": approved_topology.lane_graph_snapshot.path,
                "topology": approved_topology.topology_snapshot.path,
                "adapter_source": Path(__file__).resolve(strict=True),
            })
            immutable_paths.update({
                str(role): path
                for role, path in manifest.resolved_paths.items()
            })
            validate_projection_output_paths(
                sidecar_path,
                reference_path,
                immutable_paths=immutable_paths,
            )
            _, _, records_hash = normalize_vehicle_records(
                state_snapshot.value, approved_topology.topology.tolerance_m
            )
            hash_context = {
                "topology_file_sha256": approved_topology.topology_snapshot.file_sha256,
                "topology_semantic_sha256": approved_topology.topology.semantic_sha256,
                "approving_manifest_sha256": approved_topology.approval_snapshot.file_sha256,
                "state_file_sha256": state_snapshot.file_sha256,
                "vehicle_records_semantic_sha256": records_hash,
            }
            result = project_vehicle_records(
                approved_topology.topology, state_snapshot.value, hash_context
            )
            publish_projection_outputs(
                workspace_root=WORKSPACE_ROOT,
                sidecar_path=sidecar_path,
                reference_path=reference_path,
                immutable_paths=immutable_paths,
                projection_ledger=result.ledger,
                run_manifest=manifest,
                run_manifest_snapshot=manifest_snapshot,
                state_snapshot=state_snapshot,
                approved_topology=approved_topology,
            )
            print(json.dumps({
                "status": "PASS", "projection_sidecar": str(sidecar_path),
                "projection_reference": str(reference_path),
            }, ensure_ascii=False))
            return
        except BaseException as exc:
            if reference_invalidatable and reference_path is not None:
                validate_projection_output_paths(
                    sidecar_path,
                    reference_path,
                    immutable_paths=immutable_paths,
                )
                reference_path.unlink(missing_ok=True)
            if isinstance(
                exc,
                (MemoryError, OSError, OverflowError, TypeError, ValueError),
            ):
                raise SystemExit(f"B1a projection-only failed: {exc}") from exc
            raise

    if not args.state_json or not args.out_action_json or not args.out_action_csv:
        parser.error("normal action mode requires --out-action-json and --out-action-csv")
    prevalidated_projection = None
    if args.b1a_required:
        required = {
            "--run-manifest": args.run_manifest,
            "--projection-reference": args.projection_reference,
            "--projection-reference-sha256": args.projection_reference_sha256,
        }
        missing = [name for name, value in required.items() if not value]
        if missing:
            parser.error("B1a required action mode requires " + ", ".join(missing))
        if re.fullmatch(r"[0-9a-f]{64}", args.projection_reference_sha256) is None:
            parser.error("--projection-reference-sha256 must be lowercase SHA-256")
        try:
            run_manifest_path = _b1a_existing_path(args.run_manifest)
            reference_path = _b1a_existing_path(args.projection_reference)
            caller_state_path = _b1a_existing_path(args.state_json)
            manifest_snapshot = load_bounded_json_snapshot(
                run_manifest_path, max_bytes=MAX_RUN_MANIFEST_BYTES
            )
            manifest = validate_run_manifest(
                manifest_snapshot.value, workspace_root=WORKSPACE_ROOT
            )
            _validate_b1a_adapter_source(manifest)
            prevalidated_projection = validate_physical_projection_reference(
                reference_path.relative_to(WORKSPACE_ROOT).as_posix(),
                workspace_root=WORKSPACE_ROOT,
                run_manifest_path=run_manifest_path.relative_to(WORKSPACE_ROOT).as_posix(),
                expected_reference_file_sha256=args.projection_reference_sha256,
            )
            if (
                manifest_snapshot.data
                != prevalidated_projection.run_manifest_snapshot.data
                or manifest_snapshot.file_sha256
                != prevalidated_projection.run_manifest_snapshot.file_sha256
            ):
                raise ProjectionReferenceValidationError(
                    ["run manifest changed during required-mode validation"]
                )
            if caller_state_path != prevalidated_projection.state_path:
                raise ProjectionReferenceValidationError(["caller state path differs from projection reference"])
        except (MemoryError, OSError, OverflowError, TypeError, ValueError) as exc:
            raise SystemExit(f"B1a required action mode failed: {exc}") from exc

    started = time.perf_counter()
    repo_root = Path(args.repo_root)
    mapping_path = Path(args.mapping_json)
    state_path = prevalidated_projection.state_path if prevalidated_projection else Path(args.state_json)
    out_json = Path(args.out_action_json)
    out_csv = Path(args.out_action_csv)
    physical_projection_input = None
    if prevalidated_projection:
        state_json, physical_projection_input = _state_json_from_b1a_projection(
            prevalidated_projection
        )
    else:
        state_json = json.loads(state_path.read_text(encoding="utf-8"))
    mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
    calibration = load_optional_json(args.calibration_json)
    tuning = load_optional_json(args.tuning_json)
    # 런타임 스위치를 config 에서 심는다. 키가 없으면 env 폴백이라 비트 동일이다.
    install_config_switches(tuning)
    # **검지 매핑은 tuning 이 이긴다** (2026-08-22).
    #
    # 러너는 생성 VBS 설정의 `RW_DETECTOR_MAPPING_PATH` 를 --detector-mapping-json 으로
    # 넘긴다. 그 값은 망 단위 상수라 팔마다 바뀌지 않는다. 그래서 tuning 에
    # `detector_mapping_json` 을 넣어도 조용히 무시됐다 — 매핑을 바꾼 팔 셋이 전부
    # 옛 매핑으로 돌았고, 상태 JSON 에 옛 경로가 찍혀 있는 걸 나중에야 발견했다.
    # 매핑은 관측 귀속을 정하는 실험 변수이므로 설정으로 갈아끼울 수 있어야 한다.
    _tuned_detector = str(tuning.get("detector_mapping_json", "") or "").strip()
    detector_mapping_path = _tuned_detector or args.detector_mapping_json
    if _tuned_detector and not Path(detector_mapping_path).is_absolute():
        detector_mapping_path = str(WORKSPACE_ROOT / detector_mapping_path)
    detector_mapping = load_optional_json(detector_mapping_path)
    # tuning 이 매핑을 지정했는데 안 열리면 **세운다**. 2026-08-26 에 config 의
    # 백슬래시 경로가 JSON 에서 캐리지리턴으로 해석돼 파일이 없어졌고,
    # load_optional_json 이 조용히 빈 dict 를 내서 map4etau_20260826 이 관측 없이
    # 92분을 완주했다 (local_observation_runtime_guard=0, TTT 가 무제어와 같음).
    # 진단의 detector_mapping_effective 는 basename 만 찍어 정상처럼 보였다.
    if _tuned_detector and not detector_mapping:
        raise SystemExit(
            "DETECTOR_MAPPING_UNREADABLE: tuning 이 지정한 매핑을 못 읽었다.\n"
            "  tuning 값 : %r\n"
            "  해석 경로 : %r\n"
            "  존재      : %s\n"
            "경로에 제어문자가 있으면 JSON 백슬래시 이스케이프다. 슬래시로 써라."
            % (_tuned_detector, detector_mapping_path,
               Path(detector_mapping_path).is_file())
        )
    # 미드블록 정지선 링크를 관측에서 뺀다(tuning `urban.midblock.exclude_links`).
    # 투영보다 먼저여야 한다 — traffic_state_from_vissim 이 이 매핑으로 큐를 귀속한다.
    detector_mapping, _midblock_meta = filter_midblock_links_from_detector_mapping(
        detector_mapping, tuning)
    calibration_override = tuning.get("calibration_override", {})
    if isinstance(calibration_override, Mapping):
        calibration = deep_update(dict(calibration), calibration_override)
    actuation = adapter_actuation_settings(calibration, tuning)
    control_interval = float(state_json.get("control_interval_sec", 60.0))
    sim_period = float(state_json.get("sim_period_sec", max(180.0, control_interval)))

    (
        StackelbergMPCController,
        DemandStep,
        ControlAction,
        _ExperimentConfig,
        TrafficState,
        segment_vsl_func,
    ) = repo_imports(repo_root)
    local_observation = bool(
        _link_counts_from_local_observation(state_json)
        and (detector_mapping or physical_projection_input is not None)
    )
    cfg = build_config(
        repo_root,
        control_interval,
        sim_period,
        args.mode,
        calibration,
        tuning,
        local_observation=local_observation,
        flagship=(args.controller in ("pstack-flagship", "wu-link")),
    )
    adapter_runtime_metadata = install_adapter_calibration_fingerprints(cfg, tuning)
    # 실제로 쓴 검지 매핑을 남긴다. 상태 JSON 의 `detector_mapping_json` 은 **러너가**
    # 쓰는 값이라 tuning 이 덮은 경우를 못 잡는다(2026-08-22 에 그걸로 팔 셋을 헛돌렸다).
    adapter_runtime_metadata["detector_mapping_effective"] = Path(detector_mapping_path).name
    adapter_runtime_metadata["detector_mapping_from_tuning"] = 1.0 if _tuned_detector else 0.0
    # basename 만 찍으면 깨진 경로가 정상처럼 보인다(2026-08-26). 해석 경로와 규모를 남긴다.
    adapter_runtime_metadata["detector_mapping_resolved_path"] = str(detector_mapping_path)
    adapter_runtime_metadata["detector_mapping_observable_link_count"] = float(
        len(detector_mapping.get("observable_links") or []))
    adapter_runtime_metadata["detector_mapping_link_to_origins_count"] = float(
        len(_mapping(detector_mapping.get("link_to_origins"))))
    from evaluation.controllers.runtime_setup import configure_runtime
    state, detector_mapping, runtime_patch_metadata = configure_runtime(
        sys.modules[__name__], cfg, tuning, mapping, state_json,
        args.previous_action_json, detector_mapping, calibration, TrafficState,
        physical_projection_input=physical_projection_input,
    )
    forecast_horizon_steps = int(cfg.mpc.horizon_steps)
    if args.controller in ("pstack-flagship", "wu-link"):
        # 러너 L1044: 리더 value-depth rollout이 horizon 밖 수요를 소비한다 —
        # forecast 길이 = horizon_steps + max(0, leader_value_depth).
        forecast_horizon_steps += max(0, int(getattr(cfg.mpc, "leader_value_depth", 0)))
    forecast = demand_from_state(
        state_json,
        cfg,
        DemandStep,
        forecast_horizon_steps,
        calibration,
        detector_mapping,
    )
    previous_path = Path(args.previous_action_json) if args.previous_action_json else Path("__missing_previous.json")
    previous = control_from_json(previous_path, cfg, ControlAction)
    observed_summary = summarize_model_state(state, cfg)
    prediction_error = prediction_error_from_previous(previous_path, observed_summary)

    metadata: dict[str, Any] = {
        "controller": (
            "StackelbergMPCController"
            if args.controller == "stackelberg"
            else "StackelbergWuMeteredController"
            if args.controller == "stackelberg-wu-metered"
            else "F1StackelbergWuMeteredController"
            if args.controller == "pstack-flagship"
            else "DistributedCoordinator"
            if args.controller == "pfo"
            else "NoControl"
            if args.controller == "no-control"
            else "DiagnosticVslRampMetering"
            if args.controller == "diagnostic-vsl-rm"
            else "DiagnosticFixedActuation"
            if args.controller.startswith("diagnostic-")
            else "WuDistributedController"
        ),
        "controller_variant": args.controller,
        "adapter_mode": args.mode,
        "controller_status": "ok",
        "sim_sec": float(state_json.get("sim_sec", 0.0)),
        "calibration_version": str(calibration.get("calibration_version", "")),
        "tuning_name": str(tuning.get("name", "")),
        "F_ramp_mode": str(actuation.get("F_ramp_mode", "")),
        "F_ramp_invalid_guard_configured": float(bool(actuation.get("F_ramp_invalid_guard_active", False))),
        "observation_mode": "detector_local_v2_storage_split" if local_observation else "global_fallback",
        "follower_solver_mode": str(cfg.mpc.follower_solver_mode),
        "local_observation_runtime_guard": float(local_observation),
        "mpc_horizon_steps": float(cfg.mpc.horizon_steps),
        "mpc_control_horizon_steps": float(cfg.mpc.control_horizon_steps),
        "mpc_max_nash_iter": float(cfg.mpc.max_nash_iter),
        "freeway_horizon_beam_width": float(getattr(cfg.freeway_follower, "horizon_beam_width", 0.0)),
        "freeway_horizon_ramp_candidate_limit": float(
            getattr(cfg.freeway_follower, "horizon_ramp_candidate_limit", 0.0)
        ),
        "freeway_horizon_vsl_candidate_limit_per_link": float(
            getattr(cfg.freeway_follower, "horizon_vsl_candidate_limit_per_link", 0.0)
        ),
    }
    metadata["run_provenance"] = build_run_provenance(
        repo_root=repo_root,
        state_json=state_json,
        state_path=state_path,
        mapping_path=mapping_path,
        detector_mapping_path=Path(args.detector_mapping_json),
        calibration_path=Path(args.calibration_json),
        tuning_path=Path(args.tuning_json) if args.tuning_json else Path("__missing_tuning.json"),
        network_path=_network_path_from_state(state_json),
    )
    if prevalidated_projection:
        metadata["physical_projection_provenance"] = _projection_provenance(
            prevalidated_projection
        )
        metadata["projection_diagnostics"] = thaw_json(
            prevalidated_projection.sidecar["projection_diagnostics"]
        )
    if forecast:
        forecast0 = forecast[0]
        demand_payload = _mapping(state_json.get("demand"))
        forecast_profile = str(demand_payload.get("demand_profile", "")).lower()
        route_bias_forecast = _mapping(_mapping(calibration.get("prediction")).get("route_bias_forecast"))
        route_bias_enabled = bool(route_bias_forecast.get("enabled", True))
        route_bias_applied = route_bias_enabled and forecast_profile in {
            "d_ramp_bias",
            "d_ramp_heavy",
            "f_ramp_bias",
            "f_ramp_heavy",
        }
        metadata.update({
            "demand_profile_forecast_profile_aware": 1.0,
            "demand_profile": forecast_profile,
            "demand_urban_west_east_ratio": float(_as_float(demand_payload.get("urban_west_east_ratio"), 1.0)),
            "demand_profile_route_bias_forecast_applied": float(route_bias_applied),
            "route_bias_forecast_target_share": float(_as_float(route_bias_forecast.get("target_share"), 0.98)),
            "forecast_freeway_FW_E_vph": float(forecast0.freeway_mainline.get("FW_E", 0.0)),
            "forecast_freeway_FW_W_vph": float(forecast0.freeway_mainline.get("FW_W", 0.0)),
            "forecast_urban_boundary_in_total_vph": float(
                sum(
                    float(forecast0.urban_boundary.get(str(link), 0.0))
                    for link in cfg.network.boundary_in_links
                )
            ),
            "forecast_ramp_arrival_total_vph": float(
                sum(float(value) for value in forecast0.ramp_arrival.values())
            ),
            "forecast_ramp_arrival_R_D_W_vph": float(forecast0.ramp_arrival.get("R_D_W", 0.0)),
            "forecast_ramp_arrival_R_D_E_vph": float(forecast0.ramp_arrival.get("R_D_E", 0.0)),
            "forecast_ramp_arrival_R_F_W_vph": float(forecast0.ramp_arrival.get("R_F_W", 0.0)),
            "forecast_ramp_arrival_R_F_E_vph": float(forecast0.ramp_arrival.get("R_F_E", 0.0)),
        })
    storage_values = [
        max(0.0, _as_float(value))
        for value in getattr(cfg.network, "urban_link_storage_veh", {}).values()
    ]
    metadata.update({
        "network_lost_time_sec": float(getattr(cfg.network, "lost_time", 0.0)),
        "network_movement_capacity_veh_h": float(getattr(cfg.network, "movement_capacity_veh_h", 0.0)),
        "network_boundary_queue_max_veh": float(getattr(cfg.network, "boundary_queue_max_veh", 0.0)),
        "network_ramp_queue_max_veh": float(getattr(cfg.network, "ramp_queue_max_veh", 0.0)),
        "network_urban_link_storage_count": float(len(storage_values)),
        "network_urban_link_storage_min_veh": float(min(storage_values)) if storage_values else 0.0,
        "network_urban_link_storage_max_veh": float(max(storage_values)) if storage_values else 0.0,
        "network_urban_link_storage_total_veh": float(sum(storage_values)),
        "network_ramp_capacity_R_D_W_veh_h": float(cfg.network.ramp_capacity_veh_h.get("R_D_W", 0.0)),
        "network_ramp_capacity_R_D_E_veh_h": float(cfg.network.ramp_capacity_veh_h.get("R_D_E", 0.0)),
        "network_ramp_capacity_R_F_W_veh_h": float(cfg.network.ramp_capacity_veh_h.get("R_F_W", 0.0)),
        "network_ramp_capacity_R_F_E_veh_h": float(cfg.network.ramp_capacity_veh_h.get("R_F_E", 0.0)),
    })
    # 램프 spillback 관측(기록 전용). 대장이 없으면 no-op.
    metadata.update(emit_ramp_feed_observation(cfg, state, state_json))
    metadata.update(adapter_runtime_metadata)
    metadata.update(runtime_patch_metadata)
    if hasattr(state, "local_observation_summary"):
        summary = state.local_observation_summary
        projection_diagnostics = summary.get("projection_diagnostics", {})
        if isinstance(projection_diagnostics, Mapping):
            metadata["projection_diagnostics"] = dict(projection_diagnostics)
            for key, value in projection_diagnostics.items():
                if isinstance(value, (int, float, bool)):
                    metadata[f"projection_{key}"] = float(value)
        # 차로보정 arm 의 온디스크 증거. `native_phase_share_scaled_count` 가 축좁힘 arm 을
        # 관측 가능하게 만드는 것과 같은 역할이다 - 이게 없으면 A/B 의 한 축이 사후 검증
        # 불가능해진다. 켜짐이면 links_corrected 가 양수, 꺼짐이면 0 이어야 한다.
        lane_correction = summary.get("lane_delay_correction")
        if isinstance(lane_correction, Mapping):
            metadata["lane_delay_correction"] = dict(lane_correction)
            metadata["lane_delay_enabled"] = float(bool(lane_correction.get("enabled", False)))
            metadata["lane_delay_links_corrected"] = float(lane_correction.get("links_corrected", 0))
            metadata["lane_delay_mean_lanes"] = float(lane_correction.get("mean_lanes_applied", 0.0))
        summary_agents = summary.get("agents", {})
        metadata["local_observation_agent_count"] = float(len(summary_agents))
        if isinstance(summary_agents, Mapping):
            flagged_agents = [
                agent
                for agent in summary_agents.values()
                if isinstance(agent, Mapping)
                and ("control_enabled" in agent or "monitoring_only" in agent)
            ]
            if flagged_agents:
                metadata["local_observation_control_agent_count"] = float(
                    sum(1 for agent in flagged_agents if bool(agent.get("control_enabled", True)))
                )
                metadata["local_observation_monitoring_agent_count"] = float(
                    sum(1 for agent in flagged_agents if bool(agent.get("monitoring_only", False)))
                )
        metadata["local_observation_total_movement_queue"] = float(
            sum(max(0.0, _as_float(v)) for v in summary.get("urban_movement_queue", {}).values())
        )
        metadata["local_observation_total_ramp_queue"] = float(
            sum(max(0.0, _as_float(v)) for v in summary.get("ramp_queue", {}).values())
        )
        storage_occupancy = summary.get("urban_link_storage_occupancy", {})
        if isinstance(storage_occupancy, Mapping):
            metadata["local_observation_total_storage_occupancy"] = float(
                sum(max(0.0, _as_float(v)) for v in storage_occupancy.values())
            )
            off_storage_links = {str(v) for v in cfg.network.off_ramp_storage_link.values()}
            metadata["local_observation_offramp_storage_occupancy"] = float(
                sum(
                    max(0.0, _as_float(value))
                    for key, value in storage_occupancy.items()
                    if str(key) in off_storage_links
                )
            )
        split_params = summary.get("split_parameters", {})
        if isinstance(split_params, Mapping):
            metadata["local_observation_internal_storage_fraction"] = float(
                split_params.get("internal_storage_fraction", 0.0)
            )
            metadata["local_observation_offramp_storage_fraction"] = float(
                split_params.get("offramp_storage_fraction", 0.0)
            )
    if prediction_error:
        metadata["prediction_audit_available"] = float(prediction_error.get("status") == "ok")
        scalar_errors = prediction_error.get("scalar_errors", {})
        if isinstance(scalar_errors, Mapping):
            total_error = scalar_errors.get("total_model_vehicles", {})
            protected_error = scalar_errors.get("protected_accumulation_veh", {})
            freeway_error = scalar_errors.get("freeway_total_veh", {})
            if isinstance(total_error, Mapping):
                metadata["prediction_total_model_vehicles_error"] = float(total_error.get("error", 0.0))
                metadata["prediction_total_model_vehicles_abs_error"] = float(total_error.get("abs_error", 0.0))
            if isinstance(protected_error, Mapping):
                metadata["prediction_protected_accumulation_abs_error"] = float(protected_error.get("abs_error", 0.0))
            if isinstance(freeway_error, Mapping):
                metadata["prediction_freeway_total_abs_error"] = float(freeway_error.get("abs_error", 0.0))
    try:
        controller = None
        if args.controller == "no-control":
            control = ControlAction.uncontrolled(cfg)
            control.diagnostics["no_control_active"] = 1.0
        elif args.controller == "diagnostic-vsl-rm":
            control = diagnostic_vsl_rm_control(cfg, ControlAction)
            metadata["diagnostic_forced_vsl_rm_active"] = 1.0
        elif args.controller == "native-fixed":
            control = native_fixed_control(cfg, ControlAction)
            metadata["native_fixed_active"] = 1.0
        elif args.controller == "diagnostic-fixed57":
            control = diagnostic_fixed57_control(cfg, ControlAction)
            metadata["diagnostic_fixed57_active"] = 1.0
        elif args.controller == "diagnostic-ramp-hold":
            control = diagnostic_ramp_hold_control(cfg, ControlAction)
            metadata["diagnostic_ramp_hold_active"] = 1.0
        elif args.controller == "diagnostic-ramp-d1364":
            control = diagnostic_ramp_d1364_control(cfg, ControlAction)
            metadata["diagnostic_ramp_d1364_active"] = 1.0
        elif args.controller == "diagnostic-ramp-d1253":
            control = diagnostic_ramp_d1253_control(cfg, ControlAction)
            metadata["diagnostic_ramp_d1253_active"] = 1.0
        elif args.controller == "diagnostic-ramp-all500":
            control = diagnostic_ramp_all500_control(cfg, ControlAction)
            metadata["diagnostic_ramp_all500_active"] = 1.0
        elif args.controller == "diagnostic-ramp-all400":
            control = diagnostic_ramp_all400_control(cfg, ControlAction)
            metadata["diagnostic_ramp_all400_active"] = 1.0
        elif args.controller == "diagnostic-ramp-all300":
            control = diagnostic_ramp_all300_control(cfg, ControlAction)
            metadata["diagnostic_ramp_all300_active"] = 1.0
        elif args.controller == "diagnostic-vsl60-only":
            control = diagnostic_vsl60_only_control(cfg, ControlAction)
            metadata["diagnostic_vsl60_only_active"] = 1.0
            metadata["suppress_signal_rows"] = 1.0
        elif args.controller == diagnostic_signal_profile.CONTROLLER:
            control = diagnostic_signal_profile.build_control(
                cfg, ControlAction, tuning, load_signal_group_actuation_plan(), WORKSPACE_ROOT)
            actuation = diagnostic_signal_profile.fixed_actuation(actuation)
            metadata["diagnostic_signal_profile_active"] = 1.0
        elif args.controller in diagnostic_profile.CONTROLLERS:
            diagnostic_profile.validate_controller(args.controller, tuning)
            control = diagnostic_profile.build_control(
                cfg, ControlAction, tuning, mapping, args.diagnostic_allowed_vsl_speeds)
            actuation = diagnostic_profile.fixed_actuation(actuation, tuning)
            metadata["diagnostic_vsl_profile_active"] = 1.0
            metadata["suppress_signal_rows"] = 1.0
        elif args.controller == "diagnostic-vsl80-only":
            control = diagnostic_vsl80_only_control(cfg, ControlAction)
            metadata["diagnostic_vsl80_only_active"] = 1.0
            metadata["suppress_signal_rows"] = 1.0
        elif args.controller == "diagnostic-vsl110":
            control = diagnostic_vsl110_control(cfg, ControlAction)
            metadata["diagnostic_vsl110_active"] = 1.0
        elif args.controller == "diagnostic-vsl100":
            control = diagnostic_vsl100_control(cfg, ControlAction)
            metadata["diagnostic_vsl100_active"] = 1.0
        elif args.controller == "diagnostic-vsl90":
            control = diagnostic_vsl90_control(cfg, ControlAction)
            metadata["diagnostic_vsl90_active"] = 1.0
        elif args.controller == "diagnostic-vsl80":
            control = diagnostic_vsl80_control(cfg, ControlAction)
            metadata["diagnostic_vsl80_active"] = 1.0
        elif args.controller == "diagnostic-vsl70":
            control = diagnostic_vsl70_control(cfg, ControlAction)
            metadata["diagnostic_vsl70_active"] = 1.0
        elif args.controller == "diagnostic-vsl60":
            control = diagnostic_vsl60_control(cfg, ControlAction)
            metadata["diagnostic_vsl60_active"] = 1.0
        elif args.controller == "diagnostic-vsl50":
            control = diagnostic_vsl50_control(cfg, ControlAction)
            metadata["diagnostic_vsl50_active"] = 1.0
        elif args.controller == "diagnostic-vsl80-original":
            control = diagnostic_vsl80_original_signal_control(cfg, ControlAction)
            metadata["diagnostic_vsl80_original_signal_active"] = 1.0
            metadata["suppress_signal_rows"] = 1.0
        elif args.controller == "diagnostic-ramp-all735-original":
            control = diagnostic_ramp_all735_original_signal_control(cfg, ControlAction)
            metadata["diagnostic_ramp_all735_original_signal_active"] = 1.0
            metadata["suppress_signal_rows"] = 1.0
        elif args.controller == "diagnostic-ramp-all360-original":
            control = diagnostic_ramp_all360_original_signal_control(cfg, ControlAction)
            metadata["diagnostic_ramp_all360_original_signal_active"] = 1.0
            metadata["suppress_signal_rows"] = 1.0
        elif args.controller == "diagnostic-signal-major90-only":
            control = diagnostic_signal_major90_only_control(cfg, ControlAction)
            metadata["diagnostic_signal_major90_only_active"] = 1.0
        elif args.controller == "diagnostic-signal-minor90-only":
            control = diagnostic_signal_minor90_only_control(cfg, ControlAction)
            metadata["diagnostic_signal_minor90_only_active"] = 1.0
        elif args.controller == "diagnostic-signal-offset60-only":
            control = diagnostic_signal_offset60_only_control(cfg, ControlAction)
            metadata["diagnostic_signal_offset60_only_active"] = 1.0
        elif args.controller == "diagnostic-signal-major62":
            control = diagnostic_signal_major62_control(cfg, ControlAction)
            metadata["diagnostic_signal_major62_active"] = 1.0
        elif args.controller == "diagnostic-signal-minor62":
            control = diagnostic_signal_minor62_control(cfg, ControlAction)
            metadata["diagnostic_signal_minor62_active"] = 1.0
        elif args.controller == "diagnostic-signal-major":
            control = diagnostic_signal_major_control(cfg, ControlAction)
            metadata["diagnostic_signal_major_active"] = 1.0
        elif args.controller == "diagnostic-signal-minor":
            control = diagnostic_signal_minor_control(cfg, ControlAction)
            metadata["diagnostic_signal_minor_active"] = 1.0
        elif args.controller == "diagnostic-signal-offset30":
            control = diagnostic_signal_offset30_control(cfg, ControlAction)
            metadata["diagnostic_signal_offset30_active"] = 1.0
        elif args.controller == "diagnostic-combined-strong":
            control = diagnostic_combined_strong_control(cfg, ControlAction)
            metadata["diagnostic_combined_strong_active"] = 1.0
        elif args.controller == "diagnostic-combined-extreme":
            control = diagnostic_combined_extreme_control(cfg, ControlAction)
            metadata["diagnostic_combined_extreme_active"] = 1.0
        elif args.controller in ("stackelberg", "wu-link"):
            controller = (
                build_priced_wu_link_controller(cfg, tuning)
                if args.controller == "wu-link"
                else StackelbergMPCController(cfg)
            )
            metadata.update(install_vissim_terminal_cost_objective(controller, cfg, tuning))
            metadata.update(
                install_price_worker_bootstrap(controller, state_json, detector_mapping)
            )
            if hasattr(controller, "decide_with_info"):
                result = controller.decide_with_info(state, forecast, previous, cfg)
                control = result.control
                metadata["leader_objective"] = float(getattr(result, "leader_objective", 0.0))
                metadata["nash_objective"] = float(getattr(getattr(result, "nash", None), "objective_value", 0.0))
                metadata.update({
                    f"meta_{k}": float(v)
                    for k, v in getattr(result, "metadata", {}).items()
                    if isinstance(v, (int, float, bool))
                })
            else:
                control = controller.decide(state, forecast, previous, cfg)
        elif args.controller == "stackelberg-wu-metered":
            # Same Stackelberg leader path as "stackelberg" but with the follower replaced by
            # WuFaithfulFollower (the new O(n)-local metering-PFO follower). The subclass only
            # overrides _make_follower_solver/_evaluate_candidate_set, so decide_with_info is
            # inherited and the call is identical. Note: the follower is NOT a DistributedCoordinator,
            # so leader output-closure keeps N_P_star at intent (no realized override) and the
            # local-observation runtime guard (which patches DistributedCoordinator) does not apply
            # because WuFaithfulFollower is natively local.
            from src.controllers.stackelberg_wu_metered import StackelbergWuMeteredController

            controller = StackelbergWuMeteredController(cfg)
            metadata.update(install_vissim_terminal_cost_objective(controller, cfg, tuning))
            if hasattr(controller, "decide_with_info"):
                result = controller.decide_with_info(state, forecast, previous, cfg)
                control = result.control
                metadata["leader_objective"] = float(getattr(result, "leader_objective", 0.0))
                metadata["nash_objective"] = float(getattr(getattr(result, "nash", None), "objective_value", 0.0))
                metadata["wu_metered_follower"] = 1.0
                metadata.update({
                    f"meta_{k}": float(v)
                    for k, v in getattr(result, "metadata", {}).items()
                    if isinstance(v, (int, float, bool))
                })
            else:
                control = controller.decide(state, forecast, previous, cfg)
        elif args.controller == "pstack-flagship":
            # NumSim flagship P-Stack(P-STACK-WU-FAITHFUL-ALLPRICE-JOINT) 이식 모드.
            # 구성·per-step 로직·사이드카는 run_pstack_flagship_decision 참조.
            control, controller, flagship_metadata = run_pstack_flagship_decision(
                cfg,
                state,
                forecast,
                previous,
                tuning,
                out_json.parent / FLAGSHIP_RUNTIME_FILENAME,
            )
            metadata.update(flagship_metadata)
        elif args.controller == "pfo":
            from src.controllers.distributed_coordinator import DistributedCoordinator

            controller = DistributedCoordinator(cfg)
            result = controller.solve(state.copy(), None, forecast, previous)
            control = result.control
            metadata["pfo_iterations"] = float(getattr(result, "iterations", 0))
            metadata["pfo_converged"] = float(bool(getattr(result, "converged", False)))
            metadata["pfo_objective"] = float(getattr(result, "objective_value", 0.0))
            metadata["pfo_residual_objective"] = float(getattr(result, "residual_objective", 0.0))
            metadata["pfo_residual_control"] = float(getattr(result, "residual_control", 0.0))
            metadata.update({
                f"meta_{k}": float(v)
                for k, v in getattr(result, "diagnostics", {}).items()
                if isinstance(v, (int, float, bool))
            })
        else:
            from src.controllers.wu_distributed import WuDistributedController

            controller = WuDistributedController(cfg, leader_enabled=(args.controller == "wu-leader"))
            result = controller.decide_with_info(state, forecast, previous)
            control = result.control
            metadata["wu_leader_enabled"] = float(args.controller == "wu-leader")
            metadata["wu_iterations"] = float(getattr(result, "iterations", 0))
            metadata["wu_converged"] = float(bool(getattr(result, "converged", False)))
            metadata["wu_coupling_residual"] = float(getattr(result, "coupling_residual", 0.0))
            metadata["wu_solver_evaluations"] = float(getattr(result, "solver_evaluations", 0))
            metadata["wu_computation_time_sec"] = float(getattr(result, "computation_time_sec", 0.0))
            metadata["wu_leader_candidates"] = float(getattr(result, "leader_candidates", 0))
            metadata["wu_leader_objective"] = float(getattr(result, "leader_objective", 0.0))
        if controller is not None and hasattr(controller, "close"):
            controller.close()
    except Exception as exc:  # Keep Vissim running; log and fall back safely.
        if args.controller in (*diagnostic_profile.CONTROLLERS, diagnostic_signal_profile.CONTROLLER):
            raise  # An invalid causal arm must not silently become fixed control.
        control = ControlAction.fixed(cfg)
        metadata["controller_status"] = "fallback_fixed"
        metadata["controller_error_type"] = type(exc).__name__
        metadata["controller_error"] = str(exc)

    if args.controller not in (*diagnostic_profile.CONTROLLERS, diagnostic_signal_profile.CONTROLLER):
        control, policy_guard_metadata = apply_vissim_policy_guards(
            control,
            cfg,
            state,
            state_json,
            actuation,
            ControlAction,
        )
        metadata.update(policy_guard_metadata)
        metadata.update(apply_actuation_guards_to_control(control, cfg, actuation))
    prediction = build_one_step_prediction(state, control, forecast, cfg, calibration)
    post_guard_tuning: Mapping[str, Any] = tuning
    if args.controller == "pstack-flagship" and not bool(
        flagship_settings(tuning).get("post_guard_pfo_baseline", False)
    ):
        # SUP_PFO가 flagship의 정식 PFO 기권 메커니즘이므로 post_guard의 PFO 기준선
        # 평가(폴백 포함)는 기본 OFF — 이중 개입 방지. tuning
        # adapter.flagship.post_guard_pfo_baseline=true로만 재활성.
        post_guard_tuning = deep_update(
            dict(tuning),
            {"adapter": {"post_guard_safety": {"pfo_baseline": {"enabled": False}}}},
        )
        metadata["flagship_post_guard_pfo_baseline_forced_off"] = 1.0
    if args.controller in (*diagnostic_profile.CONTROLLERS, diagnostic_signal_profile.CONTROLLER):
        post_guard_safety_metadata = {"diagnostic_fixed_profile_guards_bypassed": 1.0}
    else:
        control, post_guard_safety_metadata, prediction = apply_post_guard_safety_evaluation(
            control,
            cfg,
            state,
            state_json,
            forecast,
            previous,
            calibration,
            post_guard_tuning,
            actuation,
            ControlAction,
            prediction,
        )
    metadata.update(post_guard_safety_metadata)
    metadata["prediction_status"] = str(prediction.get("status", ""))
    metadata["prediction_wall_sec"] = float(prediction.get("wall_sec", 0.0))
    audit_calibration = prediction.get("audit_calibration", {})
    if isinstance(audit_calibration, Mapping):
        metadata.update({
            str(key): float(value)
            for key, value in audit_calibration.items()
            if isinstance(value, (int, float, bool))
        })
    # N4-7. offset 승격 판정은 action JSON 을 쓰기 **전에** 나와야 한다. 억눌린 의도가
    # 어디로 갔는지 그 JSON 하나로 설명되어야 하기 때문이다(intent_only 의 "기록").
    offset_verdict = offset_promotion.evaluate()
    offset_writer = offset_promotion.resolve_writer(actuation, verdict=offset_verdict)
    metadata.update(offset_promotion.action_metadata(control, offset_writer, offset_verdict))
    # 2026-09-06 미터 전달함수: 실현 가능한 유량을 JSON 을 쓰기 전에 되쓴다(게이트 밖이면 no-op).
    if args.controller not in (*diagnostic_profile.CONTROLLERS, diagnostic_signal_profile.CONTROLLER):
        apply_ramp_spillback_guard(control, cfg, state, actuation, metadata)
        real_world_ramp_meter_write_back(control, cfg, actuation, mapping, metadata, state_json=state_json, previous=previous)
    metadata["decision_wall_sec"] = round(time.perf_counter() - started, 6)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(
        json.dumps(
            control_to_json_dict(control, metadata, prediction=prediction, prediction_error=prediction_error),
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    write_action_csv(
        out_csv,
        control,
        cfg,
        mapping,
        segment_vsl_func,
        metadata,
        actuation,
        signal_group_plan_table=load_signal_group_actuation_plan(),
        offset_writer=offset_writer,
    )
    print(json.dumps({
        "status": metadata["controller_status"],
        "out_action_json": str(out_json),
        "out_action_csv": str(out_csv),
        "decision_wall_sec": metadata["decision_wall_sec"],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
